(() => {
"use strict";
const DATA=JSON.parse(document.querySelector("#homepage-data").textContent);
const MIGSRC=DATA.migration.from_sources;
const TRB=DATA.migration.base_url,TRK=DATA.migration.api_key_env;
const escH=t=>t.replace(/&/g,"&amp;").replace(/</g,"&lt;");
function migCode(lang,src){const o=MIGSRC[src];const D=t=>`<span class="del">- ${escH(t)}</span>`,A=t=>`<span class="add">+ ${escH(t)}</span>`,L=t=>`  ${escH(t)}\n`,C=t=>`<span class="cm">  ${escH(t)}</span>\n`;
 if(lang==="py")return L("from openai import OpenAI")+L("import os")+"\n"+L("client = OpenAI(")+D(`    base_url="${o.b}",`)+D(`    api_key=os.environ["${o.k}"],`)+A(`    base_url="${TRB}",`)+A(`    api_key=os.environ["${TRK}"],`)+L(")")+"\n"+L("response = client.chat.completions.create(")+L('    model="z-ai/glm-5.3-flash",')+L('    messages=[{"role": "user", "content": "Hello"}],')+C('    # optional: extra_body={"provider": {"min_privacy": "confidential"}}')+L(")");
 if(lang==="ts")return L('import OpenAI from "openai";')+"\n"+L("const client = new OpenAI({")+D(`  baseURL: "${o.b}",`)+D(`  apiKey: process.env.${o.k},`)+A(`  baseURL: "${TRB}",`)+A(`  apiKey: process.env.${TRK},`)+L("});")+"\n"+L("const res = await client.chat.completions.create({")+L('  model: "z-ai/glm-5.3-flash",')+L('  messages: [{ role: "user", content: "Hello" }],')+C('  // optional: provider: { min_privacy: "zdr" }')+L("});");
 return D(`curl ${o.b}/chat/completions \\`)+D(`  -H "Authorization: Bearer $${o.k}" \\`)+A(`curl ${TRB}/chat/completions \\`)+A(`  -H "Authorization: Bearer $${TRK}" \\`)+L('  -H "Content-Type: application/json" \\')+L(`  -d '{"model": "z-ai/glm-5.3-flash",`)+L(`       "messages": [{"role": "user", "content": "Hello"}]}'`);}
const AGENT=DATA.migration.agent_prompt;

const $ = (selector, root=document) => root.querySelector(selector);
const $$ = (selector, root=document) => [...root.querySelectorAll(selector)];
// Share the existing first-party acquisition pipeline. Only event names leave
// the page; search terms, model IDs, clipboard text and properties remain local.
function track(name, properties={}) {
 document.dispatchEvent(new CustomEvent('trustedrouter:analytics', {detail:{name, properties}}));
 if(navigator.globalPrivacyControl || navigator.doNotTrack==='1')return;
 Promise.resolve().then(()=>fetch('/analytics/events',{
  method:'POST',headers:{'Content-Type':'application/json'},
  body:JSON.stringify({event:name}),credentials:'same-origin',keepalive:true,
 })).catch(()=>{}); // Telemetry must never interrupt navigation or interaction.
}
let feedbackTimer;
function feedback(message) {
 const el=$('.copy-feedback'); el.textContent=message;
 clearTimeout(feedbackTimer); feedbackTimer=setTimeout(()=>el.textContent='',2400);
}
async function copyText(text, button) {
 button.disabled=true;
 const original=button.innerHTML;
 const originalLabel=button.getAttribute('aria-label');
 try {
  await navigator.clipboard.writeText(text);
  if(button.classList.contains('icon-button')){
   button.innerHTML='<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m5 12 4 4L19 6"/></svg>';
   button.setAttribute('aria-label','Copied');
  }else button.textContent='Copied';
  feedback('Copied to clipboard');
  setTimeout(()=>{button.innerHTML=original;button.disabled=false;if(originalLabel)button.setAttribute('aria-label',button.title||originalLabel);},1600); return true;
 } catch {
  button.disabled=false;
  feedback('Clipboard unavailable. Select the text and copy it manually.'); return false;
 }
}
$$('.trc .fl button').forEach(button=>button.addEventListener('click',()=>{
 $$('.trc .fl button').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
 $$('.trc tbody').forEach(t=>t.hidden=t.dataset.f!==button.dataset.f);
 const count=$$('.trc tbody:not([hidden]) tr').length;
 $('.trc .cnt').textContent=button.dataset.f==='all'?`Featured · ${count} of ${DATA.catalog_total}`:`${button.textContent.trim()} · ${count} shown`;
 track('home.catalog_filter',{filter:button.textContent.toLowerCase()});
}));
$$('[data-alias]').forEach(button=>button.addEventListener('click',async()=>{
 if(await copyText(button.dataset.alias,button)){
  feedback('Copied '+button.dataset.alias);
  track('home.alias_copied',{alias:button.dataset.alias});
 }
}));
let lang='py', source='openai';
const migration=$('.trm'), pre=$('.mcode');
function renderCode(){
 $$('.tab',migration).forEach(tab=>{const selected=tab.dataset.lang===lang;tab.setAttribute('aria-selected',String(selected));tab.tabIndex=selected?0:-1;});
 $$('.from button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.src===source)));
 $('.from').hidden=lang==='agent';
 pre.setAttribute('aria-labelledby','code-tab-'+lang);
 if(lang==='agent'){pre.className='mcode prompt';pre.textContent=AGENT;}
 else{pre.className='mcode';pre.innerHTML=migCode(lang,source);}
 $('.pf .hint').textContent=lang==='agent'?DATA.migration.agent_hint:'';
 $('.pf .hint').hidden=lang!=='agent';
 $('[data-copycode]').setAttribute('aria-label',lang==='agent'?'Copy agent prompt':'Copy code');
 $('[data-copycode]').title=lang==='agent'?'Copy agent prompt':'Copy code';
}
function setLang(value){lang=value;renderCode();track('home.migration_tab',{tab:value,from:source});}
$$('.tab').forEach((tab,index,tabs)=>{
 tab.addEventListener('click',()=>setLang(tab.dataset.lang));
 tab.addEventListener('keydown',e=>{
  let next;
  if(e.key==='ArrowRight')next=(index+1)%tabs.length;
  if(e.key==='ArrowLeft')next=(index-1+tabs.length)%tabs.length;
  if(e.key==='Home')next=0;if(e.key==='End')next=tabs.length-1;
  if(next!==undefined){e.preventDefault();setLang(tabs[next].dataset.lang);tabs[next].focus();}
 });
});
$$('.from button').forEach(button=>button.addEventListener('click',()=>{source=button.dataset.src;renderCode();track('home.migration_tab',{tab:lang,from:source});}));
$('[data-copy]').addEventListener('click',async e=>{if(await copyText(TRB,e.currentTarget))track('home.base_url_copied');});
$('[data-copycode]').addEventListener('click',async e=>{
 const clean=pre.cloneNode(true);$$('.del',clean).forEach(n=>n.remove());$$('.add',clean).forEach(n=>n.append('\n'));
 const text=lang==='agent'?AGENT:clean.textContent.split('\n').map(line=>line.replace(/^[+ ] /,'')).join('\n');
 if(await copyText(text,e.currentTarget))track(lang==='agent'?'home.agent_prompt_copied':'home.code_copied',{tab:lang,from:source});
});
renderCode();
const labs=$('.trh .labs');let keyboardInput=false;
document.addEventListener('keydown',()=>{keyboardInput=true;},true);document.addEventListener('pointerdown',()=>{keyboardInput=false;},true);
if(labs){labs.addEventListener('focusin',()=>{labs.classList.toggle('paused',keyboardInput);});labs.addEventListener('focusout',()=>{labs.classList.remove('paused');});}
const tooltip=document.createElement('div');tooltip.className='page-tooltip';tooltip.id='page-tooltip';tooltip.role='tooltip';tooltip.hidden=true;document.body.append(tooltip);
let tipOwner;
function hideTip(){tooltip.hidden=true;tipOwner?.removeAttribute('aria-describedby');tipOwner=null;}
function showTip(element){tipOwner=element;tooltip.textContent=element.dataset.tip;tooltip.hidden=false;element.setAttribute('aria-describedby',tooltip.id);const r=element.getBoundingClientRect(),t=tooltip.getBoundingClientRect();tooltip.style.left=Math.max(12,Math.min(r.left,innerWidth-t.width-12))+'px';tooltip.style.top=(r.top>t.height+16?r.top-t.height-8:r.bottom+8)+'px';}
$$('[data-tip]').forEach(element=>{
 element.addEventListener('pointerenter',()=>showTip(element));element.addEventListener('pointerleave',()=>{if(document.activeElement!==element)hideTip();});element.addEventListener('focus',()=>showTip(element));element.addEventListener('blur',hideTip);element.addEventListener('click',()=>showTip(element));
});
document.addEventListener('keydown',e=>{if(e.key==='Escape')hideTip();});
document.addEventListener('pointerdown',e=>{if(tipOwner&&!tipOwner.contains(e.target))hideTip();});
addEventListener('scroll',hideTip,{passive:true});addEventListener('resize',hideTip);
$$('#faq details').forEach((el,index)=>{
 let wasOpen=el.open;
 el.addEventListener('toggle',()=>{
  if(el.open&&!wasOpen)track('home.faq_opened',{question_index:index});
  wasOpen=el.open;
 });
});
$$('.trc .m a').forEach(a=>a.addEventListener('click',()=>track('home.catalog_row_clicked',{model_id:a.href.split('/models/')[1]})));
// Shared auth-aware chrome replaces signed-in links; delegate so tracking survives.
function trackHomepageCta(event){
 const a=event.target.closest('.button-primary[href="/console/api-keys"]:not(.signin)');
 if(a)track('home.cta_clicked',{module:a.closest('#get-started')?'closing':a.closest('#migrate')?'migration':'hero',cta:'api_key'});
}
document.addEventListener('click',trackHomepageCta);

})();
