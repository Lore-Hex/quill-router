"use strict";
/* TrustedRouter marketing page — sign-in modal + MetaMask SIWE flow.
 *
 * No Alpine. Plain DOM. The dashboard is now thin marketing only; the
 * console lives at /console/* as server-rendered pages.
 *
 * Responsibilities:
 *   1. Open/close the <dialog id="signinModal"> on Sign-in clicks.
 *   2. Auto-open the modal when the URL carries `?reason=signin` (set by
 *      the console redirect when there's no session cookie).
 *   3. Drive the MetaMask SIWE handshake against /v1/auth/wallet/*.
 */
function requestedSigninTarget() {
    const value = new URLSearchParams(location.search).get("next");
    if (!value || !value.startsWith("/") || value.startsWith("//") || value.includes("\\")) {
        return null;
    }
    const target = new URL(value, location.origin);
    if (target.origin !== location.origin)
        return null;
    return `${target.pathname}${target.search}${target.hash}`;
}
function applySigninTarget() {
    const target = requestedSigninTarget();
    if (!target)
        return;
    document.querySelectorAll("#signinModal a[data-provider]").forEach((link) => {
        const url = new URL(link.href, location.origin);
        url.searchParams.set("next", target);
        link.href = `${url.pathname}${url.search}`;
    });
    if (target.startsWith("/auth?") || target.startsWith("/v1/auth?")) {
        const creditNote = document.getElementById("signinCreditNote");
        if (creditNote) {
            creditNote.textContent =
                "Accounts created for this app start at $0. After sign in, add credits and choose the maximum this app may spend.";
        }
    }
}
function moneyFromMicrodollars(value) {
    if (value === null || value === undefined || value === "")
        return "$0.00";
    const raw = typeof value === "number" ? String(Math.trunc(value)) : String(value);
    let micros = BigInt(raw);
    const negative = micros < 0n;
    if (negative)
        micros = -micros;
    const whole = micros / 1000000n;
    const fraction = micros % 1000000n;
    if (fraction === 0n)
        return (negative ? "-$" : "$") + whole.toString() + ".00";
    const frac = fraction.toString().padStart(6, "0").replace(/0+$/, "");
    return (negative ? "-$" : "$") + whole.toString() + "." + frac;
}
function openSigninModal() {
    const dialog = document.getElementById("signinModal");
    if (!dialog)
        return;
    if (typeof dialog.showModal === "function" && !dialog.open) {
        dialog.showModal();
    }
}
function trackFunnelEvent(event) {
    void fetch("/analytics/events", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ event }),
        credentials: "same-origin",
        keepalive: true,
    }).catch(() => {
        /* measurement is best-effort and must never interrupt sign-in */
    });
}
function trackEngagedLanding() {
    let sent = false;
    const sendWhenVisible = () => {
        if (sent || document.visibilityState !== "visible")
            return;
        sent = true;
        document.removeEventListener("visibilitychange", sendWhenVisible);
        trackFunnelEvent("landing_engaged");
    };
    window.setTimeout(() => {
        sendWhenVisible();
        if (!sent) {
            document.addEventListener("visibilitychange", sendWhenVisible);
        }
    }, 1500);
}
// Swap a click-to-load video facade for the real player.
//
// The facade exists so the homepage makes NO third-party request until the
// visitor asks for one. A page whose claim is "we cannot read your requests"
// should not hand Google a pageview to render. We therefore load the
// privacy-enhanced host (youtube-nocookie.com), and only on an explicit press.
function loadVideoEmbed(facade) {
    const videoId = facade.dataset.videoId;
    if (!videoId || facade.classList.contains("is-loaded")) {
        return;
    }
    const start = Number.parseInt(facade.dataset.videoStart ?? "", 10);
    const params = new URLSearchParams({ autoplay: "1", rel: "0" });
    if (Number.isFinite(start) && start > 0) {
        params.set("start", String(start));
    }
    const iframe = document.createElement("iframe");
    iframe.src = `https://www.youtube-nocookie.com/embed/${encodeURIComponent(videoId)}?${params}`;
    iframe.title = facade.dataset.videoTitle || "TrustedRouter explainer video";
    iframe.allow = "accelerometer; autoplay; encrypted-media; picture-in-picture";
    iframe.referrerPolicy = "strict-origin-when-cross-origin";
    iframe.setAttribute("allowfullscreen", "");
    facade.classList.add("is-loaded");
    facade.replaceChildren(iframe);
    facade.removeAttribute("role");
    facade.removeAttribute("tabindex");
    facade.removeAttribute("aria-label");
}
async function copyCode(button) {
    const targetId = button.dataset.copyTarget;
    const target = targetId ? document.getElementById(targetId) : null;
    const text = target?.textContent?.trim();
    if (!text || !navigator.clipboard || !window.isSecureContext)
        return;
    const original = button.textContent || "Copy";
    try {
        await navigator.clipboard.writeText(text);
        button.textContent = "Copied";
        button.setAttribute("aria-live", "polite");
    }
    catch {
        button.textContent = "Copy failed";
    }
    window.setTimeout(() => {
        button.textContent = original;
    }, 1600);
}
function setSigninError(message) {
    const el = document.getElementById("signinError");
    if (!el)
        return;
    if (message) {
        el.textContent = message;
        el.removeAttribute("hidden");
    }
    else {
        el.textContent = "";
        el.setAttribute("hidden", "");
    }
}
async function startMetaMaskSignin() {
    setSigninError("");
    const ethereum = window.ethereum;
    if (!ethereum) {
        setSigninError("MetaMask is not installed in this browser. Try Google or GitHub.");
        return;
    }
    let address;
    try {
        const accounts = (await ethereum.request({ method: "eth_requestAccounts" }));
        if (!Array.isArray(accounts) || !accounts[0]) {
            setSigninError("No wallet account was returned. Try again.");
            return;
        }
        address = accounts[0];
    }
    catch {
        setSigninError("Wallet connection was rejected.");
        return;
    }
    const challenge = await postJSON("/v1/auth/wallet/challenge", { address });
    if (!challenge?.data?.message) {
        setSigninError("Unable to start sign-in. Please try again.");
        return;
    }
    let signature;
    try {
        signature = (await ethereum.request({
            method: "personal_sign",
            params: [challenge.data.message, address],
        }));
    }
    catch {
        setSigninError("Sign-in was cancelled.");
        return;
    }
    const verify = await postJSON("/v1/auth/wallet/verify", {
        address,
        signature,
        nonce: challenge.data.nonce,
    });
    if (!verify?.data?.redirect) {
        setSigninError("Verification failed. The nonce may have expired.");
        return;
    }
    location.href = requestedSigninTarget() ?? verify.data.redirect;
}
async function postJSON(path, body) {
    try {
        const res = await fetch(path, {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify(body),
            credentials: "same-origin",
        });
        if (!res.ok)
            return null;
        return (await res.json());
    }
    catch {
        return null;
    }
}
// Read the `tr_signed_in=1` companion cookie set alongside the HttpOnly
// session cookie. The marketing chrome (static/dashboard.js + the
// _base.html "Sign in" / "Get an API key" buttons) uses this to know
// whether to render the auth-aware version of the nav. Returning `true`
// when the cookie is present is a UI hint only — actual auth happens via
// the HttpOnly `tr_session` cookie, which is sent automatically on every
// request to /console/*. So a stale `tr_signed_in=1` cookie can only
// cause a wasted click ("Open console" → 302 to /?reason=signin) not an
// auth bypass.
function hasSignedInHint() {
    return document.cookie
        .split(";")
        .map((c) => c.trim())
        .some((c) => c === "tr_signed_in=1");
}
// Swap the marketing-chrome "Sign in" + "Get an API key" buttons for an
// "Open console" link when the user is signed in. Fixes the 2026-05-23
// Gabriella bug where a logged-in user clicked Models → saw "Sign in"
// → assumed they were signed out → OAuth'd a second time.
function applyAuthAwareChrome() {
    if (!hasSignedInHint())
        return;
    document.querySelectorAll('[data-action="open-signin"]').forEach((el) => {
        // The marketing chrome has two of these:
        //   header nav: <button>Sign in</button>
        //   hero CTA:   <button>Get an API key</button>
        // For a signed-in user, both should become "Open console" links.
        const replacement = document.createElement("a");
        replacement.href = "/console/api-keys";
        replacement.className = el.className;
        replacement.textContent =
            el.textContent && el.textContent.trim().toLowerCase().includes("api key")
                ? "Open console"
                : "Console";
        el.replaceWith(replacement);
    });
}
function init() {
    applyAuthAwareChrome();
    applySigninTarget();
    trackEngagedLanding();
    document.addEventListener("click", (event) => {
        const target = event.target;
        if (!target)
            return;
        const opener = target.closest('[data-action="open-signin"]');
        if (opener) {
            event.preventDefault();
            trackFunnelEvent("sign_in_opened");
            openSigninModal();
            return;
        }
        const copyButton = target.closest('[data-action="copy-code"]');
        if (copyButton) {
            event.preventDefault();
            void copyCode(copyButton);
            return;
        }
        const metamask = target.closest('[data-action="metamask-signin"]');
        if (metamask) {
            event.preventDefault();
            void startMetaMaskSignin();
        }
        const videoFacade = target.closest('[data-action="load-video"]');
        if (videoFacade) {
            event.preventDefault();
            loadVideoEmbed(videoFacade);
            return;
        }
        const regionLi = target.closest(".region-list li[data-region-id]");
        if (regionLi && regionLi.dataset.regionId) {
            selectRegion(regionLi.dataset.regionId);
        }
    });
    document.addEventListener("keydown", (event) => {
        if (event.key !== "Enter" && event.key !== " ")
            return;
        const target = event.target;
        const regionLi = target && target.closest
            ? target.closest(".region-list li[data-region-id]")
            : null;
        if (regionLi && regionLi.dataset.regionId) {
            event.preventDefault();
            selectRegion(regionLi.dataset.regionId);
            return;
        }
        // The video facade is a role="button", so it must answer Enter/Space too.
        const videoFacade = target && target.closest
            ? target.closest('[data-action="load-video"]')
            : null;
        if (videoFacade) {
            event.preventDefault();
            loadVideoEmbed(videoFacade);
        }
    });
    // Don't auto-pop the sign-in modal on `?reason=signin` if the user is
    // already signed in — that'd be the same kind of "you're signed out"
    // false-alarm that triggered Gabriella's second OAuth roundtrip.
    if (location.search.includes("reason=signin") && !hasSignedInHint()) {
        openSigninModal();
    }
}
// Highlight a region: clears any previous selection on both list +
// SVG markers, then sets `is-selected` on the matching pair. Clicking
// the same region a second time toggles it off so the list returns to
// neutral.
function selectRegion(id) {
    const stage = document.querySelector("[data-regions-stage]");
    if (!stage)
        return;
    const li = stage.querySelector(`.region-list li[data-region-id="${id}"]`);
    const marker = stage.querySelector(`.region-marker[data-region-id="${id}"]`);
    if (!li || !marker)
        return;
    const wasSelected = li.classList.contains("is-selected");
    stage.querySelectorAll(".region-list li.is-selected, .region-marker.is-selected").forEach((el) => el.classList.remove("is-selected"));
    if (!wasSelected) {
        li.classList.add("is-selected");
        marker.classList.add("is-selected");
    }
}
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
}
else {
    init();
}
window.moneyFromMicrodollars = moneyFromMicrodollars;
