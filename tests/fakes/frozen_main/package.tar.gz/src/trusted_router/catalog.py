from __future__ import annotations

from dataclasses import replace
from datetime import datetime

from trusted_router.catalog_capabilities import (
    manifest_supported_parameters,
    provider_extension_parameters,
    union_supported_parameters,
)
from trusted_router.catalog_data import (  # noqa: F401 - re-exported for back-compat
    _EMBEDDING_SPECS,
    _MODEL_PROVIDER_PRIVACY_OVERRIDES,
    _PROVIDER_DISPLAY_ORDER,
    _PROVIDER_SERVED_MODEL_ALLOWLIST,
    _PROVIDER_UNSERVED_CREDITS_MODELS,
    _UNSERVED_CREDITS_MODELS,
    ADVISOR_CATALOG_MODEL_ORDERS,
    ADVISOR_MODEL_ID,
    ARCHIMEDES_1_0_MODEL_ID,
    ARISTOTLE_1_0_MODEL_ID,
    ARISTOTLE_1_1_MODEL_ID,
    ARISTOTLE_2_0_MODEL_ID,
    ARISTOTLE_MODEL_ID,
    ATHENA_1_0_MODEL_ID,
    ATHENA_2_0_MODEL_ID,
    ATHENA_MODEL_ID,
    AUTO_MODEL_ID,
    CANONICAL_ORCHESTRATION_MODEL_ID,
    CHEAP_MODEL_ID,
    CONFIDENTIAL_MODEL_ID,
    DECIDE_PATH,
    DECIDE_PATH_ALIASES,
    DEEPSEEK_V4_PRO_0423_MODEL_ID,
    DEEPSEEK_V4_PRO_0813_MODEL_ID,
    DEFAULT_AUTO_MODEL_ORDER,
    E2E_MODEL_ID,
    EU_FOCUSED_PROVIDER_ORDER,
    EU_MODEL_ID,
    FAST_MODEL_ID,
    FREE_MODEL_ID,
    FUSION_CODE_MODEL_ID,
    FUSION_MODEL_ID,
    GATEWAY_PREPAID_PROVIDER_SLUGS,
    IRIS_1_0_MODEL_ID,
    IRIS_2_0_MODEL_ID,
    IRIS_3_0_MODEL_ID,
    IRIS_CODE_1_0_MODEL_ID,
    IRIS_CODE_MODEL_ID,
    IRIS_MODEL_ID,
    LIBERTY_1_0_1M_MODEL_ID,
    LIBERTY_1_0_1M_MODEL_ORDER,
    LIBERTY_1_0_MODEL_ID,
    LIBERTY_1_0_MODEL_ORDER,
    LIBERTY_2_0_MODEL_ID,
    LIBERTY_3_0_MODEL_ID,
    MAPREDUCE_CATALOG_MODEL_ORDER,
    MAPREDUCE_MODEL_ID,
    META_MODEL_IDS,
    MISTRAL_LARGE_MODEL_ID,
    MONITOR_MODEL_ID,
    NAMED_DECISION_MODEL_PROVIDERS,
    NAMED_DECISION_MODELS,
    NATIVE_DECISION_MODEL_IDS,
    NATIVE_DECISION_MODEL_PROVIDERS,
    OPEN_PATCHER_A1_MODEL_ID,
    OPEN_PATCHER_FAST1_MODEL_ID,
    OPEN_PATCHER_G1_MODEL_ID,
    OPEN_PATCHER_G2_MODEL_ID,
    OPEN_PATCHER_G3_MODEL_ID,
    OPEN_PATCHER_S1_MODEL_ID,
    OPEN_PATCHER_S2_MODEL_ID,
    OPEN_PATCHER_S3_MODEL_ID,
    ORCHESTRATION_LEGACY_ALIAS_MODEL_IDS,
    ORCHESTRATION_PRIMITIVE_BY_MODEL_ID,
    ORCHESTRATION_PRIMITIVE_MODEL_IDS,
    ORCHESTRATION_PRIMITIVE_NAMES,
    ORCHESTRATION_ROLLING_ALIAS_MODEL_IDS,
    PARASAIL_LIBERTY_2_0_MODEL_ID,
    PLATO_1_0_MODEL_ID,
    PLATO_3_0_MODEL_ID,
    PLATO_4_0_MODEL_ID,
    PLATO_MODEL_ID,
    PLATO_PRO_1_0_MODEL_ID,
    PLATO_PRO_2_0_MODEL_ID,
    PLATO_PRO_MODEL_ID,
    PRIVACY_TIER_ALIASES,
    PRIVACY_TIER_CONFIDENTIAL,
    PRIVACY_TIER_LABELS,
    PRIVACY_TIER_NO_STORE,
    PRIVACY_TIER_STANDARD,
    PRIVACY_TIER_ZERO_RETENTION,
    PRIVATE_PROXY_MODEL_TARGETS,
    PROMETHEUS_1_0_1M_MODEL_ID,
    PROMETHEUS_1_0_MODEL_ID,
    PROMETHEUS_2_0_MODEL_ID,
    PROMETHEUS_3_0_MODEL_ID,
    PROMETHEUS_4_0_MODEL_ID,
    PROMETHEUS_CODE_1_0_MODEL_ID,
    PROMETHEUS_CODE_MODEL_ID,
    PROMETHEUS_MODEL_ID,
    PROVIDER_JURISDICTION_US,
    PROVIDERS,
    ROUTING_MODEL_ALIAS_TARGETS,
    ROUTING_MODEL_MIN_PRIVACY_TIERS,
    SELECTOR_CATALOG_MODEL_ORDER,
    SELECTOR_MODEL_ID,
    SOCRATES_1_0_MODEL_ID,
    SOCRATES_1_1_MODEL_ID,
    SOCRATES_2_0_MODEL_ID,
    SOCRATES_3_0_MODEL_ID,
    SOCRATES_ADVISOR_MODEL_ORDER,
    SOCRATES_CATALOG_MODEL_ORDER,
    SOCRATES_MODEL_ID,
    SOCRATES_PRO_1_0_MODEL_ID,
    SOCRATES_PRO_MODEL_ID,
    SOCRATES_PRO_PLUS_1_0_MODEL_ID,
    SOCRATES_PRO_PLUS_MODEL_ID,
    SOCRATES_WORKER_MODEL_ORDER,
    SUBAGENT_MODEL_ID,
    SYNTH_BUDGET_MODEL_ORDER,
    SYNTH_CODE_BUDGET_1_MODEL_ORDER,
    SYNTH_CODE_BUDGET_MODEL_ORDER,
    SYNTH_CODE_FRONTIER_MODEL_ORDER,
    SYNTH_CODE_MODEL_ID,
    SYNTH_CODE_QUALITY_1_MODEL_ORDER,
    SYNTH_CODE_QUALITY_MODEL_ORDER,
    SYNTH_FRONTIER_1_MODEL_ORDER,
    SYNTH_FRONTIER_MINI_MODEL_ORDER,
    SYNTH_FRONTIER_MODEL_ORDER,
    SYNTH_IRIS_1_MODEL_ORDER,
    SYNTH_IRIS_2_MODEL_ORDER,
    SYNTH_IRIS_3_MODEL_ORDER,
    SYNTH_MODEL_ID,
    SYNTH_PROMETHEUS_1_MODEL_ORDER,
    SYNTH_PROMETHEUS_2_MODEL_ORDER,
    SYNTH_PROMETHEUS_3_MODEL_ORDER,
    SYNTH_QUALITY_1M_MODEL_ORDER,
    SYNTH_QUALITY_MODEL_ORDER,
    TREV_1_0_MODEL_ID,
    US_PROVIDER_ONLY_MODEL_IDS,
    ZDR_MODEL_ID,
    ZEUS_1_0_MINI_MODEL_ID,
    ZEUS_1_0_MODEL_ID,
    ZEUS_2_0_MODEL_ID,
    ZEUS_3_0_MODEL_ID,
    ZEUS_CODE_1_0_MODEL_ID,
    ZEUS_CODE_MODEL_ID,
    ZEUS_MODEL_ID,
    Model,
    ModelDocumentation,
    ModelEndpoint,
    ModelProviderPrivacyOverride,
    Provider,
    _EmbeddingSpec,
    decide_url,
    offers_chat,
)
from trusted_router.catalog_energy import (
    GREEN_MODEL_ID,
    provider_has_renewable_inference,
    renewable_provider_slugs,
)
from trusted_router.catalog_ingest import (  # noqa: F401 - used by import-time build below
    _AUTHOR_TO_PROVIDER_SLUG,
    _INGEST_PATH,
    _PROVIDER_DEPRECATED_UPSTREAM_MODELS,
    _PROVIDER_MODELS_DIR,
    _author_provider,
    _build_endpoints,
    _embedding_models,
    _endpoint,
    _filter_unserved_provider_endpoints,
    _ingested_models_and_endpoints,
    _is_provider_deprecated_model,
    _supplemental_provider_models_and_endpoints,
)

# Privacy tiers + routing candidate selection were split into dedicated
# modules (#38); re-exported here so `from trusted_router.catalog import ...`
# keeps working for every existing caller.
from trusted_router.catalog_privacy import (  # noqa: F401 - re-exported for back-compat
    endpoint_confidential_compute,
    endpoint_e2ee,
    endpoint_meets_privacy_requirement,
    endpoint_privacy_tier,
    endpoint_provider_policy,
    endpoint_provider_policy_url,
    endpoint_stores_content,
    endpoint_zero_data_retention,
    endpoint_zero_data_retention_scope,
    model_provider_policy,
    model_provider_policy_url,
    model_provider_privacy_tier,
    model_provider_zero_data_retention,
    provider_confidential_inference,
    provider_privacy_tier,
)
from trusted_router.catalog_registry import (  # noqa: F401 - built there, re-exported
    MODEL_ENDPOINTS,
    MODELS,
)
from trusted_router.catalog_usage_policy import provider_usage_estimation_policy
from trusted_router.image_generation import FIXED_IMAGE_PRICES_MICRODOLLARS
from trusted_router.money import (
    microdollars_per_million_tokens_to_token_decimal,
    microdollars_to_decimal,
)
from trusted_router.polyphemus import MODEL_ID as POLYPHEMUS_MODEL_ID
from trusted_router.polyphemus import SELECTOR_PROMPT_MICRODOLLARS_PER_MILLION
from trusted_router.pricing import (  # noqa: F401 - re-exported for back-compat
    _CACHE_READ_PRICE_MULTIPLIER,
    _CACHE_WRITE_PRICE_MULTIPLIER,
    _DEFAULT_CACHE_READ_MULTIPLIER,
    _DEFAULT_CACHE_WRITE_MULTIPLIER,
    _PRICE_FLOOR_MICRODOLLARS_PER_M,
    _PRICE_MARKUP_RATIO,
    ModelPricingKwargs,
    PriceTier,
    _as_positive_int,
    _customer_price,
    _customer_price_from_dollars_per_token,
    _flat_tier,
    _priced,
    _provider_manifest_price_cost,
    _provider_manifest_price_scale,
    _provider_manifest_price_tiers,
    _read_pricing_tiers,
    cache_token_prices_microdollars,
    customer_fixed_price_microdollars,
    select_price_tier,
)
from trusted_router.provider_lifecycle import (
    provider_model_retired,
    provider_price_microdollars,
)
from trusted_router.provider_locations import inference_location_metadata, provider_geography
from trusted_router.provider_precision import endpoint_precision_metadata, endpoint_quantization
from trusted_router.request_capabilities import (
    endpoint_capabilities,
    model_capabilities,
)
from trusted_router.routing_candidates import (  # noqa: F401 - re-exported for back-compat
    FAST_MODEL_ORDER,
    InvalidAutoModelOrder,
    _is_regular_chat_model,
    _meta_route_kind,
    _models_for_ids,
    _price_sort_key,
    _privacy_candidate_models,
    auto_candidate_models,
    cheap_candidate_models,
    e2e_candidate_models,
    eu_candidate_models,
    fast_candidate_models,
    free_candidate_models,
    meta_candidate_models,
    monitor_candidate_models,
    socrates_candidate_models,
    validate_auto_model_order,
    zdr_candidate_models,
)

# Uniform pricing: customer pays cost + 5.5%, floor $0.01/M tokens. Same
# value goes into both `prompt_price_*` and `published_*` — TR no longer
# runs the 1¢/M "discount theater". The floor catches free upstream tiers
# so the catalog never advertises $0/M to end users; $0.01/M is ~10×
# margin over real per-request infra cost (~$0.00001/req on a typical
# 10K-token call), recovered via 10K-tokens × $0.01/M = $0.0001/req.


# ---------------------------------------------------------------------------
# Prompt-cache pricing
#
# The attested gateway reports cache_read_input_tokens /
# cache_creation_input_tokens at settle. Cached tokens are billed as a
# multiple of the endpoint's (already marked-up) prompt price, so the
# uniform x1.055 margin structure is preserved: provider charges
# cost x multiplier, we bill customer_price x multiplier.
#
# Multipliers mirror published provider pricing as of 2026-06:
#   anthropic: cache read 0.1x, 5-minute cache write 1.25x
#              (docs.anthropic.com/en/docs/build-with-claude/prompt-caching)
#   openai:    cached input 0.5x for the gpt-4o family; newer families
#              are CHEAPER (0.1x), so 0.5x is the safe-side bound that
#              never bills below our upstream cost. Tighten per-model
#              when the pricing scrapers track cached rates.
#   gemini/vertex: cached content 0.25x.
# Providers absent from the read table get NO discount (1.0x) until
# their cached pricing is verified — overcharging a discount we can't
# confirm is the safe failure mode for margin, and those providers
# rarely report cache fields anyway. Only Anthropic reports cache
# WRITES; the 1.25x default keeps any future writer safe-side too.


# Vertex is intentionally excluded until TR's GCP project gets the
# Anthropic-on-Vertex / Gemini-on-Vertex quota approvals.

# Providers with a direct prepaid implementation in the attested
# quill-cloud-proxy llm_multi gateway. BYOK endpoints may exist for any
# keyed provider, but Credits endpoints must stay in sync with this set so
# the control plane cannot authorize a prepaid route the enclave cannot
# dispatch.


def orchestration_primitive(model_id: str) -> str | None:
    return ORCHESTRATION_PRIMITIVE_BY_MODEL_ID.get(model_id)


def canonical_orchestration_model_id(model_id: str) -> str | None:
    if model_id not in META_MODEL_IDS:
        return None
    return ROUTING_MODEL_ALIAS_TARGETS.get(
        model_id,
        CANONICAL_ORCHESTRATION_MODEL_ID.get(model_id, model_id),
    )


def orchestration_role(model_id: str) -> str | None:
    if model_id not in META_MODEL_IDS:
        return None
    if model_id in PRIVATE_PROXY_MODEL_TARGETS:
        return "private_proxy"
    if model_id in ORCHESTRATION_LEGACY_ALIAS_MODEL_IDS:
        return "legacy_alias"
    if model_id in ORCHESTRATION_ROLLING_ALIAS_MODEL_IDS:
        return "rolling_alias"
    if model_id in ORCHESTRATION_PRIMITIVE_MODEL_IDS:
        return "primitive"
    if model_id in ORCHESTRATION_PRIMITIVE_BY_MODEL_ID:
        return "named_preset"
    return "routing_pool"


# EU-focused routing is a provider policy, not a hard data-residency promise.
# It keeps traffic on the EU regional attested gateway when the caller uses
# that base URL, then prefers European / EU-regionable / privacy-forward
# upstreams. Customers needing contractual residency should still pin a
# provider allowlist in their agreement and request body.
# IDs follow snapshot naming exactly. The picks span the 8 keyed
# providers so `trustedrouter/auto` rolls over across providers if any
# one is down. Each entry must have an authoritative price for the API that the
# gateway actually calls. Unconfigured OR-only models cannot reach the catalog;
# explicitly labelled proxy-backed routes are never auto candidates.
#
# 2026-06 update: OpenAI's GPT-5.4 line (incl. gpt-5.4-nano) and the "-pro"
# tiers 502 on our key — verified via the gateway probe; see
# _PROVIDER_UNSERVED_CREDITS_MODELS. Route auto/monitor callers to
# openai/gpt-4.1-mini, which is served (verified OK) and is the current cheap
# mid-tier model. (gpt-5.5 works too but is the pricey flagship.)


def effective_endpoint(
    endpoint: ModelEndpoint,
    *,
    at: datetime | str | None = None,
) -> ModelEndpoint:
    """Return an endpoint with any effective-dated announced price applied."""
    provider_price = provider_price_microdollars(
        endpoint.provider,
        endpoint.model_id,
        at=at,
    )
    if provider_price is None:
        return endpoint
    prompt_price = _customer_price(provider_price.prompt_microdollars_per_million_tokens)
    completion_price = _customer_price(provider_price.completion_microdollars_per_million_tokens)
    cached_prompt_price = (
        _customer_price(provider_price.prompt_cached_microdollars_per_million_tokens)
        if provider_price.prompt_cached_microdollars_per_million_tokens is not None
        else None
    )
    tiers = _flat_tier(
        prompt_price,
        completion_price,
        prompt_cached=cached_prompt_price,
    )
    return replace(
        endpoint,
        prompt_price_microdollars_per_million_tokens=prompt_price,
        completion_price_microdollars_per_million_tokens=completion_price,
        published_prompt_price_microdollars_per_million_tokens=prompt_price,
        published_completion_price_microdollars_per_million_tokens=completion_price,
        price_tiers=tiers,
        published_price_tiers=tiers,
    )


def endpoints_for_model(
    model_id: str, *, at: datetime | str | None = None,
) -> list[ModelEndpoint]:
    endpoints: list[ModelEndpoint] = []
    for endpoint in MODEL_ENDPOINTS.values():
        if endpoint.model_id != model_id:
            continue
        if not endpoint.catalog_is_current():
            continue
        if provider_model_retired(
            endpoint.provider,
            endpoint.model_id,
            endpoint.upstream_id,
        ):
            continue
        endpoints.append(effective_endpoint(endpoint, at=at))
    return endpoints


def endpoint_for_id(endpoint_id: str | None) -> ModelEndpoint | None:
    if endpoint_id is None:
        return None
    return MODEL_ENDPOINTS.get(endpoint_id)


def default_endpoint_for_model(model: Model) -> ModelEndpoint | None:
    endpoints = endpoints_for_model(model.id)
    if not endpoints:
        return None
    for endpoint in endpoints:
        if endpoint.usage_type == "Credits":
            return endpoint
    return endpoints[0]


def _meta_price_range(
    model_id: str,
    attr: str,
) -> tuple[int, int]:
    """Return (min, max) of the requested price attribute across the
    Auto model's candidate set. Auto itself has no intrinsic price —
    the request lands on whatever model the router picks — so we
    surface the range so /v1/models doesn't show a misleading $0."""
    candidates = meta_candidate_models(model_id)
    if model_id == POLYPHEMUS_MODEL_ID:
        # Generation is separate from the selector's prompt-token charge.
        # Publish its price envelope, with the selector rate exposed below.
        values = [
            getattr(endpoint, attr)
            for candidate in MODELS.values()
            if candidate.id not in META_MODEL_IDS and offers_chat(candidate)
            for endpoint in endpoints_for_model(candidate.id)
            if endpoint.usage_type == "Credits" and getattr(endpoint, attr, 0) > 0
        ]
        return (min(values), max(values)) if values else (0, 0)
    if model_id == GREEN_MODEL_ID:
        values = [
            getattr(endpoint, attr)
            for candidate in candidates
            for endpoint in endpoints_for_model(candidate.id)
            if endpoint.usage_type == "Credits"
            and provider_has_renewable_inference(PROVIDERS[endpoint.provider])
            and getattr(endpoint, attr, 0) > 0
        ]
        return (min(values), max(values)) if values else (0, 0)
    values = [getattr(c, attr) for c in candidates if getattr(c, attr, 0) > 0]
    if not values:
        return (0, 0)
    return (min(values), max(values))


def _model_max_privacy_tier(model: Model, endpoints: list[ModelEndpoint]) -> int:
    """Highest privacy tier this model can be routed through. For meta
    models (auto/free/cheap), that's the best tier across the candidate
    pool — NOT the 'trustedrouter' pseudo-provider, which would falsely
    claim confidential for Auto. For regular models, the max across the
    model's own provider plus any serving endpoints."""
    tiers: list[int] = []
    if model.id == GREEN_MODEL_ID:
        tiers = [
            endpoint_privacy_tier(endpoint)
            for candidate in meta_candidate_models(model.id)
            for endpoint in endpoints_for_model(candidate.id)
            if endpoint.provider in renewable_provider_slugs()
        ]
        return max(tiers, default=PRIVACY_TIER_STANDARD)
    if model.id in META_MODEL_IDS:
        for candidate in meta_candidate_models(model.id):
            tiers.append(model_max_privacy_tier(candidate))
    else:
        for endpoint in endpoints:
            tiers.append(endpoint_privacy_tier(endpoint))
        if not tiers and model.provider in PROVIDERS:
            tiers.append(model_provider_privacy_tier(model.id, model.provider))
    return max(tiers) if tiers else PRIVACY_TIER_STANDARD


def model_max_privacy_tier(model: Model) -> int:
    """Public wrapper: highest privacy tier `model` can be routed through,
    resolving its serving endpoints internally. Used by the router's
    min_privacy filter."""
    return _model_max_privacy_tier(model, endpoints_for_model(model.id))


_OPEN_WEIGHT_PREFIXES = (
    "amd/",
    "deepseek/",
    "google/gemma",
    "ibm-granite/",
    "meta-llama/",
    "minimax/minimax-m3",
    "mistralai/mistral-large-4",
    "moonshotai/kimi",
    "nvidia/nemotron",
    "qwen/",
    "tencent/hy4",
    "thinkingmachines/",
    "xiaomi/mimo",
    "z-ai/glm",
)
_OPEN_WEIGHT_CONTAINS = (
    "/qwen",
    "gpt-oss",
    "zai-glm",
)


def model_open_weights(model: Model, *, _seen: frozenset[str] = frozenset()) -> bool:
    """Whether a model route is purely open weights.

    For TrustedRouter orchestration models this is recursive: every candidate
    beneath the alias must be open weights. If the graph is empty or cycles, we
    fail closed and do not show the badge.
    """
    model_id = model.id.lower()
    if model.hidden_public_metadata:
        return False
    if model.id in _seen:
        return False
    if model.id in META_MODEL_IDS:
        candidates = meta_candidate_models(model.id)
        if not candidates:
            return False
        next_seen = frozenset((*_seen, model.id))
        return all(model_open_weights(candidate, _seen=next_seen) for candidate in candidates)
    return model_id.startswith(_OPEN_WEIGHT_PREFIXES) or any(
        marker in model_id for marker in _OPEN_WEIGHT_CONTAINS
    )


def _route_provider_slugs(
    model: Model,
    endpoints: list[ModelEndpoint],
    *,
    _seen: frozenset[str] = frozenset(),
) -> set[str]:
    """Serving provider slugs reachable for this model.

    For public orchestration aliases, recurse into their component models so
    badges/filters describe the actual route pool. For hidden orchestration
    presets, stop at TrustedRouter so we do not reveal private configuration.
    """
    if model.hidden_public_metadata:
        return {model.provider}
    if model.id == GREEN_MODEL_ID:
        return {
            endpoint.provider
            for candidate in meta_candidate_models(model.id)
            for endpoint in endpoints_for_model(candidate.id)
            if endpoint.provider in renewable_provider_slugs()
        }
    if model.id in _seen:
        return set()
    if model.id in META_MODEL_IDS:
        next_seen = frozenset((*_seen, model.id))
        providers: set[str] = set()
        for candidate in meta_candidate_models(model.id):
            providers.update(
                _route_provider_slugs(
                    candidate,
                    endpoints_for_model(candidate.id),
                    _seen=next_seen,
                )
            )
        return providers
    providers = {endpoint.provider for endpoint in endpoints}
    if not providers and model.provider in PROVIDERS:
        providers.add(model.provider)
    return providers


def model_us_provider_available(model: Model) -> bool:
    provider_slugs = _route_provider_slugs(model, endpoints_for_model(model.id))
    return any(
        PROVIDERS[slug].provider_headquarters_country == PROVIDER_JURISDICTION_US
        for slug in provider_slugs
        if slug in PROVIDERS
    )


def model_eu_focused_provider_available(model: Model) -> bool:
    provider_slugs = _route_provider_slugs(model, endpoints_for_model(model.id))
    return model.id == EU_MODEL_ID or any(
        slug in EU_FOCUSED_PROVIDER_ORDER for slug in provider_slugs
    )


def model_to_openrouter_shape(model: Model) -> dict[str, object]:
    provider = PROVIDERS[model.provider]
    is_meta = model.id in META_MODEL_IDS
    endpoints = endpoints_for_model(model.id)
    capabilities = [endpoint_capabilities(model, endpoint) for endpoint in endpoints]
    # Discovery fields are a union over the model's own routes. A private
    # proxy (for example a named decision model) is served through another
    # model's routes, so it keeps its own declarations instead.
    input_modalities = (
        model.input_modalities
        if model.id in PRIVATE_PROXY_MODEL_TARGETS
        else tuple(dict.fromkeys((
            *model.input_modalities,
            *(value for endpoint in endpoints for value in (endpoint.input_modalities or ())),
        )))
    )
    named_chain = NAMED_DECISION_MODEL_PROVIDERS.get(model.id)
    if named_chain is not None:
        # A named decision model has no endpoints of its own: authorize serves
        # it from its backing model's routes on the pinned chain. Reading its
        # own (empty) endpoint list advertised it as unavailable for Credits
        # while authorize served it on Credits. Ask the question authorize
        # asks, so the flag cannot be wrong in either direction: true while a
        # chain host can serve it, false when none can (authorize says 503).
        prepaid_available = any(
            endpoint.usage_type == "Credits" and endpoint.provider in named_chain
            for endpoint in endpoints_for_model(PRIVATE_PROXY_MODEL_TARGETS[model.id])
        )
    else:
        prepaid_available = (
            model.prepaid_available
            if is_meta
            else any(endpoint.usage_type == "Credits" for endpoint in endpoints)
        )
    byok_available = (
        False if is_meta else any(endpoint.usage_type == "BYOK" for endpoint in endpoints)
    )
    supported_parameters = union_supported_parameters(
        manifest_supported_parameters(
            {},
            supports_chat=model.supports_chat,
            supports_embeddings=model.supports_embeddings,
        ),
        model.supported_parameters,
        *(endpoint.supported_parameters for endpoint in endpoints),
    )

    # For meta routers, derive prompt/completion price from the candidate range
    # rather than the catalog's hard-coded 0. Most OpenRouter-compat
    # consumers (browsers, marketplace listings, billing previews) read
    # `pricing.prompt` / `pricing.completion`; if those are 0, Auto
    # appears free in every dashboard. We report the cheapest candidate
    # as the headline price (matches OpenRouter's convention for their
    # `openrouter/auto` meta-model) and add `*_max` fields plus the
    # full candidate manifest so anything that wants a range can show one.
    prompt_min = model.prompt_price_microdollars_per_million_tokens
    prompt_max = prompt_min
    completion_min = model.completion_price_microdollars_per_million_tokens
    completion_max = completion_min
    pub_prompt_min = model.published_prompt_price_microdollars_per_million_tokens
    pub_prompt_max = pub_prompt_min
    pub_completion_min = model.published_completion_price_microdollars_per_million_tokens
    pub_completion_max = pub_completion_min
    if not is_meta and endpoints:
        prompt_min = min(
            endpoint.prompt_price_microdollars_per_million_tokens for endpoint in endpoints
        )
        completion_min = min(
            endpoint.completion_price_microdollars_per_million_tokens for endpoint in endpoints
        )
        prompt_max = prompt_min
        completion_max = completion_min
        pub_prompt_min = min(
            endpoint.published_prompt_price_microdollars_per_million_tokens
            for endpoint in endpoints
        )
        pub_completion_min = min(
            endpoint.published_completion_price_microdollars_per_million_tokens
            for endpoint in endpoints
        )
        pub_prompt_max = pub_prompt_min
        pub_completion_max = pub_completion_min
    elif is_meta and ((prompt_min == 0 and completion_min == 0) or model.id == POLYPHEMUS_MODEL_ID):
        prompt_min, prompt_max = _meta_price_range(
            model.id, "prompt_price_microdollars_per_million_tokens"
        )
        completion_min, completion_max = _meta_price_range(
            model.id, "completion_price_microdollars_per_million_tokens"
        )
        pub_prompt_min, pub_prompt_max = _meta_price_range(
            model.id, "published_prompt_price_microdollars_per_million_tokens"
        )
        pub_completion_min, pub_completion_max = _meta_price_range(
            model.id, "published_completion_price_microdollars_per_million_tokens"
        )
    if model.id == POLYPHEMUS_MODEL_ID:
        # Standard price previews need both stages. Actual selector and model
        # token counts are separate; expose the selector basis/rate below too.
        prompt_min += SELECTOR_PROMPT_MICRODOLLARS_PER_MILLION
        prompt_max += SELECTOR_PROMPT_MICRODOLLARS_PER_MILLION
        pub_prompt_min += SELECTOR_PROMPT_MICRODOLLARS_PER_MILLION
        pub_prompt_max += SELECTOR_PROMPT_MICRODOLLARS_PER_MILLION

    pricing: dict[str, str] = {
        "prompt": microdollars_per_million_tokens_to_token_decimal(prompt_min),
        "completion": microdollars_per_million_tokens_to_token_decimal(completion_min),
    }
    # The endpoint payloads have always published input_cache_read; the model
    # headline never did, so /v1/models hid the cache-read discount on more
    # than a thousand endpoints. OR convention, same field name.
    model_tiers = getattr(model, "price_tiers", ()) or ()
    model_cached = (
        model_tiers[0].prompt_cached_price_microdollars_per_million_tokens if model_tiers else None
    )
    if model_cached is not None:
        pricing["input_cache_read"] = microdollars_per_million_tokens_to_token_decimal(model_cached)
    if model.request_price_microdollars:
        pricing["request"] = microdollars_to_decimal(model.request_price_microdollars)
    fixed_image_prices = FIXED_IMAGE_PRICES_MICRODOLLARS.get(model.id)
    if fixed_image_prices:
        customer_prices = [
            customer_fixed_price_microdollars(microdollars)
            for microdollars in fixed_image_prices.values()
        ]
        pricing["image"] = microdollars_to_decimal(min(customer_prices))
        if max(customer_prices) != min(customer_prices):
            pricing["image_max"] = microdollars_to_decimal(max(customer_prices))
    if model.minimum_charge_microdollars:
        pricing["minimum"] = microdollars_to_decimal(model.minimum_charge_microdollars)
    if is_meta and (prompt_max != prompt_min or completion_max != completion_min):
        pricing["prompt_max"] = microdollars_per_million_tokens_to_token_decimal(prompt_max)
        pricing["completion_max"] = microdollars_per_million_tokens_to_token_decimal(completion_max)

    auto_candidates = None
    route_kind = _meta_route_kind(model.id) if is_meta else "model"
    if is_meta and not model.hidden_public_metadata:
        auto_candidates = [c.id for c in meta_candidate_models(model.id)]
    if model.hidden_public_metadata:
        route_kind = "private_proxy" if model.id in PRIVATE_PROXY_MODEL_TARGETS else "private_orchestration"

    documentation = (
        model.documentation.to_dict()
        if model.documentation is not None
        else None
    )

    tr_block: dict[str, object] = {
        "provider": model.provider,
        "prepaid_available": prepaid_available,
        "byok_available": byok_available,
        "attested_gateway": provider.attested_gateway,
        # Gateway-scoped OpenRouter-compat flag: TrustedRouter does not
        # retain prompt/output content. Upstream provider retention still
        # varies and is exposed per endpoint below plus provider_* fields.
        "stores_content": False,
        "provider_zero_data_retention": model_provider_zero_data_retention(
            model.id, model.provider
        ),
        "zero_data_retention_available": any(
            endpoint_zero_data_retention(endpoint) is True for endpoint in endpoints
        ),
        "provider_confidential_compute": provider.provider_confidential_compute,
        "provider_e2ee": provider.provider_e2ee,
        "provider_policy": model_provider_policy(model.id, model.provider),
        "provider_policy_url": model_provider_policy_url(model.id, model.provider),
        "provider_headquarters_country": provider.provider_headquarters_country,
        "provider_us_based": provider.provider_headquarters_country == PROVIDER_JURISDICTION_US,
        "us_provider_available": model_us_provider_available(model),
        "eu_focused_provider_available": model_eu_focused_provider_available(model),
        "required_provider_jurisdiction": (
            PROVIDER_JURISDICTION_US if model.id in US_PROVIDER_ONLY_MODEL_IDS else None
        ),
        # Highest privacy tier reachable for this model — the max across
        # every provider that serves it (a request can route to the best
        # one). Lets the picker / SEO pages show "this model can run
        # confidential" without re-deriving from raw posture flags.
        "privacy_tier": _model_max_privacy_tier(model, endpoints),
        "privacy_tier_label": PRIVACY_TIER_LABELS[_model_max_privacy_tier(model, endpoints)],
        "open_weights": model_open_weights(model),
        "prompt_price_microdollars_per_million_tokens": prompt_min,
        "completion_price_microdollars_per_million_tokens": completion_min,
        "published_prompt_price_microdollars_per_million_tokens": pub_prompt_min,
        "published_completion_price_microdollars_per_million_tokens": pub_completion_min,
        "request_price_microdollars": model.request_price_microdollars,
        "minimum_charge_microdollars": model.minimum_charge_microdollars,
        # Uniform pricing means the customer pays the headline rate — no
        # secret 1¢/M discount layered on top. Field kept for OpenRouter
        # consumer compat, but always zero.
        "discount_microdollars_per_million_tokens": 0,
        "auto_candidates": auto_candidates,
        "route_kind": route_kind,
        "orchestration_primitive": orchestration_primitive(model.id),
        "orchestration_role": orchestration_role(model.id),
        "canonical_model_id": canonical_orchestration_model_id(model.id),
        "configuration_hidden": model.hidden_public_metadata,
        "synthetic_monitor": model.id == MONITOR_MODEL_ID,
        "internal_only": model.id == MONITOR_MODEL_ID,
        # Capability flags so OpenRouter-compat clients (and TR's own chat
        # picker) can tell an embedding model from a chat model without
        # parsing `architecture.modality`.
        # What a CALLER can do with it. A named decision model keeps
        # Model.supports_chat so authorize can route its backing chat model, but
        # it answers POST /v1/decide only: advertised as chat-capable it showed
        # up in the chat picker and as a custom-model base, and both then
        # refused it.
        "supports_chat": offers_chat(model),
        "supports_responses": offers_chat(model) or model.id == POLYPHEMUS_MODEL_ID,
        **({
            "pricing_type": "selection_fee_plus_selected_model_tokens",
            "selector_pricing_unit": "prompt_tokens",
            "selector_prompt_price_per_million": microdollars_to_decimal(SELECTOR_PROMPT_MICRODOLLARS_PER_MILLION),
            "selector_prompt_price_microdollars_per_million": SELECTOR_PROMPT_MICRODOLLARS_PER_MILLION,
            "selector_usage_estimated": True,
            "selector_token_basis": "serialized_context_utf8_bytes_div_4",
            "selector_minimum_charge_microdollars": 1,
        }
           if model.id == POLYPHEMUS_MODEL_ID else {}),
        "supports_embeddings": model.supports_embeddings,
        "supports_video": model.supports_video,
        # True for hosted decision models AND for the chat models the gateway
        # drives as decision models on POST /v1/decide.
        "supports_decide": model.supports_decide or model.id in NATIVE_DECISION_MODEL_IDS,
        "endpoints": [
            {
                "id": endpoint.id,
                "provider": endpoint.provider,
                "provider_name": PROVIDERS[endpoint.provider].name,
                "usage_type": endpoint.usage_type,
                "upstream_id": endpoint.upstream_id,
                "quantization": endpoint_quantization(endpoint),
                "precision": endpoint_precision_metadata(endpoint),
                "attested_gateway": PROVIDERS[endpoint.provider].attested_gateway,
                "stores_content": endpoint_stores_content(endpoint),
                "provider_zero_data_retention": endpoint_zero_data_retention(endpoint),
                "zero_data_retention_scope": endpoint_zero_data_retention_scope(endpoint),
                "privacy_tier": endpoint_privacy_tier(endpoint),
                "privacy_tier_label": PRIVACY_TIER_LABELS[endpoint_privacy_tier(endpoint)],
                "provider_confidential_compute": endpoint_confidential_compute(endpoint),
                "provider_e2ee": endpoint_e2ee(endpoint),
                "provider_policy": endpoint_provider_policy(endpoint),
                "provider_policy_url": endpoint_provider_policy_url(endpoint),
                "provider_headquarters_country": PROVIDERS[
                    endpoint.provider
                ].provider_headquarters_country,
                "provider_us_based": PROVIDERS[endpoint.provider].provider_headquarters_country
                == PROVIDER_JURISDICTION_US,
                "provider_eu_focused": endpoint.provider in EU_FOCUSED_PROVIDER_ORDER,
                "inference_location": inference_location_metadata(endpoint.provider, endpoint.model_id),
                "renewable_energy_inference": PROVIDERS[endpoint.provider].renewable_energy_inference,
                "energy_policy_url": PROVIDERS[endpoint.provider].energy_policy_url,
                "supported_parameters": list(
                    union_supported_parameters(
                        endpoint.supported_parameters,
                        provider_extension_parameters(endpoint.provider),
                    )
                ),
                "capabilities": capability,
                "request_price_microdollars": endpoint.request_price_microdollars,
            }
            for endpoint, capability in zip(endpoints, capabilities, strict=True)
        ],
    }
    # Orchestrators can select/subcall different models and have no stable
    # endpoint contract. Do not manufacture capabilities from an empty pool.
    if not is_meta and not model.hidden_public_metadata:
        tr_block["capabilities"] = model_capabilities(
            capabilities, supported_parameters, input_modalities,
        )
    if documentation is not None:
        tr_block["documentation"] = documentation
    usage_estimation = provider_usage_estimation_policy(model.provider)
    if usage_estimation is not None:
        tr_block["usage_estimation"] = usage_estimation
    if model.id == GREEN_MODEL_ID:
        tr_block.update({
            "renewable_energy_required": True,
            "energy_claim_scope": "provider_inference",
            "energy_evidence_type": "provider_declaration",
            "eligible_providers": sorted(renewable_provider_slugs()),
            "provider_confidential_compute": False,
            "provider_e2ee": False,
            "provider_policy": "Renewable-powered provider inference under the provider's published energy policy. Gateway attestation is separate from energy sourcing.",
            "provider_policy_url": "https://trustedrouter.com/green-tokens#energy-evidence",
        })
    if is_meta:
        tr_block["prompt_price_max_microdollars_per_million_tokens"] = prompt_max
        tr_block["completion_price_max_microdollars_per_million_tokens"] = completion_max
        tr_block["published_prompt_price_max_microdollars_per_million_tokens"] = pub_prompt_max
        tr_block["published_completion_price_max_microdollars_per_million_tokens"] = (
            pub_completion_max
        )
    if model.id in PRIVATE_PROXY_MODEL_TARGETS:
        tr_block.update(
            {
                "provider_zero_data_retention": False,
                "zero_data_retention_available": False,
                "provider_confidential_compute": False,
                "provider_e2ee": False,
                "provider_policy": (
                    "Private route configuration. Standard provider data-handling terms apply."
                ),
                "provider_policy_url": "https://trust.trustedrouter.com",
                "provider_headquarters_country": None,
                "provider_us_based": False,
                "us_provider_available": False,
                "eu_focused_provider_available": False,
                "privacy_tier": PRIVACY_TIER_STANDARD,
                "privacy_tier_label": PRIVACY_TIER_LABELS[PRIVACY_TIER_STANDARD],
            }
        )

    return {
        "id": model.id,
        "name": model.name,
        "created": 0,
        "description": (
            model.documentation.description
            if model.documentation is not None
            else f"{model.name} via TrustedRouter"
        ) + (f". {usage_estimation['description']}" if usage_estimation else ""),
        "context_length": model.context_length,
        "architecture": {
            "modality": (
                "text->embedding"
                if model.supports_embeddings and not model.supports_chat
                else "text->decision"
                if model.supports_decide and not model.supports_chat
                else (f"{'+'.join(input_modalities)}->{'+'.join(model.output_modalities)}")
            ),
            "input_modalities": list(input_modalities),
            "output_modalities": list(model.output_modalities),
            "tokenizer": "unknown",
            "instruct_type": None,
        },
        "pricing": pricing,
        "top_provider": {
            "context_length": model.context_length,
            "max_completion_tokens": None,
            "is_moderated": False,
        },
        "per_request_limits": None,
        "supported_parameters": list(supported_parameters),
        "trustedrouter": tr_block,
    }


def provider_to_openrouter_shape(provider: Provider) -> dict[str, object]:
    routing_status = "active" if provider_is_routable(provider) else "blocked"
    return {
        "id": provider.slug,
        "name": provider.name,
        "supports_prepaid": provider.supports_prepaid,
        "supports_byok": provider.supports_byok,
        "routing_status": routing_status,
        "routing_status_reason": provider.provider_policy if routing_status == "blocked" else None,
        "attested_gateway": provider.attested_gateway,
        "stores_content": provider.stores_content,
        "provider_zero_data_retention": provider.provider_zero_data_retention,
        "prepaid_zero_data_retention": provider.prepaid_zero_data_retention,
        "prepaid_zero_data_retention_effective_on": (
            provider.prepaid_zero_data_retention_effective_on
        ),
        "zero_data_retention_scope": (
            "trustedrouter_prepaid"
            if provider.prepaid_zero_data_retention
            else "provider"
            if provider.provider_zero_data_retention is True
            else None
        ),
        "provider_confidential_compute": provider.provider_confidential_compute,
        "provider_e2ee": provider.provider_e2ee,
        "provider_policy": provider.provider_policy,
        "provider_policy_url": provider.provider_policy_url,
        "provider_headquarters_country": provider.provider_headquarters_country,
        "provider_us_based": provider.provider_headquarters_country == PROVIDER_JURISDICTION_US,
        "geography": provider_geography(provider.slug),
    }


def provider_is_routable(provider: Provider) -> bool:
    """Return whether the public catalog currently exposes a route for a provider."""
    if provider.slug == "trustedrouter":
        return provider.supports_prepaid or provider.supports_byok
    return any(endpoint.provider == provider.slug for endpoint in MODEL_ENDPOINTS.values())


def providers_for_display() -> tuple[Provider, ...]:
    """Order transparency surfaces by the strongest tracked privacy posture."""
    pinned_rank = {slug: index for index, slug in enumerate(_PROVIDER_DISPLAY_ORDER)}

    def display_key(provider: Provider) -> tuple[int, int, str, str]:
        if provider.slug == "trustedrouter":
            posture_rank = 0
        elif provider_confidential_inference(provider, prepaid=True):
            posture_rank = 1
        elif (
            provider.provider_zero_data_retention is True
            or provider.prepaid_zero_data_retention is True
        ):
            posture_rank = 2
        else:
            posture_rank = 3
        return (
            posture_rank,
            pinned_rank.get(provider.slug, len(pinned_rank)),
            provider.name.casefold(),
            provider.slug,
        )

    return tuple(sorted(PROVIDERS.values(), key=display_key))
