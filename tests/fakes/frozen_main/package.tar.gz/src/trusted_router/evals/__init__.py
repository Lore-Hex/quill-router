"""Evaluation helpers for TrustedRouter."""
