from __future__ import annotations

import json
import time
import uuid
from collections.abc import AsyncIterator
from typing import Any, cast

import httpx

from trusted_router.adapter import resolve_max_output_tokens
from trusted_router.catalog import PROVIDERS, Model
from trusted_router.provider_payloads import (
    anthropic_messages_payload,
    gemini_payload,
    messages,
    upstream_model_id,
)
from trusted_router.provider_streaming import (
    gemini_finish_reason,
    openai_stream_chunk,
    record_anthropic_stream_payload,
    record_gemini_stream_payload,
    record_openai_stream_payload,
    safe_error_message,
    safe_stream_error_message,
)
from trusted_router.provider_types import (
    ProviderError,
    ProviderResult,
    ProviderStreamState,
    estimate_tokens_from_messages,
    estimate_tokens_from_text,
)

OPENAI_COMPATIBLE_PASSTHROUGH_FIELDS = (
    # Provider-specific controls still use the OpenAI-compatible envelope.
    # Xiaomi MiMo requires `thinking: {"type": "disabled"}` to suppress
    # reasoning text that otherwise arrives as normal delta.content.
    "thinking",
    "chat_template_kwargs",
    "response_format",
    "tools",
    "tool_choice",
    "parallel_tool_calls",
    "top_p",
    "seed",
    "frequency_penalty",
    "presence_penalty",
    "logit_bias",
    "stop",
)


def _openai_compatible_passthrough(request: dict[str, Any]) -> dict[str, Any]:
    return {
        field: request[field]
        for field in OPENAI_COMPATIBLE_PASSTHROUGH_FIELDS
        if request.get(field) is not None
    }


def _openai_cached_input_tokens(usage: dict[str, Any]) -> int:
    details = usage.get("prompt_tokens_details")
    if isinstance(details, dict) and details.get("cached_tokens") is not None:
        return int(details["cached_tokens"])
    if usage.get("cached_tokens") is not None:
        return int(usage["cached_tokens"])
    return 0


def _openai_reasoning_tokens(usage: dict[str, Any]) -> int:
    details = usage.get("completion_tokens_details")
    if isinstance(details, dict) and details.get("reasoning_tokens") is not None:
        return int(details["reasoning_tokens"])
    if usage.get("reasoning_tokens") is not None:
        return int(usage["reasoning_tokens"])
    return 0


def _openai_tool_calls(message: dict[str, Any]) -> list[dict[str, Any]] | None:
    tool_calls = message.get("tool_calls")
    if not isinstance(tool_calls, list):
        return None
    parsed = [cast(dict[str, Any], item) for item in tool_calls if isinstance(item, dict)]
    return parsed or None


async def openai_compatible_chat(
    model: Model,
    request: dict[str, Any],
    *,
    api_key: str,
    base_url: str,
    extra_headers: dict[str, str] | None = None,
) -> ProviderResult:
    started = time.monotonic()
    payload = {
        "model": upstream_model_id(model),
        "messages": messages(request),
        "stream": False,
        "temperature": request.get("temperature"),
        "max_tokens": resolve_max_output_tokens(request),
    }
    payload.update(_openai_compatible_passthrough(request))
    payload = {k: v for k, v in payload.items() if v is not None}
    async with httpx.AsyncClient(timeout=120) as client:
        headers = {"authorization": f"Bearer {api_key}"}
        headers.update(extra_headers or {})
        resp = await client.post(
            f"{base_url}/chat/completions",
            headers=headers,
            json=payload,
        )
    if resp.status_code >= 400:
        raise ProviderError(model.provider, resp.status_code, safe_error_message(resp))
    data = resp.json()
    choice = data.get("choices", [{}])[0]
    message = choice.get("message") or {}
    usage = data.get("usage") or {}
    text = str(message.get("content") or "")
    tool_calls = _openai_tool_calls(message)
    return ProviderResult(
        text=text,
        input_tokens=int(
            usage.get("prompt_tokens") or estimate_tokens_from_messages(messages(request))
        ),
        output_tokens=int(usage.get("completion_tokens") or estimate_tokens_from_text(text)),
        finish_reason=str(choice.get("finish_reason") or "stop"),
        provider_name=PROVIDERS[model.provider].name,
        request_id=str(data.get("id") or f"req-{uuid.uuid4()}"),
        usage_estimated=not bool(usage),
        elapsed_seconds=max(time.monotonic() - started, 0.001),
        cached_input_tokens=_openai_cached_input_tokens(usage),
        reasoning_tokens=_openai_reasoning_tokens(usage),
        tool_calls=tool_calls,
    )


async def openai_compatible_chat_stream(
    model: Model,
    request: dict[str, Any],
    state: ProviderStreamState,
    *,
    api_key: str,
    base_url: str,
    extra_headers: dict[str, str] | None = None,
) -> AsyncIterator[bytes]:
    payload = {
        "model": upstream_model_id(model),
        "messages": messages(request),
        "stream": True,
        "stream_options": {"include_usage": True},
        "temperature": request.get("temperature"),
        "max_tokens": resolve_max_output_tokens(request),
    }
    payload.update(_openai_compatible_passthrough(request))
    payload = {k: v for k, v in payload.items() if v is not None}
    async with httpx.AsyncClient(timeout=120) as client:
        headers = {"authorization": f"Bearer {api_key}"}
        headers.update(extra_headers or {})
        async with client.stream(
            "POST",
            f"{base_url}/chat/completions",
            headers=headers,
            json=payload,
        ) as resp:
            if resp.status_code >= 400:
                raise ProviderError(
                    model.provider, resp.status_code, await safe_stream_error_message(resp)
                )
            async for line in resp.aiter_lines():
                if not line:
                    continue
                if not line.startswith("data:"):
                    yield f"{line}\n\n".encode()
                    continue
                data = line[5:].strip()
                if data == "[DONE]":
                    yield b"data: [DONE]\n\n"
                    break
                try:
                    payload_chunk = json.loads(data)
                except ValueError:
                    yield f"data: {data}\n\n".encode()
                    continue
                record_openai_stream_payload(state, payload_chunk)
                yield f"data: {data}\n\n".encode()


# ---------------------------------------------------------------------------
# Embeddings. Each adapter returns the OpenAI embeddings envelope
#   {object:"list", data:[{object:"embedding", embedding:[...], index}],
#    model, usage:{prompt_tokens, total_tokens}}
# so the route can return it verbatim. Embeddings bill INPUT tokens only;
# `total_tokens == prompt_tokens` and there is no completion component.
#
# These run in the control plane only for local/test/dev (the live path);
# in production the attested enclave performs the upstream call. They double
# as the executable contract the enclave's per-provider embeddings must match.
# ---------------------------------------------------------------------------


def _embedding_inputs(request: dict[str, Any]) -> list[str]:
    value = request.get("input", "")
    if isinstance(value, list):
        return [str(item) for item in value]
    return [str(value)]


def _estimate_embedding_tokens(inputs: list[str]) -> int:
    return sum(estimate_tokens_from_text(text) for text in inputs)


def _embedding_envelope(
    model: Model,
    data_rows: list[dict[str, Any]],
    *,
    prompt_tokens: int,
) -> dict[str, Any]:
    return {
        "object": "list",
        "data": data_rows,
        "model": model.id,
        "usage": {"prompt_tokens": prompt_tokens, "total_tokens": prompt_tokens},
    }


def _embedding_rows(vectors: list[Any]) -> list[dict[str, Any]]:
    return [
        {"object": "embedding", "embedding": vector, "index": index}
        for index, vector in enumerate(vectors)
    ]


async def openai_compatible_embeddings(
    model: Model,
    request: dict[str, Any],
    *,
    api_key: str,
    base_url: str,
) -> dict[str, Any]:
    """OpenAI / Together — POST {base_url}/embeddings with {model, input}."""
    inputs = _embedding_inputs(request)
    payload: dict[str, Any] = {"model": upstream_model_id(model), "input": inputs}
    if request.get("encoding_format"):
        payload["encoding_format"] = request["encoding_format"]
    if request.get("dimensions"):
        payload["dimensions"] = request["dimensions"]
    async with httpx.AsyncClient(timeout=120) as client:
        resp = await client.post(
            f"{base_url}/embeddings",
            headers={"authorization": f"Bearer {api_key}"},
            json=payload,
        )
    if resp.status_code >= 400:
        raise ProviderError(model.provider, resp.status_code, safe_error_message(resp))
    data = resp.json()
    usage = data.get("usage") or {}
    prompt_tokens = int(usage.get("prompt_tokens") or _estimate_embedding_tokens(inputs))
    # OpenAI-compatible upstreams already return rows in the right shape;
    # pass them through (preserves base64 encoding_format) and re-stamp model.
    # Default a missing `object` to "embedding" so the envelope stays
    # OpenAI-conformant even if an upstream omits it — matches the enclave's
    # Go adapter (cross-implementation symmetry).
    rows = list(data.get("data") or [])
    for row in rows:
        if isinstance(row, dict) and not row.get("object"):
            row["object"] = "embedding"
    return _embedding_envelope(model, rows, prompt_tokens=prompt_tokens)


async def gemini_embeddings(
    model: Model,
    request: dict[str, Any],
    *,
    api_key: str,
) -> dict[str, Any]:
    """Gemini — POST :batchEmbedContents (one entry per input)."""
    inputs = _embedding_inputs(request)
    upstream_model = upstream_model_id(model)
    body = {
        "requests": [
            {"model": f"models/{upstream_model}", "content": {"parts": [{"text": text}]}}
            for text in inputs
        ]
    }
    async with httpx.AsyncClient(timeout=120) as client:
        resp = await client.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/{upstream_model}:batchEmbedContents",
            params={"key": api_key},
            json=body,
        )
    if resp.status_code >= 400:
        raise ProviderError("google-ai-studio", resp.status_code, safe_error_message(resp))
    data = resp.json()
    vectors = [row.get("values") or [] for row in (data.get("embeddings") or [])]
    # Gemini's embed API does not report token usage; estimate from input.
    prompt_tokens = _estimate_embedding_tokens(inputs)
    return _embedding_envelope(model, _embedding_rows(vectors), prompt_tokens=prompt_tokens)


async def cohere_embeddings(
    model: Model,
    request: dict[str, Any],
    *,
    api_key: str,
) -> dict[str, Any]:
    """Cohere — POST /v2/embed (native shape) adapted to OpenAI envelope.

    Cohere is NOT OpenAI-shaped: it takes `texts` + a required `input_type`
    and returns `embeddings.float` (a list of vectors). OpenAI's embeddings
    request has no `input_type`; default to `search_document` (the right
    choice for indexing corpora) and let callers override it."""
    inputs = _embedding_inputs(request)
    body = {
        "model": upstream_model_id(model),
        "texts": inputs,
        "input_type": str(request.get("input_type") or "search_document"),
        "embedding_types": ["float"],
    }
    async with httpx.AsyncClient(timeout=120) as client:
        resp = await client.post(
            "https://api.cohere.com/v2/embed",
            headers={"authorization": f"Bearer {api_key}"},
            json=body,
        )
    if resp.status_code >= 400:
        raise ProviderError("cohere", resp.status_code, safe_error_message(resp))
    data = resp.json()
    floats = (data.get("embeddings") or {}).get("float") or []
    vectors = [list(vector) for vector in floats]
    billed = (data.get("meta") or {}).get("billed_units") or {}
    prompt_tokens = int(billed.get("input_tokens") or _estimate_embedding_tokens(inputs))
    return _embedding_envelope(model, _embedding_rows(vectors), prompt_tokens=prompt_tokens)


async def anthropic_chat(
    model: Model,
    request: dict[str, Any],
    *,
    api_key: str,
) -> ProviderResult:
    started = time.monotonic()
    payload = anthropic_messages_payload(model, request, stream=False)
    async with httpx.AsyncClient(timeout=120) as client:
        resp = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": api_key, "anthropic-version": "2023-06-01"},
            json=payload,
        )
    if resp.status_code >= 400:
        raise ProviderError("anthropic", resp.status_code, safe_error_message(resp))
    data = resp.json()
    text = "".join(
        part.get("text", "") for part in data.get("content", []) if part.get("type") == "text"
    )
    usage = data.get("usage") or {}
    return ProviderResult(
        text=text,
        input_tokens=int(
            usage.get("input_tokens") or estimate_tokens_from_messages(messages(request))
        ),
        output_tokens=int(usage.get("output_tokens") or estimate_tokens_from_text(text)),
        finish_reason=str(data.get("stop_reason") or "stop"),
        provider_name="Anthropic",
        request_id=str(data.get("id") or f"req-{uuid.uuid4()}"),
        usage_estimated=not bool(usage),
        elapsed_seconds=max(time.monotonic() - started, 0.001),
    )


async def anthropic_messages_stream(
    model: Model,
    request: dict[str, Any],
    state: ProviderStreamState,
    *,
    api_key: str,
    output_format: str,
) -> AsyncIterator[bytes]:
    payload = anthropic_messages_payload(model, request, stream=True)
    created = int(time.time())
    openai_done_sent = False
    openai_role_sent = False
    async with httpx.AsyncClient(timeout=120) as client:
        async with client.stream(
            "POST",
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": api_key, "anthropic-version": "2023-06-01"},
            json=payload,
        ) as resp:
            if resp.status_code >= 400:
                raise ProviderError(
                    "anthropic", resp.status_code, await safe_stream_error_message(resp)
                )
            event_name = ""
            async for line in resp.aiter_lines():
                if not line:
                    continue
                if line.startswith("event:"):
                    event_name = line[6:].strip()
                    continue
                if not line.startswith("data:"):
                    if output_format == "anthropic":
                        yield f"{line}\n\n".encode()
                    continue
                data = line[5:].strip()
                try:
                    payload_chunk = json.loads(data)
                except ValueError:
                    if output_format == "anthropic":
                        if event_name:
                            yield f"event: {event_name}\n".encode()
                        yield f"data: {data}\n\n".encode()
                    continue

                text_delta = record_anthropic_stream_payload(state, payload_chunk)
                if output_format == "anthropic":
                    if event_name:
                        yield f"event: {event_name}\n".encode()
                    yield f"data: {data}\n\n".encode()
                    continue
                if not openai_role_sent and payload_chunk.get("type") in {
                    "message_start",
                    "content_block_start",
                    "content_block_delta",
                    "message_stop",
                }:
                    yield openai_stream_chunk(
                        request_id=state.request_id,
                        model_id=model.id,
                        created=created,
                        delta={"role": "assistant", "content": ""},
                        finish_reason=None,
                    )
                    openai_role_sent = True
                if text_delta:
                    yield openai_stream_chunk(
                        request_id=state.request_id,
                        model_id=model.id,
                        created=created,
                        delta={"content": text_delta},
                        finish_reason=None,
                    )
                if payload_chunk.get("type") == "message_stop":
                    yield openai_stream_chunk(
                        request_id=state.request_id,
                        model_id=model.id,
                        created=created,
                        delta={},
                        finish_reason=state.finish_reason,
                    )
                    yield b"data: [DONE]\n\n"
                    openai_done_sent = True

    if output_format == "openai" and not openai_done_sent:
        yield openai_stream_chunk(
            request_id=state.request_id,
            model_id=model.id,
            created=created,
            delta={},
            finish_reason=state.finish_reason,
        )
        yield b"data: [DONE]\n\n"


async def gemini_chat(model: Model, request: dict[str, Any], *, api_key: str) -> ProviderResult:
    started = time.monotonic()
    upstream_model = upstream_model_id(model)
    async with httpx.AsyncClient(timeout=120) as client:
        resp = await client.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/{upstream_model}:generateContent",
            params={"key": api_key},
            json=gemini_payload(request),
        )
    if resp.status_code >= 400:
        raise ProviderError("google-ai-studio", resp.status_code, safe_error_message(resp))
    data = resp.json()
    candidate = (data.get("candidates") or [{}])[0]
    parts = (candidate.get("content") or {}).get("parts") or []
    text = _gemini_parts_to_openai_content(parts)
    usage = data.get("usageMetadata") or {}
    candidates_tokens = usage.get("candidatesTokenCount")
    thoughts_tokens = int(usage.get("thoughtsTokenCount") or 0)
    output_tokens = (
        int(candidates_tokens) + thoughts_tokens
        if candidates_tokens is not None
        else estimate_tokens_from_text(text) + thoughts_tokens
    )
    return ProviderResult(
        text=text,
        input_tokens=int(
            usage.get("promptTokenCount") or estimate_tokens_from_messages(messages(request))
        ),
        output_tokens=output_tokens,
        finish_reason=gemini_finish_reason(str(candidate.get("finishReason") or "stop")),
        provider_name="Google AI Studio",
        request_id=f"req-{uuid.uuid4()}",
        usage_estimated=not bool(usage),
        elapsed_seconds=max(time.monotonic() - started, 0.001),
        cached_input_tokens=int(usage.get("cachedContentTokenCount") or 0),
        reasoning_tokens=thoughts_tokens,
    )


def _gemini_parts_to_openai_content(parts: list[Any]) -> str:
    """Flatten Gemini response `parts` into an OpenAI-shaped `content`
    string. Text parts join with newlines; image parts (Nano Banana,
    `gemini-3.1-flash-image-preview`, etc.) are emitted as
    `data:<mime>;base64,<body>` URLs so callers like forty.news that
    regex-scan `choices[0].message.content` for `data:image/...;base64,...`
    pick up the image without needing a separate `images` array.

    Without this, Gemini's `inline_data` parts were silently dropped and
    image-generation requests through TR returned an empty content
    string."""
    chunks: list[str] = []
    for part in parts:
        if not isinstance(part, dict):
            continue
        text = part.get("text")
        if isinstance(text, str) and text:
            chunks.append(text)
        # Gemini's REST API has historically returned both spellings.
        inline = part.get("inline_data") or part.get("inlineData")
        if isinstance(inline, dict):
            mime_type = (
                inline.get("mime_type") or inline.get("mimeType") or "application/octet-stream"
            )
            body = inline.get("data")
            if isinstance(body, str) and body:
                chunks.append(f"data:{mime_type};base64,{body}")
    return "\n".join(chunks)


async def gemini_chat_stream(
    model: Model,
    request: dict[str, Any],
    state: ProviderStreamState,
    *,
    api_key: str,
) -> AsyncIterator[bytes]:
    upstream_model = upstream_model_id(model)
    created = int(time.time())
    role_sent = False
    async with httpx.AsyncClient(timeout=120) as client:
        async with client.stream(
            "POST",
            f"https://generativelanguage.googleapis.com/v1beta/models/{upstream_model}:streamGenerateContent",
            params={"key": api_key, "alt": "sse"},
            json=gemini_payload(request),
        ) as resp:
            if resp.status_code >= 400:
                raise ProviderError(
                    "google-ai-studio", resp.status_code, await safe_stream_error_message(resp)
                )
            async for line in resp.aiter_lines():
                if not line:
                    continue
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if data == "[DONE]":
                    break
                try:
                    payload_chunk = json.loads(data)
                except ValueError:
                    continue
                text_delta = record_gemini_stream_payload(state, payload_chunk)
                if not role_sent:
                    yield openai_stream_chunk(
                        request_id=state.request_id,
                        model_id=model.id,
                        created=created,
                        delta={"role": "assistant", "content": ""},
                        finish_reason=None,
                    )
                    role_sent = True
                if text_delta:
                    yield openai_stream_chunk(
                        request_id=state.request_id,
                        model_id=model.id,
                        created=created,
                        delta={"content": text_delta},
                        finish_reason=None,
                    )
    yield openai_stream_chunk(
        request_id=state.request_id,
        model_id=model.id,
        created=created,
        delta={},
        finish_reason=state.finish_reason,
    )
    yield b"data: [DONE]\n\n"
