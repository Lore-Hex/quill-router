from __future__ import annotations

import datetime as dt
from collections.abc import Callable
from dataclasses import dataclass
from typing import Annotated

from fastapi import Depends, Request, Response

from trusted_router.config import Settings
from trusted_router.errors import api_error
from trusted_router.request_limits import enforce_authenticated_rate_limit
from trusted_router.scopes import SCOPE_INFERENCE
from trusted_router.storage import (
    STORE,
    ApiKey,
    ApiKeyAuthContext,
    SessionAuthContext,
    User,
    Workspace,
)
from trusted_router.types import ErrorType

SESSION_COOKIE_NAME = "tr_session"
# Companion non-HttpOnly hint cookie that marketing-chrome JS reads to swap
# the "Sign in" button for "Open console" when a user is logged in. Carries
# no auth power — the real session is in HttpOnly `tr_session`. See
# set_session_cookie below for the rationale; this constant just gives the
# JS in static/dashboard.js a single source of truth for the name.
SIGNED_IN_HINT_COOKIE_NAME = "tr_signed_in"
# Cookie lifetime must match auth_session_ttl_seconds (30 days) — otherwise
# users get "signed out" the day after sign-in even though the server-side
# session is still valid for 30 days. Originally the cookie was 24h while
# the session TTL was 30 days; that mismatch was the 2026-05-23 bug where
# Gabriella reported "got signed out" the day after signup. The cookie
# itself is the source of truth for the browser; if it expires, the user
# loses access regardless of how long the DB session record is alive.
#
# 30 days is the session-record TTL set on every new session in
# storage_auth_sessions.create_auth_session, driven by
# settings.auth_session_ttl_seconds. Keeping these two numbers in lockstep
# is the right operational discipline; we hard-code the cookie max_age to
# the same constant so a future change has to touch both. If you ever
# extend the session TTL further (e.g. to 90 days), bump this in lockstep.
SESSION_COOKIE_MAX_AGE = 60 * 60 * 24 * 30  # 30d — matches auth_session_ttl_seconds default

# Bearer-token prefix dispatch. The two shapes are minted with distinct
# prefixes (security.py:new_api_key default = "sk-tr-v1";
# storage_auth_sessions.py:create uses "trsess-v1") so we can route
# without ever calling the wrong store.
_API_KEY_BEARER_PREFIX = "sk-tr-"
_SESSION_BEARER_PREFIX = "trsess-"


@dataclass(frozen=True)
class Principal:
    user: User | None
    workspace: Workspace
    api_key: ApiKey | None
    is_management: bool
    scopes: frozenset[str]


def bootstrap_management_key(settings: Settings) -> ApiKey | None:
    raw = settings.bootstrap_management_key
    if not raw:
        return None
    existing = STORE.get_key_by_raw(raw)
    if existing is not None:
        return existing
    user = STORE.ensure_user("local-admin", email="local-admin@trustedrouter.local")
    workspace = STORE.list_workspaces_for_user(user.id)[0]
    _, key = STORE.create_api_key(
        workspace_id=workspace.id,
        name="Bootstrap management key",
        creator_user_id=user.id,
        raw_key=raw,
        management=True,
    )
    return key


def get_authorization_bearer(request: Request) -> str | None:
    header = request.headers.get("authorization", "")
    if not header.lower().startswith("bearer "):
        return None
    return header.split(" ", 1)[1].strip()


def principal_from_request(request: Request, settings: Settings) -> Principal:
    """Resolve the caller's `Principal` from one of three credential
    sources. Sources are tried in order:
        1. dev-user header (local/test only)
        2. session cookie (browser console)
        3. Authorization bearer (API clients + bearer-shaped sessions)

    For the bearer path, the token shape is dispatched by prefix:
        sk-tr-...    → API-key lookup ONLY
        trsess-...   → session-token lookup ONLY
        anything else → 401 "Bearer token has unrecognized shape"

    The previous version tried API-key first and silently fell back to
    session-token semantics on the same string. That was correct for
    well-formed inputs but made the error path ambiguous: a bearer
    that was neither shape produced "Invalid API key" even though the
    token might have been a typo'd session id. Prefix dispatch makes
    each path own its own error and removes any cross-shape coupling.
    """
    dev_user_id = request.headers.get("x-trustedrouter-user")
    if dev_user_id:
        return _principal_from_dev_header(request, settings, dev_user_id)

    raw_bearer = get_authorization_bearer(request)
    cookie_token = request.cookies.get(SESSION_COOKIE_NAME)
    if not raw_bearer and cookie_token:
        # Browser console only ever sends the cookie. Resolve as a session;
        # don't fall through to the API-key lookup since we don't have a
        # bearer to look up.
        session_context = STORE.session_auth_context(
            cookie_token,
            requested_workspace_id=(request.headers.get("x-trustedrouter-workspace") or None),
        )
        if session_context is None:
            raise api_error(401, "Invalid session", "unauthorized")
        principal = _principal_for_session(request, session_context)
        enforce_authenticated_rate_limit(
            request,
            settings,
            credential_kind="session",
            stable_subject=session_context.session.lookup_hash,
        )
        return principal
    if not raw_bearer:
        raise api_error(401, "Missing Authentication header", "unauthorized")

    bootstrap_management_key(settings)

    if raw_bearer.startswith(_API_KEY_BEARER_PREFIX):
        api_key_context = STORE.api_key_auth_context(raw_bearer)
        if api_key_context is None:
            raise api_error(401, "Invalid API key", "unauthorized")
        principal = _principal_for_api_key(api_key_context)
        enforce_authenticated_rate_limit(
            request,
            settings,
            credential_kind="api_key",
            stable_subject=api_key_context.api_key.lookup_hash,
        )
        return principal

    if raw_bearer.startswith(_SESSION_BEARER_PREFIX):
        # Bearer-shaped session token. Used by management programs that
        # prefer a bearer header over the browser session cookie.
        session_context = STORE.session_auth_context(
            raw_bearer,
            requested_workspace_id=(request.headers.get("x-trustedrouter-workspace") or None),
        )
        if session_context is None:
            raise api_error(401, "Invalid session token", "unauthorized")
        principal = _principal_for_session(request, session_context)
        enforce_authenticated_rate_limit(
            request,
            settings,
            credential_kind="session",
            stable_subject=session_context.session.lookup_hash,
        )
        return principal

    # Neither shape matched. Don't claim "Invalid API key" — the token
    # was never API-key-shaped to begin with. Surface the actual issue
    # so callers debugging a malformed bearer don't chase the wrong
    # ghost.
    raise api_error(
        401,
        "Bearer token has unrecognized shape (expected sk-tr-... or trsess-...)",
        "unauthorized",
    )


def _principal_from_dev_header(
    request: Request,
    settings: Settings,
    dev_user_id: str,
) -> Principal:
    if settings.environment.lower() not in {"local", "test"}:
        raise api_error(401, "User header auth is disabled in production", "unauthorized")
    user = STORE.ensure_user(dev_user_id)
    workspace = _resolve_workspace_for_user(
        request,
        user.id,
        suggested_workspace_id=None,
    )
    principal = Principal(
        user=user,
        workspace=workspace,
        api_key=None,
        is_management=STORE.user_can_manage(user.id, workspace.id),
        scopes=frozenset(),
    )
    enforce_authenticated_rate_limit(
        request,
        settings,
        credential_kind="dev_user",
        stable_subject=user.id,
    )
    return principal


def _principal_for_session(
    request: Request,
    context: SessionAuthContext,
) -> Principal:
    # The state gate lives here rather than at each call site so that every
    # conversion from a session into an authenticated principal enforces one
    # invariant. It used to sit only on the cookie branch, so the same
    # `trsess-` string was rejected as a cookie and accepted as a bearer — and
    # no storage backend filters by state, they all check lookup, expiry and
    # token hash only. Note this is deliberately not pushed down into
    # get_auth_session_by_raw: the pending-email attach flow needs to fetch a
    # pending session directly, it just must not get a principal from one.
    session = context.session
    if session.state != "active":
        raise api_error(401, "Invalid session", "unauthorized")
    user = context.user
    if user is None:
        raise api_error(401, "Invalid session", "unauthorized")
    selected_workspace_id = request.headers.get("x-trustedrouter-workspace") or session.workspace_id
    workspace = context.workspace
    if workspace is None or not context.is_member:
        if selected_workspace_id:
            raise api_error(403, "Forbidden", "forbidden")
        raise api_error(403, "Workspace is unavailable", "forbidden")
    return Principal(
        user=user,
        workspace=workspace,
        api_key=None,
        is_management=context.is_management,
        scopes=frozenset(),
    )


def _principal_for_api_key(context: ApiKeyAuthContext) -> Principal:
    api_key = context.api_key
    if api_key.disabled:
        raise api_error(401, "Invalid API key", "unauthorized")
    if is_api_key_expired(api_key.expires_at):
        raise api_error(401, "API key expired", "unauthorized")
    workspace = context.workspace
    if workspace is None:
        raise api_error(403, "Workspace is unavailable", "forbidden")
    return Principal(
        user=None,
        workspace=workspace,
        api_key=api_key,
        is_management=api_key.management,
        scopes=frozenset(api_key.scopes),
    )


def _resolve_workspace_for_user(
    request: Request,
    user_id: str,
    *,
    suggested_workspace_id: str | None,
) -> Workspace:
    """Pick the workspace the caller wants to act on. Header wins, session-
    bound workspace is the fallback, then the user's first membership."""
    workspace_id = request.headers.get("x-trustedrouter-workspace") or suggested_workspace_id
    if workspace_id:
        workspace = STORE.get_workspace(workspace_id)
        if workspace is None or not STORE.user_is_member(user_id, workspace_id):
            raise api_error(403, "Forbidden", "forbidden")
        return workspace
    workspaces = STORE.list_workspaces_for_user(user_id)
    if not workspaces:
        raise api_error(403, "Workspace is unavailable", "forbidden")
    return workspaces[0]


def settings_from_request(request: Request) -> Settings:
    """Pull the per-app `Settings` instance set by `create_app`. Lets auth and
    route handlers depend on `Settings` via FastAPI DI without each one
    needing its own wrapper."""
    return request.app.state.settings


SettingsDep = Annotated[Settings, Depends(settings_from_request)]


def _assert_principal_scope(principal: Principal, scope: str) -> None:
    if principal.api_key is None or not principal.scopes:
        return
    if scope not in principal.scopes:
        raise api_error(
            403,
            f"API key is missing required scope: {scope}",
            ErrorType.INSUFFICIENT_SCOPE,
        )


def require_scope(scope: str) -> Callable[[Request, SettingsDep], Principal]:
    """Build a dependency that scopes API keys but never human sessions."""

    def dependency(request: Request, settings: SettingsDep) -> Principal:
        principal = principal_from_request(request, settings)
        _assert_principal_scope(principal, scope)
        return principal

    return dependency


def require_management(
    request: Request,
    settings: SettingsDep,
) -> Principal:
    principal = principal_from_request(request, settings)
    if not principal.is_management:
        raise api_error(
            403,
            "Only management keys can perform this operation",
            ErrorType.FORBIDDEN,
        )
    if principal.api_key is not None and principal.scopes:
        raise api_error(
            403,
            "No delegated scope grants management access",
            ErrorType.INSUFFICIENT_SCOPE,
        )
    return principal


def require_inference_key(
    request: Request,
    settings: SettingsDep,
) -> Principal:
    principal = principal_from_request(request, settings)
    if principal.api_key is None:
        raise api_error(403, "An inference API key is required", ErrorType.FORBIDDEN)
    _assert_principal_scope(principal, SCOPE_INFERENCE)
    return principal


def require_authenticated(
    request: Request,
    settings: SettingsDep,
) -> Principal:
    """Allow either an inference key or a management session. Used by
    workspace-scoped read-only endpoints (e.g. /v1/generation) where
    OpenRouter accepts the same key the caller used for the chat
    completion. forty.news and other OpenRouter-shaped clients post
    /chat/completions and then GET /generation?id=<id> with the SAME
    bearer token; rejecting the lookup forces a per-call key swap that
    OpenRouter doesn't require."""
    principal = principal_from_request(request, settings)
    if principal.api_key is None and not principal.is_management:
        raise api_error(403, "Authentication required", ErrorType.FORBIDDEN)
    return principal


ManagementPrincipal = Annotated[Principal, Depends(require_management)]
InferencePrincipal = Annotated[Principal, Depends(require_inference_key)]
AuthenticatedPrincipal = Annotated[Principal, Depends(require_authenticated)]


def is_api_key_expired(expires_at: str | None) -> bool:
    if not expires_at:
        return False
    normalized = expires_at.replace("Z", "+00:00")
    try:
        parsed = dt.datetime.fromisoformat(normalized)
    except ValueError:
        return True
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=dt.UTC)
    return parsed <= dt.datetime.now(dt.UTC)


def set_session_cookie(response: Response, raw_token: str, settings: Settings) -> None:
    """Attach the active session cookie to a response. HttpOnly + SameSite=Lax;
    Secure is enabled in production so cookies are never sent over plain HTTP.

    We ALSO set a companion non-HttpOnly hint cookie `tr_signed_in=1` with the
    same TTL. The marketing-chrome JS (static/dashboard.js) reads this via
    `document.cookie` to swap the prominent "Sign in" button for an
    "Open console" link on every public page. Without this hint, a logged-in
    user who clicks a marketing-chrome link (e.g. /models) sees the Sign-in
    button still up there and concludes they were signed out — which is what
    Gabriella reported on 2026-05-23. The hint carries no auth power (the
    real session is in HttpOnly `tr_session`); it's a pure UI bit, so leaking
    it via document.cookie is fine.
    """
    response.set_cookie(
        key=SESSION_COOKIE_NAME,
        value=raw_token,
        max_age=SESSION_COOKIE_MAX_AGE,
        httponly=True,
        secure=settings.environment.lower() not in {"local", "test"},
        samesite="lax",
        path="/",
    )
    response.set_cookie(
        key=SIGNED_IN_HINT_COOKIE_NAME,
        value="1",
        max_age=SESSION_COOKIE_MAX_AGE,
        httponly=False,  # JS reads this on marketing pages — that's the point
        secure=settings.environment.lower() not in {"local", "test"},
        samesite="lax",
        path="/",
    )


def clear_session_cookie(response: Response, settings: Settings) -> None:
    response.delete_cookie(
        key=SESSION_COOKIE_NAME,
        path="/",
        secure=settings.environment.lower() not in {"local", "test"},
        samesite="lax",
    )
    # Clear the hint too so the next marketing-page load reverts to "Sign in"
    response.delete_cookie(
        key=SIGNED_IN_HINT_COOKIE_NAME,
        path="/",
        secure=settings.environment.lower() not in {"local", "test"},
        samesite="lax",
    )
