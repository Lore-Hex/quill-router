"""Privacy-posture logic for catalog providers and endpoints.

The PRIVACY_TIER_* integer values are stable API vocabulary. They are not an
implication ladder for raw technical flags: confidential compute describes
where plaintext is processed, while ZDR describes retention. The Confidential
product tier requires verified compute, E2EE and explicit ZDR together, from a
host that is not the model's own vendor. The TR gateway hop is always attested;
these values describe the upstream provider.
Split out of the catalog.py god-module (#38); this module
depends only on the catalog_data leaf and therefore cannot create a cycle.
"""

from __future__ import annotations

from trusted_router.catalog_data import (
    _MODEL_PROVIDER_PRIVACY_OVERRIDES,
    _PHALA_STANDARD_PASSTHROUGH_PRIVACY_OVERRIDE,
    PRIVACY_TIER_CONFIDENTIAL,
    PRIVACY_TIER_NO_STORE,
    PRIVACY_TIER_STANDARD,
    PRIVACY_TIER_ZERO_RETENTION,
    PROVIDERS,
    ModelEndpoint,
    ModelProviderPrivacyOverride,
    Provider,
    model_vendor_provider_slugs,
)
from trusted_router.wafer_policy import wafer_zdr_support


def provider_confidential_inference(provider: Provider, *, prepaid: bool = False) -> bool:
    """Qualify a provider claim; prepaid ZDR applies only when explicitly selected."""
    return (
        provider.provider_confidential_compute is True
        and provider.provider_e2ee is True
        and (
            provider.provider_zero_data_retention is True
            or (prepaid and provider.prepaid_zero_data_retention is True)
        )
    )


def provider_privacy_tier(provider: Provider) -> int:
    """Return the provider's primary display posture.

    Enforcement must use ``endpoint_meets_privacy_requirement`` rather than
    comparing this value numerically.
    """
    if provider_confidential_inference(provider):
        return PRIVACY_TIER_CONFIDENTIAL
    if provider.provider_zero_data_retention:
        return PRIVACY_TIER_ZERO_RETENTION
    if provider.stores_content is False:
        return PRIVACY_TIER_NO_STORE
    return PRIVACY_TIER_STANDARD


def _model_provider_privacy_override(
    model_id: str, provider_slug: str
) -> ModelProviderPrivacyOverride | None:
    override = _MODEL_PROVIDER_PRIVACY_OVERRIDES.get(
        (model_id, provider_slug)
    ) or _MODEL_PROVIDER_PRIVACY_OVERRIDES.get((model_id, "*"))
    if override is not None or provider_slug != "wafer":
        return override

    zdr_supported = wafer_zdr_support(model_id)
    if zdr_supported is None:
        return None
    return ModelProviderPrivacyOverride(
        privacy_tier=(PRIVACY_TIER_ZERO_RETENTION if zdr_supported else PRIVACY_TIER_STANDARD),
        provider_zero_data_retention=zdr_supported,
        provider_policy=(
            "Wafer's authenticated model catalog reports that this exact route "
            "supports request-scoped ZDR via Wafer-ZDR: required."
            if zdr_supported
            else "Wafer's authenticated model catalog does not report ZDR support "
            "for this exact route."
        ),
    )


def _endpoint_privacy_override(
    endpoint: ModelEndpoint,
) -> ModelProviderPrivacyOverride | None:
    if endpoint.provider == "phala":
        # Only the exact phala/* upstream namespace selects Phala's
        # Confidential AI route. Fail closed for missing or upstream-author
        # IDs so a newly discovered pass-through model cannot inherit the
        # provider-wide TEE/ZDR posture before a human reviews it.
        upstream_id = (endpoint.upstream_id or "").strip().casefold()
        if upstream_id.startswith("phala/"):
            return None
        return _PHALA_STANDARD_PASSTHROUGH_PRIVACY_OVERRIDE
    return _model_provider_privacy_override(endpoint.model_id, endpoint.provider)


def served_by_model_vendor(model_id: str, provider_slug: str) -> bool:
    """Whether this route delivers the prompt to the model's own vendor.

    A Confidential request never reaches the model vendor. TrustedRouter's own
    models are exempt: a Confidential request already trusts the attested
    gateway that TrustedRouter runs.
    """
    return provider_slug != "trustedrouter" and provider_slug in model_vendor_provider_slugs(
        model_id
    )


def model_provider_privacy_tier(model_id: str, provider_slug: str) -> int:
    tier = _model_provider_privacy_tier(model_id, provider_slug)
    if tier == PRIVACY_TIER_CONFIDENTIAL and served_by_model_vendor(model_id, provider_slug):
        # Confidential already required ZDR from this route.
        return PRIVACY_TIER_ZERO_RETENTION
    return tier


def _model_provider_privacy_tier(model_id: str, provider_slug: str) -> int:
    override = _model_provider_privacy_override(model_id, provider_slug)
    if (
        model_provider_confidential_compute(model_id, provider_slug) is True
        and model_provider_e2ee(model_id, provider_slug) is True
        and model_provider_zero_data_retention(model_id, provider_slug) is True
    ):
        return PRIVACY_TIER_CONFIDENTIAL
    if override is not None:
        if override.privacy_tier != PRIVACY_TIER_CONFIDENTIAL:
            return override.privacy_tier
        if model_provider_zero_data_retention(model_id, provider_slug) is True:
            return PRIVACY_TIER_ZERO_RETENTION
        return PRIVACY_TIER_NO_STORE if override.stores_content is False else PRIVACY_TIER_STANDARD
    return provider_privacy_tier(PROVIDERS[provider_slug])


def endpoint_privacy_tier(endpoint: ModelEndpoint) -> int:
    if endpoint_meets_privacy_requirement(endpoint, PRIVACY_TIER_CONFIDENTIAL):
        return PRIVACY_TIER_CONFIDENTIAL
    if endpoint_zero_data_retention(endpoint) is True:
        return PRIVACY_TIER_ZERO_RETENTION
    if not endpoint_stores_content(endpoint):
        return PRIVACY_TIER_NO_STORE
    return PRIVACY_TIER_STANDARD


def endpoint_stores_content(endpoint: ModelEndpoint) -> bool:
    """Return the retention posture for this exact provider/model route."""
    override = _endpoint_privacy_override(endpoint)
    if override is not None and override.stores_content is not None:
        return override.stores_content
    if endpoint_zero_data_retention(endpoint) is True:
        return False
    if override is not None and override.privacy_tier in {
        PRIVACY_TIER_NO_STORE,
        PRIVACY_TIER_ZERO_RETENTION,
    }:
        return False
    return PROVIDERS[endpoint.provider].stores_content


def endpoint_zero_data_retention(endpoint: ModelEndpoint) -> bool | None:
    """Return the ZDR guarantee that applies to this exact credential path.

    Read explicit route/provider/credential policy, never infer retention from
    TEE or E2EE. The Confidential tier consumes this result as a prerequisite;
    missing or false ZDR disqualifies the tier without changing technical flags.
    """
    override = _endpoint_privacy_override(endpoint)
    if override is not None and override.provider_zero_data_retention is not None:
        return override.provider_zero_data_retention
    provider = PROVIDERS[endpoint.provider]
    if endpoint.usage_type == "Credits" and provider.prepaid_zero_data_retention:
        return True
    return provider.provider_zero_data_retention


def endpoint_zero_data_retention_scope(endpoint: ModelEndpoint) -> str | None:
    """Describe why an endpoint qualifies without broadening the claim."""
    if endpoint_zero_data_retention(endpoint) is not True:
        return None
    override = _endpoint_privacy_override(endpoint)
    if override is not None and override.provider_zero_data_retention is True:
        return "model_endpoint"
    provider = PROVIDERS[endpoint.provider]
    if endpoint.usage_type == "Credits" and provider.prepaid_zero_data_retention:
        return "trustedrouter_prepaid"
    return "provider"


def model_provider_confidential_compute(model_id: str, provider_slug: str) -> bool | None:
    override = _model_provider_privacy_override(model_id, provider_slug)
    if override is not None and override.provider_confidential_compute is not None:
        return override.provider_confidential_compute
    return PROVIDERS[provider_slug].provider_confidential_compute


def model_provider_e2ee(model_id: str, provider_slug: str) -> bool | None:
    override = _model_provider_privacy_override(model_id, provider_slug)
    if override is not None and override.provider_e2ee is not None:
        return override.provider_e2ee
    return PROVIDERS[provider_slug].provider_e2ee


def endpoint_confidential_compute(endpoint: ModelEndpoint) -> bool | None:
    override = _endpoint_privacy_override(endpoint)
    if override is not None and override.provider_confidential_compute is not None:
        return override.provider_confidential_compute
    return PROVIDERS[endpoint.provider].provider_confidential_compute


def endpoint_e2ee(endpoint: ModelEndpoint) -> bool | None:
    override = _endpoint_privacy_override(endpoint)
    if override is not None and override.provider_e2ee is not None:
        return override.provider_e2ee
    return PROVIDERS[endpoint.provider].provider_e2ee


def endpoint_provider_policy(endpoint: ModelEndpoint) -> str:
    override = _endpoint_privacy_override(endpoint)
    if override is not None and override.provider_policy is not None:
        return override.provider_policy
    return PROVIDERS[endpoint.provider].provider_policy


def endpoint_provider_policy_url(endpoint: ModelEndpoint) -> str | None:
    override = _endpoint_privacy_override(endpoint)
    if override is not None and override.provider_policy_url is not None:
        return override.provider_policy_url
    return PROVIDERS[endpoint.provider].provider_policy_url


def endpoint_meets_privacy_requirement(endpoint: ModelEndpoint, requirement: int) -> bool:
    """Match one requested privacy guarantee without conflating dimensions.

    Confidential requires all three independent facts for the same endpoint:
    verified compute, provider E2EE, and explicit ZDR. Unknown fails closed.
    The model's own vendor never qualifies, whatever its flags.
    """
    if requirement == PRIVACY_TIER_STANDARD:
        return True
    if requirement == PRIVACY_TIER_NO_STORE:
        return not endpoint_stores_content(endpoint)
    if requirement == PRIVACY_TIER_ZERO_RETENTION:
        return endpoint_zero_data_retention(endpoint) is True
    if requirement == PRIVACY_TIER_CONFIDENTIAL:
        return (
            endpoint_confidential_compute(endpoint) is True
            and endpoint_e2ee(endpoint) is True
            and endpoint_zero_data_retention(endpoint) is True
            and not served_by_model_vendor(endpoint.model_id, endpoint.provider)
        )
    return False


def model_provider_zero_data_retention(model_id: str, provider_slug: str) -> bool | None:
    override = _model_provider_privacy_override(model_id, provider_slug)
    if override is not None and override.provider_zero_data_retention is not None:
        return override.provider_zero_data_retention
    return PROVIDERS[provider_slug].provider_zero_data_retention


def model_provider_policy(model_id: str, provider_slug: str) -> str:
    override = _model_provider_privacy_override(model_id, provider_slug)
    if override is not None and override.provider_policy is not None:
        return override.provider_policy
    return PROVIDERS[provider_slug].provider_policy


def model_provider_policy_url(model_id: str, provider_slug: str) -> str | None:
    override = _model_provider_privacy_override(model_id, provider_slug)
    if override is not None and override.provider_policy_url is not None:
        return override.provider_policy_url
    return PROVIDERS[provider_slug].provider_policy_url
