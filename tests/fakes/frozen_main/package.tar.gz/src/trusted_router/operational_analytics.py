"""Read-only ClickHouse adapter for operational metadata."""

# ruff: noqa: S608
# Identifiers are fixed constants and every request value is server-bound.

from __future__ import annotations

import dataclasses
import datetime as dt
import json
import re
from typing import Any, TypeVar

import httpx

from trusted_router.clickhouse_endpoints import (
    parse_endpoints,
    request_timeout,
    send_with_failover,
)
from trusted_router.client_reliability import tenant_client_reliability_summary
from trusted_router.storage_models import (
    Generation,
    ProviderBenchmarkSample,
    SyntheticProbeSample,
    SyntheticRollup,
)
from trusted_router.types import UsageType

_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
T = TypeVar("T")
PUBLIC_SNAPSHOT_QUERY_TIMEOUT_SECONDS = 2.0


def _identifier(value: str, *, label: str) -> str:
    if _IDENTIFIER.fullmatch(value) is None:
        raise ValueError(f"{label} must be a ClickHouse identifier")
    return value


def _iso(value: Any) -> str:
    text = str(value)
    if text.endswith("Z") or "+" in text[10:]:
        return text
    return text.replace(" ", "T") + "Z"


class OperationalAnalyticsClient:
    """Fixed, parameterized reads over replicated ClickHouse tables."""

    def __init__(
        self,
        *,
        base_url: str,
        user: str,
        password: str,
        database: str = "tr",
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        # One URL, or an ordered comma-separated list: see clickhouse_endpoints.
        self._endpoints = parse_endpoints(base_url)
        if not self._endpoints:
            raise ValueError("operational analytics ClickHouse URL is required")
        self._user = user
        self._password = password
        self._database = _identifier(database, label="database")
        self._transport = transport

    def _query(
        self,
        sql: str,
        *,
        params: dict[str, str | int] | None = None,
        timeout_seconds: float = 20.0,
    ) -> list[dict[str, Any]]:
        query_params: dict[str, str] = {"database": self._database}
        for key, value in (params or {}).items():
            query_params[f"param_{key}"] = str(value)
        with httpx.Client(
            auth=(self._user, self._password),
            timeout=request_timeout(self._endpoints, timeout_seconds),
            transport=self._transport,
        ) as client:
            response = send_with_failover(
                client,
                self._endpoints,
                lambda endpoint: client.build_request(
                    "POST",
                    endpoint,
                    params=query_params,
                    content=sql,
                    headers={"content-type": "text/plain; charset=utf-8"},
                ),
            )
            response.raise_for_status()
            payload = response.json()
        rows = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(rows, list):
            raise RuntimeError("ClickHouse response did not contain data rows")
        return [dict(row) for row in rows if isinstance(row, dict)]

    def benchmark_samples(
        self,
        *,
        date: str | None = None,
        provider: str | None = None,
        model: str | None = None,
        limit: int = 1000,
    ) -> list[ProviderBenchmarkSample]:
        clauses: list[str] = []
        params: dict[str, str | int] = {"limit": max(1, limit)}
        if date is not None:
            clauses.append("toDate(created_at) = toDate({date:String})")
            params["date"] = date
        if provider is not None:
            clauses.append("provider = {provider:String}")
            params["provider"] = provider
        if model is not None:
            clauses.append("model = {model:String}")
            params["model"] = model
        where = " AND ".join(clauses) if clauses else "1"
        rows = self._query(
            """
SELECT
  id, model, provider, provider_name, status, usage_type, streamed,
  input_tokens, output_tokens, total_cost_microdollars,
  speed_tokens_per_second, elapsed_milliseconds,
  first_token_milliseconds, ttfb_milliseconds, finish_reason,
  error_type, error_status, error_message, region, source, app, created_at
FROM provider_benchmark_samples FINAL
WHERE """
            + where
            + """
ORDER BY created_at DESC
LIMIT {limit:UInt32}
FORMAT JSON
""",
            params=params,
        )
        return [_benchmark_sample(row) for row in rows]

    def balanced_benchmark_samples(
        self,
        *,
        cutoff: str | None,
        per_provider_limit: int,
        limit: int,
    ) -> list[ProviderBenchmarkSample]:
        """Read one provider-balanced window without application-side fanout."""
        params: dict[str, str | int] = {
            "per_provider_limit": max(1, per_provider_limit),
            "limit": max(1, limit),
        }
        where = "1"
        if cutoff is not None:
            where = "created_at >= parseDateTime64BestEffort({cutoff:String}, 3)"
            params["cutoff"] = cutoff
        rows = self._query(
            """
SELECT
  id, model, provider, provider_name, status, usage_type, streamed,
  input_tokens, output_tokens, total_cost_microdollars,
  speed_tokens_per_second, elapsed_milliseconds,
  first_token_milliseconds, ttfb_milliseconds, finish_reason,
  error_type, error_status, error_message, region, source, app, created_at
FROM
(
  SELECT *, row_number() OVER (
    PARTITION BY provider ORDER BY created_at DESC, id DESC
  ) AS provider_rank
  FROM provider_benchmark_samples FINAL
  WHERE """
            + where
            + """
)
WHERE provider_rank <= {per_provider_limit:UInt32}
ORDER BY created_at DESC, id DESC
LIMIT {limit:UInt32}
FORMAT JSON
""",
            params=params,
        )
        return [_benchmark_sample(row) for row in rows]

    def route_benchmark_samples(
        self,
        *,
        cutoff: str,
        per_route_limit: int,
        limit: int,
    ) -> list[ProviderBenchmarkSample]:
        """Read a bounded recent window for every synthetic provider/model route."""
        rows = self._query(
            """
SELECT
  id, model, provider, provider_name, status, usage_type, streamed,
  input_tokens, output_tokens, total_cost_microdollars,
  speed_tokens_per_second, elapsed_milliseconds,
  first_token_milliseconds, ttfb_milliseconds, finish_reason,
  error_type, error_status, error_message, region, source, app, created_at
FROM
(
  SELECT *, row_number() OVER (
    PARTITION BY provider, model ORDER BY created_at DESC, id DESC
  ) AS route_rank
  FROM provider_benchmark_samples FINAL
  WHERE source = 'synthetic'
    AND created_at >= parseDateTime64BestEffort({cutoff:String}, 3)
)
WHERE route_rank <= {per_route_limit:UInt32}
ORDER BY created_at DESC, id DESC
LIMIT {limit:UInt32}
FORMAT JSON
""",
            params={
                "cutoff": cutoff,
                "per_route_limit": max(1, per_route_limit),
                "limit": max(1, limit),
            },
        )
        return [_benchmark_sample(row) for row in rows]

    def route_workspaces(
        self, *, provider: str, model: str, start_at: str, end_at: str,
    ) -> list[str]:
        """Workspaces with a generation on this exact route in [start, end).

        Read the same activity table as /v1/activity, without its recent-row
        limit: a busy workspace must not hide another workspace's one call.
        Only workspace ids leave ClickHouse; no keys or content are selected.
        """
        rows = self._query(
            """
SELECT DISTINCT workspace_id
FROM activity_generations FINAL
WHERE provider = {provider:String} AND model = {model:String}
  AND created_at >= parseDateTime64BestEffort({start_at:String}, 3)
  AND created_at < parseDateTime64BestEffort({end_at:String}, 3)
  AND workspace_id != ''
ORDER BY workspace_id
FORMAT JSON
""",
            params={"provider": provider, "model": model, "start_at": start_at, "end_at": end_at},
        )
        return [str(row["workspace_id"]) for row in rows]

    def activity_generations(
        self,
        *,
        tenant_id: str,
        key_id: str | None = None,
        tag_key: str | None = None,
        tag_value: str | None = None,
        date: str | None = None,
        start_at: str | None = None,
        end_at: str | None = None,
        limit: int = 5001,
    ) -> list[Generation]:
        clauses = ["tenant_id = {tenant_id:String}"]
        params: dict[str, str | int] = {
            "tenant_id": tenant_id,
            "limit": max(1, limit),
        }
        if date is not None:
            clauses.append("toDate(created_at) = toDate({date:String})")
            params["date"] = date
        if key_id is not None:
            clauses.append("key_id = {key_id:String}")
            params["key_id"] = key_id
        if tag_key is not None:
            clauses.append("mapContains(tags, {tag_key:String})")
            params["tag_key"] = tag_key
            if tag_value is not None:
                clauses.append("tags[{tag_key:String}] = {tag_value:String}")
                params["tag_value"] = tag_value
        if start_at is not None:
            clauses.append("created_at >= parseDateTime64BestEffort({start_at:String}, 3)")
            params["start_at"] = start_at
        if end_at is not None:
            clauses.append("created_at < parseDateTime64BestEffort({end_at:String}, 3)")
            params["end_at"] = end_at
        rows = self._query(
            """
SELECT
  generation_id, request_id, key_id, model, provider, provider_name, app,
  tokens_prompt, tokens_completion, cached_input_tokens, reasoning_tokens,
  total_cost_microdollars, usage_type, speed_tokens_per_second,
  finish_reason, status, streamed, usage_estimated, elapsed_milliseconds,
  first_token_milliseconds, ttfb_milliseconds, region, user, session_id,
  http_referer, app_categories, tags, created_at
FROM activity_generations FINAL
WHERE """
            + " AND ".join(clauses)
            + """
ORDER BY created_at DESC
LIMIT {limit:UInt32}
FORMAT JSON
""",
            params=params,
        )
        return [_generation(row, tenant_id=tenant_id) for row in rows]

    def client_reliability_summary(
        self,
        tenant_id_surrogate: str,
        *,
        window_minutes: int,
    ) -> dict[str, Any]:
        rows = self._query(
            """
SELECT
  period, host, endpoint, sdk, requests, successes, tr_fault_failures,
  excluded_failures, aborted, attempts, attempt_tr_fault, failover_used,
  first_attempt_success, total_ms_hist, first_event_ms_hist
FROM client_availability_rollups FINAL
WHERE scope = 'tenant'
  AND tenant_id = {tenant_id:String}
  AND period IN ('5m', 'hour')
  AND period_start >= now() - INTERVAL {window_minutes:UInt32} MINUTE
  AND endpoint = ''
  AND sdk = ''
ORDER BY period_start DESC, host
FORMAT JSON
""",
            params={
                "tenant_id": tenant_id_surrogate,
                "window_minutes": max(1, window_minutes),
            },
        )
        return tenant_client_reliability_summary(
            rows,
            window_minutes=max(1, window_minutes),
        )

    def client_events_recent(
        self,
        tenant_id_surrogate: str,
        *,
        since: dt.datetime,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        if since.tzinfo is None:
            since = since.replace(tzinfo=dt.UTC)
        else:
            since = since.astimezone(dt.UTC)
        normalized_limit = max(1, min(limit, 50))
        rows = self._query(
            """
SELECT
  created_at, endpoint, model, attempt_host, attempt_count, final_outcome,
  final_http_status, first_error_class, sdk, sdk_version, attempt_request_id
FROM client_request_events FINAL
WHERE tenant_id = {tenant_id:String}
  AND created_at >= parseDateTime64BestEffort({since:String}, 3)
  AND final_outcome != 'ok'
ORDER BY created_at DESC
LIMIT {limit:UInt32}
FORMAT JSON
""",
            params={
                "tenant_id": tenant_id_surrogate,
                "since": since.isoformat().replace("+00:00", "Z"),
                "limit": normalized_limit,
            },
        )
        return [_client_event(row) for row in rows]

    def synthetic_samples(
        self,
        *,
        date: str | None = None,
        target: str | None = None,
        probe_type: str | None = None,
        monitor_region: str | None = None,
        limit: int = 1000,
    ) -> list[SyntheticProbeSample]:
        clauses: list[str] = []
        params: dict[str, str | int] = {"limit": max(1, limit)}
        for column, value in (
            ("target", target),
            ("probe_type", probe_type),
            ("monitor_region", monitor_region),
        ):
            if value is not None:
                clauses.append(f"{column} = {{{column}:String}}")
                params[column] = value
        if date is not None:
            clauses.append("toDate(created_at) = toDate({date:String})")
            params["date"] = date
        where = " AND ".join(clauses) if clauses else "1"
        rows = self._query(
            "SELECT * EXCEPT ingest_version FROM synthetic_probe_samples FINAL "
            f"WHERE {where} ORDER BY created_at DESC LIMIT {{limit:UInt32}} FORMAT JSON",
            params=params,
        )
        return [_dataclass_from_row(SyntheticProbeSample, row) for row in rows]

    def synthetic_rollups(
        self,
        *,
        period: str | None = None,
        since: str | None = None,
        until: str | None = None,
        include_histograms: bool = True,
        limit: int = 1000,
    ) -> list[SyntheticRollup]:
        clauses: list[str] = []
        params: dict[str, str | int] = {"limit": max(1, limit)}
        if period is not None:
            clauses.append("period = {period:String}")
            params["period"] = period
        if since is not None:
            clauses.append("period_start >= parseDateTimeBestEffort({since:String})")
            params["since"] = since
        if until is not None:
            clauses.append("period_start <= parseDateTimeBestEffort({until:String})")
            params["until"] = until
        where = " AND ".join(clauses) if clauses else "1"
        rows = self._query(
            "SELECT * EXCEPT ingest_version FROM synthetic_status_rollups FINAL "
            f"WHERE {where} ORDER BY period_start DESC LIMIT {{limit:UInt32}} FORMAT JSON",
            params=params,
        )
        rollups = [_dataclass_from_row(SyntheticRollup, row) for row in rows]
        if not include_histograms:
            rollups = [
                dataclasses.replace(
                    rollup,
                    latency_histogram={},
                    ttfb_histogram={},
                    dns_histogram={},
                    tcp_connect_histogram={},
                    tls_handshake_histogram={},
                    gateway_processing_histogram={},
                )
                for rollup in rollups
            ]
        return rollups

    def public_snapshot(self, name: str) -> dict[str, Any] | None:
        if name not in {
            "leaderboard",
            "leaderboard_evidence",
            "apps",
            "video_leaderboard",
            "status_inputs",
            "client_reliability",
        }:
            raise ValueError("unsupported public analytics snapshot")
        rows = self._query(
            """
SELECT payload
FROM public_analytics_snapshots FINAL
WHERE name = {name:String}
ORDER BY generated_at DESC
LIMIT 1
FORMAT JSON
""",
            params={"name": name},
            timeout_seconds=PUBLIC_SNAPSHOT_QUERY_TIMEOUT_SECONDS,
        )
        if not rows:
            return None
        payload = json.loads(str(rows[0].get("payload") or "{}"))
        return payload if isinstance(payload, dict) else None


def _dataclass_from_row(cls: type[T], row: dict[str, Any]) -> T:
    allowed = {field.name for field in dataclasses.fields(cls)}  # type: ignore[arg-type]
    payload = {key: value for key, value in row.items() if key in allowed}
    if cls is SyntheticProbeSample:
        for key in ("connection_reused", "output_match"):
            if payload.get(key) is not None:
                payload[key] = bool(payload[key])
    if cls is SyntheticRollup and payload.get("target_region") == "":
        payload["target_region"] = None
    for key in ("created_at", "period_start", "updated_at", "last_checked_at"):
        if payload.get(key) is not None:
            payload[key] = _iso(payload[key])
    return cls(**payload)


def _benchmark_sample(row: dict[str, Any]) -> ProviderBenchmarkSample:
    row = dict(row)
    row["created_at"] = _iso(row["created_at"])
    row["streamed"] = bool(row["streamed"])
    return _dataclass_from_row(ProviderBenchmarkSample, row)


def _generation(row: dict[str, Any], *, tenant_id: str) -> Generation:
    return Generation(
        id=str(row["generation_id"]),
        request_id=str(row["request_id"]),
        workspace_id=tenant_id,
        key_hash=str(row["key_id"]),
        model=str(row["model"]),
        provider_name=str(row["provider_name"]),
        app=str(row["app"]),
        tokens_prompt=int(row["tokens_prompt"]),
        tokens_completion=int(row["tokens_completion"]),
        total_cost_microdollars=int(row["total_cost_microdollars"]),
        usage_type=UsageType.coerce(row["usage_type"]),
        speed_tokens_per_second=float(row["speed_tokens_per_second"]),
        finish_reason=str(row["finish_reason"]),
        status=str(row["status"]),
        streamed=bool(row["streamed"]),
        usage_estimated=bool(row["usage_estimated"]),
        cached_input_tokens=int(row["cached_input_tokens"]),
        reasoning_tokens=int(row["reasoning_tokens"]),
        provider=str(row["provider"] or "") or None,
        elapsed_milliseconds=_optional_int(row.get("elapsed_milliseconds")),
        first_token_milliseconds=_optional_int(row.get("first_token_milliseconds")),
        ttfb_milliseconds=_optional_int(row.get("ttfb_milliseconds")),
        region=str(row["region"]) if row.get("region") is not None else None,
        user=str(row["user"]) if row.get("user") is not None else None,
        session_id=(
            str(row["session_id"]) if row.get("session_id") is not None else None
        ),
        http_referer=(
            str(row["http_referer"])
            if row.get("http_referer") is not None
            else None
        ),
        app_categories=[str(item) for item in row.get("app_categories") or []],
        tags={str(key): str(value) for key, value in (row.get("tags") or {}).items()},
        created_at=_iso(row["created_at"]),
    )


def _client_event(row: dict[str, Any]) -> dict[str, Any]:
    status = _optional_int(row.get("final_http_status"))
    return {
        "created_at": _iso(row.get("created_at")),
        "endpoint": str(row.get("endpoint") or ""),
        "model": str(row.get("model") or "") or None,
        "attempt_host": [str(item) for item in row.get("attempt_host") or []],
        "attempt_count": int(row.get("attempt_count") or 0),
        "final_outcome": str(row.get("final_outcome") or ""),
        "final_http_status": status if status else None,
        "first_error_class": str(row.get("first_error_class") or "") or None,
        "sdk": str(row.get("sdk") or ""),
        "sdk_version": str(row.get("sdk_version") or ""),
        "attempt_request_id": [
            str(item) for item in row.get("attempt_request_id") or [] if item
        ],
    }


def _optional_int(value: Any) -> int | None:
    return int(value) if value is not None else None
