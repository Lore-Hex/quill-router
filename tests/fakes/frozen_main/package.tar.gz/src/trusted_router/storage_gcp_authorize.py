"""Step 3b-3: the atomic gateway-authorize transaction (DML-only).

See docs/design/billing-typed-counters.md.

ONE Spanner read-write transaction (no mutation mixing) owns the whole authorize
decision, so a crash can never leak a hold (codex#1 #1):

  scoped idempotency read (+ fingerprint) ->
  conditional credit DML -> pause / spend-lease checks -> conditional key-cap DML ->
  tr_reservation INSERT (exact holds + hold usage type + authorization_id) ->
  gateway_authorization DML INSERT.

A rejection (insufficient credits / key cap) raises inside the callback, which
rolls the whole transaction back — releasing any hold already taken atomically,
no compensation needed. A duplicate idempotency_scope (concurrent first-call
loser) surfaces ALREADY_EXISTS (NOT retried); we re-read and REPLAY — no second
debit. Replay is resume/no-execute: the caller must NOT re-run the LLM call
(codex#2 #4).
"""

from __future__ import annotations

import logging
import threading
import time
import uuid
from collections import OrderedDict
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from google.api_core.exceptions import AlreadyExists, GoogleAPICallError

from trusted_router.app_markup_billing import (
    app_markup_microdollars_from_charge,
    app_markup_owner_share_microdollars,
    app_markup_payout_event_id,
)
from trusted_router.catalog import PROVIDERS, endpoint_for_id
from trusted_router.custom_model_billing import user_model_payout_event_id
from trusted_router.custom_model_markup_billing import (
    custom_model_markup_payout_event_id,
)
from trusted_router.spend_windows import (
    KeyWindowLimitDecision,
    KeyWindowLimitExceeded,
    decide_key_window_limits,
    utcnow,
    window_floors,
)
from trusted_router.stage_d import parse_pricing_snapshot
from trusted_router.storage_gcp_batch_dml import DmlStatement, execute_batch_dml
from trusted_router.storage_gcp_counter_dml import (
    KEY_ACCEPTED,
    KEY_INSUFFICIENT,
    KEY_MISSING,
    KEY_NO_HOLD,
    claim_reservation_statement,
    complete_reservation_retention,
    entity_insert_statement,
    read_reservation_by_idempotency,
    reservation_insert_statement,
    reserve_credit,
    reserve_credit_statement,
    reserve_credit_with_pause,
    reserve_key,
    reserve_key_statement,
)
from trusted_router.storage_gcp_counters import UNSHARDED
from trusted_router.storage_gcp_generation_records import (
    generation_insert_statement,
    insert_generation_record,
)
from trusted_router.storage_gcp_io import (
    TXN_BUDGET_SECONDS,
    _rollback_discarded_transaction,
    remaining_rpc_budget,
    run_in_transaction_with_retry,
    spanner_rpc_budget,
)
from trusted_router.storage_gcp_request_records import (
    complete_gateway_authorization_retention,
    gateway_authorization_insert_statement,
    gateway_authorization_settled_statement,
    mark_gateway_authorization_settled,
    read_gateway_authorization,
)
from trusted_router.storage_gcp_settle_outbox import (
    _GUARD_STATUS_SQL,
    GUARD_COUNT_SQL,
    done_retention_statements,
    intent_insert_counts,
    mark_done_unleased_tx,
    resolved_intent_statements,
    speculative_done_statements,
)
from trusted_router.storage_gcp_stage_d import (
    delivered_usage_charge_microdollars,
    delivered_usage_counts,
    normalized_delivered_prompt,
)
from trusted_router.storage_models import (
    AppMarkupPayout,
    CustomModelMarkupPayout,
    GatewayAuthorization,
    Generation,
    SettleOutboxRow,
    UserModelPayout,
)
from trusted_router.types import UsageType

log = logging.getLogger(__name__)

# A rejected conditional UPDATE keeps its row lock until the transaction rolls
# back. Scanning every configured shard therefore lets one depleted tenant turn
# N concurrent authorizations into N * shard_count contended row locks. Keep the
# hot transaction small; the caller retains the full shard set for its lock-free
# aggregate precheck and cold-path escrow rebalance.
MAX_CREDIT_SHARD_ATTEMPTS_PER_TRANSACTION = 4

# The one-commit settle is the fast path, not the durable one. Cap it well
# inside the settle route's 20 s Spanner budget: a contended or wedged attempt
# then still leaves the durable two-commit fallback about 15 s, while a normal
# commit (finalize p99 ~1.3 s in the slowest measured hour) never hits the cap.
ONE_COMMIT_SETTLE_BUDGET_SECONDS = 5.0


def bounded_credit_shard_candidates(candidates: tuple[int, ...]) -> tuple[int, ...]:
    """Return the fixed, pre-randomized hot-path subset for one transaction."""

    if not candidates:
        raise ValueError("credit_shard_candidates must not be empty")
    return candidates[:MAX_CREDIT_SHARD_ATTEMPTS_PER_TRANSACTION]


class AuthorizeOutcome:
    ACCEPTED = "accepted"
    REPLAY = "replay"  # idempotent replay: resume, do NOT re-execute
    INSUFFICIENT_CREDITS = "insufficient_credits"
    KEY_LIMIT_EXCEEDED = "key_limit_exceeded"
    KEY_MISSING = "key_missing"  # typed key row absent -> fail closed
    IDEMPOTENCY_MISMATCH = "idempotency_mismatch"  # same key, different request body
    KEY_WINDOW_LIMIT_EXCEEDED = "key_window_limit_exceeded"  # a daily/weekly/monthly cap


class AuthorizeVerdict(str):
    """String-compatible typed-authorize outcome with its window decision."""

    rate_limit: KeyWindowLimitDecision | None

    def __new__(
        cls,
        outcome: str,
        *,
        rate_limit: KeyWindowLimitDecision | None = None,
    ) -> AuthorizeVerdict:
        verdict = super().__new__(cls, outcome)
        verdict.rate_limit = rate_limit
        return verdict


class _Reject(Exception):
    """Roll the authorize transaction back with a terminal outcome (not retried)."""

    def __init__(self, outcome: str) -> None:
        self.outcome = outcome


class _RetrySequentialCreditReserve(GoogleAPICallError):
    """Discard the batch before sequential credit/pause classification.

    Use the same protected API-error rollback lifecycle as key misses.
    """


class _RetrySequentialKeyReserve(GoogleAPICallError):
    """Discard speculative rows before classifying a zero-row key hold.

    Use the API-error lifecycle deliberately: storage_gcp_io rolls back with an
    independent deadline floor, and the SDK then discards the transaction without
    sending another rollback (even if cleanup failed). A generic exception would
    let the SDK roll back inside the spent request budget and mask this signal.
    """


class _RetrySequentialFinalize(GoogleAPICallError):
    """Discard speculative T3 through protected rollback before rereading S11."""

    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.fallback_reason = reason
        self.rollback_started = time.monotonic()


EXHAUSTED = "exhausted"
HEADROOM = "headroom"
DEFER = "defer"


class ExhaustedKeyCache:
    """Bounded negative LRU; each hit must recheck the authoritative snapshot."""

    def __init__(self, *, max_entries: int = 4096) -> None:
        if max_entries < 1:
            raise ValueError("exhausted key cache max_entries must be positive")
        self._max_entries = max_entries
        self._entries: OrderedDict[str, None] = OrderedDict()
        self._lock = threading.Lock()

    def __contains__(self, key_hash: str) -> bool:
        with self._lock:
            if key_hash not in self._entries:
                return False
            self._entries.move_to_end(key_hash)
            return True

    def contains(self, key_hash: str) -> bool:
        return key_hash in self

    def add(self, key_hash: str) -> None:
        with self._lock:
            self._entries[key_hash] = None
            self._entries.move_to_end(key_hash)
            while len(self._entries) > self._max_entries:
                self._entries.popitem(last=False)

    def discard(self, key_hash: str) -> None:
        with self._lock:
            self._entries.pop(key_hash, None)

    def __len__(self) -> int:
        with self._lock:
            return len(self._entries)


def key_lifetime_cap_precheck(
    database: Any,
    param_types: Any,
    *,
    key_hash: str,
    estimate: int,
    has_credit_candidate: bool,
    shard_count: int = 1,
    idempotency_scope: str | None = None,
) -> str:
    """Recheck a cached rejection without locking credit, using reserve_key arithmetic.

    Each process learns from its first transactional rejection: one credit-row
    lock + rollback per exhausted key per process per headroom flip. Healthy
    keys never pay a snapshot. HEADROOM drops the entry; any existing reservation
    or read failure defers to the transaction and keeps it. This is conservative:
    it may pass a request the transaction refuses (which re-records the key), but
    must never refuse one it would accept, either per shard or after pooling.
    """
    pt = param_types
    try:
        with database.snapshot(multi_use=True) as snapshot:
            rows = list(
                snapshot.execute_sql(
                    "SELECT shard, limit_micro, usage, byok_usage, reserved, include_byok "
                    "FROM tr_key_limit WHERE key_hash=@kh "
                    "AND shard>=0 AND shard<@shard_count ORDER BY shard",
                    params={"kh": key_hash, "shard_count": shard_count},
                    param_types={"kh": pt.STRING, "shard_count": pt.INT64},
                )
            )
            if not rows or [int(row[0]) for row in rows] != list(range(shard_count)):
                return HEADROOM
            if any(row[1] is None or (not has_credit_candidate and not row[5]) for row in rows):
                return HEADROOM
            headroom = [
                int(limit_micro) - int(usage) - (int(byok_usage) if include_byok else 0) - int(reserved)
                for _, limit_micro, usage, byok_usage, reserved, include_byok in rows
            ]
            if max(headroom) >= estimate or sum(headroom) >= estimate:
                return HEADROOM
            if idempotency_scope is not None:
                existing = read_reservation_by_idempotency(snapshot, pt, idempotency_scope)
                if existing is not None:
                    return DEFER
            return EXHAUSTED
    except Exception:
        log.warning(
            "key lifetime-cap snapshot failed; deferring to authorize transaction key=%s",
            key_hash,
            exc_info=True,
        )
        return DEFER


def credit_exhaustion_precheck(
    database: Any,
    param_types: Any,
    *,
    workspace_id: str,
    estimate: int,
    idempotency_scope: str | None = None,
) -> str:
    """Recheck a cached insufficient-credit verdict without locking any credit row.

    The authorize transaction reserves ``estimate`` on the first credit shard whose
    ``total_credits - total_usage - reserved`` covers it, after the idempotency
    replay read and before the pause and key checks. A workspace that keeps
    retrying against an empty balance would otherwise lock a credit row and roll
    back on every request, which also delays settles that release that row's holds.

    It reads every credit shard the workspace has, never the process's cached
    shard count: after a split elsewhere that count can be stale for up to its
    TTL, and a funded shard beyond it would otherwise turn a payable request
    into a 402. EXHAUSTED only when no shard covers the estimate on its own and
    neither does the sum, so no bounded shard prefix and no rebalance could
    accept it. HEADROOM drops the cache entry; a pending reservation under this
    idempotency scope, a missing, non-contiguous or NULL row set, or a read
    failure defers to the transaction (HEADROOM or DEFER). Like
    the key lifetime-cap precheck this may pass a request the transaction refuses
    (which re-records the workspace) but must never refuse one it would accept.

    A workspace marked in debt (section 4.7) whose signed sum is negative is
    EXHAUSTED whatever one shard holds: every marked row refuses. A mark the
    sum no longer bears out is HEADROOM, so the transaction refuses and
    recover_credit heals it.
    """
    pt = param_types
    try:
        with database.snapshot(multi_use=True) as snapshot:
            rows = list(
                snapshot.execute_sql(
                    "SELECT shard, total_credits, total_usage, reserved, COALESCE(in_debt, FALSE) "
                    "FROM tr_credit_balance WHERE workspace_id=@pk ORDER BY shard",
                    params={"pk": workspace_id},
                    param_types={"pk": pt.STRING},
                )
            )
            if not rows or [int(row[0]) for row in rows] != list(range(len(rows))):
                return HEADROOM
            if any(value is None for row in rows for value in row[1:4]):
                return HEADROOM
            available = [
                int(total_credits) - int(total_usage) - int(reserved)
                for _, total_credits, total_usage, reserved, _marked in rows
            ]
            if any(bool(row[4]) for row in rows):
                if sum(available) >= 0:
                    return HEADROOM
            elif max(available) >= estimate or sum(available) >= estimate:
                return HEADROOM
            if idempotency_scope is not None:
                existing = read_reservation_by_idempotency(snapshot, pt, idempotency_scope)
                if existing is not None:
                    return DEFER
            return EXHAUSTED
    except Exception:
        log.warning(
            "credit exhaustion snapshot failed; deferring to authorize transaction workspace=%s",
            workspace_id,
            exc_info=True,
        )
        return DEFER


def key_window_limit_decision(
    database: Any,
    param_types: Any,
    *,
    key_hash: str,
    estimate: int,
    window_limits: dict[str, int],
    shard_count: int = 1,
    idempotency_scope: str | None = None,
    idempotency_fingerprint: str | None = None,
) -> KeyWindowLimitDecision | None:
    """Return the authoritative APPROXIMATE per-window key-cap decision.

    Runs on a lock-free SNAPSHOT, deliberately OUTSIDE the authorize read-write
    transaction: an in-txn shared read of tr_key_limit before reserve_key's
    conditional UPDATE would reintroduce the read-lock-upgrade deadlock surface
    the typed migration removed (codex #93). The wider race window this opens is
    within the accepted approximation (in-flight reserved is not counted either).

    Idempotent-replay preservation: a retry of an ALREADY-COMMITTED authorize
    must REPLAY, never 429 — so an existing same-fingerprint reservation makes
    this check a pass-through (the in-txn idempotency read stays the final
    authority). A missing typed row also passes through: reserve_key's in-txn
    classification fail-closes it as KEY_MISSING. When the configured set has
    multiple rows, usage is summed over every row and an incomplete set fails
    closed.

    The CALLER must omit windows that don't apply (e.g. a BYOK request on a key
    that excludes BYOK from its caps).
    """
    if shard_count < 1:
        raise ValueError("shard_count must be positive")
    pt = param_types
    with database.snapshot(multi_use=True) as snapshot:
        if idempotency_scope is not None:
            existing = read_reservation_by_idempotency(snapshot, pt, idempotency_scope)
            if (
                existing is not None
                and existing["idempotency_fingerprint"] == idempotency_fingerprint
            ):
                return None  # replayable — let the transaction replay it
        rows = list(
            snapshot.execute_sql(
                "SELECT shard, day_usage, day_start, week_usage, week_start, "
                "month_usage, month_start FROM tr_key_limit "
                "WHERE key_hash=@kh AND shard>=0 AND shard<@shard_count "
                "ORDER BY shard",
                params={"kh": key_hash, "shard_count": shard_count},
                param_types={"kh": pt.STRING, "shard_count": pt.INT64},
            )
        )
    if not rows:
        return None  # no typed row -> reserve_key fail-closes as KEY_MISSING
    if [int(row[0]) for row in rows] != list(range(shard_count)):
        raise RuntimeError("configured tr_key_limit usage shard set is incomplete")
    decision_now = utcnow()
    floors = window_floors(decision_now)
    # Pre-DDL rows read NULL usage; a NULL/stale start means the window rolled
    # over (or never started) = zero spend this window.
    current = {
        "daily": sum(
            int(row[1] or 0) for row in rows if row[2] is not None and row[2] >= floors["daily"]
        ),
        "weekly": sum(
            int(row[3] or 0) for row in rows if row[4] is not None and row[4] >= floors["weekly"]
        ),
        "monthly": sum(
            int(row[5] or 0) for row in rows if row[6] is not None and row[6] >= floors["monthly"]
        ),
    }
    return decide_key_window_limits(
        window_limits,
        current,
        estimate,
        now=decision_now,
    )


def check_key_window_limits(
    database: Any,
    param_types: Any,
    *,
    key_hash: str,
    estimate: int,
    window_limits: dict[str, int],
    shard_count: int = 1,
    idempotency_scope: str | None = None,
    idempotency_fingerprint: str | None = None,
) -> str | None:
    """Backward-compatible blocking-window view of the richer verdict."""
    decision = key_window_limit_decision(
        database,
        param_types,
        key_hash=key_hash,
        estimate=estimate,
        window_limits=window_limits,
        shard_count=shard_count,
        idempotency_scope=idempotency_scope,
        idempotency_fingerprint=idempotency_fingerprint,
    )
    if decision is None or decision.allowed:
        return None
    return decision.window


@spanner_rpc_budget(TXN_BUDGET_SECONDS)
def authorize_atomic(
    database: Any,
    param_types: Any,
    *,
    workspace_id: str,
    key_hash: str,
    estimate: int,
    has_credit_candidate: bool,
    reservation_usage_type: str,
    idempotency_scope: str | None,
    idempotency_fingerprint: str | None,
    expires_at: Any,
    build_authorization: Callable[[str, str], GatewayAuthorization] | None = None,
    build_auth_body: Callable[[str, str], str] | None = None,
    request_record_write_mode: str = "legacy",
    credit_shard: int = UNSHARDED,
    credit_shard_candidates: tuple[int, ...] | None = None,
    key_shard_candidates: tuple[int, ...] = (UNSHARDED,),
    skip_key_limit: bool = False,
    speculate_key_limit: bool = True,
    strict_budget: bool = False,
    enforce_strict_windows: bool = True,
    authorization_id: str | None = None,
    trust_settings: Any = None,
    created_at: datetime | None = None,
) -> dict:
    """Run the atomic authorize. Returns {outcome, reservation_id?, authorization_id?}.

    `request_record_write_mode="legacy"` preserves the generic tr_entities write
    during the expand rollout. `"typed"` writes the same authorization into the
    bounded typed table. The corresponding builder is required for the selected
    mode.
    `reservation_usage_type` is the HOLD usage type (Credits if any credit
    candidate, else BYOK). `has_credit_candidate` gates the credit hold.
    `credit_shard_candidates` is a bounded, pre-randomized order built outside
    the transaction so Spanner retries use the same order. The first shard with
    enough independent sub-budget is recorded durably on the reservation. The
    store wrapper applies `bounded_credit_shard_candidates`; direct callers must
    likewise pass no more than the hot-path limit.

    `skip_key_limit` is opt-in: the gateway's already-loaded ApiKey must have
    no lifetime cap, regardless of window caps checked by the caller. Omitted
    by older callers, it preserves the existing reserve SQL. The first candidate
    still receives settlement usage, with zero held, without an authorize read
    or write of tr_key_limit.

    `speculate_key_limit` only selects the transaction shape. Callers with
    already-loaded metadata can set it False for uncapped or BYOK-excluded keys.
    Unlike `skip_key_limit`, it retains every authoritative sequential check,
    including when that metadata is stale. Omission preserves speculation.

    Per-window key caps are checked by the CALLER via check_key_window_limits on
    a lock-free snapshot BEFORE this transaction — deliberately NOT in here: a
    shared read of tr_key_limit followed by reserve_key's conditional UPDATE on
    the same row would reintroduce the read-lock-upgrade surface this DML-only
    transaction exists to eliminate (codex #93 review).
    """
    pt = param_types
    if request_record_write_mode not in {"legacy", "typed"}:
        raise ValueError("request_record_write_mode must be 'legacy' or 'typed'")
    if request_record_write_mode == "typed" and build_authorization is None:
        raise ValueError("typed request records require build_authorization")
    if request_record_write_mode == "legacy" and build_auth_body is None:
        raise ValueError("legacy request records require build_auth_body")
    shard_candidates: tuple[int, ...]
    if credit_shard_candidates is None:
        shard_candidates = (credit_shard,)
    else:
        shard_candidates = tuple(credit_shard_candidates)
        if credit_shard != UNSHARDED:
            raise ValueError("pass credit_shard or credit_shard_candidates, not both")
    if not shard_candidates:
        raise ValueError("credit_shard_candidates must not be empty")
    if any(shard < 0 for shard in shard_candidates):
        raise ValueError("credit shards must be non-negative")
    if len(set(shard_candidates)) != len(shard_candidates):
        raise ValueError("credit_shard_candidates must be unique")
    if has_credit_candidate and len(shard_candidates) > MAX_CREDIT_SHARD_ATTEMPTS_PER_TRANSACTION:
        raise ValueError("credit_shard_candidates exceeds the hot-path transaction limit")
    if not has_credit_candidate and shard_candidates != (UNSHARDED,):
        raise ValueError("BYOK-only authorization must use credit shard zero")
    key_candidates = tuple(key_shard_candidates)
    if not key_candidates:
        raise ValueError("key_shard_candidates must not be empty")
    if any(shard < 0 for shard in key_candidates):
        raise ValueError("key shards must be non-negative")
    if len(set(key_candidates)) != len(key_candidates):
        raise ValueError("key_shard_candidates must be unique")
    is_byok = not has_credit_candidate
    # Stable ids across ABORTED retries (only the committed attempt persists).
    reservation_id = str(uuid.uuid4())
    authorization_id = authorization_id or f"gwa-{uuid.uuid4().hex}"
    # The caller's instant, which priced the request: settlement prices at
    # created_at, so a tariff change between two readings would hold at one
    # price and bill at another.
    created_at = created_at if created_at is not None else utcnow()
    authorization = (
        build_authorization(authorization_id, reservation_id)
        if build_authorization is not None
        else None
    )
    if authorization is not None:
        authorization.created_at = created_at.isoformat().replace("+00:00", "Z")
    legacy_auth_body = (
        build_auth_body(authorization_id, reservation_id) if build_auth_body is not None else None
    )

    def _replay(transaction: Any, existing: dict) -> dict:
        if existing["idempotency_fingerprint"] != idempotency_fingerprint:
            raise _Reject(AuthorizeOutcome.IDEMPOTENCY_MISMATCH)
        return {
            "outcome": AuthorizeOutcome.REPLAY,
            "reservation_id": existing["reservation_id"],
            "authorization_id": existing["authorization_id"],
            "credit_shard": int(existing.get("credit_shard", UNSHARDED)),
            "key_shard": int(existing.get("key_shard", UNSHARDED)),
        }

    if strict_budget and key_candidates != (UNSHARDED,):
        raise ValueError("strict budgets require exactly one key shard")
    speculative = not strict_budget and not skip_key_limit and speculate_key_limit

    batch_credit = has_credit_candidate and not strict_budget and (speculative or skip_key_limit)

    def check_prefix(counts: Sequence[int]) -> None:
        # Credit zero means underfunded or paused; key zero means missing,
        # exhausted, uncapped or BYOK-excluded. Classify only after rollback.
        # Later INSERT errors must not override the first missed counter.
        # ABORTED is handled first by execute_batch_dml and retries this callback.
        if batch_credit and counts and counts[0] == 0:
            raise _RetrySequentialCreditReserve("speculative credit hold missed")
        key_index = int(batch_credit)
        if speculative and len(counts) > key_index and counts[key_index] == 0:
            raise _RetrySequentialKeyReserve("speculative key hold missed")

    def txn(transaction: Any) -> dict:
        if idempotency_scope is not None:
            existing = read_reservation_by_idempotency(transaction, pt, idempotency_scope)
            if existing is not None:
                return _replay(transaction, existing)

        # Reserve credit before key so both paths use the same counter lock order.
        # Reservation/authorization INSERTs below consume the selected shards and holds.
        credit_hold = 0
        selected_credit_shard = UNSHARDED
        armed = trust_settings is not None and trust_settings.spend_lease_trust_eligibility_enabled
        paused = False
        if batch_credit:
            selected_credit_shard = shard_candidates[0]
            credit_hold = estimate
        elif has_credit_candidate:
            for candidate in shard_candidates:
                if armed:
                    reserved, paused = reserve_credit_with_pause(
                        transaction, pt, workspace_id, estimate, shard=candidate,
                    )
                else:
                    reserved = reserve_credit(transaction, pt, workspace_id, estimate, shard=candidate)
                if reserved:
                    selected_credit_shard = candidate
                    break
            else:
                raise _Reject(AuthorizeOutcome.INSUFFICIENT_CREDITS)
            credit_hold = estimate

        if armed:
            # Batched credit checks pause in its UPDATE predicate below.
            # Returning DML observes pause at the write on the selected row.
            # Returning both columns preserves the old SELECT's dependencies
            # on this key, without coupling unrelated credit shards. Spanner
            # locks cells: reading pause earlier can change race scheduling,
            # but a conflicting pause still has to serialize or abort/retry.
            # BYOK has no credit UPDATE and retains its shard-zero read.
            if not has_credit_candidate:
                from trusted_router.trust_eligibility import billing_paused_tx

                paused = billing_paused_tx(transaction, pt, workspace_id, shard=selected_credit_shard)
            if paused:
                raise _Reject("billing_paused")

        # Bounded lifetime-cap TOCTOU: a cap committed after the gateway's
        # entity read can miss only requests already in flight at that commit,
        # each admitted for its own estimate (aggregate: sum of those estimates).
        # The next fresh entity read enforces the cap; removal likewise takes
        # effect on the next request. Do not add a hot api_key/counter read here.
        strict_decision = None
        if strict_budget:
            from trusted_router.storage_gcp_strict_budget import reserve_strict_key

            key_result, strict_decision = reserve_strict_key(
                transaction, pt, key_hash, estimate, is_byok=is_byok,
                enforce_windows=enforce_strict_windows,
            )
            selected_key_shard = UNSHARDED
            if key_result in {KEY_MISSING, KEY_INSUFFICIENT}:
                raise _Reject(AuthorizeVerdict(
                    AuthorizeOutcome.KEY_MISSING if key_result == KEY_MISSING else AuthorizeOutcome.KEY_LIMIT_EXCEEDED,
                    rate_limit=strict_decision,
                ))
        elif speculative:
            key_result = KEY_ACCEPTED
            selected_key_shard = key_candidates[0]
        elif skip_key_limit:
            key_result = KEY_NO_HOLD
            selected_key_shard = key_candidates[0]
        else:
            key_result = KEY_MISSING
            selected_key_shard = UNSHARDED
            saw_key_row = False
            for candidate in key_candidates:
                candidate_result = reserve_key(
                    transaction,
                    pt,
                    key_hash,
                    estimate,
                    is_byok=is_byok,
                    shard=candidate,
                )
                if candidate_result == KEY_MISSING:
                    continue
                saw_key_row = True
                if candidate_result == KEY_INSUFFICIENT:
                    continue
                key_result = candidate_result
                selected_key_shard = candidate
                break
            if key_result == KEY_MISSING:
                raise _Reject(
                    AuthorizeOutcome.KEY_LIMIT_EXCEEDED if saw_key_row else AuthorizeOutcome.KEY_MISSING
                )
        key_hold = estimate if key_result == KEY_ACCEPTED else 0

        reservation_statement = reservation_insert_statement(
            pt,
            reservation_id=reservation_id,
            workspace_id=workspace_id,
            key_hash=key_hash,
            ws_shard=selected_credit_shard,
            credit_shard=selected_credit_shard,
            key_shard=selected_key_shard,
            credit_reserved_micro=credit_hold,
            key_reserved_micro=key_hold,
            hold_usage_type=reservation_usage_type,
            authorization_id=authorization_id,
            idempotency_scope=idempotency_scope,
            idempotency_fingerprint=idempotency_fingerprint,
            expires_at=expires_at,
            created_at=created_at,
        )
        if request_record_write_mode == "typed":
            assert authorization is not None
            authorization_statement = gateway_authorization_insert_statement(
                pt,
                authorization,
                created_at=created_at,
            )
        else:
            assert legacy_auth_body is not None
            authorization_statement = entity_insert_statement(
                pt,
                "gateway_authorization",
                authorization_id,
                legacy_auth_body,
            )
        statements = []
        if batch_credit:
            statements.append(reserve_credit_statement(
                pt, workspace_id, estimate, shard=selected_credit_shard, check_pause=armed,
            ))
        if speculative:
            statements.append(reserve_key_statement(
                pt, key_hash, estimate, is_byok=is_byok, shard=selected_key_shard,
            ))
        # Credit before key; no client RPC between these locks and commit.
        # A zero does not stop Batch DML: check the prefix before INSERT errors.
        statements.extend([reservation_statement, authorization_statement])
        execute_batch_dml(
            transaction, statements, [(1,)] * len(statements), check_prefix=check_prefix,
        )
        return {
            "outcome": AuthorizeVerdict(AuthorizeOutcome.ACCEPTED, rate_limit=strict_decision),
            "reservation_id": reservation_id,
            "authorization_id": authorization_id,
            "credit_shard": selected_credit_shard,
            "key_shard": selected_key_shard,
        }

    try:
        try:
            return run_in_transaction_with_retry(
                database, txn, transaction_tag="tr_authorize",
            )
        except (_RetrySequentialCreditReserve, _RetrySequentialKeyReserve):
            # Protected API-error cleanup attempted rollback before the SDK
            # discarded the handle. Cleanup never renews the shared T1 budget.
            # Retry the original decision path once; it handles no-hold success,
            # all shard candidates, and terminal rejection without speculation.
            # IDs, created_at, and candidate order remain stable across attempts.
            speculative = False
            batch_credit = False
            return run_in_transaction_with_retry(
                database, txn, transaction_tag="tr_authorize",
            )
    except KeyWindowLimitExceeded as exceeded:
        return {"outcome": AuthorizeVerdict(
            f"{AuthorizeOutcome.KEY_WINDOW_LIMIT_EXCEEDED}:{exceeded.window}", rate_limit=exceeded.decision,
        )}
    except _Reject as reject:
        return {"outcome": reject.outcome}
    except AlreadyExists:
        # Concurrent first-call lost the unique-idempotency-index race: the winner
        # committed; re-read and replay (codex Step-3 #4) — never a second debit.
        # The conflict was on idempotency_scope, so it is necessarily non-None.
        assert idempotency_scope is not None
        conflict_scope: str = idempotency_scope

        def replay_txn(transaction: Any) -> dict:
            existing = read_reservation_by_idempotency(transaction, pt, conflict_scope)
            if existing is None:  # pragma: no cover - winner must exist post-conflict
                raise _Reject(AuthorizeOutcome.IDEMPOTENCY_MISMATCH)
            return _replay(transaction, existing)

        try:
            return run_in_transaction_with_retry(
                database,
                replay_txn,
                transaction_tag="tr_authorize_replay",
            )
        except _Reject as reject:
            return {"outcome": reject.outcome}


class SettleOutcome:
    SETTLED = "settled"  # this caller claimed + released the holds
    ALREADY_SETTLED = "already_settled"  # replay: another caller already settled
    NOT_FOUND = "not_found"  # no such reservation
    ERROR = "error"  # a release row-count != 1 -> rolled back, re-drive/alarm
    OUTBOX_GUARDED = "outbox_guarded"  # reaper aborted: a pending/dead outbox row intends a charge
    NOT_ELIGIBLE = "not_eligible"  # reaper strong read found renewed/already-terminal state
    GUARD_LOST = "guard_lost"  # reaper candidate changed after its decisive read
    AUTHORIZATION_NOT_TYPED = "authorization_not_typed"


class _SettleError(Exception):
    """A release returned row-count != 1 — roll the settle back (don't leave the
    reservation claimed with the hold unreleased / charge unbooked)."""


class _ReapGuardLost(Exception):
    """Abort a reaper transaction whose final row-count guard lost."""


class OneCommitSettleDeclined(Exception):
    """The one-commit settle rolled back before committing anything.

    Raised inside (or straight after) the transaction whenever the happy path
    does not hold: the reservation is gone or already claimed, the typed
    authorization row is absent or terminal, the intent is already recorded, or
    a release row-count assertion failed. Nothing was written, so the caller
    runs the durable two-commit settle, which owns every one of those cases.
    """

    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


@dataclass(frozen=True, slots=True)
class ReapPassResult:
    count: int = 0
    released_hold_micro: int = 0
    started_markers: int = 0
    snapshot_bookings: int = 0
    out_of_cohort: int = 0
    not_eligible: int = 0
    guarded: int = 0
    guard_lost: int = 0
    errors: int = 0
    refunded: int = 0

    @property
    def outcome_counts(self) -> dict[str, int]:
        return {
            SettleOutcome.NOT_ELIGIBLE: self.not_eligible,
            SettleOutcome.OUTBOX_GUARDED: self.guarded,
            SettleOutcome.GUARD_LOST: self.guard_lost,
            SettleOutcome.ERROR: self.errors,
            "refunded": self.refunded,
            "snapshot_booked": self.snapshot_bookings,
        }

    @property
    def started_marker_share(self) -> float:
        return self.started_markers / self.count if self.count else 0.0

    @property
    def out_of_cohort_share(self) -> float:
        return self.out_of_cohort / self.count if self.count else 0.0


@dataclass(frozen=True, slots=True)
class _ReapOneResult:
    outcome: str
    released_hold_micro: int = 0
    started_marker: bool = False
    snapshot_booked: bool = False
    out_of_cohort: bool = False
    missing_key_releases: tuple[dict[str, Any], ...] = ()


def _release_key_or_skip_deleted(
    transaction: Any,
    param_types: Any,
    res: dict[str, Any],
    actual_micro: int,
    *,
    book_to_byok: bool,
) -> tuple[int, dict[str, Any] | None]:
    """Shared key-release classification for settle, reaper, and drain paths.

    `release_key` deliberately returns the raw UPDATE count. A 0 count is
    ambiguous only here, after the reservation has been claimed: the key row may
    have been deleted, or the `reserved >= hold` corruption guard may have fired.
    Zero-hold usage (including skip-path reservations) must book even after a
    shrink reshard: recover on shard zero or raise with the amount preserved.
    Held/deleted keys and zero-usage refunds retain their historical behavior.
    """
    from trusted_router.storage_gcp_counter_dml import key_limit_exists, release_key

    key_hash = str(res["key_hash"])
    key_hold = int(res["key_reserved_micro"])
    key_shard = int(res.get("key_shard", 0) or 0)
    floors = window_floors(utcnow())
    count = release_key(
        transaction,
        param_types,
        key_hash,
        key_hold,
        int(actual_micro),
        book_to_byok=book_to_byok,
        window_floors=floors,
        shard=key_shard,
    )
    if count == 1:
        return count, None
    # Pre-migration credit-only reservations can legitimately have no key.
    if res["key_hash"] is not None and key_hold == 0 and actual_micro > 0:
        if key_shard != 0:
            recovered = release_key(
                transaction, param_types, key_hash, 0, int(actual_micro),
                book_to_byok=book_to_byok, window_floors=floors,
                shard=0,
            )
            if recovered == 1:
                return 1, {
                    "key_hash": key_hash, "hold_micro": 0,
                    "missing_shard": key_shard, "actual_micro": int(actual_micro),
                }
        # Deliberately not _SettleError: callers must see the amount and retry
        # (the outbox retains its frozen payload), never report SETTLED.
        raise RuntimeError(
            f"key usage booking failed reservation_id={res['reservation_id']} "
            f"key_hash={key_hash} shard={key_shard} fallback_shard=0 "
            f"actual_micro={actual_micro} book_to_byok={book_to_byok}"
        )
    if key_limit_exists(transaction, param_types, key_hash, shard=key_shard):
        return count, None
    return 1, {"key_hash": key_hash, "hold_micro": key_hold}


def _log_missing_key_releases(result: dict[str, Any]) -> None:
    warnings = result.pop("missing_key_releases", ())
    for warning in warnings:
        if "missing_shard" in warning:
            # Structured counter event for log-based metrics; emit after commit
            # so Spanner transaction retries do not count speculative recovery.
            log.warning(
                "metric=key_usage_shard_fallback_total value=1 "
                "key usage recovered key_hash=%s shard=%s fallback_shard=0 actual_micro=%s",
                warning["key_hash"], warning["missing_shard"], warning["actual_micro"],
                extra={"metric": "key_usage_shard_fallback_total", "value": 1, **warning},
            )
            continue
        log.warning(
            "skipped key release for missing tr_key_limit row key_hash=%s hold_micro=%s",
            warning["key_hash"],
            warning["hold_micro"],
        )


def settle_atomic(
    database: Any,
    param_types: Any,
    *,
    reservation_id: str,
    actual_micro: int,
    settled_usage_type: str,
    success: bool,
    guard_outbox: bool = False,
    outbox_available: bool | None = None,
    expires_before: Any | None = None,
    async_fence: bool = False,
) -> dict:
    """Claim-gated settle/refund in ONE transaction (credit then key lock order).

    Claim flips settled false->true (first-writer-wins); only the winner releases
    the EXACT recorded holds and books `actual`. `success=False` is a refund:
    release the holds, book nothing. Booking matches the legacy finalize: key
    usage by settled usage type (usage vs byok_usage); credit total_usage only
    when the settled usage type is Credits.
    """
    from trusted_router.storage_gcp_counter_dml import (
        claim_reservation,
        read_reservation,
        release_credit,
    )

    pt = param_types
    book_actual = actual_micro if success else 0
    book_to_byok = settled_usage_type == "BYOK"
    terminal_at = utcnow()
    resolved_outbox_available = (
        _outbox_table_available(database, pt) if outbox_available is None else outbox_available
    )

    def txn(transaction: Any) -> dict:
        res = read_reservation(transaction, pt, reservation_id)
        if res is None:
            return {"outcome": SettleOutcome.NOT_FOUND}
        if guard_outbox and resolved_outbox_available:
            aid = res.get("authorization_id")
            if aid:
                # MF2: this strong read inside the read-write claim txn is the
                # real interlock; Spanner serializes it against a concurrent
                # enqueue commit. Snapshot scans are advisory latency filters
                # only and can miss that commit.
                rows = list(
                    transaction.execute_sql(
                        GUARD_COUNT_SQL,
                        params={"aid": aid},
                        param_types={"aid": pt.STRING},
                    )
                )
                if rows and int(rows[0][0]) > 0:
                    return {"outcome": SettleOutcome.OUTBOX_GUARDED}
        won = claim_reservation(
            transaction,
            pt,
            reservation_id,
            actual_micro=book_actual,
            settled_usage_type=settled_usage_type,
            terminal_at=terminal_at,
            outbox_available=resolved_outbox_available,
            expires_before=expires_before,
            async_fence=async_fence,
        )
        if not won:
            return {"outcome": SettleOutcome.ALREADY_SETTLED}  # replay, no double-apply

        # A "RegionalCredits" hold belongs to a retired regional-quota lease
        # (pilot removed 2026-09): its escrow lived in the retired ledger, so
        # releasing counters here would double-release the grant.
        if res.get("hold_usage_type") == "RegionalCredits":
            return {
                "outcome": SettleOutcome.SETTLED,
                "missing_key_releases": [],
            }

        if res["credit_reserved_micro"] > 0:
            credit_actual = book_actual if settled_usage_type == "Credits" else 0
            credit_count = release_credit(
                transaction,
                pt,
                res["workspace_id"],
                res["credit_reserved_micro"],
                credit_actual,
                shard=res["credit_shard"],
            )
            if credit_count != 1:
                raise _SettleError("credit release row-count != 1")

        # Credit first, key last: never hold the key while waiting for credit.
        key_actual = book_actual  # key usage counts under both Credits and BYOK
        missing_key_releases = []
        key_count, warning = _release_key_or_skip_deleted(
            transaction, pt, res, key_actual, book_to_byok=book_to_byok
        )
        if warning is not None:
            missing_key_releases.append(warning)
        # A recorded hold MUST release; an uncapped/no-hold row (key_reserved==0)
        # with positive usage must book or raise in the shared helper.
        if res["key_reserved_micro"] > 0 and key_count != 1:
            raise _SettleError("key release row-count != 1")

        return {
            "outcome": SettleOutcome.SETTLED,
            "missing_key_releases": missing_key_releases,
        }

    try:
        result = run_in_transaction_with_retry(
            database,
            txn,
            transaction_tag="tr_settle" if success else "tr_refund",
        )
        _log_missing_key_releases(result)
        return result
    except _SettleError:
        return {"outcome": SettleOutcome.ERROR}


def _is_table_missing(exc: Exception) -> bool:
    # Rollout guard: code can deploy before the operator-applied outbox DDL.
    # FAIL CLOSED on everything except the ONE real "table itself is missing"
    # shape: Cloud Spanner (and its emulator) raise NotFound("Table not found:
    # tr_settle_outbox") — table name AFTER the phrase. Anchoring on position
    # keeps wrapped transients ("Session not found while querying
    # tr_settle_outbox") and schema errors ('column "status" of relation
    # "tr_settle_outbox" does not exist') from silently unguarding a cycle;
    # any other probe error re-raises, so a mismatch can only delay reaping,
    # never free-release a guarded hold.
    lowered = str(exc).lower()
    return (
        "table not found" in lowered
        and "tr_settle_outbox" in lowered.split("table not found", 1)[1]
    )


_OUTBOX_ABSENT_CACHE_SECONDS = 5.0
# Keyed by a STABLE STRING, never by the Database object itself: the production
# google.cloud.spanner_v1.database.Database defines __eq__ and sets
# __hash__ = None, so keying a (Weak)dict on it raises TypeError on every
# get/set. A cache that swallowed that error silently never cached in prod and
# every settle/refund paid an extra GUARD_COUNT_SQL probe round trip on the hot
# path — invisible to tests, whose fake database happens to be hashable.
_OUTBOX_AVAILABILITY_CACHE: dict[str, tuple[bool, float]] = {}
_OUTBOX_AVAILABILITY_CACHE_LOCK = threading.Lock()
_OUTBOX_AVAILABILITY_PROBE_LOCK = threading.Lock()


def _outbox_cache_key(database: Any) -> str | None:
    """Stable identity for a Spanner database, or None to skip caching.

    `Database.name` is the fully-qualified `projects/.../databases/...` path:
    unique per database and stable for the process, so the cache is bounded by
    the number of databases a process talks to (one, in practice).

    A database WITHOUT a name is not cached at all. `id()` would be the obvious
    fallback, but object addresses are REUSED after garbage collection, so a
    destroyed double's entry could be inherited by an unrelated database and
    select stale SQL — present-then-absent would emit guarded DML against a
    missing table and break settlement. Only test doubles lack a name, and for
    them the probe is an in-memory call, so re-probing is strictly cheaper than
    that risk.
    """
    name = getattr(database, "name", None)
    if isinstance(name, str) and name:
        return name
    return None


def _cached_outbox_availability(database: Any, *, now: float) -> bool | None:
    key = _outbox_cache_key(database)
    if key is None:
        return None
    with _OUTBOX_AVAILABILITY_CACHE_LOCK:
        cached = _OUTBOX_AVAILABILITY_CACHE.get(key)
        if cached is None:
            return None
        available, expires_at = cached
        if expires_at <= now:
            _OUTBOX_AVAILABILITY_CACHE.pop(key, None)
            return None
        return available


def _remember_outbox_availability(
    database: Any,
    *,
    available: bool,
    now: float,
) -> None:
    key = _outbox_cache_key(database)
    if key is None:
        return
    expires_at = float("inf") if available else now + _OUTBOX_ABSENT_CACHE_SECONDS
    with _OUTBOX_AVAILABILITY_CACHE_LOCK:
        _OUTBOX_AVAILABILITY_CACHE[key] = (available, expires_at)


def _outbox_table_available(database: Any, param_types: Any) -> bool:
    """Return whether guarded SQL may reference the rollout-added outbox table.

    A positive result is stable for the life of the process. A missing-table
    result has a short TTL so a process deployed before the DDL automatically
    adopts the guard shortly after the migration lands. Only the exact Spanner
    table-missing shape selects unguarded SQL; transient/schema probe failures
    fail toward the guarded variant and are not cached.
    """
    now = time.monotonic()
    cached = _cached_outbox_availability(database, now=now)
    if cached is not None:
        return cached

    # Serialize cache misses so concurrent first settles do not stampede the
    # one process-level availability probe.
    with _OUTBOX_AVAILABILITY_PROBE_LOCK:
        now = time.monotonic()
        cached = _cached_outbox_availability(database, now=now)
        if cached is not None:
            return cached
        try:
            with database.snapshot() as snapshot:
                list(
                    snapshot.execute_sql(
                        GUARD_COUNT_SQL,
                        params={"aid": ""},
                        param_types={"aid": param_types.STRING},
                    )
                )
        except Exception as exc:
            if not _is_table_missing(exc):
                log.warning(
                    "tr_settle_outbox availability probe failed; using guarded SQL",
                    exc_info=True,
                )
                return True
            available = False
        else:
            available = True
        _remember_outbox_availability(database, available=available, now=now)
        return available


# Reaper scan, two forms. The guarded form excludes holds with an outbox row
# whose status is in GUARD_STATUSES IN THE SCAN so frozen holds never consume @limit and cannot
# starve unguarded expired holds behind them (PR #116 review P2). The NOT
# EXISTS runs on a snapshot, so it is ADVISORY ONLY — the strong re-read
# inside settle_atomic(guard_outbox=True) remains the MF2 interlock.
_REAP_SCAN_SQL = (
    "SELECT reservation_id, authorization_id, credit_reserved_micro, key_reserved_micro "
    "FROM tr_reservation "
    "WHERE settled=false AND expires_at < @now LIMIT @limit"
)
_REAP_SCAN_GUARDED_SQL = (
    "SELECT reservation_id, authorization_id, credit_reserved_micro, "  # noqa: S608
    "key_reserved_micro "
    "FROM tr_reservation "
    "WHERE settled=false AND expires_at < @now "
    "AND NOT EXISTS (SELECT 1 FROM tr_settle_outbox o "
    "WHERE o.authorization_id = tr_reservation.authorization_id "
    f"AND o.status IN ({_GUARD_STATUS_SQL})) "
    "LIMIT @limit"
)


def reap_expired_reservations_result(
    database: Any,
    param_types: Any,
    *,
    now: Any,
    limit: int = 100,
    snapshot_booking_enabled: bool = False,
    async_fence: bool = False,
    operational_analytics_outbox: Any | None = None,
) -> ReapPassResult:
    """Reclaim crashed-before-settle reservations (settled=false AND expires_at<now).

    Releases each stranded reservation's holds via the SAME claim-gated settle
    path (success=False = refund, books nothing), so a late settle racing the
    reaper is safe — whoever claims the row first wins, the other no-ops.

    The outbox guard is live: advisory filtering happens in the scan SQL, so a
    hold whose authorization has a `tr_settle_outbox` row with status in
    GUARD_STATUSES is invisible to the scan and cannot starve later unguarded
    holds behind @limit (PR #116 review P2). `settle_atomic(..., guard_outbox=True)`
    still does the in-txn re-check; that strong read remains the MF2 interlock.
    `release_approved` is the only human-set status that re-permits this free
    release. Returns the count reaped.
    """
    pt = param_types
    guard_active = True
    try:
        with database.snapshot() as snapshot:
            list(
                snapshot.execute_sql(
                    GUARD_COUNT_SQL,
                    params={"aid": ""},
                    param_types={"aid": pt.STRING},
                )
            )
    except Exception as exc:
        if not _is_table_missing(exc):
            raise
        # Pre-migration: the table does not exist, so no intent rows can exist
        # either. Unguarded free-release is exactly today's behavior; the guard
        # arms itself the moment the DDL is applied.
        guard_active = False
    _remember_outbox_availability(
        database,
        available=guard_active,
        now=time.monotonic(),
    )

    scan_sql = _REAP_SCAN_GUARDED_SQL if guard_active else _REAP_SCAN_SQL
    with database.snapshot() as snapshot:
        rows = list(
            snapshot.execute_sql(
                scan_sql,
                params={"now": now, "limit": int(limit)},
                param_types={"now": pt.TIMESTAMP, "limit": pt.INT64},
            )
        )
    count = 0
    released_hold_micro = 0
    started_markers = 0
    snapshot_bookings = 0
    out_of_cohort = 0
    not_eligible = 0
    guarded = 0
    guard_lost = 0
    errors = 0
    refunded = 0
    for (
        reservation_id,
        _authorization_id,
        advisory_credit_hold_micro,
        advisory_key_hold_micro,
    ) in rows:
        # One reservation's failure is that reservation's error, never the
        # end of the pass: the rows after it still expire and still hold credit.
        try:
            result = _finalize_reaped_reservation_atomic(
                database,
                pt,
                reservation_id=str(reservation_id),
                reap_now=now,
                guard_outbox=guard_active,
                snapshot_booking_enabled=snapshot_booking_enabled,
                operational_analytics_outbox=operational_analytics_outbox,
                async_fence=async_fence,
            )
            if result.outcome == SettleOutcome.AUTHORIZATION_NOT_TYPED:
                # Rolling legacy authorizations have no heartbeat columns. Preserve
                # their existing zero-release behavior, now with the same strong
                # expiry predicate that protects typed Stage D reservations.
                legacy = settle_atomic(
                    database,
                    pt,
                    reservation_id=str(reservation_id),
                    actual_micro=0,
                    settled_usage_type="Credits",
                    success=False,
                    guard_outbox=guard_active,
                    outbox_available=guard_active,
                    expires_before=now,
                    async_fence=async_fence,
                )
                if legacy["outcome"] == SettleOutcome.SETTLED:
                    result = _ReapOneResult(
                        outcome=SettleOutcome.SETTLED,
                        released_hold_micro=max(
                            int(advisory_credit_hold_micro or 0),
                            int(advisory_key_hold_micro or 0),
                        ),
                        out_of_cohort=True,
                    )
                elif legacy["outcome"] == SettleOutcome.OUTBOX_GUARDED:
                    result = _ReapOneResult(SettleOutcome.OUTBOX_GUARDED)
                elif legacy["outcome"] == SettleOutcome.ERROR:
                    result = _ReapOneResult(SettleOutcome.ERROR)
                else:
                    result = _ReapOneResult(SettleOutcome.GUARD_LOST)
        except Exception:
            log.exception(
                "gateway reap failed reservation_id=%s; continuing the pass",
                reservation_id,
            )
            result = _ReapOneResult(SettleOutcome.ERROR)
        if result.outcome == SettleOutcome.NOT_ELIGIBLE:
            not_eligible += 1
            continue
        if result.outcome == SettleOutcome.OUTBOX_GUARDED:
            guarded += 1
            continue
        if result.outcome == SettleOutcome.GUARD_LOST:
            guard_lost += 1
            continue
        if result.outcome == SettleOutcome.ERROR:
            errors += 1
            continue
        if result.outcome != SettleOutcome.SETTLED:
            errors += 1
            continue
        count += 1
        released_hold_micro += result.released_hold_micro
        started_markers += int(result.started_marker)
        snapshot_bookings += int(result.snapshot_booked)
        refunded += int(not result.snapshot_booked)
        out_of_cohort += int(result.out_of_cohort)
    return ReapPassResult(
        count=count,
        released_hold_micro=released_hold_micro,
        started_markers=started_markers,
        snapshot_bookings=snapshot_bookings,
        out_of_cohort=out_of_cohort,
        not_eligible=not_eligible,
        guarded=guarded,
        guard_lost=guard_lost,
        errors=errors,
        refunded=refunded,
    )


def reap_expired_reservations(
    database: Any, param_types: Any, *, now: Any, limit: int = 100,
    async_fence: bool = False,
) -> int:
    """Compatibility wrapper for callers that only need the reaped count."""

    return reap_expired_reservations_result(
        database,
        param_types,
        now=now,
        limit=limit,
        async_fence=async_fence,
    ).count


def _finalize_reaped_reservation_atomic(
    database: Any,
    param_types: Any,
    *,
    reservation_id: str,
    reap_now: Any,
    guard_outbox: bool,
    snapshot_booking_enabled: bool,
    operational_analytics_outbox: Any | None,
    async_fence: bool = False,
) -> _ReapOneResult:
    """Finalize one advisory reaper candidate under strong transaction reads."""

    from trusted_router.storage_gcp_counter_dml import (
        claim_reservation,
        read_reservation,
        release_credit,
    )

    pt = param_types
    reap_timestamp = _reap_datetime(reap_now)

    def txn(transaction: Any) -> _ReapOneResult:
        # Decision 70's decisive read: the scan may be stale, but this read and
        # every write below share one serializable transaction.
        res = read_reservation(transaction, pt, reservation_id)
        if (
            res is None
            or bool(res.get("settled"))
            or res.get("expires_at") is None
            or _reap_datetime(res["expires_at"]) >= reap_timestamp
        ):
            return _ReapOneResult(SettleOutcome.NOT_ELIGIBLE)
        authorization_id = str(res.get("authorization_id") or "")
        if guard_outbox and authorization_id:
            guarded = list(
                transaction.execute_sql(
                    GUARD_COUNT_SQL,
                    params={"aid": authorization_id},
                    param_types={"aid": pt.STRING},
                )
            )
            if guarded and int(guarded[0][0]) > 0:
                return _ReapOneResult(SettleOutcome.OUTBOX_GUARDED)

        authorization = read_gateway_authorization(transaction, pt, authorization_id)
        if authorization is None:
            return _ReapOneResult(SettleOutcome.AUTHORIZATION_NOT_TYPED)
        if (
            authorization.settled
            or authorization.credit_reservation_id != reservation_id
        ):
            raise _ReapGuardLost("authorization terminal/binding guard lost")

        started_marker = authorization.started_at is not None
        out_of_cohort = authorization.pricing_snapshot is None
        snapshot_booked = bool(
            snapshot_booking_enabled and started_marker and not out_of_cohort
        )
        generation: Generation | None = None
        app_markup_payout: AppMarkupPayout | None = None
        actual_micro = 0
        if snapshot_booked:
            if (
                authorization.selected_endpoint_id is None
                or authorization.delivered_usage is None
            ):
                raise _SettleError("started snapshot is missing endpoint or delivered usage")
            usage = delivered_usage_counts(authorization.delivered_usage)
            document = parse_pricing_snapshot(authorization.pricing_snapshot or "")
            selected_endpoint = endpoint_for_id(authorization.selected_endpoint_id)
            selected_provider = (
                selected_endpoint.provider
                if selected_endpoint is not None
                else authorization.provider
            )
            selected_model_id = (
                selected_endpoint.model_id
                if selected_endpoint is not None
                else authorization.model_id
            )
            actual_micro = delivered_usage_charge_microdollars(
                authorization,
                document,
                selected_provider,
                authorization.selected_endpoint_id,
                usage,
            )
            _uncached_input, total_input = normalized_delivered_prompt(
                selected_provider,
                usage,
            )
            provider = PROVIDERS.get(selected_provider)
            app_markup_micro = 0
            if authorization.app_markup_basis_points > 0:
                app_markup_micro = app_markup_microdollars_from_charge(
                    actual_micro,
                    authorization.app_markup_basis_points,
                )
                payout_micro = min(
                    app_markup_owner_share_microdollars(app_markup_micro),
                    app_markup_micro,
                )
                app_markup_payout = AppMarkupPayout(
                    owner_user_id=authorization.app_owner_user_id,
                    app_id=authorization.app_id,
                    amount_microdollars=payout_micro,
                    payer_workspace_id=authorization.workspace_id,
                )
            generation = Generation.from_settle_body(
                authorization=authorization,
                provider_name=str(getattr(provider, "name", selected_provider)),
                model_id=selected_model_id,
                usage_type=UsageType.CREDITS,
                provider=selected_provider,
                body={
                    "streamed": True,
                    "usage_estimated": True,
                    "cache_read_input_tokens": usage["cache_read_input_tokens"],
                    "reasoning_tokens": usage["reasoning_tokens"],
                    "status": "success",
                    "finish_reason": "reaped_snapshot",
                },
                input_tokens=total_input,
                output_tokens=usage["output_tokens"],
                actual_cost_microdollars=actual_micro,
                app_markup_microdollars=app_markup_micro,
            )
            generation.settled_from = "heartbeat"

        won = claim_reservation(
            transaction,
            pt,
            reservation_id,
            actual_micro=actual_micro,
            settled_usage_type="Credits",
            terminal_at=reap_timestamp,
            defer_retention=True,
            outbox_available=guard_outbox,
            expires_before=reap_timestamp,
            async_fence=async_fence,
        )
        if not won:
            raise _ReapGuardLost("expired reservation claim guard lost")

        if (
            snapshot_booked
            and app_markup_payout is not None
            and app_markup_payout.amount_microdollars > 0
        ):
            _apply_app_markup_payout_tx(
                transaction,
                pt,
                authorization_id=authorization_id,
                payout=app_markup_payout,
                now=reap_timestamp,
            )

        authorization.record_finalization(
            success=snapshot_booked,
            actual_microdollars=actual_micro,
            selected_usage_type=UsageType.CREDITS,
            generation=generation,
            outcome="reaped_snapshot" if snapshot_booked else "refunded",
        )
        marked = mark_gateway_authorization_settled(transaction, pt, authorization)
        if marked != 1:
            raise _ReapGuardLost("gateway authorization finalize guard lost")
        if generation is not None:
            insert_generation_record(
                transaction,
                pt,
                generation,
                terminal_at=reap_timestamp,
            )
            if operational_analytics_outbox is not None:
                operational_analytics_outbox.enqueue_activity_tx(transaction, generation)
        if (
            complete_reservation_retention(
                transaction,
                pt,
                reservation_id,
                terminal_at=reap_timestamp,
                outbox_available=guard_outbox,
            )
            != 1
        ):
            raise _ReapGuardLost("reservation retention guard lost")
        if (
            complete_gateway_authorization_retention(
                transaction,
                pt,
                authorization_id,
                terminal_at=reap_timestamp,
                outbox_available=guard_outbox,
            )
            != 1
        ):
            raise _ReapGuardLost("authorization retention guard lost")
        # Release credit first and key last, after all other transaction DML.
        # A "RegionalCredits" hold belongs to a retired regional-quota lease
        # (pilot removed 2026-09): its escrow lived in the retired ledger, so
        # nothing on the counters is released for it.
        missing_key_releases = []
        if res.get("hold_usage_type") != "RegionalCredits":
            if res["credit_reserved_micro"] > 0:
                credit_count = release_credit(
                    transaction,
                    pt,
                    res["workspace_id"],
                    res["credit_reserved_micro"],
                    actual_micro,
                    shard=res["credit_shard"],
                )
                if credit_count != 1:
                    raise _SettleError("credit release row-count != 1")

            key_count, warning = _release_key_or_skip_deleted(
                transaction,
                pt,
                res,
                actual_micro,
                book_to_byok=False,
            )
            if warning is not None:
                missing_key_releases.append(warning)
            if res["key_reserved_micro"] > 0 and key_count != 1:
                raise _SettleError("key release row-count != 1")

        return _ReapOneResult(
            outcome=SettleOutcome.SETTLED,
            released_hold_micro=max(
                int(res["credit_reserved_micro"] or 0),
                int(res["key_reserved_micro"] or 0),
            ),
            started_marker=started_marker,
            snapshot_booked=snapshot_booked,
            out_of_cohort=out_of_cohort,
            missing_key_releases=tuple(missing_key_releases),
        )

    try:
        result = run_in_transaction_with_retry(
            database,
            txn,
            transaction_tag="tr_reap_snapshot_finalize",
        )
        _log_missing_key_releases(
            {"missing_key_releases": result.missing_key_releases}
        )
        return result
    except _ReapGuardLost as exc:
        log.warning(
            "gateway snapshot reap guard lost reservation_id=%s reason=%s",
            reservation_id,
            exc,
        )
        return _ReapOneResult(SettleOutcome.GUARD_LOST)
    except (_SettleError, TypeError, ValueError):
        log.exception("gateway snapshot reap finalize failed reservation_id=%s", reservation_id)
        return _ReapOneResult(SettleOutcome.ERROR)


def _reap_datetime(value: Any) -> datetime:
    if isinstance(value, datetime):
        parsed = value
    elif isinstance(value, str):
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    else:
        raise TypeError("reap timestamp is not a datetime")
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _dispose_open_transaction(opened: list[Any]) -> None:
    """Roll back the one transaction a failed one-commit attempt can leave open.

    Within one runner call only the LAST attempt can still be open: earlier
    attempts ended in ``Aborted`` (already dead server-side, though the client
    leaves ``committed`` None and ``rolled_back`` False), and a callback error
    is rolled back by the runner. Rolling back only the last keeps cleanup to
    one bounded Rollback, so a burst of aborts before a commit timeout cannot
    consume the durable fallback's budget.
    """

    if not opened:
        return
    transaction = opened[-1]
    if getattr(transaction, "committed", None) is None and not getattr(
        transaction, "rolled_back", False
    ):
        _rollback_discarded_transaction(transaction)


@spanner_rpc_budget(TXN_BUDGET_SECONDS)
def typed_finalize_atomic(
    database: Any,
    param_types: Any,
    *,
    reservation_id: str,
    authorization_id: str,
    success: bool,
    actual_micro: int,
    settled_usage_type: str,
    now: Any,
    outbox_available: bool | None = None,
    authorization: GatewayAuthorization | None = None,
    auth_body_settled: str,
    generation_writes: list[tuple[str, str, str]] | None = None,
    generation: Generation | None = None,
    persist_generation_record: bool = False,
    operational_analytics_outbox: Any | None = None,
    user_model_payout: UserModelPayout | None = None,
    app_markup_payout: AppMarkupPayout | None = None,
    custom_model_markup_payout: CustomModelMarkupPayout | None = None,
    settle_outbox_done: tuple[str, str] | None = None,
    settle_outbox_intent: SettleOutboxRow | None = None,
    intent_initial_delay_seconds: int = 0,
    benchmark_statement: DmlStatement | None = None,
    async_fence: bool = False,
) -> dict:
    """Full DML-only finalize for the typed path (codex 3e, Option B).

    ``settle_outbox_done=(authorization_id, intent_kind)`` also resolves that
    durable settle-outbox intent to ``done`` in the SAME transaction, when the
    activity row is durable in this commit and the outbox table exists. The
    result carries ``outbox_marked``: True (marked), False (row leased or
    already resolved -- the drain re-derives), or None (not attempted).

    ``settle_outbox_intent`` is the ONE-COMMIT settle: this transaction also
    INSERTs that intent already resolved (``intent_insert_statements(...,
    resolved=True)``, with the enqueue's own retention clears) and arms
    retention exactly as the done-mark would, so the enqueue, the charge and
    the done-mark commit together. ``benchmark_statement`` (one-commit only)
    adds the post-commit benchmark INSERT to the same batch. It is the happy
    path only: any deviation (reservation missing or already claimed, typed
    authorization absent or terminal, intent already recorded, a release
    row-count failure) raises ``OneCommitSettleDeclined`` or the API error
    after rolling back, and the caller runs the durable two-commit settle,
    which owns those cases. It never runs the sequential fallback below.

    ONE transaction reproduces legacy finalize_gateway_authorization's whole
    behavior so a crash can't leave counters charged but the authorization
    active: claim the reservation -> DML-mark the authorization settled ->
    release the EXACT holds and book actual (credit then key). Typed request records
    keep their repair payload until durable analytics delivery is confirmed;
    rolling legacy records retain the old generic generation repair rows.

    `auth_body_settled` and `generation_writes` remain for rolling compatibility
    with an authorization created by the generic-table revision. Returns
    {outcome: settled|already_settled|not_found|error}.
    """
    from trusted_router.storage_gcp_counter_dml import (
        claim_reservation,
        insert_entity_dml_at,
        read_reservation,
        release_credit,
        release_credit_no_debt_statement,
        release_key_statement,
        update_entity_body_dml,
    )
    pt = param_types
    book_actual = actual_micro if success else 0
    book_to_byok = settled_usage_type == "BYOK"
    writes = generation_writes or []
    resolved_outbox_available = (
        _outbox_table_available(database, pt) if outbox_available is None else outbox_available
    )

    # Known legacy inputs and custom outbox callbacks keep the sequential path.
    speculate = (
        authorization is not None
        and (operational_analytics_outbox is None or callable(
            getattr(operational_analytics_outbox, "activity_insert_statement", None)
        ))
    )
    activity_durable = generation is None or operational_analytics_outbox is not None
    mark_done = (
        settle_outbox_done is not None and resolved_outbox_available and activity_durable
    )
    one_commit = settle_outbox_intent is not None
    if benchmark_statement is not None and not one_commit:
        raise ValueError("benchmark_statement rides only in the one-commit settle")
    if settle_outbox_intent is not None:
        # A resolved intent is only truthful when this commit itself makes the
        # activity durable, uses the guarded (outbox-aware) claim, and takes the
        # speculative shape whose every deviation can roll back to the caller.
        if settle_outbox_done is not None:
            raise ValueError("pass settle_outbox_done or settle_outbox_intent, not both")
        if not (speculate and activity_durable and resolved_outbox_available):
            raise ValueError("the one-commit settle needs speculation, durable activity and the outbox")
        if (
            settle_outbox_intent.authorization_id != authorization_id
            or settle_outbox_intent.reservation_id != reservation_id
            or settle_outbox_intent.intent_kind != ("settle" if success else "refund")
        ):
            raise ValueError("settle_outbox_intent does not describe this finalize")
    attempts = 0
    eligible_attempts = 0
    fallback_reason = "none"
    rollback_ms = 0.0
    fallback_outcome = "not_attempted"

    def speculative_batch(transaction: Any, *, include_claim: bool, res: dict, fold_tail: bool) -> None:
        nonlocal eligible_attempts
        eligible_attempts += 1
        assert authorization is not None
        statements = []
        reasons: list[str | None] = []
        if include_claim:
            statements.append(claim_reservation_statement(
                pt, reservation_id, actual_micro=book_actual,
                settled_usage_type=settled_usage_type, terminal_at=now,
                defer_retention=True, outbox_available=resolved_outbox_available,
                async_fence=async_fence,
            ))
            reasons.append("claim_zero")
        statements.append(gateway_authorization_settled_statement(pt, authorization))
        reasons.append("typed_zero")
        counts: list[tuple[int, ...]] = [(1,)] * len(statements)
        if settle_outbox_intent is not None:
            # The enqueue's whole statement set (INSERT + retention clears),
            # with the row already in its done state, then the done-mark's
            # retention resolution. A duplicate intent fails the INSERT
            # (ALREADY_EXISTS), never a zero count; no prefix reason applies.
            resolved = resolved_intent_statements(
                pt, settle_outbox_intent, initial_delay_seconds=intent_initial_delay_seconds,
            )
            statements.extend(resolved)
            counts.extend(intent_insert_counts(resolved))
        elif mark_done:
            assert settle_outbox_done is not None
            done = speculative_done_statements(
                pt, authorization_id=settle_outbox_done[0], intent_kind=settle_outbox_done[1],
                reservation_id=reservation_id,
            )
            statements.extend(done)
            counts.extend([(1,), *[(0, 1)] * (len(done) - 1)])
            reasons.append("done_zero")
        if success and generation is not None:
            if persist_generation_record:
                statements.append(generation_insert_statement(pt, generation, terminal_at=now))
                counts.append((1,))
            if operational_analytics_outbox is not None:
                # PENDING_COMMIT_TIMESTAMP is the last analytics access.
                statements.append(operational_analytics_outbox.activity_insert_statement(generation))
                counts.append((1,))
        if benchmark_statement is not None:
            # One-commit only; the benchmark outbox is touched nowhere else here.
            statements.append(benchmark_statement)
            counts.append((1,))

        # These hot rows are last, credit before key. A miss rolls back ALL
        # speculative writes before recovery/rollover/deletion classification;
        # never hold a speculative key lock while running credit recovery.
        reasons.extend([None] * (len(statements) - len(reasons)))
        sampled_floors = window_floors(utcnow()) if fold_tail else None
        if fold_tail:
            assert sampled_floors is not None
            statements.append(release_credit_no_debt_statement(
                pt, res["workspace_id"], res["credit_reserved_micro"], book_actual,
                shard=res["credit_shard"],
            ))
            # The key's release in both window forms: the current one, which
            # leaves the boundary columns unlocked (#1083), and the rolling one
            # for a key with a window to roll forward. Exactly one matches.
            for windows in ("current", "stale"):
                statements.append(release_key_statement(
                    pt, str(res["key_hash"]), res["key_reserved_micro"], book_actual,
                    book_to_byok=book_to_byok, window_floors=sampled_floors,
                    shard=res["key_shard"], windows=windows,
                ))
            counts.extend([(1,), (0, 1), (0, 1)])
            reasons.extend(["credit_release_zero", None, None])

        def check_prefix(row_counts: Sequence[int]) -> None:
            for count, reason, allowed in zip(row_counts, reasons, counts, strict=False):
                if count == 0 and reason is not None:
                    raise _RetrySequentialFinalize(reason)
                if count not in allowed:
                    # A malformed earlier count cannot authorize a later fallback.
                    return
            if fold_tail and len(row_counts) == len(statements) and sum(row_counts[-2:]) != 1:
                # Neither form matched: a deleted key or a hold the key no
                # longer covers, which the sequential path classifies.
                raise _RetrySequentialFinalize("key_release_zero")

        execute_batch_dml(transaction, statements, counts, check_prefix=check_prefix)
        if sampled_floors is not None:
            # Main samples after credit release/recovery. A batch crossing a
            # boundary must discard its old-window increments and resample in
            # the sequential path, before any of these writes can commit.
            current_floors = window_floors(utcnow())
            if any(current_floors[window] > floor for window, floor in sampled_floors.items()):
                raise _RetrySequentialFinalize("window_boundary_advanced")

    def txn(transaction: Any) -> dict:
        nonlocal attempts
        attempts += 1
        res = read_reservation(transaction, pt, reservation_id)
        if res is None:
            if one_commit:
                # Raise (not return) so this attempt commits nothing at all.
                raise OneCommitSettleDeclined("not_found")
            return {"outcome": SettleOutcome.NOT_FOUND}
        fold_tail = (
            speculate and success and not res["settled"]
            and settled_usage_type == "Credits"
            and isinstance(res["credit_reserved_micro"], int)
            and isinstance(res["key_reserved_micro"], int)
            and res["key_reserved_micro"] >= 0 and res["key_hash"] is not None
            and 0 <= book_actual <= res["credit_reserved_micro"]
            and res["credit_reserved_micro"] > 0
            and user_model_payout is None and app_markup_payout is None
            and custom_model_markup_payout is None
        )
        if speculate:
            speculative_batch(transaction, include_claim=True, res=res, fold_tail=fold_tail)
        else:
            won = claim_reservation(
                transaction,
                pt,
                reservation_id,
                actual_micro=book_actual,
                settled_usage_type=settled_usage_type,
                terminal_at=now,
                defer_retention=True,
                outbox_available=resolved_outbox_available,
                async_fence=async_fence,
            )
            if not won:
                return {"outcome": SettleOutcome.ALREADY_SETTLED}

        if success and user_model_payout is not None and user_model_payout.amount_microdollars > 0:
            # Deliberately NOT wrapped in a swallow. The payout is two DML
            # statements in this same transaction; a failure between them
            # would otherwise commit the movement row without the balance
            # bump (or the reverse), and every later replay would read the
            # row as "already paid" — a permanent, silent underpayment. An
            # exception here aborts the whole finalize: transient errors are
            # retried by run_in_transaction_with_retry, and a deterministic
            # one (schema drift) fails the settle LOUDLY, which the outbox
            # repair/drain surfaces, instead of quietly not paying owners.
            _apply_user_model_payout_tx(
                transaction,
                pt,
                authorization_id=authorization_id,
                payout=user_model_payout,
                now=now,
            )
        if success and app_markup_payout is not None and app_markup_payout.amount_microdollars > 0:
            _apply_app_markup_payout_tx(
                transaction,
                pt,
                authorization_id=authorization_id,
                payout=app_markup_payout,
                now=now,
            )
        if (
            success
            and custom_model_markup_payout is not None
            and custom_model_markup_payout.amount_microdollars > 0
        ):
            _apply_custom_model_markup_payout_tx(
                transaction,
                pt,
                authorization_id=authorization_id,
                payout=custom_model_markup_payout,
                now=now,
            )

        if speculate:
            request_record_typed = True
            outbox_marked: bool | None = True if (mark_done or one_commit) else None
        else:
            marked = 0
            request_record_typed = False
            if authorization is not None:
                marked = mark_gateway_authorization_settled(
                    transaction,
                    pt,
                    authorization,
                )
                request_record_typed = marked == 1
            if not request_record_typed:
                if success:
                    for kind, entity_id, body_json in writes:
                        insert_entity_dml_at(
                            transaction,
                            pt,
                            kind,
                            entity_id,
                            body_json,
                            now,
                        )
                marked = update_entity_body_dml(
                    transaction,
                    pt,
                    "gateway_authorization",
                    authorization_id,
                    auth_body_settled,
                    now,
                )
                complete_reservation_retention(
                    transaction,
                    pt,
                    reservation_id,
                    terminal_at=now,
                    outbox_available=resolved_outbox_available,
                )
            outbox_marked = None
            final_writes: list[DmlStatement] = []
            final_counts: list[tuple[int, ...]] = []
            if settle_outbox_done is not None and resolved_outbox_available and activity_durable:
                # Same commit as the charge: no post-finalize window in which a
                # crash leaves an already-charged authorization pending, and one
                # fewer multi-region round trip per settle. A leased row is left
                # to its drain worker (False), exactly as the standalone mark did.
                outbox_marked = mark_done_unleased_tx(
                    transaction, pt, authorization_id=settle_outbox_done[0],
                    intent_kind=settle_outbox_done[1], retention_statements=final_writes,
                )
                final_counts.extend([(0, 1)] * len(final_writes))
            if success and generation is not None:
                if persist_generation_record:
                    final_writes.append(generation_insert_statement(pt, generation, terminal_at=now))
                    final_counts.append((1,))
                if operational_analytics_outbox is not None:
                    # Preserve rolling/custom outbox implementations without the
                    # statement-building API. Flush in the original write order.
                    builder = getattr(operational_analytics_outbox, "activity_insert_statement", None)
                    if builder is not None:
                        final_writes.append(builder(generation))
                        final_counts.append((1,))
                    else:
                        if final_writes:
                            execute_batch_dml(transaction, final_writes, final_counts)
                            final_writes.clear()
                            final_counts.clear()
                        operational_analytics_outbox.enqueue_activity_tx(transaction, generation)
            if final_writes:
                execute_batch_dml(transaction, final_writes, final_counts)
            if marked != 1:
                raise _SettleError("gateway_authorization update row-count != 1")

        if (async_fence and request_record_typed and activity_durable and resolved_outbox_available
                and not mark_done and not one_commit):
            # F1-001: fresh snapshot-sync has no durable intent to mark later.
            # Reuse the legacy done-mark's guarded stamps in the money commit.
            # Outstanding intents still defer TTL; retries never extend it.
            retention = done_retention_statements(
                pt, authorization_id=authorization_id,
                intent_kind="settle" if success else "refund",
                reservation_id=reservation_id, now=now,
            )
            execute_batch_dml(transaction, retention, [(0, 1)] * len(retention))

        # Hot-row releases LAST, in the SAME transaction (never split: separating
        # claim_reservation(settled=true) from these releases opens a crash
        # window that strands a settled reservation's hold or double-releases
        # on retry). tr_key_limit / tr_credit_balance are the rows every
        # concurrent settle of one key/workspace serializes on; taking their
        # Exclusive locks after the authorization, outbox, generation and
        # activity writes holds them for ~2 RPCs + commit instead of ~12 RPCs +
        # commit. Credit goes first so its contention cannot extend the key lock.
        # The `!= 1` raises still abort the whole transaction.
        missing_key_releases = []
        if not fold_tail and res["credit_reserved_micro"] > 0:
            credit_actual = book_actual if settled_usage_type == "Credits" else 0
            credit_count = release_credit(
                transaction,
                pt,
                res["workspace_id"],
                res["credit_reserved_micro"],
                credit_actual,
                shard=res["credit_shard"],
            )
            if credit_count != 1:
                raise _SettleError("credit release row-count != 1")

        if not fold_tail:
            key_count, warning = _release_key_or_skip_deleted(
                transaction, pt, res, book_actual, book_to_byok=book_to_byok,
            )
            if warning is not None:
                missing_key_releases.append(warning)
            if res["key_reserved_micro"] > 0 and key_count != 1:
                raise _SettleError("key release row-count != 1")

        return {
            "outcome": SettleOutcome.SETTLED,
            "missing_key_releases": missing_key_releases,
            "request_record_typed": request_record_typed,
            "activity_durable": activity_durable,
            "outbox_marked": outbox_marked,
        }

    def run() -> dict:
        tag = "tr_finalize" if success else "tr_refund_finalize"
        if not one_commit:
            return run_in_transaction_with_retry(database, txn, transaction_tag=tag)
        tag = "tr_settle_one_commit" if success else "tr_refund_one_commit"
        opened: list[Any] = []

        def tracked(transaction: Any) -> dict:
            opened.append(transaction)
            return txn(transaction)

        try:
            return run_in_transaction_with_retry(database, tracked, transaction_tag=tag)
        except BaseException:
            # The runner rolls back failures inside the callback only. A commit
            # that failed or timed out (including the attempt budget expiring at
            # the commit boundary) leaves its transaction open, and its locks on
            # the reservation, intent and counter rows would block the caller's
            # durable two-commit fallback until Spanner reaps them. Dispose of it
            # first. If that commit actually landed, the rollback fails harmlessly
            # and the first-writer-wins claim turns the fallback into a replay.
            _dispose_open_transaction(opened)
            raise

    try:
        try:
            result = run()
        except _RetrySequentialFinalize as exc:
            # The runner has completed protected rollback and discarded T3.
            # Never carry S11 across this boundary: deletion can legitimately
            # change ALREADY_SETTLED into NOT_FOUND on the fresh observation.
            rollback_ms = (time.monotonic() - exc.rollback_started) * 1000
            fallback_reason = exc.fallback_reason
            if one_commit:
                # The happy path did not hold and nothing committed. The
                # caller's durable two-commit settle owns every such case.
                fallback_outcome = "one_commit_declined"
                raise OneCommitSettleDeclined(exc.fallback_reason) from None
            speculate = False
            fallback_outcome = "exception"
            result = run()
            fallback_outcome = result["outcome"]
        result["attempts"] = attempts
        _log_missing_key_releases(result)
        return result
    except _SettleError as exc:
        if fallback_reason != "none":
            fallback_outcome = SettleOutcome.ERROR
        if one_commit:
            raise OneCommitSettleDeclined(f"release_row_count: {exc}") from None
        return {"outcome": SettleOutcome.ERROR}
    finally:
        if eligible_attempts:
            from google.api_core.exceptions import DeadlineExceeded

            try:
                remaining_ms = remaining_rpc_budget(TXN_BUDGET_SECONDS) * 1000
            except DeadlineExceeded:
                remaining_ms = 0.0
            log.info(
                "typed finalize speculation timing eligible_attempts=%d attempts=%d "
                "fallback_reason=%s rollback_ms=%.1f remaining_ms=%.1f fallback_outcome=%s",
                eligible_attempts, attempts, fallback_reason, rollback_ms,
                remaining_ms, fallback_outcome,
            )


def _apply_user_model_payout_tx(
    transaction: Any,
    param_types: Any,
    *,
    authorization_id: str,
    payout: UserModelPayout,
    now: Any,
) -> None:
    """Credit one owner payout inside the customer finalize transaction.

    The reservation claim is the primary exactly-once guard; the movement PK
    (`account_id`, deterministic payout event id) is the secondary guard, so
    a duplicate movement skips the balance increment. Both statements live in
    the caller's transaction and either both commit or neither does — see the
    call site for why a failure here is allowed to abort the finalize.

    ``created_at`` is a client timestamp on purpose: tr_credit_movement was
    created WITHOUT ``allow_commit_timestamp`` (migrate_money_primitives.sh),
    and Spanner rejects PENDING_COMMIT_TIMESTAMP() into such a column
    (FAILED_PRECONDITION). Phase 1's credit_user_earnings writes it the same
    way; only tr_earnings_balance.updated_at is a commit-timestamp column.
    """
    pt = param_types
    movement_id = user_model_payout_event_id(authorization_id)
    inserted = transaction.execute_update(
        "INSERT OR IGNORE INTO tr_credit_movement "
        "(account_id, movement_id, kind, amount_microdollars, "
        "counterparty_account_id, custom_model_id, authorization_id, created_at) "
        "VALUES (@account_id, @movement_id, @kind, @amount, "
        "@counterparty, @custom_model_id, @authorization_id, @created_at)",
        params={
            "account_id": f"user:{payout.owner_user_id}",
            "movement_id": movement_id,
            "kind": "custom_model_payout",
            "amount": payout.amount_microdollars,
            "counterparty": payout.payer_workspace_id,
            "custom_model_id": payout.model_id,
            "authorization_id": authorization_id,
            "created_at": now,
        },
        param_types={
            "account_id": pt.STRING,
            "movement_id": pt.STRING,
            "kind": pt.STRING,
            "amount": pt.INT64,
            "counterparty": pt.STRING,
            "custom_model_id": pt.STRING,
            "authorization_id": pt.STRING,
            "created_at": pt.TIMESTAMP,
        },
    )
    if inserted == 0:
        return
    updated = transaction.execute_update(
        "UPDATE tr_earnings_balance "
        "SET total_earned = total_earned + @amount, "
        "updated_at = PENDING_COMMIT_TIMESTAMP() "
        "WHERE user_id=@user_id AND shard=0",
        params={"amount": payout.amount_microdollars, "user_id": payout.owner_user_id},
        param_types={"amount": pt.INT64, "user_id": pt.STRING},
    )
    if updated == 0:
        transaction.execute_update(
            "INSERT INTO tr_earnings_balance "
            "(user_id, shard, total_earned, total_transferred, updated_at) "
            "VALUES (@user_id, 0, @amount, 0, PENDING_COMMIT_TIMESTAMP())",
            params={"user_id": payout.owner_user_id, "amount": payout.amount_microdollars},
            param_types={"user_id": pt.STRING, "amount": pt.INT64},
        )


def _apply_app_markup_payout_tx(
    transaction: Any,
    param_types: Any,
    *,
    authorization_id: str,
    payout: AppMarkupPayout,
    now: Any,
) -> None:
    """Mirror the proven custom-model payout transaction for app markup."""
    pt = param_types
    inserted = transaction.execute_update(
        "INSERT OR IGNORE INTO tr_credit_movement "
        "(account_id, movement_id, kind, amount_microdollars, "
        "counterparty_account_id, custom_model_id, authorization_id, created_at) "
        "VALUES (@account_id, @movement_id, @kind, @amount, "
        "@counterparty, @app_id, @authorization_id, @created_at)",
        params={
            "account_id": f"user:{payout.owner_user_id}",
            "movement_id": app_markup_payout_event_id(authorization_id),
            "kind": "app_markup_payout",
            "amount": payout.amount_microdollars,
            "counterparty": payout.payer_workspace_id,
            "app_id": payout.app_id,
            "authorization_id": authorization_id,
            "created_at": now,
        },
        param_types={
            "account_id": pt.STRING,
            "movement_id": pt.STRING,
            "kind": pt.STRING,
            "amount": pt.INT64,
            "counterparty": pt.STRING,
            "app_id": pt.STRING,
            "authorization_id": pt.STRING,
            "created_at": pt.TIMESTAMP,
        },
    )
    if inserted == 0:
        return
    updated = transaction.execute_update(
        "UPDATE tr_earnings_balance "
        "SET total_earned = total_earned + @amount, "
        "updated_at = PENDING_COMMIT_TIMESTAMP() "
        "WHERE user_id=@user_id AND shard=0",
        params={"amount": payout.amount_microdollars, "user_id": payout.owner_user_id},
        param_types={"amount": pt.INT64, "user_id": pt.STRING},
    )
    if updated == 0:
        transaction.execute_update(
            "INSERT INTO tr_earnings_balance "
            "(user_id, shard, total_earned, total_transferred, updated_at) "
            "VALUES (@user_id, 0, @amount, 0, PENDING_COMMIT_TIMESTAMP())",
            params={"user_id": payout.owner_user_id, "amount": payout.amount_microdollars},
            param_types={"user_id": pt.STRING, "amount": pt.INT64},
        )


def _apply_custom_model_markup_payout_tx(
    transaction: Any,
    param_types: Any,
    *,
    authorization_id: str,
    payout: CustomModelMarkupPayout,
    now: Any,
) -> None:
    """Credit prompt-wrapper markup in the customer finalize transaction."""
    pt = param_types
    inserted = transaction.execute_update(
        "INSERT OR IGNORE INTO tr_credit_movement "
        "(account_id, movement_id, kind, amount_microdollars, "
        "counterparty_account_id, custom_model_id, authorization_id, created_at) "
        "VALUES (@account_id, @movement_id, @kind, @amount, "
        "@counterparty, @custom_model_id, @authorization_id, @created_at)",
        params={
            "account_id": f"user:{payout.owner_user_id}",
            "movement_id": custom_model_markup_payout_event_id(authorization_id),
            "kind": "custom_model_markup_payout",
            "amount": payout.amount_microdollars,
            "counterparty": payout.payer_workspace_id,
            "custom_model_id": payout.model_id,
            "authorization_id": authorization_id,
            "created_at": now,
        },
        param_types={
            "account_id": pt.STRING,
            "movement_id": pt.STRING,
            "kind": pt.STRING,
            "amount": pt.INT64,
            "counterparty": pt.STRING,
            "custom_model_id": pt.STRING,
            "authorization_id": pt.STRING,
            "created_at": pt.TIMESTAMP,
        },
    )
    if inserted == 0:
        return
    updated = transaction.execute_update(
        "UPDATE tr_earnings_balance "
        "SET total_earned = total_earned + @amount, "
        "updated_at = PENDING_COMMIT_TIMESTAMP() "
        "WHERE user_id=@user_id AND shard=0",
        params={"amount": payout.amount_microdollars, "user_id": payout.owner_user_id},
        param_types={"amount": pt.INT64, "user_id": pt.STRING},
    )
    if updated == 0:
        transaction.execute_update(
            "INSERT INTO tr_earnings_balance "
            "(user_id, shard, total_earned, total_transferred, updated_at) "
            "VALUES (@user_id, 0, @amount, 0, PENDING_COMMIT_TIMESTAMP())",
            params={"user_id": payout.owner_user_id, "amount": payout.amount_microdollars},
            param_types={"user_id": pt.STRING, "amount": pt.INT64},
        )
