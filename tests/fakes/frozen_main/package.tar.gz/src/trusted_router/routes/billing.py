from __future__ import annotations

import logging
from typing import Annotated, Any, cast

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse
from pydantic import ValidationError

from trusted_router.auth import (
    ManagementPrincipal,
    Principal,
    SettingsDep,
    principal_from_request,
    require_scope,
)
from trusted_router.billing_policy import (
    WALLET_ONLY_STABLECOIN_MESSAGE,
    is_stablecoin_checkout_method,
    is_wallet_only_principal,
)
from trusted_router.config import Settings
from trusted_router.domains import request_control_origin
from trusted_router.errors import api_error, deprecated
from trusted_router.money import VERIFICATION_MIN_LIFETIME_TOPUP_MICRODOLLARS, money_pair
from trusted_router.routes.helpers import json_body
from trusted_router.schemas import CheckoutRequest, X402FundingRequest, X402SettleRequest
from trusted_router.scopes import SCOPE_BALANCE_READ
from trusted_router.services.adyen_billing import create_adyen_checkout_session
from trusted_router.services.paypal_billing import (
    capture_paypal_order_for_workspace,
    create_paypal_checkout_session,
)
from trusted_router.services.stripe_billing import (
    create_billing_portal_session,
    create_checkout_session,
    create_payment_method_session,
)
from trusted_router.services.x402_billing import (
    X402_HEADER,
    create_x402_funding_challenge,
    settle_x402_payment,
    validate_x402_funding_amount,
    x402_payment_required_response_body,
)
from trusted_router.storage import STORE
from trusted_router.typed_balance import live_credit_summary, remaining_credit_summary
from trusted_router.types import ErrorType

log = logging.getLogger(__name__)


def register_billing_routes(router: APIRouter) -> None:
    @router.get("/credits")
    async def credits(principal: ManagementPrincipal) -> dict[str, dict[str, Any]]:
        summary = live_credit_summary(principal.workspace.id)
        if summary is None:
            raise api_error(404, "Credit account not found", ErrorType.NOT_FOUND)
        return {
            "data": {
                **money_pair("total_credits", summary["total_credits"]),
                **money_pair("total_usage", summary["total_usage"]),
                **money_pair("reserved", summary["reserved"]),
                **money_pair("available", summary["available"]),
            }
        }

    @router.get("/credits/summary")
    async def credits_summary(
        principal: Annotated[
            Principal,
            Depends(require_scope(SCOPE_BALANCE_READ)),
        ],
    ) -> dict[str, dict[str, Any]]:
        summary = remaining_credit_summary(principal.workspace.id)
        if summary is None:
            raise api_error(404, "Credit account not found", ErrorType.NOT_FOUND)
        return {"data": dict(summary)}

    @router.post("/billing/checkout")
    async def billing_checkout(
        request: Request,
        body: CheckoutRequest,
        principal: ManagementPrincipal,
        settings: SettingsDep,
    ) -> JSONResponse:
        workspace_id = body.workspace_id or principal.workspace.id
        if workspace_id != principal.workspace.id:
            raise api_error(403, "Forbidden", ErrorType.FORBIDDEN)
        if is_wallet_only_principal(principal) and not is_stablecoin_checkout_method(
            body.payment_method
        ):
            raise api_error(
                403,
                WALLET_ONLY_STABLECOIN_MESSAGE,
                ErrorType.FORBIDDEN,
            )
        body = _checkout_body_with_first_party_returns(body, request, settings)
        account = STORE.get_credit_account(workspace_id)
        initiating_user_id = _principal_user_id(principal)
        checkout_data = (
            create_adyen_checkout_session(
                body=body,
                workspace_id=workspace_id,
                customer_email=_checkout_customer_email(principal),
                settings=settings,
            )
            if body.payment_method == "adyen"
            else create_paypal_checkout_session(
                body=body,
                workspace_id=workspace_id,
                initiating_user_id=initiating_user_id,
                customer_email=_checkout_customer_email(principal),
                settings=settings,
            )
            if body.payment_method == "paypal"
            else create_checkout_session(
                body=body,
                workspace_id=workspace_id,
                initiating_user_id=initiating_user_id,
                customer_email=_checkout_customer_email(principal),
                customer_id=account.stripe_customer_id if account else None,
                settings=settings,
            )
        )
        if body.purpose == "identity_verification":
            # Checkout response metadata only; verification gates read strongly.
            lifetime_topup = STORE.get_lifetime_topup_microdollars(
                initiating_user_id,
                allow_stale=True,
            )
            checkout_data.update(
                money_pair(
                    "verification_topup_remaining",
                    max(0, VERIFICATION_MIN_LIFETIME_TOPUP_MICRODOLLARS - lifetime_topup),
                )
            )
        return JSONResponse(
            {"data": checkout_data},
            status_code=201,
        )

    @router.post("/billing/paypal/orders/{order_id}/capture")
    async def billing_paypal_capture(
        order_id: str,
        principal: ManagementPrincipal,
        settings: SettingsDep,
    ) -> dict[str, dict[str, Any]]:
        _reject_wallet_only_traditional_billing(principal)
        result = capture_paypal_order_for_workspace(
            order_id=order_id,
            workspace_id=principal.workspace.id,
            settings=settings,
        )
        return {
            "data": {
                "order_id": result.order_id or order_id,
                "capture_id": result.capture_id,
                "workspace_id": result.workspace_id,
                "credited": result.credited,
                "status": result.status,
                **money_pair("amount", result.amount_microdollars),
                **money_pair("processing_fee", result.processing_fee_microdollars),
                **money_pair("total", result.charge_amount_microdollars),
            }
        }

    @router.post("/billing/x402/fund")
    async def billing_x402_fund(
        request: Request,
        settings: SettingsDep,
    ) -> JSONResponse:
        if not settings.x402_enabled:
            raise api_error(404, "route not found", ErrorType.NOT_FOUND)
        principal = principal_from_request(request, settings)
        if principal.api_key is None:
            raise api_error(403, "An API key is required for x402 funding", ErrorType.FORBIDDEN)
        # No v1 delegated scope grants money movement through x402.
        if principal.scopes:
            raise api_error(
                403,
                "No delegated scope grants x402 funding",
                ErrorType.INSUFFICIENT_SCOPE,
            )
        body = _validated_x402_body(X402FundingRequest, await json_body(request))
        validate_x402_funding_amount(body.amount, settings)
        _enforce_x402_rate_limit(
            namespace="x402_fund_key",
            subject=principal.api_key.hash,
            limit=settings.x402_rate_limit_key_per_window,
            settings=settings,
        )
        _enforce_x402_rate_limit(
            namespace="x402_fund_workspace",
            subject=principal.workspace.id,
            limit=settings.x402_rate_limit_workspace_per_window,
            settings=settings,
        )
        challenge = create_x402_funding_challenge(
            body=body,
            workspace_id=principal.workspace.id,
            initiating_user_id=_principal_user_id(principal),
            settings=settings,
        )
        return JSONResponse(
            x402_payment_required_response_body(challenge),
            status_code=402,
            headers={X402_HEADER: str(challenge["payment_required_header"])},
        )

    @router.post("/billing/x402/settle")
    async def billing_x402_settle(
        request: Request,
        settings: SettingsDep,
    ) -> dict[str, dict[str, Any]]:
        if not settings.x402_enabled:
            raise api_error(404, "route not found", ErrorType.NOT_FOUND)
        principal = principal_from_request(request, settings)
        if principal.api_key is None:
            raise api_error(403, "An API key is required for x402 settlement", ErrorType.FORBIDDEN)
        # No v1 delegated scope grants money movement through x402.
        if principal.scopes:
            raise api_error(
                403,
                "No delegated scope grants x402 settlement",
                ErrorType.INSUFFICIENT_SCOPE,
            )
        body = _validated_x402_body(X402SettleRequest, await json_body(request))
        _enforce_x402_rate_limit(
            namespace="x402_settle_workspace",
            subject=principal.workspace.id,
            limit=settings.x402_settle_workspace_per_window,
            settings=settings,
        )
        _enforce_x402_rate_limit(
            namespace="x402_settle",
            subject=f"{principal.workspace.id}:{body.payment_intent_id}",
            limit=settings.x402_settle_rate_limit_per_window,
            settings=settings,
        )
        result = settle_x402_payment(
            payment_intent_id=body.payment_intent_id,
            workspace_id=principal.workspace.id,
            settings=settings,
        )
        return {"data": result}

    @router.post("/billing/portal")
    async def billing_portal(
        request: Request,
        principal: ManagementPrincipal,
        settings: SettingsDep,
    ) -> dict[str, dict[str, str]]:
        _reject_wallet_only_traditional_billing(principal)
        body = await json_body(request)
        return_url = str(body.get("return_url") or f"{request_control_origin(request, settings)}/billing")
        account = STORE.get_credit_account(principal.workspace.id)
        customer_id = account.stripe_customer_id if account else None
        return {"data": create_billing_portal_session(customer_id=customer_id, return_url=return_url, settings=settings)}

    @router.post("/billing/payment-methods/setup")
    async def billing_payment_method_setup(
        request: Request,
        principal: ManagementPrincipal,
        settings: SettingsDep,
    ) -> JSONResponse:
        _reject_wallet_only_traditional_billing(principal)
        account = STORE.get_credit_account(principal.workspace.id)
        return JSONResponse(
            {
                "data": create_payment_method_session(
                    workspace_id=principal.workspace.id,
                    customer_email=_checkout_customer_email(principal),
                    customer_id=account.stripe_customer_id if account else None,
                    success_url=(
                        f"{request_control_origin(request, settings)}"
                        "/billing/payment-methods/success"
                    ),
                    cancel_url=(
                        f"{request_control_origin(request, settings)}"
                        "/billing/payment-methods"
                    ),
                    settings=settings,
                )
            },
            status_code=201,
        )

    @router.post("/credits/coinbase")
    async def credits_coinbase() -> JSONResponse:
        return deprecated()


def _checkout_customer_email(principal: Any) -> str | None:
    if principal.user is not None and principal.user.email and "@" in principal.user.email:
        return principal.user.email
    if principal.api_key is not None and principal.api_key.creator_user_id:
        user = STORE.get_user(principal.api_key.creator_user_id)
        if user is not None and user.email and "@" in user.email:
            return user.email
    return None


def _principal_user_id(principal: Any) -> str:
    if principal.user is not None:
        return str(principal.user.id)
    if principal.api_key is not None and principal.api_key.creator_user_id:
        return str(principal.api_key.creator_user_id)
    return str(principal.workspace.owner_user_id)


def _reject_wallet_only_traditional_billing(principal: Any) -> None:
    if is_wallet_only_principal(principal):
        raise api_error(
            403,
            WALLET_ONLY_STABLECOIN_MESSAGE,
            ErrorType.FORBIDDEN,
        )


def _checkout_body_with_first_party_returns(
    body: CheckoutRequest,
    request: Request,
    settings: Settings,
) -> CheckoutRequest:
    origin = request_control_origin(request, settings)
    if body.payment_method == "paypal":
        default_success = f"{origin}/billing/paypal/success"
        default_cancel = f"{origin}/billing/paypal/cancel"
    elif body.payment_method == "adyen":
        default_success = f"{origin}/billing/adyen/return"
        default_cancel = f"{origin}/billing"
    else:
        default_success = f"{origin}/billing/success"
        default_cancel = f"{origin}/billing"
    return body.model_copy(
        update={
            "success_url": body.success_url or default_success,
            "cancel_url": body.cancel_url or default_cancel,
        }
    )


def _validated_x402_body(model: Any, body: dict[str, Any]) -> Any:
    try:
        return model.model_validate(body)
    except ValidationError as exc:
        first = cast(dict[str, Any], exc.errors()[0]) if exc.errors() else {}
        loc = ".".join(str(part) for part in first.get("loc", []) if part != "body") or "body"
        message = first.get("msg") or "Invalid request body"
        raise api_error(400, f"{loc}: {message}", ErrorType.BAD_REQUEST) from exc


def _enforce_x402_rate_limit(
    *,
    namespace: str,
    subject: str,
    limit: int,
    settings: Any,
) -> None:
    if limit <= 0:
        return
    try:
        hit = STORE.hit_rate_limit(
            namespace=namespace,
            subject=subject,
            limit=limit,
            window_seconds=settings.x402_rate_limit_window_seconds,
        )
    except Exception as exc:  # noqa: BLE001 - payment creation must fail closed.
        log.exception(
            "x402.rate_limit_unavailable",
            extra={"namespace": namespace, "subject": subject},
        )
        raise api_error(503, "x402 rate limiter is unavailable", ErrorType.SERVICE_UNAVAILABLE) from exc
    if not hit.allowed:
        raise api_error(429, "x402 funding rate limit exceeded", ErrorType.RATE_LIMITED)
