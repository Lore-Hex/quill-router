from __future__ import annotations

import asyncio
import datetime as dt
import hashlib
import html
import json
import logging
import re
import threading
import time
import uuid
from collections import OrderedDict
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse

import httpx
from email_validator import EmailNotValidError, validate_email
from fastapi import BackgroundTasks, FastAPI, HTTPException, Query, Request
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.responses import (
    FileResponse,
    HTMLResponse,
    JSONResponse,
    PlainTextResponse,
    RedirectResponse,
)
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool
from starlette.responses import Response
from starlette.types import Scope

from trusted_router.acquisition import (
    exchange_site_campaign,
    exchange_site_touch,
    log_browser_funnel_event,
    log_exchange_site_funnel_event,
)
from trusted_router.ai_iq import ai_iq_catalog_payload
from trusted_router.apps import aggregate_apps
from trusted_router.benchmark_reports import monthly_benchmark_report
from trusted_router.benchmark_samples import (
    PUBLIC_BENCHMARK_RECENT_MINUTES,
    PUBLIC_BENCHMARK_SAMPLE_LIMIT,
    public_benchmark_samples,
    public_video_benchmark_samples,
)
from trusted_router.catalog import (
    META_MODEL_IDS,
    MODELS,
    PROVIDERS,
    endpoints_for_model,
    provider_to_openrouter_shape,
    providers_for_display,
)
from trusted_router.choose_catalog import choose_catalog_payload
from trusted_router.client_reliability import client_observed_status_section
from trusted_router.config import Settings
from trusted_router.dashboard import (
    MODEL_SEO_SECTIONS,
    OPENROUTER_PAID_LANDING_VARIANTS,
    STATIC_DIR,
    assigned_openrouter_landing_path,
    canonical_model_comparison_path,
    dashboard_html,
    docs_llms_full_txt,
    docs_llms_txt,
    hipaa_readiness_json,
    llms_txt,
    procurement_json,
    public_about_html,
    public_apps_html,
    public_baa_html,
    public_benchmark_report_html,
    public_benchmark_reports_index_html,
    public_benchmarks_html,
    public_blog_index_html,
    public_blog_post_html,
    public_chat_html,
    public_competitor_compare_html,
    public_competitor_compare_index_html,
    public_contact_html,
    public_dpa_html,
    public_fusion_html,
    public_google_search_experiment_html,
    public_hipaa_readiness_html,
    public_leaderboard_html,
    public_legal_html,
    public_model_compare_html,
    public_model_compare_index_html,
    public_model_detail_html,
    public_model_not_found_html,
    public_model_region_html,
    public_model_section_html,
    public_models_html,
    public_openrouter_experiment_html,
    public_page_html,
    public_privacy_html,
    public_provider_detail_html,
    public_provider_performance_html,
    public_providers_html,
    public_rankings_html,
    public_sms_html,
    public_soc2_readiness_html,
    public_subprocessors_html,
    public_support_html,
    public_terms_html,
    public_video_leaderboard_html,
    robots_txt,
    sitemap_comparisons_xml,
    sitemap_core_xml,
    sitemap_models_xml,
    sitemap_providers_xml,
    sitemap_xml,
    soc2_readiness_json,
    subprocessors_json,
)
from trusted_router.domains import (
    canonical_public_url,
    control_domain_for_hostname,
    is_status_hostname,
    is_trust_hostname,
    request_api_base_url,
    request_control_domain,
    request_hostname,
    status_hostname_for_domain,
)
from trusted_router.marketing_experiments import (
    GOOGLE_SEARCH_CELLS_BY_ID,
    GOOGLE_SEARCH_EXPERIMENT_ID,
    assigned_google_search_cell,
)
from trusted_router.mcp_metadata import (
    MCP_SERVER_DESCRIPTION,
    MCP_SERVER_NAME,
    MCP_SERVER_TITLE,
)
from trusted_router.og import OG_PNG_PATH
from trusted_router.operational_analytics_freshness import (
    ANALYTICS_STATUS_KEY,
    REASON_UNREACHABLE,
    OutboxFreshness,
    analytics_status_from_reading,
    analytics_status_unavailable,
)
from trusted_router.provider_contract import (
    PROVIDER_CATALOG_SCHEMA,
    PROVIDER_CATALOG_V2_SCHEMA,
)
from trusted_router.public_analytics_snapshots import current_public_analytics_snapshot
from trusted_router.public_catalog_aliases import (
    canonical_public_model_id,
    canonical_public_provider_slug,
)
from trusted_router.receipt_keys import (
    is_canonical_receipt_kid,
    with_receipt_attestation_sha256,
)
from trusted_router.request_limits import normalized_client_identity
from trusted_router.routes.mcp import MCP_PROTOCOL_VERSION
from trusted_router.scopes import KNOWN_SCOPES
from trusted_router.serialization import user_model_public_shape
from trusted_router.services.email import EmailMessage, get_email_service
from trusted_router.services.ops_chat import OpsChatSupportMessage, fanout_support_message
from trusted_router.services.trust_release import (
    ResolvedTrustRelease,
    TrustReleaseResolver,
    TrustReleaseUnavailable,
    embedded_aws_metadata,
    embedded_azure_metadata,
    unavailable_trust_release,
    validated_aws_metadata,
    validated_azure_metadata,
)
from trusted_router.storage import STORE
from trusted_router.storage_custom_models import (
    is_user_provided_model_id,
    normalize_user_provided_model_id,
)
from trusted_router.storage_models import (
    ReceiptKey,
    SyntheticProbeSample,
    SyntheticRollup,
    iso_now,
    utcnow,
)
from trusted_router.synthetic.fleet import fleet_peers, fleet_snapshot
from trusted_router.synthetic.leaderboard import aggregate_leaderboard
from trusted_router.synthetic.status import history_payload, status_snapshot
from trusted_router.synthetic.video_leaderboard import aggregate_video_leaderboard
from trusted_router.token_exchange import PROFILES as EXCHANGE_PROFILES
from trusted_router.token_exchange import exchange_evidence
from trusted_router.trust import aws_release, azure_release, gcp_release, trust_html
from trusted_router.views import render_template

STATUS_SNAPSHOT_CACHE_SECONDS = 15
LEGACY_MODEL_PAGE_REDIRECTS: dict[str, str] = {
    "deepseek/deepseek-chat-v3.1": "/models/deepseek/deepseek-v3.1",
    "google/gemini-3-pro-image": "/models/google/gemini-3.1-flash-image-preview",
}
LEGACY_MODEL_SECTION_REDIRECTS: dict[tuple[str, str], str] = {
    # This one-route model answers its only pricing question on the overview.
    # Consolidate the historical facet instead of serving a duplicate thin page.
    ("qwen/qwen-3-8-27b", "pricing"): "/models/qwen/qwen-3-8-27b",
}


def _canonical_public_provider_slug(provider_slug: str) -> str:
    return canonical_public_provider_slug(provider_slug, PROVIDERS)


def _canonical_public_model_id(model_id: str) -> str:
    return canonical_public_model_id(model_id, MODELS)


STATUS_RAW_SAMPLE_LIMIT_PER_DAY = 35_000
STATUS_LIVE_SAMPLE_LIMIT = 500
STATUS_HOUR_ROLLUP_LIMIT = 5_000
STATUS_DAY_ROLLUP_LIMIT = 25_000
STATUS_MONTH_ROLLUP_LIMIT = 5_000
STATUS_ROLLUP_RETENTION_MONTHS = 24
STATUS_RESPONSE_CACHE_SECONDS = 60
STATUS_RESPONSE_STALE_SECONDS = 600
PUBLIC_RESPONSE_CACHE_MAX_ENTRIES = 32
PUBLIC_RESPONSE_REFRESH_MAX_THREADS = 2
STATUS_HISTORY_CACHE_SECONDS = 300
STATUS_HISTORY_STALE_SECONDS = 1_800
LEADERBOARD_SAMPLE_LIMIT = PUBLIC_BENCHMARK_SAMPLE_LIMIT
LEADERBOARD_MIN_SAMPLES = 1
LEADERBOARD_MODEL_RANK_MIN_SAMPLES = 10
LEADERBOARD_PROVIDER_RANK_MIN_SAMPLES = 30
LEADERBOARD_RANK_MIN_TTFT_SAMPLES = 3
LEADERBOARD_RECENT_WINDOW_MINUTES = PUBLIC_BENCHMARK_RECENT_MINUTES
LEADERBOARD_SNAPSHOT_CACHE_SECONDS = 300
LEADERBOARD_RESPONSE_CACHE_SECONDS = 60
LEADERBOARD_RESPONSE_STALE_SECONDS = 600
VIDEO_LEADERBOARD_SAMPLE_LIMIT = 5_000
VIDEO_LEADERBOARD_RECENT_WINDOW_MINUTES = 30 * 24 * 60
CHOOSE_PAGE_CACHE_SECONDS = 300
CHOOSE_PAGE_STALE_SECONDS = 86_400
CHOOSE_CATALOG_CACHE_SECONDS = 300
CHOOSE_CATALOG_STALE_SECONDS = 86_400
# Jurisdiction directories walk every model's endpoints on each build, so they
# cache on the same terms as /choose: fresh for five minutes, servable stale for
# a day while a background rebuild runs.
MODEL_REGION_PAGE_CACHE_SECONDS = 300
MODEL_REGION_PAGE_STALE_SECONDS = 86_400
INDEXNOW_KEY = "360a02e48445d297f9612a4c3fef878b"
OPENROUTER_LANDING_EXPERIMENT_CAMPAIGNS = frozenset(
    {
        "openrouter_alternative_exact",
        "openrouter_lp_multi_20260822",
    }
)
_STATUS_CACHE: tuple[float, dict[str, Any]] | None = None
# Share the 60s response cadence even across snapshot/stale-fallback rebuilds.
_STATUS_ANALYTICS_CACHE: tuple[float, dict[str, Any]] | None = None
_STATUS_ANALYTICS_CACHE_LOCK = threading.Lock()
# /fleet fans out to every peer's status.json, so its cache TTL is what keeps
# a page-refresh storm from turning into a cross-cloud fetch storm.
_FLEET_CACHE: tuple[float, dict[str, Any]] | None = None
_FLEET_CACHE_LOCK = asyncio.Lock()
FLEET_SNAPSHOT_CACHE_SECONDS = 30
_LEADERBOARD_CACHE: tuple[float, dict[str, Any]] | None = None
_VIDEO_LEADERBOARD_CACHE: tuple[float, dict[str, Any]] | None = None
_APPS_CACHE: tuple[float, dict[str, Any]] | None = None
_STATUS_RESPONSE_CACHE: OrderedDict[str, _CachedPublicBody] = OrderedDict()
_STATUS_RESPONSE_REFRESHING: set[str] = set()
_STATUS_RESPONSE_CACHE_LOCK = threading.RLock()
_STATUS_RESPONSE_REFRESH_SLOTS = threading.BoundedSemaphore(PUBLIC_RESPONSE_REFRESH_MAX_THREADS)
_STATIC_ASSET_CACHE_LOCK = threading.Lock()
_STATIC_ASSET_BYTES_BY_ROOT: dict[str, dict[str, bytes]] = {}


@dataclass(frozen=True)
class _CachedPublicBody:
    cached_at: float
    body: bytes
    media_type: str
    cache_control: str


class _CachedStaticFiles(StaticFiles):
    """Serve immutable image assets without runtime container-file reads.

    Cloud Run's container filesystem is normally reliable, but a regional
    storage incident must not turn a cache miss for a logo into a website
    outage. Public images are small enough to load once before the instance is
    ready. Range requests retain Starlette's disk-backed behavior; ordinary
    GET and HEAD requests use the in-memory copy.

    Browser caches keep unversioned paths for one day while Cloud CDN keeps a
    shared copy for seven. Explicit ``?v=`` URLs are immutable for one year.
    """

    _SHARED_MAX_AGE = 7 * 86_400
    _VERSIONED_MAX_AGE = 365 * 86_400

    def __init__(self, *args: Any, max_age: int = 86_400, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._max_age = max_age
        self._asset_bytes: dict[str, bytes] = {}
        for directory in self.all_directories:
            root = Path(directory).resolve()
            root_key = str(root)
            with _STATIC_ASSET_CACHE_LOCK:
                cached = _STATIC_ASSET_BYTES_BY_ROOT.get(root_key)
                if cached is None:
                    cached = {
                        str(asset.resolve()): asset.read_bytes()
                        for asset in root.rglob("*")
                        if asset.is_file()
                    }
                    _STATIC_ASSET_BYTES_BY_ROOT[root_key] = cached
            self._asset_bytes.update(cached)

    def _cache_control(self, scope: Scope) -> str:
        query = scope.get("query_string", b"")
        versioned = any(
            field.partition(b"=")[0] == b"v" for field in query.split(b"&") if field
        )
        if versioned:
            return f"public, max-age={self._VERSIONED_MAX_AGE}, immutable"
        return (
            f"public, max-age={self._max_age}, s-maxage={self._SHARED_MAX_AGE}, "
            f"stale-while-revalidate={self._max_age}, "
            f"stale-if-error={self._SHARED_MAX_AGE}"
        )

    def file_response(
        self,
        full_path: Any,
        stat_result: Any,
        scope: Scope,
        status_code: int = 200,
    ) -> Response:
        response = super().file_response(full_path, stat_result, scope, status_code=status_code)
        if str(full_path).casefold().endswith(".woff2"):
            response.headers["content-type"] = "font/woff2"
        response.headers.setdefault("cache-control", self._cache_control(scope))
        if response.status_code == 304 or any(
            name.lower() == b"range" for name, _value in scope.get("headers", [])
        ):
            return response

        content = self._asset_bytes.get(str(Path(full_path).resolve()))
        if content is None:
            return response
        body = b"" if scope.get("method") == "HEAD" else content
        return Response(
            content=body,
            status_code=response.status_code,
            headers=dict(response.headers),
        )


log = logging.getLogger(__name__)
_leads_log = logging.getLogger("tr_leads.trustedos_inquiry")
_leads_log.propagate = False
if not _leads_log.handlers:
    _leads_handler = logging.StreamHandler()
    _leads_handler.setFormatter(logging.Formatter("%(message)s"))
    _leads_log.addHandler(_leads_handler)

# Simple in-process sliding-window limiter for the public TrustedOS inquiry
# form. Not a substitute for an edge WAF, but enough to blunt casual abuse of
# an unauthenticated POST that fans out to email. Keyed by client IP.
_INQUIRY_RATE_LOCK = threading.Lock()
_INQUIRY_MAX_CLIENTS = 4096
_INQUIRY_HITS: OrderedDict[str, list[float]] = OrderedDict()
_INQUIRY_GLOBAL_HITS: list[float] = []
_INQUIRY_WINDOW_SECONDS = 3600.0
_INQUIRY_MAX_PER_WINDOW = 5
_INQUIRY_GLOBAL_MAX_PER_WINDOW = 60
_RECEIPT_KEY_CACHE_MAX_KIDS = 128
_RECEIPT_KEY_PUBLIC_PAGE_SIZE = 250
_RECEIPT_KEY_PUBLIC_MAX_BYTES = 1024 * 1024
_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
_SUPPORT_CATEGORIES = {
    "api": "API and routing",
    "account": "Account access",
    "billing": "Billing and credits",
    "provider": "Provider or model",
    "model": "Model request",
    "feature": "Feature request",
    "other": "Other",
}


def _remember_receipt_key_records(
    cache: OrderedDict[str, list[ReceiptKey]],
    kid: str,
    records: list[ReceiptKey],
) -> None:
    """Cache only known kids in a fixed-size least-recently-written map."""

    cache.pop(kid, None)
    if not records:
        return
    cache[kid] = records
    while len(cache) > _RECEIPT_KEY_CACHE_MAX_KIDS:
        cache.popitem(last=False)


def _public_receipt_key(record: ReceiptKey) -> dict[str, Any]:
    return {
        "kid": record.kid,
        "jwk": {
            "kty": record.jwk.get("kty"),
            "crv": record.jwk.get("crv"),
            "x": record.jwk.get("x"),
        },
        "att": record.att,
        "att_kind": record.att_kind,
        "att_sha256": record.att_sha256,
        "plane": record.plane,
        "first_seen": record.first_seen,
        "last_seen": record.last_seen,
        "revoked": record.revoked,
        "verified": record.verified,
    }


def _receipt_key_cursor(record: ReceiptKey) -> str:
    return f"{record.kid}.{record.att_sha256}"


def _parse_receipt_key_cursor(value: str) -> tuple[str, str] | None:
    parts = value.split(".")
    if len(parts) != 2 or not all(is_canonical_receipt_kid(part) for part in parts):
        return None
    return parts[0], parts[1]


@dataclass(frozen=True)
class _UnfilteredReceiptKeyCursor:
    phase: str
    kid: str
    att_sha256: str = ""


def _parse_unfiltered_receipt_key_cursor(
    value: str,
) -> _UnfilteredReceiptKeyCursor | None:
    parts = value.split(".")
    if (
        len(parts) == 3
        and parts[0] == "v"
        and is_canonical_receipt_kid(parts[1])
        and is_canonical_receipt_kid(parts[2])
    ):
        return _UnfilteredReceiptKeyCursor("v", parts[1], parts[2])
    if len(parts) == 2 and parts[0] == "l" and is_canonical_receipt_kid(parts[1]):
        return _UnfilteredReceiptKeyCursor("l", parts[1])
    return None


def _unfiltered_receipt_key_page(
    *,
    limit: int,
    after: _UnfilteredReceiptKeyCursor | None,
) -> tuple[list[ReceiptKey], list[str]]:
    """Read projected versions first, then legacy ids, without mixing cursors."""

    records: list[ReceiptKey] = []
    cursors: list[str] = []
    if after is None or after.phase == "v":
        version_after = None if after is None else (after.kid, after.att_sha256)
        versioned = [
            with_receipt_attestation_sha256(record)
            for record in STORE.list_receipt_keys(
                limit=limit,
                after=version_after,
                phase="v",
            )
        ]
        records.extend(versioned)
        cursors.extend(f"v.{record.kid}.{record.att_sha256}" for record in versioned)
    if len(records) < limit:
        legacy_after = after.kid if after is not None and after.phase == "l" else None
        legacy = [
            with_receipt_attestation_sha256(record)
            for record in STORE.list_receipt_keys(
                limit=limit - len(records),
                phase="l",
                legacy_after=legacy_after,
            )
        ]
        records.extend(legacy)
        cursors.extend(f"l.{record.kid}" for record in legacy)
    return records, cursors


def _inquiry_rate_ok(client_ip: str, *, now: float | None = None) -> bool:
    now = time.time() if now is None else now
    cutoff = now - _INQUIRY_WINDOW_SECONDS
    with _INQUIRY_RATE_LOCK:
        _INQUIRY_GLOBAL_HITS[:] = [hit for hit in _INQUIRY_GLOBAL_HITS if hit > cutoff]
        if len(_INQUIRY_GLOBAL_HITS) >= _INQUIRY_GLOBAL_MAX_PER_WINDOW:
            return False
        hits = [t for t in _INQUIRY_HITS.get(client_ip, ()) if t > cutoff]
        if len(hits) >= _INQUIRY_MAX_PER_WINDOW:
            _INQUIRY_HITS[client_ip] = hits
            _INQUIRY_HITS.move_to_end(client_ip)
            _bound_inquiry_clients(cutoff)
            return False
        hits.append(now)
        _INQUIRY_GLOBAL_HITS.append(now)
        _INQUIRY_HITS[client_ip] = hits
        _INQUIRY_HITS.move_to_end(client_ip)
        _bound_inquiry_clients(cutoff)
    return True


def _bound_inquiry_clients(cutoff: float) -> None:
    if len(_INQUIRY_HITS) <= _INQUIRY_MAX_CLIENTS:
        return
    stale = [key for key, hits in _INQUIRY_HITS.items() if not any(hit > cutoff for hit in hits)]
    for key in stale:
        _INQUIRY_HITS.pop(key, None)
    while len(_INQUIRY_HITS) > _INQUIRY_MAX_CLIENTS:
        _INQUIRY_HITS.popitem(last=False)


def _inquiry_client_identity(request: Request, settings: Settings) -> str:
    """Select the bounded form limiter's client identity.

    The explicit combined bridge preserves the pre-#714 socket identity until
    #712 moves these actions behind an edge that overwrites the dedicated
    client-IP header. Split surfaces retain the fail-closed edge identity
    contract and never trust forwarding headers or an arbitrary socket peer.
    """

    if settings.service_surface == "combined" and settings.allow_deployed_combined_surface:
        return request.client.host if request.client else "unknown"
    return normalized_client_identity(request, settings)


async def _handle_trustedos_inquiry(settings: Settings, request: Request) -> JSONResponse:
    """Receive a TrustedOS partner-inquiry submission and email it to the
    configured recipient. Returns an opaque {"ok": true} on accept so the
    endpoint never leaks whether email delivery or suppression happened."""
    ok = JSONResponse({"ok": True})

    try:
        payload = await request.json()
    except (json.JSONDecodeError, ValueError):
        return JSONResponse({"ok": False, "error": "invalid_request"}, status_code=400)
    if not isinstance(payload, dict):
        return JSONResponse({"ok": False, "error": "invalid_request"}, status_code=400)

    # Honeypot: a hidden field real users never fill. Silently accept so bots
    # get a success and move on, without an email being sent.
    if str(payload.get("website", "")).strip():
        return ok

    name = str(payload.get("name", "")).strip()[:200]
    email = str(payload.get("email", "")).strip()[:320]
    company = str(payload.get("company", "")).strip()[:200]
    message = str(payload.get("message", "")).strip()[:5000]

    if not name or not message or not _EMAIL_RE.match(email):
        return JSONResponse({"ok": False, "error": "missing_fields"}, status_code=422)

    client_ip = _inquiry_client_identity(request, settings)
    if not _inquiry_rate_ok(client_ip):
        return JSONResponse({"ok": False, "error": "rate_limited"}, status_code=429)

    recipient = settings.partner_inquiry_email or settings.ses_from_email
    if not recipient:
        # No inbox configured — emit a metadata-only diagnostic and still
        # report success to the sender.
        log.error(
            "trustedos_inquiry.no_recipient name=%r email=%r company_len=%d message_len=%d",
            name,
            email,
            len(company or ""),
            len(message or ""),
        )
        # Full lead goes to first-party stderr logs only. This logger is outside
        # the trusted_router namespace and propagate=False keeps it off the
        # root-attached third-party Axiom handler.
        _leads_log.error(
            "trustedos_inquiry.lead recipient=%r name=%r email=%r company=%r message=%r",
            recipient,
            name,
            email,
            company,
            message,
        )
        return ok

    log.info(
        "trustedos_inquiry.received name=%r email=%r company_len=%d message_len=%d",
        name,
        email,
        len(company or ""),
        len(message or ""),
    )

    text_body = (
        "New TrustedOS partner inquiry\n\n"
        f"Name:    {name}\n"
        f"Company: {company or '(not given)'}\n"
        f"Email:   {email}\n"
        f"IP:      {client_ip}\n\n"
        f"Message:\n{message}\n"
    )
    subject = f"TrustedOS inquiry: {company or name}"
    try:
        sent = get_email_service(settings).send(
            EmailMessage(
                to=recipient,
                subject=subject,
                text_body=text_body,
                mail_class="partner_inquiry",
            )
        )
    except Exception:  # noqa: BLE001 - never surface mailer errors to the form
        sent = False
        log.exception(
            "trustedos_inquiry.send_failed name=%r email=%r company_len=%d message_len=%d",
            name,
            email,
            len(company or ""),
            len(message or ""),
        )
    if not sent:
        # send() returns False when SES is unconfigured or the recipient is
        # suppressed. Surface a metadata-only diagnostic so alerting sees the
        # delivery issue without logging submitted free text.
        log.error(
            "trustedos_inquiry.delivery_failed recipient=%r name=%r email=%r company_len=%d message_len=%d",
            recipient,
            name,
            email,
            len(company or ""),
            len(message or ""),
        )
        # Full lead goes to first-party stderr logs only. This logger is outside
        # the trusted_router namespace and propagate=False keeps it off the
        # root-attached third-party Axiom handler.
        _leads_log.error(
            "trustedos_inquiry.lead recipient=%r name=%r email=%r company=%r message=%r",
            recipient,
            name,
            email,
            company,
            message,
        )
    return ok


async def _handle_support_inquiry(settings: Settings, request: Request) -> JSONResponse:
    """Send support mail without logging submitted free text or identity fields."""
    try:
        payload = await request.json()
    except (json.JSONDecodeError, ValueError):
        return JSONResponse({"ok": False, "error": "invalid_request"}, status_code=400)
    if not isinstance(payload, dict):
        return JSONResponse({"ok": False, "error": "invalid_request"}, status_code=400)

    # Silently accept honeypot submissions so automated senders do not learn
    # which field caused the drop.
    if str(payload.get("website", "")).strip():
        return JSONResponse({"ok": True})

    name = str(payload.get("name", "")).strip()[:200]
    email = str(payload.get("email", "")).strip()[:320]
    subject = " ".join(str(payload.get("subject", "")).splitlines()).strip()[:200]
    message = str(payload.get("message", "")).strip()[:5000]
    request_id = str(payload.get("request_id", "")).strip()[:200]
    category = str(payload.get("category", "other")).strip().lower()
    category_label = _SUPPORT_CATEGORIES.get(category)

    if (
        not name
        or not subject
        or not message
        or not _EMAIL_RE.fullmatch(email)
        or category_label is None
    ):
        return JSONResponse({"ok": False, "error": "missing_fields"}, status_code=422)

    client_ip = _inquiry_client_identity(request, settings)
    if not _inquiry_rate_ok(f"support:{client_ip}"):
        return JSONResponse({"ok": False, "error": "rate_limited"}, status_code=429)

    text_body = (
        "New TrustedRouter support request\n\n"
        f"Category:   {category_label}\n"
        f"Name:       {name}\n"
        f"Email:      {email}\n"
        f"Request ID: {request_id or '(not given)'}\n\n"
        f"Subject: {subject}\n\n"
        f"Message:\n{message}\n"
    )
    support_message = EmailMessage(
        to=settings.support_email,
        reply_to=email,
        subject=f"TrustedRouter support: {category_label}: {subject}",
        text_body=text_body,
        mail_class="support_inquiry",
    )
    try:
        sent = await run_in_threadpool(
            get_email_service(settings).send,
            support_message,
        )
    except Exception:  # noqa: BLE001 - return a stable support fallback
        sent = False
        log.exception(
            "support_inquiry.send_failed category=%s has_request_id=%s "
            "subject_len=%d message_len=%d",
            category,
            bool(request_id),
            len(subject),
            len(message),
        )
    if not sent:
        log.error(
            "support_inquiry.delivery_failed category=%s has_request_id=%s "
            "subject_len=%d message_len=%d",
            category,
            bool(request_id),
            len(subject),
            len(message),
        )
        return JSONResponse(
            {"ok": False, "error": "delivery_unavailable"},
            status_code=503,
        )

    ops_message = OpsChatSupportMessage(
        message_id=f"support:{uuid.uuid4().hex}",
        name=name,
        email=email,
        subject=f"{category_label}: {subject}",
        message=(f"Request ID: {request_id}\n\n{message}" if request_id else message),
    )
    try:
        fanout = await fanout_support_message(settings, ops_message)
    except Exception:  # noqa: BLE001 - email delivery remains authoritative
        fanout = None
        log.exception(
            "support_inquiry.ops_fanout_exception category=%s",
            category,
        )
    if fanout is not None and fanout.configured and fanout.accepted == 0:
        log.error(
            "support_inquiry.ops_fanout_failed configured=%d category=%s",
            fanout.configured,
            category,
        )
    elif fanout is not None and fanout.accepted < fanout.configured:
        log.warning(
            "support_inquiry.ops_fanout_partial accepted=%d configured=%d category=%s",
            fanout.accepted,
            fanout.configured,
            category,
        )

    log.info(
        "support_inquiry.sent category=%s has_request_id=%s subject_len=%d message_len=%d",
        category,
        bool(request_id),
        len(subject),
        len(message),
    )
    return JSONResponse({"ok": True})


_ENTERPRISE_BRIEF = (
    Path(__file__).parents[1] / "data" / "enterprise" / "TrustedRouter-Token-Exchange-Brochure.pdf"
)
_SECURITY_PACK = _ENTERPRISE_BRIEF.with_name("TrustedRouter-Security-Pack.zip")
_BRIEF_HEADERS = {"Cache-Control": "private, no-store", "X-Robots-Tag": "noindex, nofollow"}
# The static Token Exchange sites (sites/token-exchange/markets.json) host the same brochure
# form and post it here from their own domains. Only the canonical origins are allowed;
# www and alias hosts redirect to these before a page is ever served. The site tests fail
# if a market is missing from this list, and the site publish refuses until it is deployed.
_EXCHANGE_ORIGINS = frozenset(
    f"https://{domain}"
    for domain in json.loads(
        (Path(__file__).parents[1] / "data" / "token_exchange_origins.json").read_text()
    )
)
_BRIEF_PREFLIGHT_HEADERS = {
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "content-type",
    "Access-Control-Max-Age": "600",
}


def _exchange_origin(request: Request) -> str | None:
    """The canonical Token Exchange site a browser request came from, or None."""
    origin = request.headers.get("origin")
    return origin if origin in _EXCHANGE_ORIGINS else None


def _brief_headers(exchange_origin: str | None) -> dict[str, str]:
    headers = dict(_BRIEF_HEADERS)
    if exchange_origin is not None:
        headers["Access-Control-Allow-Origin"] = exchange_origin
        headers["Vary"] = "Origin"
    return headers


async def _handle_enterprise_brief_preflight(request: Request) -> Response:
    """Answer the browser's CORS preflight for the exchange sites only."""
    exchange_origin = _exchange_origin(request)
    if exchange_origin is None:
        return Response(status_code=403, headers=_BRIEF_HEADERS)
    return Response(status_code=204, headers={**_brief_headers(exchange_origin), **_BRIEF_PREFLIGHT_HEADERS})


async def _handle_enterprise_brief(settings: Settings, request: Request) -> Response:
    """Deliver an allowlisted resource only after SES accepts the inquiry.

    Pages on this origin and the canonical Token Exchange sites may call it."""
    exchange_origin = _exchange_origin(request)
    headers = _brief_headers(exchange_origin)

    def error(code: str, status: int) -> JSONResponse:
        return JSONResponse({"ok": False, "error": code}, status_code=status, headers=headers)

    if exchange_origin is None:
        origin = request.headers.get("origin")
        try:
            parsed_origin = urlparse(origin) if origin is not None else None
        except ValueError:
            return error("invalid_origin", 403)
        if request.headers.get("sec-fetch-site") == "cross-site" or (
            parsed_origin is not None
            and (
                parsed_origin.scheme not in {"http", "https"}
                or parsed_origin.netloc != request.url.netloc
            )
        ):
            return error("invalid_origin", 403)
    if request.headers.get("content-type", "").split(";", 1)[0] != "application/json":
        return error("invalid_request", 415)

    # Bound this tiny form independently of the much larger API upload budget.
    body = bytearray()
    async for chunk in request.stream():
        if len(body) + len(chunk) > 8192:
            return error("request_too_large", 413)
        body.extend(chunk)
    try:
        payload = json.loads(body)
    except (ValueError, RecursionError):
        return error("invalid_request", 400)
    if not isinstance(payload, dict):
        return error("invalid_request", 400)
    if payload.get("website"):
        return JSONResponse({"ok": True}, headers=headers)
    resource = payload.get("resource", "brochure")
    if resource == "brochure":
        asset, media_type = _ENTERPRISE_BRIEF, "application/pdf"
        label, page = "brochure", "/token-exchange"
        event = "enterprise_brief_delivered"
    elif resource == "security":
        asset, media_type = _SECURITY_PACK, "application/zip"
        label, page = "security pack", "/token-exchange/security"
        event = "enterprise_security_pack_delivered"
    else:
        return error("invalid_resource", 422)
    email = payload.get("email")
    if not isinstance(email, str) or len(email) > 320:
        return error("invalid_email", 422)
    try:
        address = validate_email(
            email.strip(), check_deliverability=False, allow_smtputf8=False
        )
        email = address.ascii_email or address.normalized
    except EmailNotValidError:
        return error("invalid_email", 422)

    client_ip = _inquiry_client_identity(request, settings)
    if not _inquiry_rate_ok(f"enterprise-brief:{client_ip}"):
        return error("rate_limited", 429)
    if not asset.is_file():
        log.error("enterprise_brief.asset_unavailable")
        return error("delivery_unavailable", 503)

    page_url = f"{exchange_origin}/" if exchange_origin else f"https://trustedrouter.com{page}"
    campaign = exchange_site_campaign(request, payload.get("campaign")) if exchange_origin else {}
    campaign_lines = "".join(f"{name}: {value}\n" for name, value in campaign.items())
    message = EmailMessage(
        to=settings.partner_inquiry_email or "enterprise@trustedrouter.com",
        reply_to=email,
        subject=f"Token Exchange {label} requested | TrustedRouter token exchange",
        text_body=(
            f"An enterprise visitor requested the Token Exchange {label}.\n\n"
            f"Email: {email}\n"
            f"Page: {page_url}\n"
            f"{campaign_lines}\n"
            "The form permits follow-up about enterprise AI. It does not subscribe "
            "the visitor to a newsletter. Reply directly to discuss their requirements.\n"
        ),
        mail_class="enterprise_brief",
    )
    try:
        sent = await run_in_threadpool(get_email_service(settings).send, message)
    except Exception:  # noqa: BLE001 - never expose submitted identity in exception logs
        sent = False
    if not sent:
        log.error("enterprise_brief.delivery_unavailable")
        return error("delivery_unavailable", 503)
    if exchange_origin is not None:
        log_exchange_site_funnel_event(request, event, exchange_site_touch(page_url, campaign))
    else:
        log_browser_funnel_event(request, event)
    return FileResponse(
        asset,
        media_type=media_type,
        filename=asset.name,
        headers=headers,
    )


def register_public_action_routes(app: FastAPI, settings: Settings) -> None:
    """Register anonymous actions on their credential-minimal bulkhead."""

    @app.post("/trustedos/inquiry", include_in_schema=False)
    async def trustedos_inquiry(request: Request) -> JSONResponse:
        return await _handle_trustedos_inquiry(settings, request)

    @app.post("/support/inquiry", include_in_schema=False)
    async def support_inquiry(request: Request) -> JSONResponse:
        return await _handle_support_inquiry(settings, request)

    @app.post("/token-exchange/brief", include_in_schema=False)
    async def enterprise_brief(request: Request) -> Response:
        return await _handle_enterprise_brief(settings, request)

    @app.options("/token-exchange/brief", include_in_schema=False)
    async def enterprise_brief_preflight(request: Request) -> Response:
        return await _handle_enterprise_brief_preflight(request)


def register_public_routes(app: FastAPI, settings: Settings) -> None:
    app.mount("/static", _CachedStaticFiles(directory=STATIC_DIR), name="static")
    trust_release_resolver = TrustReleaseResolver(settings)
    # One resolver per plane. The control plane mirrors three independently
    # published records rather than authoring two of them from its own config.
    aws_release_resolver = TrustReleaseResolver(
        settings,
        urls=[settings.trust_aws_release_url],
        validator=validated_aws_metadata,
        embedded=embedded_aws_metadata,
    )
    azure_release_resolver = TrustReleaseResolver(
        settings,
        urls=[settings.trust_azure_release_url],
        validator=validated_azure_metadata,
        embedded=embedded_azure_metadata,
    )
    # The unfiltered page cache keeps the phase-tagged cursor vector WITH its
    # records: a cached page that crossed from versioned into legacy rows must
    # hand back `l.<id>` for those rows, never a reconstructed `v.` cursor.
    receipt_key_global_cache: tuple[list[ReceiptKey], list[str]] | None = None
    receipt_key_cache: OrderedDict[str, list[ReceiptKey]] = OrderedDict()

    async def _mirrored(
        resolver: TrustReleaseResolver, embedded: Callable[[Settings], Mapping[str, Any]]
    ) -> tuple[Mapping[str, Any], str]:
        """Authoritative record if reachable, else the offline fallback.

        Falling back to config keeps a verified measurement available during an
        upstream outage. It is labelled 'embedded' rather than 'live' so the
        response never implies it was just confirmed from the source.
        """
        try:
            resolved = await resolver.resolve()
            return resolved.metadata, resolved.status
        except TrustReleaseUnavailable:
            return embedded(settings), "embedded"

    async def _plane_record(
        resolver: TrustReleaseResolver,
        embedded: Callable[[Settings], Mapping[str, Any]],
        release: Callable[..., dict[str, Any]],
    ) -> tuple[dict[str, Any], str]:
        """An AWS or Azure record as its route serves it, and the route's status.

        'unavailable' when the record has no measurement to publish.
        """
        metadata, status = await _mirrored(resolver, embedded)
        record = release(settings, metadata=metadata)
        if record["release_metadata_status"] == "not-configured":
            return record, "unavailable"
        return record, status

    async def resolved_trust_release() -> ResolvedTrustRelease:
        try:
            return await trust_release_resolver.resolve()
        except TrustReleaseUnavailable:
            return unavailable_trust_release()

    def trust_response_headers(status: str) -> dict[str, str]:
        return {
            "cache-control": (
                "max-age=60, public" if status in {"live", "embedded"} else "no-store"
            ),
            "x-trustedrouter-release-status": status,
        }

    def trust_response_status(status: str) -> int:
        return 200 if status in {"live", "embedded"} else 503

    async def trust_page_response(*, public_domain: str, api_base_url: str) -> HTMLResponse:
        """The trust page, rendering the three records their own routes serve.

        The page takes the cache policy of its least cacheable record: a stale
        or missing AWS or Azure record makes it no-store, as it makes
        /trust/aws-release.json or /trust/azure-release.json. Its HTTP status
        and x-trustedrouter-release-status are the GCP record's.
        """
        release = await resolved_trust_release()
        aws, aws_status = await _plane_record(
            aws_release_resolver, embedded_aws_metadata, aws_release
        )
        azure, azure_status = await _plane_record(
            azure_release_resolver, embedded_azure_metadata, azure_release
        )
        headers = trust_response_headers(release.status)
        if {aws_status, azure_status} - {"live", "embedded"}:
            headers["cache-control"] = "no-store"
        return HTMLResponse(
            trust_html(
                settings,
                public_domain=public_domain,
                api_base_url=api_base_url,
                release_metadata=release.metadata,
                release_metadata_status=release.status,
                aws_record=aws,
                aws_status=aws_status,
                azure_record=azure,
                azure_status=azure_status,
            ),
            status_code=trust_response_status(release.status),
            headers=headers,
        )

    def public_document_headers(path: str) -> dict[str, str]:
        return {
            "cache-control": "public, max-age=300, s-maxage=3600",
            "link": f'<{canonical_public_url(settings, path)}>; rel="canonical"',
        }

    def public_html_route(
        path: str, *, include_slash: bool = True
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            app.api_route(path, methods=["GET", "HEAD"], response_class=HTMLResponse)(func)
            if include_slash and not path.endswith("/"):
                app.api_route(
                    f"{path}/",
                    methods=["GET", "HEAD"],
                    response_class=HTMLResponse,
                    include_in_schema=False,
                )(func)
            return func

        return decorator

    @app.api_route(
        "/api/reference",
        methods=["GET", "HEAD"],
        response_class=HTMLResponse,
        include_in_schema=False,
    )
    @app.api_route(
        "/api/reference/",
        methods=["GET", "HEAD"],
        response_class=HTMLResponse,
        include_in_schema=False,
    )
    async def api_reference() -> Response:
        canonical_url = f"https://{settings.trusted_domain}/api/reference"
        if settings.service_surface == "observer":
            # Regional status/catalog observers intentionally expose no local
            # schema. Send readers to the CDN-backed public documentation
            # service instead of presenting a Swagger shell that fetches 404.
            return RedirectResponse(url=canonical_url, status_code=307)
        response = get_swagger_ui_html(
            openapi_url=app.openapi_url or "/openapi.json",
            title=f"{app.title} API reference",
        )
        canonical = html.escape(
            canonical_url,
            quote=True,
        )
        title = "TrustedRouter API Reference: Endpoints and Schemas"
        description = (
            "Explore TrustedRouter's OpenAI-compatible API endpoints, request schemas, "
            "authentication, models, keys, billing, observability, and stable compatibility errors."
        )
        escaped_description = html.escape(description, quote=True)
        metadata = (
            f'<meta name="description" content="{escaped_description}">\n'
            f'<link rel="canonical" href="{canonical}">\n'
            '<meta property="og:type" content="website">\n'
            f'<meta property="og:title" content="{html.escape(title, quote=True)}">\n'
            f'<meta property="og:description" content="{escaped_description}">\n'
            f'<meta property="og:url" content="{canonical}">\n'
            '<meta property="og:image" content="https://trustedrouter.com/og.png">\n'
            '<meta name="twitter:card" content="summary_large_image">\n'
        )
        reference_header = (
            '<header style="padding:16px 24px;background:#101820;color:#fff;font-family:'
            'ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif">'
            '<h1 style="font-size:18px;line-height:1.2;margin:0 0 6px;color:#fff">'
            "TrustedRouter API reference</h1>"
            '<p style="max-width:900px;margin:0 0 10px;color:#d7e6f5;font-size:14px;line-height:1.45">'
            "Explore the OpenAI-compatible endpoints, request schemas, authentication, model "
            "routing, billing, observability, and stable compatibility errors used by "
            "TrustedRouter clients. Start with the integration guide, browse the live model "
            "catalog, and review how the attested gateway keeps prompt traffic separate from "
            "the control plane. Requests use one base URL and standard bearer authentication."
            "</p>"
            '<nav aria-label="TrustedRouter API reference links" '
            'style="display:flex;align-items:center;gap:18px;flex-wrap:wrap">'
            '<a href="/docs" style="color:#fff;font-weight:700;text-decoration:none">Docs</a>'
            '<a href="/models" style="color:#d7e6f5;text-decoration:none">Models</a>'
            '<a href="/security" style="color:#d7e6f5;text-decoration:none">Security</a>'
            '<a href="/" style="color:#d7e6f5;text-decoration:none">TrustedRouter</a>'
            "</nav></header>"
        )
        body = (
            bytes(response.body)
            .decode()
            .replace("<html>", '<html lang="en">', 1)
            .replace(
                f"<title>{html.escape(app.title)} API reference</title>",
                f"<title>{html.escape(title)}</title>",
                1,
            )
            .replace(
                "</head>",
                f"{metadata}</head>",
                1,
            )
            .replace("<body>", f"<body>{reference_header}", 1)
        )
        return HTMLResponse(body)

    @app.api_route(
        "/redoc",
        methods=["GET", "HEAD"],
        include_in_schema=False,
    )
    @app.api_route(
        "/docs/oauth2-redirect",
        methods=["GET", "HEAD"],
        include_in_schema=False,
    )
    async def legacy_api_reference() -> RedirectResponse:
        return RedirectResponse(url="/api/reference", status_code=301)

    @public_html_route("/", include_slash=False)
    async def dashboard(request: Request, background_tasks: BackgroundTasks) -> Any:
        hostname = request_hostname(request)
        domain = request_control_domain(request, settings)
        api_base_url = request_api_base_url(request, settings)
        if is_trust_hostname(settings, hostname):
            return await trust_page_response(public_domain=domain, api_base_url=api_base_url)
        if is_status_hostname(settings, hostname):
            return await _cached_status_page_response(
                settings,
                host=hostname,
                background_tasks=background_tasks,
            )
        if hostname == "eu.trustedrouter.com":
            return public_page_html(settings, "eu", site_url="https://eu.trustedrouter.com/")
        alternate_brand = {
            "uptimerouter.com": "UptimeRouter",
            "www.uptimerouter.com": "UptimeRouter",
            "allyrouter.com": "AllyRouter",
            "www.allyrouter.com": "AllyRouter",
        }.get(hostname)
        if alternate_brand:
            canonical_host = hostname.removeprefix("www.")
            return dashboard_html(
                settings,
                api_base_url=api_base_url,
                brand_name=alternate_brand,
                site_url=f"https://{canonical_host}/",
            )
        return dashboard_html(settings, api_base_url=api_base_url)

    @public_html_route("/trust")
    async def trust_page(request: Request) -> HTMLResponse:
        return await trust_page_response(
            public_domain=request_control_domain(request, settings),
            api_base_url=request_api_base_url(request, settings),
        )

    @public_html_route("/compare/openrouter")
    async def compare_openrouter() -> HTMLResponse:
        body = public_competitor_compare_html(settings, "openrouter")
        assert body is not None
        return HTMLResponse(body)

    @public_html_route("/compare/vercel-ai-gateway")
    async def compare_vercel_ai_gateway() -> HTMLResponse:
        body = public_competitor_compare_html(settings, "vercel-ai-gateway")
        assert body is not None
        return HTMLResponse(body)

    @public_html_route("/compare/litellm")
    async def compare_litellm() -> HTMLResponse:
        body = public_competitor_compare_html(settings, "litellm")
        assert body is not None
        return HTMLResponse(body)

    @public_html_route("/compare")
    async def competitor_compare_index() -> HTMLResponse:
        return HTMLResponse(public_competitor_compare_index_html(settings))

    @public_html_route("/docs/migrate-from-openrouter")
    async def migrate_from_openrouter() -> str:
        return public_page_html(settings, "docs/migrate-from-openrouter")

    @public_html_route("/docs/agent-setup")
    async def agent_setup() -> str:
        return public_page_html(settings, "docs/agent-setup")

    @public_html_route("/docs/tagging")
    async def tagging_docs() -> str:
        return public_page_html(settings, "docs/tagging")

    @public_html_route("/docs/provider-routing")
    async def provider_routing_docs() -> str:
        return public_page_html(settings, "docs/provider-routing")

    @public_html_route("/performance-routing")
    async def performance_routing_landing() -> str:
        return public_page_html(settings, "performance-routing")

    @public_html_route("/spend-controls")
    async def spend_controls_landing() -> str:
        return public_page_html(settings, "spend-controls")

    @public_html_route("/prompt-caching")
    async def prompt_caching_landing() -> str:
        return public_page_html(settings, "prompt-caching")

    @public_html_route("/model-precision")
    async def model_precision_landing() -> str:
        return public_page_html(settings, "model-precision")

    @public_html_route("/docs/performance-routing")
    async def performance_routing_docs() -> str:
        return public_page_html(settings, "docs/performance-routing")

    @public_html_route("/docs/spend-controls")
    async def spend_controls_docs() -> str:
        return public_page_html(settings, "docs/spend-controls")

    @public_html_route("/docs/model-precision")
    async def model_precision_docs() -> str:
        return public_page_html(settings, "docs/model-precision")

    @public_html_route("/docs/receipts")
    async def receipts_docs() -> str:
        return public_page_html(settings, "docs/receipts")

    @public_html_route("/docs/telemetry")
    async def telemetry_docs() -> str:
        return public_page_html(settings, "docs/telemetry")

    @public_html_route("/docs/prompt-caching")
    async def prompt_caching_docs() -> str:
        return public_page_html(settings, "docs/prompt-caching")

    @public_html_route("/docs/batch")
    async def batch_docs() -> str:
        return public_page_html(settings, "docs/batch")

    @public_html_route("/docs/decide")
    async def decide_docs() -> str:
        return public_page_html(settings, "docs/decide")

    @public_html_route("/docs/web-search")
    async def web_search_docs() -> str:
        return public_page_html(settings, "docs/web-search")

    @public_html_route("/docs/video")
    async def video_docs() -> str:
        return public_page_html(settings, "docs/video")

    @public_html_route("/docs/mcp")
    async def mcp_docs() -> str:
        return public_page_html(settings, "docs/mcp")

    @public_html_route("/docs/notify")
    async def notify_docs() -> str:
        return public_page_html(settings, "docs/notify")

    @public_html_route("/docs/evals")
    async def evals() -> str:
        return public_page_html(settings, "docs/evals")

    @public_html_route("/docs/provider-conformance")
    async def provider_conformance_docs() -> str:
        return public_page_html(settings, "docs/provider-conformance")

    @public_html_route("/docs/synth")
    async def synth_docs() -> str:
        return public_page_html(settings, "docs/synth")

    @public_html_route("/docs/fusion")
    async def fusion_docs() -> RedirectResponse:
        return RedirectResponse(url="/docs/synth", status_code=301)

    @public_html_route("/docs/x402")
    async def x402_docs() -> str:
        return public_page_html(settings, "docs/x402")

    @public_html_route("/docs/user-models")
    async def user_models_docs() -> str:
        return public_page_html(settings, "docs/user-models")

    @public_html_route("/docs/custom-models")
    async def custom_models_docs() -> str:
        return public_page_html(settings, "docs/custom-models")

    @public_html_route("/eu")
    async def eu() -> str:
        return public_page_html(settings, "eu")

    @public_html_route("/trustedos")
    async def trustedos() -> str:
        return public_page_html(settings, "trustedos")

    @public_html_route("/confidential-cowork")
    async def confidential_cowork() -> str:
        return public_page_html(settings, "confidential-cowork")

    # ── SEO landing pages ────────────────────────────────────────────
    # Top-level slugs targeting high-intent buyer queries. Each is a
    # self-contained sales surface (see PUBLIC_PAGES in dashboard.py).
    # Keep these top-level (not under /seo or /landing) — that hurts
    # ranking and looks defensive.
    @public_html_route("/azure-openai-alternative")
    async def seo_azure_openai_alternative() -> str:
        return public_page_html(settings, "azure-openai-alternative")

    @public_html_route("/deepseek-api-privacy")
    async def seo_deepseek_api_privacy() -> str:
        return public_page_html(settings, "deepseek-api-privacy")

    @public_html_route("/glm-5-api")
    async def seo_glm_5_api() -> str:
        return public_page_html(settings, "glm-5-api")

    @public_html_route("/gdpr-compliant-llm-api")
    async def seo_gdpr_compliant_llm_api() -> str:
        return public_page_html(settings, "gdpr-compliant-llm-api")

    @public_html_route("/chinese-ai-models-us-hosted")
    async def seo_chinese_ai_models_us_hosted() -> str:
        return public_page_html(settings, "chinese-ai-models-us-hosted")

    # Jurisdiction directories. Their provider and model lists are rebuilt from
    # the catalog on each render, so they are cached like the other
    # catalog-derived pages rather than recomputed per request.
    @public_html_route("/us-ai-models")
    async def seo_us_ai_models(background_tasks: BackgroundTasks) -> Response:
        return await _model_region_response(settings, "us-ai-models", background_tasks)

    @public_html_route("/eu-ai-models")
    async def seo_eu_ai_models(background_tasks: BackgroundTasks) -> Response:
        return await _model_region_response(settings, "eu-ai-models", background_tasks)

    @public_html_route("/china-ai-models")
    async def seo_china_ai_models(background_tasks: BackgroundTasks) -> Response:
        return await _model_region_response(settings, "china-ai-models", background_tasks)

    @public_html_route("/minimax-m3-api")
    async def seo_minimax_m3_api() -> str:
        return public_page_html(settings, "minimax-m3-api")

    @public_html_route("/best-llm-router")
    async def seo_best_llm_router() -> str:
        return public_page_html(settings, "best-llm-router")

    @public_html_route("/llm-failover")
    async def seo_llm_failover() -> str:
        return public_page_html(settings, "llm-failover")

    @public_html_route("/groq-alternative")
    async def seo_groq_alternative() -> str:
        return public_page_html(settings, "groq-alternative")

    @public_html_route("/vertex-ai-alternative")
    async def seo_vertex_ai_alternative() -> str:
        return public_page_html(settings, "vertex-ai-alternative")

    @public_html_route("/llm-api-for-financial-services")
    async def seo_llm_api_for_financial_services() -> str:
        return public_page_html(settings, "llm-api-for-financial-services")

    @public_html_route("/llm-api-for-law-firms")
    async def seo_llm_api_for_law_firms() -> str:
        return public_page_html(settings, "llm-api-for-law-firms")

    @public_html_route("/llm-data-residency")
    async def seo_llm_data_residency() -> str:
        return public_page_html(settings, "llm-data-residency")

    @public_html_route("/no-log-llm-api")
    async def seo_no_log_llm_api() -> str:
        return public_page_html(settings, "no-log-llm-api")

    @public_html_route("/anonymous-llm-api")
    async def seo_anonymous_llm_api() -> str:
        return public_page_html(settings, "anonymous-llm-api")

    @public_html_route("/cline-api-provider")
    async def seo_cline_api_provider() -> str:
        return public_page_html(settings, "cline-api-provider")

    @public_html_route("/sillytavern-api")
    async def seo_sillytavern_api() -> str:
        return public_page_html(settings, "sillytavern-api")

    @public_html_route("/aws-bedrock-alternative")
    async def seo_aws_bedrock_alternative() -> str:
        return public_page_html(settings, "aws-bedrock-alternative")

    @public_html_route("/llm-document-processing")
    async def seo_llm_document_processing() -> str:
        return public_page_html(settings, "llm-document-processing")

    @public_html_route("/gpt-oss-120b-api")
    async def seo_gpt_oss_120b_api() -> str:
        return public_page_html(settings, "gpt-oss-120b-api")

    @public_html_route("/latest-model-apis")
    async def seo_latest_model_apis() -> str:
        return public_page_html(settings, "latest-model-apis")

    @public_html_route("/eu-ai-act-llm-compliance")
    async def seo_eu_ai_act_llm_compliance() -> str:
        return public_page_html(settings, "eu-ai-act-llm-compliance")

    @public_html_route("/x402-llm-api")
    async def seo_x402_llm_api() -> str:
        return public_page_html(settings, "x402-llm-api")

    def openrouter_landing_experiment_redirect(request: Request) -> RedirectResponse:
        attribution = getattr(request.state, "acquisition_attribution", None)
        seed = getattr(attribution, "anonymous_id", None)
        if seed is None:
            selected_path = assigned_openrouter_landing_path(None)
            query = request.url.query
        else:
            cell = assigned_google_search_cell(seed)
            selected_path = f"/openrouter-alternative/test/{cell.cell_id}"
            query_items = [
                (name, value)
                for name, value in parse_qsl(request.url.query, keep_blank_values=True)
                if name not in {"tr_exp", "tr_cell"}
            ]
            query_items.extend(
                (
                    ("tr_exp", GOOGLE_SEARCH_EXPERIMENT_ID),
                    ("tr_cell", cell.cell_id),
                )
            )
            query = urlencode(query_items)
        location = f"{selected_path}?{query}" if query else selected_path
        return RedirectResponse(
            url=location,
            status_code=307,
            headers={
                "cache-control": "private, no-store",
                "vary": "cookie",
            },
        )

    @public_html_route("/openrouter-alternative")
    async def seo_openrouter_alternative(
        request: Request,
    ) -> Response:
        if request.query_params.get("utm_campaign") in OPENROUTER_LANDING_EXPERIMENT_CAMPAIGNS:
            return openrouter_landing_experiment_redirect(request)
        return HTMLResponse(public_page_html(settings, "openrouter-alternative"))

    @public_html_route("/private-llm-api")
    async def seo_private_llm_api() -> str:
        return public_page_html(settings, "private-llm-api")

    @public_html_route("/openrouter-alternative/quickstart")
    async def experiment_openrouter_quickstart() -> str:
        return public_page_html(
            settings,
            "openrouter-alternative/quickstart",
            canonical_path="/openrouter-alternative",
            robots_meta="noindex,follow",
        )

    @public_html_route("/openrouter-alternative/experiment")
    async def experiment_openrouter_landing_router(
        request: Request,
    ) -> RedirectResponse:
        return openrouter_landing_experiment_redirect(request)

    @public_html_route(
        "/openrouter-alternative/lp/{variant_slug}",
        include_slash=False,
    )
    async def experiment_openrouter_landing_variant(
        variant_slug: str,
    ) -> Response:
        if variant_slug not in OPENROUTER_PAID_LANDING_VARIANTS:
            # Raise rather than return HTML: the central 404 handler picks the
            # representation from Accept, so an agent gets the markdown body
            # with the site indexes and a browser gets the same styled page as
            # before. Returning HTML here would hand every client HTML.
            raise HTTPException(status_code=404)
        return HTMLResponse(public_openrouter_experiment_html(settings, variant_slug))

    @public_html_route(
        "/openrouter-alternative/test/{cell_id}",
        include_slash=False,
    )
    async def experiment_google_search_landing_cell(cell_id: str) -> Response:
        cell = GOOGLE_SEARCH_CELLS_BY_ID.get(cell_id)
        if cell is None:
            raise HTTPException(status_code=404)
        return HTMLResponse(public_google_search_experiment_html(settings, cell))

    @public_html_route("/private-llm-api/quickstart")
    async def experiment_private_llm_quickstart() -> str:
        return public_page_html(
            settings,
            "private-llm-api/quickstart",
            canonical_path="/private-llm-api",
            robots_meta="noindex,follow",
        )

    @public_html_route("/hipaa-llm-api")
    async def seo_hipaa_llm_api() -> str:
        return public_page_html(settings, "hipaa-llm-api")

    @public_html_route("/llm-zero-data-retention")
    async def seo_llm_zero_data_retention() -> str:
        return public_page_html(settings, "llm-zero-data-retention")

    @public_html_route("/claude-api-privacy")
    async def seo_claude_api_privacy() -> str:
        return public_page_html(settings, "claude-api-privacy")

    @public_html_route("/litellm-alternative")
    async def seo_litellm_alternative() -> str:
        return public_page_html(settings, "litellm-alternative")

    @public_html_route("/portkey-alternative")
    async def seo_portkey_alternative() -> str:
        return public_page_html(settings, "portkey-alternative")

    @public_html_route("/confidential-computing-llm")
    async def seo_confidential_computing_llm() -> str:
        return public_page_html(settings, "confidential-computing-llm")

    @public_html_route("/badge")
    async def confidential_ai_badge() -> str:
        return public_page_html(settings, "badge")

    @public_html_route("/media-kit")
    async def media_kit() -> str:
        return public_page_html(settings, "media-kit")

    @public_html_route("/tinfoil-alternative")
    async def seo_tinfoil_alternative() -> str:
        return public_page_html(settings, "tinfoil-alternative")

    @public_html_route("/sign-in-with-trustedrouter")
    async def seo_sign_in_with_trustedrouter() -> str:
        return public_page_html(settings, "sign-in-with-trustedrouter")

    @public_html_route("/sign-in-as-ycombinator")
    @public_html_route("/sign-in-as-startx")
    @public_html_route("/sign-in-as-vc")
    async def company_signin_guide(request: Request) -> str:
        return public_page_html(settings, request.url.path.strip("/"))

    @public_html_route("/openai-compatible-llm-api")
    async def seo_openai_compatible_llm_api() -> str:
        return public_page_html(settings, "openai-compatible-llm-api")

    @public_html_route("/kimi-k2-api")
    async def seo_kimi_k2_api() -> str:
        return public_page_html(settings, "kimi-k2-api")

    @public_html_route("/gemini-flash-alternative")
    async def seo_gemini_flash_alternative() -> str:
        return public_page_html(settings, "gemini-flash-alternative")

    @public_html_route("/llm-provider-latency-benchmarks")
    async def seo_llm_provider_latency_benchmarks() -> str:
        return public_page_html(settings, "llm-provider-latency-benchmarks")

    @public_html_route("/pricing")
    async def pricing() -> str:
        return public_page_html(settings, "pricing")

    @public_html_route("/choose")
    async def choose(background_tasks: BackgroundTasks) -> Response:
        return await _cached_public_response(
            settings,
            key=f"choose:page:{settings.release}",
            media_type="text/html",
            ttl_seconds=CHOOSE_PAGE_CACHE_SECONDS,
            stale_seconds=CHOOSE_PAGE_STALE_SECONDS,
            background_tasks=background_tasks,
            build=lambda: public_page_html(settings, "choose").encode(),
        )

    @app.get("/choose/catalog.json")
    async def choose_catalog(background_tasks: BackgroundTasks) -> Response:
        return await _cached_public_response(
            settings,
            key=f"choose:catalog:{settings.release}",
            media_type="application/json",
            ttl_seconds=CHOOSE_CATALOG_CACHE_SECONDS,
            stale_seconds=CHOOSE_CATALOG_STALE_SECONDS,
            background_tasks=background_tasks,
            build=lambda: _json_body(
                choose_catalog_payload(test_mode=settings.environment == "test")
            ),
        )

    @app.get("/ai-iq/models.json")
    async def ai_iq_models() -> JSONResponse:
        payload = ai_iq_catalog_payload(
            (model_id for model_id in MODELS if model_id not in META_MODEL_IDS),
            test_mode=settings.environment == "test",
        )
        return JSONResponse(
            payload,
            headers={"cache-control": "public, max-age=3600, stale-while-revalidate=86400"},
        )

    @public_html_route("/docs")
    async def docs_hub() -> str:
        return public_page_html(settings, "docs")

    @public_html_route("/vibe-coders")
    async def vibe_coders() -> str:
        return public_page_html(settings, "vibe-coders")

    @app.get("/claude-code", include_in_schema=False)
    async def claude_code_redirect() -> RedirectResponse:
        return RedirectResponse(url="/vibe-coders", status_code=301)

    @public_html_route("/for-developers")
    async def for_developers() -> str:
        return public_page_html(settings, "for-developers")

    @public_html_route("/providers/marketplace")
    async def provider_marketplace() -> str:
        return public_page_html(settings, "providers/marketplace")

    @app.get(
        "/providers/marketplace/catalog.schema.json",
        include_in_schema=False,
    )
    async def provider_catalog_schema() -> JSONResponse:
        return JSONResponse(
            PROVIDER_CATALOG_SCHEMA,
            media_type="application/schema+json",
            headers={"cache-control": "public, max-age=3600, stale-while-revalidate=86400"},
        )

    @app.get(
        "/providers/marketplace/catalog.v2.schema.json",
        include_in_schema=False,
    )
    async def provider_catalog_v2_schema() -> JSONResponse:
        return JSONResponse(
            PROVIDER_CATALOG_V2_SCHEMA,
            media_type="application/schema+json",
            headers={"cache-control": "public, max-age=3600, stale-while-revalidate=86400"},
        )

    @app.api_route(
        "/providers/apply",
        methods=["GET", "HEAD"],
        include_in_schema=False,
    )
    @app.api_route(
        "/providers/apply/",
        methods=["GET", "HEAD"],
        include_in_schema=False,
    )
    async def legacy_provider_apply() -> RedirectResponse:
        return RedirectResponse(url="/providers/marketplace", status_code=301)

    @app.api_route(
        "/providers/apply/catalog.schema.json",
        methods=["GET", "HEAD"],
        include_in_schema=False,
    )
    async def legacy_provider_catalog_schema() -> RedirectResponse:
        return RedirectResponse(
            url="/providers/marketplace/catalog.schema.json",
            status_code=301,
        )

    @public_html_route("/apps")
    async def apps() -> str:
        return public_apps_html(settings, apps=_apps_snapshot(settings))

    @public_html_route("/resources")
    async def resources() -> str:
        return public_page_html(settings, "resources")

    @public_html_route("/token-exchange")
    async def token_exchange() -> str:
        return public_page_html(settings, "token-exchange")

    @public_html_route("/token-exchange/savings")
    async def token_exchange_savings() -> str:
        return public_page_html(settings, "token-exchange/savings")

    @public_html_route("/token-exchange/security")
    async def token_exchange_security() -> str:
        return public_page_html(settings, "token-exchange/security")

    @public_html_route("/green-tokens")
    async def green_tokens() -> str:
        return public_page_html(settings, "green-tokens")

    @public_html_route("/index")
    async def token_index() -> str:
        return public_page_html(settings, "index")

    @public_html_route("/customers/robot-robot-human")
    async def customer_robot_robot_human() -> str:
        return public_page_html(settings, "customers/robot-robot-human")

    @public_html_route("/careers")
    async def careers() -> str:
        return public_page_html(settings, "careers")

    @public_html_route("/blog")
    async def blog() -> str:
        return public_blog_index_html(settings)

    @public_html_route("/blog/{slug}")
    async def blog_post(slug: str) -> Any:
        if slug in {"zeus-terminal-bench-hard-72", "socrates-pro-plus-terminal-bench-hard-72"}:
            return RedirectResponse(
                url="/blog/socrates-1.1-terminal-bench-hard-72", status_code=301
            )
        html = public_blog_post_html(settings, slug)
        if html is None:
            raise HTTPException(status_code=404)
        return html

    @public_html_route("/security")
    async def security() -> str:
        return public_page_html(settings, "security")

    @public_html_route("/about")
    async def about() -> str:
        return public_about_html(settings)

    @public_html_route("/contact")
    async def contact() -> str:
        return public_contact_html(settings)

    @public_html_route("/legal")
    async def legal() -> str:
        return public_legal_html(settings)

    @public_html_route("/privacy")
    async def privacy() -> str:
        return public_privacy_html(settings)

    @public_html_route("/sms")
    async def sms_program() -> str:
        return public_sms_html(settings)

    @public_html_route("/terms")
    async def terms() -> str:
        return public_terms_html(settings)

    @public_html_route("/support")
    async def support() -> str:
        return public_support_html(settings)

    @public_html_route("/legal/dpa")
    async def legal_dpa() -> str:
        return public_dpa_html(settings)

    @public_html_route("/legal/baa")
    async def legal_baa() -> str:
        return public_baa_html(settings)

    @public_html_route("/legal/soc2-readiness")
    async def legal_soc2_readiness() -> str:
        return public_soc2_readiness_html(settings)

    @public_html_route("/legal/hipaa-readiness")
    async def legal_hipaa_readiness() -> str:
        return public_hipaa_readiness_html(settings)

    @public_html_route("/legal/subprocessors")
    async def legal_subprocessors() -> str:
        return public_subprocessors_html(settings)

    @app.api_route(
        "/legal/procurement.json",
        methods=["GET", "HEAD"],
        response_class=PlainTextResponse,
    )
    async def legal_procurement_json() -> PlainTextResponse:
        return PlainTextResponse(
            procurement_json(settings),
            media_type="application/json",
            headers={"cache-control": "public, max-age=300, s-maxage=3600"},
        )

    @app.api_route(
        "/legal/soc2-readiness.json",
        methods=["GET", "HEAD"],
        response_class=PlainTextResponse,
    )
    async def legal_soc2_readiness_json() -> PlainTextResponse:
        return PlainTextResponse(
            soc2_readiness_json(settings),
            media_type="application/json",
            headers={"cache-control": "public, max-age=300, s-maxage=3600"},
        )

    @app.api_route(
        "/legal/hipaa-readiness.json",
        methods=["GET", "HEAD"],
        response_class=PlainTextResponse,
    )
    async def legal_hipaa_readiness_json() -> PlainTextResponse:
        return PlainTextResponse(
            hipaa_readiness_json(settings),
            media_type="application/json",
            headers={"cache-control": "public, max-age=300, s-maxage=3600"},
        )

    @app.api_route(
        "/legal/subprocessors.json",
        methods=["GET", "HEAD"],
        response_class=PlainTextResponse,
    )
    async def legal_subprocessors_json() -> PlainTextResponse:
        return PlainTextResponse(
            subprocessors_json(settings),
            media_type="application/json",
            headers={"cache-control": "public, max-age=300, s-maxage=3600"},
        )

    @public_html_route("/benchmarks")
    async def benchmarks() -> str:
        return public_benchmarks_html(settings)

    @public_html_route("/benchmarks/reports")
    async def benchmark_reports() -> str:
        return public_benchmark_reports_index_html(settings)

    @app.get("/benchmarks/reports/{period}.json", include_in_schema=False)
    async def benchmark_report_json(period: str) -> JSONResponse:
        report = monthly_benchmark_report(period)
        if report is None:
            return JSONResponse(
                {"error": {"message": "benchmark report not found", "type": "not_found"}},
                status_code=404,
            )
        return JSONResponse(
            {"data": report},
            headers={"cache-control": "public, max-age=300, s-maxage=86400"},
        )

    @public_html_route("/benchmarks/reports/{period}")
    async def benchmark_report(period: str) -> HTMLResponse:
        body = public_benchmark_report_html(settings, period)
        if body is None:
            raise HTTPException(status_code=404)
        return HTMLResponse(body)

    @public_html_route("/rankings")
    async def rankings() -> str:
        return public_rankings_html(settings)

    @app.api_route("/robots.txt", methods=["GET", "HEAD"], response_class=PlainTextResponse)
    async def robots() -> PlainTextResponse:
        return PlainTextResponse(
            robots_txt(settings),
            headers={"cache-control": "public, max-age=300, s-maxage=3600"},
        )

    @app.api_route(
        f"/{INDEXNOW_KEY}.txt",
        methods=["GET", "HEAD"],
        response_class=PlainTextResponse,
        include_in_schema=False,
    )
    async def indexnow_key() -> PlainTextResponse:
        return PlainTextResponse(
            f"{INDEXNOW_KEY}\n",
            headers={"cache-control": "public, max-age=86400, s-maxage=86400"},
        )

    @app.api_route("/sitemap.xml", methods=["GET", "HEAD"])
    async def sitemap() -> Response:
        return Response(
            sitemap_xml(settings),
            media_type="application/xml",
            headers={"cache-control": "public, max-age=300, s-maxage=3600"},
        )

    @app.api_route("/sitemap-core.xml", methods=["GET", "HEAD"])
    async def sitemap_core() -> Response:
        return Response(
            sitemap_core_xml(settings),
            media_type="application/xml",
            headers={"cache-control": "public, max-age=300, s-maxage=3600"},
        )

    @app.api_route("/sitemap-providers.xml", methods=["GET", "HEAD"])
    async def sitemap_providers() -> Response:
        return Response(
            sitemap_providers_xml(settings),
            media_type="application/xml",
            headers={"cache-control": "public, max-age=300, s-maxage=3600"},
        )

    @app.api_route("/sitemap-models.xml", methods=["GET", "HEAD"])
    async def sitemap_models() -> Response:
        return Response(
            sitemap_models_xml(settings),
            media_type="application/xml",
            headers={"cache-control": "public, max-age=300, s-maxage=3600"},
        )

    @app.api_route("/sitemap-comparisons.xml", methods=["GET", "HEAD"])
    async def sitemap_comparisons() -> Response:
        return Response(
            sitemap_comparisons_xml(settings),
            media_type="application/xml",
            headers={"cache-control": "public, max-age=300, s-maxage=3600"},
        )

    @app.get("/.well-known/mcp/server-card.json", include_in_schema=False)
    @app.get("/.well-known/mcp.json", include_in_schema=False)
    async def mcp_discovery(request: Request) -> JSONResponse:
        """Where the MCP server is, for a client that has only the domain.

        Lives with the public documents rather than beside the MCP endpoint
        itself: /mcp is authenticated and mounted on the control surface, while
        discovery has to be reachable by anyone holding only the hostname. The
        surface-routing contract caught the first version of this, which was
        registered next to the server and so was absent from the public app the
        URL map points at.

        Everything needed to connect was published in prose on /docs/mcp: the
        URL, the transport, that it wants a Bearer key. An agent handed
        "trustedrouter.com" and asked to use its MCP server had to read a
        marketing page to find them, which is the same discoverability gap that
        made openapi.json unfindable.

        This mirrors the values the server itself reports at `initialize`
        rather than restating them, so the document cannot describe a server
        different from the one that answers.
        """
        domain = request_control_domain(request, settings)
        return JSONResponse(
            {
                "name": MCP_SERVER_NAME,
                "title": MCP_SERVER_TITLE,
                "description": MCP_SERVER_DESCRIPTION,
                "iconUrl": f"https://{domain}/static/favicon.svg",
                "version": settings.release,
                "protocolVersion": MCP_PROTOCOL_VERSION,
                "transport": "http",
                "url": f"https://{domain}/mcp",
                "authentication": {
                    "type": "http",
                    "scheme": "bearer",
                    "description": "A TrustedRouter API key: Authorization: Bearer sk-tr-...",
                    "tokenUrl": f"https://{domain}/console/keys",
                },
                "capabilities": {"tools": {}},
                "documentation": f"https://{domain}/docs/mcp",
            },
            headers={"cache-control": "public, max-age=300, s-maxage=3600"},
        )

    @app.get("/.well-known/oauth-authorization-server", include_in_schema=False)
    async def oauth_authorization_server_metadata(request: Request) -> JSONResponse:
        """Describe the delegated API-key authorization flow to public clients."""
        origin = f"https://{request_control_domain(request, settings)}"
        return JSONResponse(
            {
                "issuer": origin,
                "authorization_endpoint": f"{origin}/oauth/authorize",
                "token_endpoint": f"{origin}/oauth/token",
                "response_types_supported": ["code"],
                "grant_types_supported": ["authorization_code"],
                "code_challenge_methods_supported": ["S256"],
                "token_endpoint_auth_methods_supported": ["none"],
                "service_documentation": f"{origin}/sign-in-with-trustedrouter",
                "scopes_supported": sorted(KNOWN_SCOPES),
            },
            headers={"cache-control": "public, max-age=300, s-maxage=3600"},
        )

    @app.api_route("/llms.txt", methods=["GET", "HEAD"], response_class=PlainTextResponse)
    async def llms() -> PlainTextResponse:
        return PlainTextResponse(
            llms_txt(settings),
            headers=public_document_headers("/llms.txt"),
        )

    @app.api_route("/docs/llms.txt", methods=["GET", "HEAD"], response_class=PlainTextResponse)
    async def docs_llms() -> PlainTextResponse:
        return PlainTextResponse(
            docs_llms_txt(settings),
            headers=public_document_headers("/docs/llms.txt"),
        )

    @app.api_route(
        "/docs/llms-full.txt",
        methods=["GET", "HEAD"],
        response_class=PlainTextResponse,
    )
    async def docs_llms_full() -> PlainTextResponse:
        return PlainTextResponse(
            docs_llms_full_txt(settings),
            headers=public_document_headers("/docs/llms-full.txt"),
        )

    # Root-level aliases for the paths an agent tries by convention before it
    # tries anything else. /llms-full.txt and /.well-known/llms.txt are where
    # the llms.txt convention says to look; both used to 404 while the real
    # documents sat under /docs, which is discoverable only after you have
    # already found the index you were looking for.
    @app.api_route("/llms-full.txt", methods=["GET", "HEAD"], response_class=PlainTextResponse)
    async def llms_full() -> PlainTextResponse:
        return PlainTextResponse(
            docs_llms_full_txt(settings),
            headers=public_document_headers("/llms-full.txt"),
        )

    @app.api_route(
        "/.well-known/llms.txt", methods=["GET", "HEAD"], response_class=PlainTextResponse
    )
    async def well_known_llms() -> PlainTextResponse:
        return PlainTextResponse(
            llms_txt(settings),
            headers=public_document_headers("/llms.txt"),
        )

    @app.api_route("/api", methods=["GET", "HEAD"], include_in_schema=False)
    async def api_alias() -> RedirectResponse:
        """/api is the first URL an agent guesses for API docs. It 404'd."""
        return RedirectResponse(url="/docs", status_code=308)

    @public_html_route("/status")
    async def status_page(request: Request, background_tasks: BackgroundTasks) -> Response:
        return await _cached_status_page_response(
            settings,
            host=request.headers.get("host", ""),
            background_tasks=background_tasks,
        )

    @public_html_route("/leaderboard")
    async def leaderboard_page(request: Request, background_tasks: BackgroundTasks) -> Response:
        window = request.query_params.get("window", "24h")
        if window not in {"24h", "7d"}:
            return JSONResponse(
                {"error": {"type": "bad_request", "message": "window must be 24h or 7d"}},
                status_code=400,
            )
        return await _cached_public_response(
            settings,
            key=f"leaderboard:page:{window}",
            media_type="text/html",
            ttl_seconds=LEADERBOARD_RESPONSE_CACHE_SECONDS,
            stale_seconds=LEADERBOARD_RESPONSE_STALE_SECONDS,
            background_tasks=background_tasks,
            build=lambda: public_leaderboard_html(
                settings, _leaderboard_snapshot(settings, window=window)
            ).encode(),
        )

    @public_html_route("/leaderboard/video")
    async def video_leaderboard_page(
        request: Request, background_tasks: BackgroundTasks
    ) -> Response:
        _ = request
        return await _cached_public_response(
            settings,
            key="leaderboard:video:page",
            media_type="text/html",
            ttl_seconds=LEADERBOARD_RESPONSE_CACHE_SECONDS,
            stale_seconds=LEADERBOARD_RESPONSE_STALE_SECONDS,
            background_tasks=background_tasks,
            build=lambda: public_video_leaderboard_html(
                settings, _video_leaderboard_snapshot(settings)
            ).encode(),
        )

    @app.get("/leaderboard/video.json")
    async def video_leaderboard_json(background_tasks: BackgroundTasks) -> Response:
        return await _cached_public_response(
            settings,
            key="leaderboard:video:json",
            media_type="application/json",
            ttl_seconds=LEADERBOARD_RESPONSE_CACHE_SECONDS,
            stale_seconds=LEADERBOARD_RESPONSE_STALE_SECONDS,
            background_tasks=background_tasks,
            build=lambda: _json_body({"data": _video_leaderboard_snapshot(settings)}),
        )

    @app.get("/fleet.json")
    async def fleet_json() -> Response:
        # Served by EVERY control plane so the fleet view is as multi-cloud
        # as the service: any healthy deployment can be the command center.
        return Response(
            content=_json_body({"data": await _fleet_snapshot_cached(settings)}),
            media_type="application/json",
        )

    @public_html_route("/fleet")
    async def fleet_page(request: Request) -> HTMLResponse:
        _ = request
        return HTMLResponse(_fleet_page_html(await _fleet_snapshot_cached(settings)))

    @app.get("/token-exchange/evidence/{profile}.json")
    async def token_exchange_evidence(profile: str, background_tasks: BackgroundTasks) -> Response:
        if profile not in EXCHANGE_PROFILES:
            raise HTTPException(status_code=404, detail="Unknown evidence profile")
        response = await _cached_public_response(
            settings,
            key=f"exchange:evidence:{profile}",
            media_type="application/json",
            ttl_seconds=60,
            stale_seconds=0,
            background_tasks=background_tasks,
            cache_control_override="no-store",
            build=lambda: _json_body(exchange_evidence(profile)),
        )
        # Public, credential-free data shared by all market domains.
        response.headers["Access-Control-Allow-Origin"] = "*"
        return response

    @app.get("/status.json")
    async def status_json(background_tasks: BackgroundTasks) -> Response:
        return await _cached_public_response(
            settings,
            key=f"status:json:{int(settings.public_client_observed_enabled)}",
            media_type="application/json",
            ttl_seconds=STATUS_RESPONSE_CACHE_SECONDS,
            stale_seconds=STATUS_RESPONSE_STALE_SECONDS,
            background_tasks=background_tasks,
            cache_control_override=_status_cache_control(settings),
            build=lambda: _json_body(
                {"data": _compact_status_json(_status_snapshot(settings), settings=settings)}
            ),
        )

    @app.get("/status/history")
    async def status_history(
        request: Request,
        background_tasks: BackgroundTasks,
        window: str = "48h",
        response_format: str | None = Query(default=None, alias="format"),
    ) -> Response:
        if window not in {"5m", "24h", "48h", "daily", "monthly"}:
            return JSONResponse(
                {
                    "error": {
                        "message": "window must be 5m, 24h, 48h, daily, or monthly",
                        "type": "bad_request",
                    }
                },
                status_code=400,
            )
        if not _wants_history_html(request, explicit_format=response_format):
            return await _cached_public_response(
                settings,
                key=f"status:history:{window}:json",
                media_type="application/json",
                ttl_seconds=STATUS_HISTORY_CACHE_SECONDS,
                stale_seconds=STATUS_HISTORY_STALE_SECONDS,
                background_tasks=background_tasks,
                build=lambda: _json_body({"data": _status_history_payload(window)}),
            )
        render_host = _status_render_host(settings, request.headers.get("host", ""))
        return await _cached_public_response(
            settings,
            key=f"status:history:{window}:html:{render_host}",
            media_type="text/html",
            ttl_seconds=STATUS_HISTORY_CACHE_SECONDS,
            stale_seconds=STATUS_HISTORY_STALE_SECONDS,
            background_tasks=background_tasks,
            build=lambda: _status_history_page_html(
                settings,
                host=render_host,
                window=window,
                history=_status_history_payload(window),
            ).encode(),
        )

    @public_html_route("/models")
    async def models(request: Request) -> str:
        return public_models_html(settings, model_filter=request.query_params.get("filter", "all"))

    @public_html_route("/providers")
    async def providers(request: Request) -> Response:
        if _wants_html(request):
            return HTMLResponse(public_providers_html(settings))
        return JSONResponse(
            {
                "data": [
                    provider_to_openrouter_shape(provider) for provider in providers_for_display()
                ]
            }
        )

    @public_html_route("/providers/{provider_slug}/performance")
    async def provider_performance(provider_slug: str) -> Response:
        requested = provider_slug.strip()
        canonical = _canonical_public_provider_slug(requested)
        if canonical != requested:
            return RedirectResponse(url=f"/providers/{canonical}/performance", status_code=301)
        body = public_provider_performance_html(settings, canonical)
        if body is None:
            return HTMLResponse(
                public_page_html(settings, "security"),
                status_code=404,
            )
        return HTMLResponse(body)

    @public_html_route("/providers/{provider_slug}")
    async def provider_detail(provider_slug: str) -> Response:
        requested = provider_slug.strip()
        canonical = _canonical_public_provider_slug(requested)
        if canonical != requested:
            return RedirectResponse(url=f"/providers/{canonical}", status_code=301)
        body = public_provider_detail_html(settings, canonical)
        if body is None:
            return HTMLResponse(
                public_page_html(settings, "security"),
                status_code=404,
            )
        return HTMLResponse(body)

    @public_html_route("/compare/models")
    async def model_compare_index() -> HTMLResponse:
        body = public_model_compare_index_html(settings)
        assert body is not None
        return HTMLResponse(body)

    @public_html_route("/compare/models/page/{page}")
    async def model_compare_index_page(page: int) -> Response:
        if page == 1:
            return RedirectResponse(url="/compare/models", status_code=301)
        body = public_model_compare_index_html(settings, page=page)
        if body is None:
            return HTMLResponse(
                public_model_not_found_html(settings, f"comparison page {page}"),
                status_code=404,
            )
        return HTMLResponse(body)

    @public_html_route("/compare/models/{left_author}/{left_slug}/vs/{right_author}/{right_slug}")
    async def model_compare(
        left_author: str,
        left_slug: str,
        right_author: str,
        right_slug: str,
    ) -> Response:
        requested_left_id = f"{left_author.strip()}/{left_slug.strip()}"
        requested_right_id = f"{right_author.strip()}/{right_slug.strip()}"
        left_id = _canonical_public_model_id(requested_left_id)
        right_id = _canonical_public_model_id(requested_right_id)
        canonical_path = canonical_model_comparison_path(left_id, right_id)
        if canonical_path is not None:
            requested_path = f"/compare/models/{requested_left_id}/vs/{requested_right_id}"
            if requested_path != canonical_path:
                return RedirectResponse(url=canonical_path, status_code=301)
        body = public_model_compare_html(settings, left_id, right_id)
        if body is None:
            return HTMLResponse(
                public_model_not_found_html(settings, f"{left_id}/vs/{right_id}"),
                status_code=404,
            )
        return HTMLResponse(body)

    @public_html_route("/compare/{competitor_slug}")
    async def competitor_compare(competitor_slug: str) -> HTMLResponse:
        body = public_competitor_compare_html(settings, competitor_slug.strip())
        if body is None:
            raise HTTPException(status_code=404)
        return HTMLResponse(body)

    @public_html_route("/chat")
    async def chat() -> str:
        return public_chat_html(settings)

    @public_html_route("/user-chat")
    async def user_chat(model: str = Query(..., min_length=1)) -> str:
        locked_model_id = model.strip().lower()
        user_model = (
            STORE.get_user_model(normalize_user_provided_model_id(locked_model_id))
            if is_user_provided_model_id(locked_model_id)
            else None
        )
        return public_chat_html(
            settings,
            locked_model_id=locked_model_id,
            locked_model_label=(
                "User-provided model" if user_model is not None else "Custom model"
            ),
        )

    @public_html_route("/synth")
    async def synth() -> str:
        return public_fusion_html(settings)

    @public_html_route("/fusion")
    async def fusion() -> RedirectResponse:
        return RedirectResponse(url="/synth", status_code=301)

    # Per-model detail page. Path captures `{author}/{slug}` (e.g.
    # `z-ai/glm-4.6`, `moonshotai/kimi-k2.6`) so the URL exactly mirrors
    # the OpenRouter model id. The `:path` converter lets the slash
    # through. Unknown ids render a styled 404 page (HTML, same chrome
    # as the rest of the marketing site) instead of FastAPI's default
    # JSON error body.
    @app.api_route(
        "/models/{model_id:path}",
        methods=["GET", "HEAD"],
        response_class=HTMLResponse,
    )
    async def model_detail(model_id: str) -> Response:
        cleaned = model_id.strip()
        maybe_base_model_id, separator, maybe_section = cleaned.rpartition("/")
        legacy_model_id = (
            maybe_base_model_id if separator and maybe_section in MODEL_SEO_SECTIONS else cleaned
        )
        canonical_model_id = _canonical_public_model_id(legacy_model_id)
        section_redirect = LEGACY_MODEL_SECTION_REDIRECTS.get((canonical_model_id, maybe_section))
        if section_redirect and canonical_model_id in MODELS:
            return RedirectResponse(url=section_redirect, status_code=301)
        if canonical_model_id != legacy_model_id:
            section_suffix = (
                f"/{maybe_section}" if separator and maybe_section in MODEL_SEO_SECTIONS else ""
            )
            return RedirectResponse(
                url=f"/models/{canonical_model_id}{section_suffix}",
                status_code=301,
            )
        legacy_target = LEGACY_MODEL_PAGE_REDIRECTS.get(legacy_model_id)
        if legacy_target:
            return RedirectResponse(url=legacy_target, status_code=301)
        if separator and maybe_section in MODEL_SEO_SECTIONS:
            body = public_model_section_html(settings, maybe_base_model_id, maybe_section)
            if body is None:
                return HTMLResponse(
                    public_model_not_found_html(settings, cleaned),
                    status_code=404,
                )
            return HTMLResponse(body)
        body = public_model_detail_html(settings, cleaned)
        if body is None:
            user_model = (
                STORE.get_user_model(normalize_user_provided_model_id(cleaned))
                if is_user_provided_model_id(cleaned)
                else None
            )
            if user_model is not None and user_model.enabled and user_model.status == "active":
                shape = user_model_public_shape(user_model)
                body = render_template(
                    "public/user_model_detail.html",
                    api_base_url=settings.api_base_url,
                    site_url=(f"https://{settings.trusted_domain}/models/{user_model.id}"),
                    title=f"{user_model.name} | User-provided model",
                    heading=user_model.name,
                    description=shape["privacy_notice"],
                    robots_meta="noindex",
                    model=shape,
                    google_enabled=settings.google_oauth_enabled,
                    github_enabled=settings.github_oauth_enabled,
                    static_version=settings.release,
                )
        if body is None:
            return HTMLResponse(
                public_model_not_found_html(settings, cleaned),
                status_code=404,
            )
        return HTMLResponse(body)

    @app.get("/og.png")
    async def og_image() -> FileResponse:
        return FileResponse(
            path=OG_PNG_PATH,
            media_type="image/png",
            headers={"cache-control": "max-age=3600, public"},
        )

    @app.get("/favicon.ico")
    @app.head("/favicon.ico")
    async def favicon() -> FileResponse:
        return FileResponse(
            path=STATIC_DIR / "favicon.ico",
            media_type="image/x-icon",
            headers={"cache-control": "max-age=86400, public"},
        )

    @app.get("/trust/control-plane.json")
    async def trust_control_plane() -> JSONResponse:
        """What commit THIS control plane is running.

        The enclave release records answer "which gateway build is serving".
        Nothing answered the same question about the control plane, and two of
        the three planes did not even record it: AWS shipped TR_RELEASE="eu"
        and Azure "azure", both constants, so every deploy reported the same
        string and a fresh plane was indistinguishable from a stale one. That
        is why Azure ran for an unknown length of time on a deploy script that
        could no longer deploy it, with nothing able to notice.

        Deliberately per-plane and unauthenticated: the staleness check reads
        this from outside, the same way the trust-drift check reads
        attestations, so it measures what is SERVING rather than what some
        deploy job believed it shipped.
        """
        return JSONResponse(
            {
                # trusted_domain is what already differs per plane
                # (trustedrouter.com / aws. / azure.), so it identifies the
                # plane without adding a setting that could be set wrong.
                "plane": settings.trusted_domain,
                "release": settings.release,
                "api_base_url": settings.api_base_url,
            },
            headers=public_document_headers("/trust/control-plane.json"),
        )

    @app.get("/.well-known/inference-receipt-keys", include_in_schema=False)
    @app.get("/trust/receipt-keys.json", include_in_schema=False)
    async def inference_receipt_keys(
        request: Request,
        kid: str | None = None,
        cursor: str | None = None,
    ) -> Response:
        """Immutable, cursor-paged receipt-key attestation-version log."""

        nonlocal receipt_key_global_cache
        if kid is not None and not is_canonical_receipt_kid(kid):
            raise HTTPException(status_code=400, detail="kid must be canonical base64url")
        filtered_after = (
            _parse_receipt_key_cursor(cursor)
            if cursor is not None and kid is not None
            else None
        )
        unfiltered_after = (
            _parse_unfiltered_receipt_key_cursor(cursor)
            if cursor is not None and kid is None
            else None
        )
        if cursor is not None and filtered_after is None and unfiltered_after is None:
            raise HTTPException(status_code=400, detail="cursor is invalid")
        if kid is not None and filtered_after is not None and filtered_after[0] != kid:
            raise HTTPException(status_code=400, detail="cursor does not match kid")
        cursors: list[str] = []
        degraded = False
        try:
            if kid is None:
                records, cursors = await asyncio.wait_for(
                    run_in_threadpool(
                        _unfiltered_receipt_key_page,
                        limit=_RECEIPT_KEY_PUBLIC_PAGE_SIZE,
                        after=unfiltered_after,
                    ),
                    timeout=3.0,
                )
            else:
                list_kwargs: dict[str, Any] = {
                    "limit": _RECEIPT_KEY_PUBLIC_PAGE_SIZE,
                    "kid": kid,
                }
                if filtered_after is not None:
                    list_kwargs["after"] = filtered_after
                records = await asyncio.wait_for(
                    run_in_threadpool(
                        STORE.list_receipt_keys,
                        **list_kwargs,
                    ),
                    timeout=3.0,
                )
            records = [with_receipt_attestation_sha256(record) for record in records]
            if kid is not None:
                cursors = [_receipt_key_cursor(record) for record in records]
            if cursor is None:
                if kid is None:
                    receipt_key_global_cache = (records, list(cursors))
                else:
                    _remember_receipt_key_records(receipt_key_cache, kid, records)
        except Exception:
            if cursor is not None:
                log.exception("receipt_key_log_read_degraded_cursor_unavailable")
                raise HTTPException(
                    status_code=503,
                    detail="receipt-key log pagination is temporarily unavailable",
                    headers={"x-trustedrouter-key-log-status": "degraded"},
                ) from None
            degraded = True
            if kid is None:
                records, cursors = receipt_key_global_cache or ([], [])
            else:
                records = receipt_key_cache.get(kid, [])
                cursors = [_receipt_key_cursor(record) for record in records]
            log.exception("receipt_key_log_read_degraded_serving_cached")
        generated_at = iso_now()
        keys: list[dict[str, Any]] = []
        for index, record in enumerate(records):
            keys.append(_public_receipt_key(record))
            has_more = (
                index + 1 < len(records)
                or len(records) == _RECEIPT_KEY_PUBLIC_PAGE_SIZE
            )
            candidate = {
                "spec": "inference-receipt/1",
                "degraded": degraded,
                "page_size": _RECEIPT_KEY_PUBLIC_PAGE_SIZE,
                "next_cursor": cursors[index] if has_more else None,
                "keys": keys,
                "generated_at": generated_at,
            }
            if len(_json_body(candidate)) > _RECEIPT_KEY_PUBLIC_MAX_BYTES:
                keys.pop()
                break
        if not keys and records:
            raise HTTPException(
                status_code=500,
                detail="receipt-key record exceeds public response byte ceiling",
            )
        has_more = len(keys) < len(records) or len(records) == _RECEIPT_KEY_PUBLIC_PAGE_SIZE
        semantic_payload: dict[str, Any] = {
            "spec": "inference-receipt/1",
            "degraded": degraded,
            "page_size": _RECEIPT_KEY_PUBLIC_PAGE_SIZE,
            "next_cursor": (
                cursors[len(keys) - 1] if keys and has_more else None
            ),
            "keys": keys,
        }
        semantic_bytes = json.dumps(
            semantic_payload, sort_keys=True, separators=(",", ":")
        ).encode()
        # generated_at is intentionally outside this weak validator: clients
        # care whether the key evidence changed, not which revalidation emitted
        # an otherwise equivalent representation.
        etag = f'W/"{hashlib.sha256(semantic_bytes).hexdigest()}"'
        headers = {
            "cache-control": "public, max-age=60, s-maxage=300, must-revalidate",
            "etag": etag,
            "link": (
                f'<{canonical_public_url(settings, "/.well-known/inference-receipt-keys")}>; '
                'rel="canonical"'
            ),
            "x-trustedrouter-key-log-status": "degraded" if degraded else "live",
        }
        if request.headers.get("if-none-match") == etag:
            return Response(status_code=304, headers=headers)
        body = _json_body({**semantic_payload, "generated_at": generated_at})
        if len(body) > _RECEIPT_KEY_PUBLIC_MAX_BYTES:  # pragma: no cover
            raise RuntimeError("receipt-key response exceeded byte ceiling")
        return Response(
            content=body,
            media_type="application/json",
            headers=headers,
        )

    @app.get("/trust/gcp-release.json")
    async def trust_release() -> JSONResponse:
        release = await resolved_trust_release()
        return JSONResponse(
            gcp_release(
                settings,
                release_metadata=release.metadata,
                release_metadata_status=release.status,
            ),
            status_code=trust_response_status(release.status),
            headers=trust_response_headers(release.status),
        )

    # An AWS or Azure record with no measurement must not render as one: serve
    # 503 so a verifier treats it as "no answer" rather than reading
    # "not-configured" as the value it should expect.
    def _plane_release_response(record: dict[str, Any], status: str) -> JSONResponse:
        return JSONResponse(
            record,
            status_code=503 if status == "unavailable" else 200,
            headers=trust_response_headers(status),
        )

    @app.get("/trust/aws-release.json")
    async def trust_release_aws() -> JSONResponse:
        record, status = await _plane_record(
            aws_release_resolver, embedded_aws_metadata, aws_release
        )
        return _plane_release_response(record, status)

    @app.get("/trust/azure-release.json")
    async def trust_release_azure() -> JSONResponse:
        record, status = await _plane_record(
            azure_release_resolver, embedded_azure_metadata, azure_release
        )
        return _plane_release_response(record, status)

    @app.get("/trust/pcr0-aws.txt")
    async def trust_pcr0_aws() -> PlainTextResponse:
        record, status = await _plane_record(
            aws_release_resolver, embedded_aws_metadata, aws_release
        )
        return PlainTextResponse(
            "".join(f"{value}\n" for value in record["accepted_pcr0s"]),
            status_code=503 if status == "unavailable" else 200,
            headers=trust_response_headers(status),
        )

    @app.get("/trust/hostdata-azure.txt")
    async def trust_hostdata_azure() -> PlainTextResponse:
        record, status = await _plane_record(
            azure_release_resolver, embedded_azure_metadata, azure_release
        )
        return PlainTextResponse(
            "".join(f"{value}\n" for value in record["accepted_hostdata"]),
            status_code=503 if status == "unavailable" else 200,
            headers=trust_response_headers(status),
        )

    @app.get("/trust/image-digest-gcp.txt")
    async def trust_digest() -> PlainTextResponse:
        release = await resolved_trust_release()
        return PlainTextResponse(
            f"{release.metadata['image_digest']}\n",
            status_code=trust_response_status(release.status),
            headers=trust_response_headers(release.status),
        )

    @app.get("/trust/image-reference-gcp.txt")
    async def trust_image_reference() -> PlainTextResponse:
        release = await resolved_trust_release()
        return PlainTextResponse(
            f"{release.metadata['image_reference']}\n",
            status_code=trust_response_status(release.status),
            headers=trust_response_headers(release.status),
        )


async def _cached_status_page_response(
    settings: Settings,
    *,
    host: str,
    background_tasks: BackgroundTasks,
) -> Response:
    render_host = _status_render_host(settings, host)
    return await _cached_public_response(
        settings,
        key=f"status:page:{render_host}:{int(settings.public_client_observed_enabled)}",
        media_type="text/html",
        ttl_seconds=STATUS_RESPONSE_CACHE_SECONDS,
        stale_seconds=STATUS_RESPONSE_STALE_SECONDS,
        background_tasks=background_tasks,
        cache_control_override=_status_cache_control(settings),
        build=lambda: _status_page_html(settings, host=render_host).encode(),
    )


def _status_render_host(settings: Settings, host: str) -> str:
    """Collapse arbitrary Host headers to configured status/apex variants."""
    hostname = host.partition(":")[0].strip().lower()
    if is_status_hostname(settings, hostname):
        return hostname
    return settings.trusted_domain


async def _model_region_response(
    settings: Settings,
    slug: str,
    background_tasks: BackgroundTasks,
) -> Response:
    return await _cached_public_response(
        settings,
        key=f"model-region:{slug}:{settings.release}",
        media_type="text/html",
        ttl_seconds=MODEL_REGION_PAGE_CACHE_SECONDS,
        stale_seconds=MODEL_REGION_PAGE_STALE_SECONDS,
        background_tasks=background_tasks,
        build=lambda: public_model_region_html(settings, slug).encode(),
    )


async def _cached_public_response(
    settings: Settings,
    *,
    key: str,
    media_type: str,
    ttl_seconds: int,
    stale_seconds: int,
    background_tasks: BackgroundTasks,
    build: Callable[[], bytes],
    cache_control_override: str | None = None,
) -> Response:
    """Serve a cached public body, building it OFF the event loop on a miss.

    `build` reaches ClickHouse through a synchronous httpx client with a
    20-second timeout (`OperationalAnalytics._query`). Calling it inline from
    an async route blocked the worker's whole event loop for as long as that
    query took, so every other request on the instance -- including
    /internal/gateway/authorize and /settle on the paid inference path --
    queued behind a status-page render. The stale-refresh path already ran on
    a daemon thread for exactly this reason; only the cold/expired path was
    left on the loop.
    """
    cache_control = cache_control_override or _public_cache_control(
        ttl_seconds=ttl_seconds, stale_seconds=stale_seconds
    )
    if settings.environment == "test":
        return Response(
            content=await run_in_threadpool(build),
            media_type=media_type,
            headers={"cache-control": cache_control, "x-tr-cache": "bypass"},
        )

    now = time.monotonic()
    with _STATUS_RESPONSE_CACHE_LOCK:
        cached = _STATUS_RESPONSE_CACHE.get(key)
        if cached is not None:
            age = now - cached.cached_at
            if age < ttl_seconds:
                _STATUS_RESPONSE_CACHE.move_to_end(key)
                return _cached_body_response(cached, cache_state="hit")
            if age < ttl_seconds + stale_seconds:
                _STATUS_RESPONSE_CACHE.move_to_end(key)
                _schedule_cached_response_refresh(
                    key=key,
                    media_type=media_type,
                    cache_control=cache_control,
                    build=build,
                    background_tasks=background_tasks,
                )
                return _cached_body_response(cached, cache_state="stale")

    body = await run_in_threadpool(build)
    cached = _CachedPublicBody(
        cached_at=time.monotonic(),
        body=body,
        media_type=media_type,
        cache_control=cache_control,
    )
    with _STATUS_RESPONSE_CACHE_LOCK:
        _STATUS_RESPONSE_CACHE[key] = cached
        _STATUS_RESPONSE_CACHE.move_to_end(key)
        while len(_STATUS_RESPONSE_CACHE) > PUBLIC_RESPONSE_CACHE_MAX_ENTRIES:
            _STATUS_RESPONSE_CACHE.popitem(last=False)
    return _cached_body_response(cached, cache_state="miss")


def _schedule_cached_response_refresh(
    *,
    key: str,
    media_type: str,
    cache_control: str,
    build: Callable[[], bytes],
    background_tasks: BackgroundTasks,
) -> None:
    _ = background_tasks
    with _STATUS_RESPONSE_CACHE_LOCK:
        if key in _STATUS_RESPONSE_REFRESHING:
            return
        if not _STATUS_RESPONSE_REFRESH_SLOTS.acquire(blocking=False):
            return
        _STATUS_RESPONSE_REFRESHING.add(key)
    refresh_thread = threading.Thread(
        target=_refresh_cached_response,
        args=(key, media_type, cache_control, build),
        daemon=True,
    )
    try:
        refresh_thread.start()
    except Exception:
        with _STATUS_RESPONSE_CACHE_LOCK:
            _STATUS_RESPONSE_REFRESHING.discard(key)
        _STATUS_RESPONSE_REFRESH_SLOTS.release()
        raise


def _refresh_cached_response(
    key: str,
    media_type: str,
    cache_control: str,
    build: Callable[[], bytes],
) -> None:
    try:
        body = build()
        with _STATUS_RESPONSE_CACHE_LOCK:
            _STATUS_RESPONSE_CACHE[key] = _CachedPublicBody(
                cached_at=time.monotonic(),
                body=body,
                media_type=media_type,
                cache_control=cache_control,
            )
            _STATUS_RESPONSE_CACHE.move_to_end(key)
            while len(_STATUS_RESPONSE_CACHE) > PUBLIC_RESPONSE_CACHE_MAX_ENTRIES:
                _STATUS_RESPONSE_CACHE.popitem(last=False)
    except Exception:
        log.exception("public_cache_refresh_failed key=%s", key)
    finally:
        with _STATUS_RESPONSE_CACHE_LOCK:
            _STATUS_RESPONSE_REFRESHING.discard(key)
        _STATUS_RESPONSE_REFRESH_SLOTS.release()


def _cached_body_response(cached: _CachedPublicBody, *, cache_state: str) -> Response:
    return Response(
        content=cached.body,
        media_type=cached.media_type,
        headers={
            "cache-control": cached.cache_control,
            "x-tr-cache": cache_state,
        },
    )


def _public_cache_control(*, ttl_seconds: int, stale_seconds: int) -> str:
    browser_ttl = min(ttl_seconds, 15)
    return (
        f"public, max-age={browser_ttl}, s-maxage={ttl_seconds}, "
        f"stale-while-revalidate={stale_seconds}"
    )


def _status_cache_control(settings: Settings) -> str:
    if settings.public_client_observed_enabled:
        return "no-store"
    return _public_cache_control(
        ttl_seconds=STATUS_RESPONSE_CACHE_SECONDS,
        stale_seconds=STATUS_RESPONSE_STALE_SECONDS,
    )


def _json_body(payload: dict[str, Any]) -> bytes:
    return json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()


def _status_history_payload(window: str) -> dict[str, Any]:
    return history_payload(_status_samples(hours=1), window, rollups=_status_rollups(window))


def _wants_history_html(request: Request, *, explicit_format: str | None) -> bool:
    if explicit_format == "html":
        return True
    if explicit_format == "json":
        return False
    accept = request.headers.get("accept", "")
    return "text/html" in accept


def _wants_html(request: Request) -> bool:
    accept = request.headers.get("accept", "")
    if not accept or accept == "*/*":
        return True
    if "text/html" in accept:
        return True
    return "application/json" not in accept


def _status_history_page_html(
    settings: Settings,
    *,
    host: str,
    window: str,
    history: dict[str, Any],
) -> str:
    hostname = host.split(":", 1)[0].lower()
    domain = control_domain_for_hostname(settings, hostname)
    status_hostname = status_hostname_for_domain(domain)
    site_url = (
        f"https://{status_hostname}/status/history?window={window}"
        if is_status_hostname(settings, hostname)
        else f"https://{settings.trusted_domain}/status/history?window={window}"
    )
    title = {
        "48h": "48 hour Status History | TrustedRouter",
        "monthly": "Monthly Status History | TrustedRouter",
        "daily": "Daily Status History | TrustedRouter",
        "24h": "24 hour Status History | TrustedRouter",
        "5m": "Current Status History | TrustedRouter",
    }[window]
    heading = {
        "48h": "48 hour status history",
        "monthly": "Monthly status history",
        "daily": "Daily status history",
        "24h": "24 hour status history",
        "5m": "Current status history",
    }[window]
    return render_template(
        "public/status_history.html",
        api_base_url=settings.api_base_url,
        site_url=site_url,
        canonical_url=canonical_public_url(
            settings,
            "/status/history",
            query=f"window={window}",
        ),
        title=title,
        heading=heading,
        description=(
            "Explore TrustedRouter uptime history from metadata-only synthetic checks, with visual "
            "rollups for gateway health, attestation, SDK requests, billing, fallback, and regions."
        ),
        google_enabled=settings.google_oauth_enabled,
        github_enabled=settings.github_oauth_enabled,
        static_version=settings.release,
        snapshot=_status_snapshot(settings),
        history=history,
        window=window,
        json_url=f"/status/history?window={window}&format=json",
    )


_LEADERBOARD_EVIDENCE_CACHE: tuple[float, dict[str, Any]] | None = None


def _leaderboard_snapshot(settings: Settings, *, window: str = "24h") -> dict[str, Any]:
    if window == "7d":
        return _leaderboard_evidence_snapshot(settings)
    if window != "24h":
        raise ValueError("unsupported leaderboard window")
    global _LEADERBOARD_CACHE
    now = time.monotonic()
    if settings.environment != "test" and _LEADERBOARD_CACHE is not None:
        cached_at, payload = _LEADERBOARD_CACHE
        if now - cached_at < LEADERBOARD_SNAPSHOT_CACHE_SECONDS:
            return payload
    if settings.environment != "test":
        try:
            precomputed = _precomputed_public_analytics_snapshot("leaderboard")
        except Exception as exc:
            _log_public_analytics_snapshot_read_failure("leaderboard", exc)
            if _LEADERBOARD_CACHE is not None:
                return _LEADERBOARD_CACHE[1]
        else:
            if precomputed is not None:
                _LEADERBOARD_CACHE = (now, precomputed)
                return precomputed
    try:
        samples = public_benchmark_samples(
            limit=LEADERBOARD_SAMPLE_LIMIT,
            recent_minutes=LEADERBOARD_RECENT_WINDOW_MINUTES,
        )
        payload = aggregate_leaderboard(
            samples,
            min_samples=LEADERBOARD_MIN_SAMPLES,
            model_rank_min_samples=LEADERBOARD_MODEL_RANK_MIN_SAMPLES,
            provider_rank_min_samples=LEADERBOARD_PROVIDER_RANK_MIN_SAMPLES,
            rank_min_ttft_samples=LEADERBOARD_RANK_MIN_TTFT_SAMPLES,
        )
        payload["rank_minimums"] = {
            "model_availability_samples": LEADERBOARD_MODEL_RANK_MIN_SAMPLES,
            "provider_availability_samples": LEADERBOARD_PROVIDER_RANK_MIN_SAMPLES,
            "ttft_samples": LEADERBOARD_RANK_MIN_TTFT_SAMPLES,
        }
        payload["generated_at"] = utcnow().isoformat().replace("+00:00", "Z")
        payload["sample_window_count"] = len(samples)
        payload["sample_limit"] = LEADERBOARD_SAMPLE_LIMIT
        payload["window_label"] = (
            f"rolling benchmark set of up to {LEADERBOARD_SAMPLE_LIMIT:,} samples"
        )
    except Exception:
        if settings.environment != "test" and _LEADERBOARD_CACHE is not None:
            log.exception("leaderboard_live_fallback_failed_serving_stale")
            return _LEADERBOARD_CACHE[1]
        raise
    if settings.environment != "test":
        _LEADERBOARD_CACHE = (now, payload)
    return payload


def _leaderboard_evidence_snapshot(settings: Settings) -> dict[str, Any]:
    global _LEADERBOARD_EVIDENCE_CACHE
    now = time.monotonic()
    if settings.environment != "test" and _LEADERBOARD_EVIDENCE_CACHE is not None:
        cached_at, cached = _LEADERBOARD_EVIDENCE_CACHE
        if now - cached_at < LEADERBOARD_SNAPSHOT_CACHE_SECONDS:
            return cached
    payload = None
    if settings.environment != "test":
        try:
            payload = _precomputed_public_analytics_snapshot("leaderboard_evidence")
        except Exception as exc:
            _log_public_analytics_snapshot_read_failure("leaderboard_evidence", exc)
            if _LEADERBOARD_EVIDENCE_CACHE is not None:
                return _LEADERBOARD_EVIDENCE_CACHE[1]
    if payload is None:
        # Never add a seven-day raw scan to the public request path. A worker
        # that has not published yet is honestly shown as warming.
        payload = aggregate_leaderboard([], min_samples=LEADERBOARD_MIN_SAMPLES)
        payload.update(
            {
                "generated_at": utcnow().isoformat().replace("+00:00", "Z"),
                "sample_limit": LEADERBOARD_SAMPLE_LIMIT,
                "sample_window_count": 0,
                "window_label": "7-day evidence sample, awaiting publication",
            }
        )
    payload = {**payload, "window": "7d"}
    if settings.environment != "test":
        _LEADERBOARD_EVIDENCE_CACHE = (now, payload)
    return payload


def _video_leaderboard_snapshot(settings: Settings) -> dict[str, Any]:
    global _VIDEO_LEADERBOARD_CACHE
    now = time.monotonic()
    if settings.environment != "test" and _VIDEO_LEADERBOARD_CACHE is not None:
        cached_at, payload = _VIDEO_LEADERBOARD_CACHE
        if now - cached_at < LEADERBOARD_SNAPSHOT_CACHE_SECONDS:
            return payload
    if settings.environment != "test":
        try:
            precomputed = _precomputed_public_analytics_snapshot("video_leaderboard")
        except Exception as exc:
            _log_public_analytics_snapshot_read_failure("video_leaderboard", exc)
            if _VIDEO_LEADERBOARD_CACHE is not None:
                return _VIDEO_LEADERBOARD_CACHE[1]
        else:
            if precomputed is not None:
                _VIDEO_LEADERBOARD_CACHE = (now, precomputed)
                return precomputed
    try:
        samples = public_video_benchmark_samples(
            limit=VIDEO_LEADERBOARD_SAMPLE_LIMIT,
            recent_minutes=VIDEO_LEADERBOARD_RECENT_WINDOW_MINUTES,
        )
        configured_routes = {
            (endpoint.provider, model.id)
            for model in MODELS.values()
            if model.supports_video
            for endpoint in endpoints_for_model(model.id)
        }
        payload = aggregate_video_leaderboard(
            samples,
            configured_routes=configured_routes,
        )
        payload["generated_at"] = utcnow().isoformat().replace("+00:00", "Z")
        payload["sample_window_count"] = len(samples)
        payload["sample_limit"] = VIDEO_LEADERBOARD_SAMPLE_LIMIT
        payload["window_label"] = (
            f"rolling video benchmark set of up to {VIDEO_LEADERBOARD_SAMPLE_LIMIT:,} jobs"
        )
    except Exception:
        if settings.environment != "test" and _VIDEO_LEADERBOARD_CACHE is not None:
            log.exception("video_leaderboard_live_fallback_failed_serving_stale")
            return _VIDEO_LEADERBOARD_CACHE[1]
        raise
    if settings.environment != "test":
        _VIDEO_LEADERBOARD_CACHE = (now, payload)
    return payload


def _apps_snapshot(settings: Settings) -> dict[str, Any]:
    """Cached self-reported app directory, aggregated from the same recent
    benchmark sample set as the leaderboard (no per-view live reads)."""
    global _APPS_CACHE
    now = time.monotonic()
    if settings.environment != "test" and _APPS_CACHE is not None:
        cached_at, payload = _APPS_CACHE
        if now - cached_at < STATUS_SNAPSHOT_CACHE_SECONDS:
            return payload
    if settings.environment != "test":
        try:
            precomputed = _precomputed_public_analytics_snapshot("apps")
        except Exception as exc:
            _log_public_analytics_snapshot_read_failure("apps", exc)
            if _APPS_CACHE is not None:
                return _APPS_CACHE[1]
        else:
            if precomputed is not None:
                _APPS_CACHE = (now, precomputed)
                return precomputed
    samples = public_benchmark_samples(
        limit=LEADERBOARD_SAMPLE_LIMIT,
        recent_minutes=LEADERBOARD_RECENT_WINDOW_MINUTES,
    )
    payload = aggregate_apps(samples)
    payload["generated_at"] = utcnow().isoformat().replace("+00:00", "Z")
    if settings.environment != "test":
        _APPS_CACHE = (now, payload)
    return payload


def _precomputed_public_analytics_snapshot(name: str) -> dict[str, Any] | None:
    reader = getattr(STORE, "public_analytics_snapshot", None)
    if not callable(reader):
        return None
    return current_public_analytics_snapshot(
        name,
        reader=reader,
        max_age_seconds=(2_147_483_647 if name == "client_reliability" else 600),
    )


def _log_public_analytics_snapshot_read_failure(name: str, exc: Exception) -> None:
    """Keep cacheable dependency blips visible without paging twice.

    Every public analytics surface has a stale or live fallback, and the fleet
    freshness workflow separately pages on sustained snapshot unavailability.
    A connect/read timeout here therefore degrades one cache fill; it is not an
    unhandled application error. Unexpected response/schema defects remain
    ERRORs with tracebacks because those require a code or data repair.
    """
    context = {
        "snapshot_name": name,
        "error_class": type(exc).__name__,
        "error_message": str(exc)[:500],
        "retryable": isinstance(exc, (httpx.TimeoutException, httpx.NetworkError)),
    }
    if context["retryable"]:
        log.warning("public_analytics_snapshot_read_degraded", extra=context)
        return
    log.exception("public_analytics_snapshot_read_failed", extra=context)


def _merge_client_observed_status(
    payload: dict[str, Any],
    *,
    settings: Settings,
) -> dict[str, Any]:
    result = dict(payload)
    snapshot = None
    if settings.environment != "test":
        try:
            snapshot = _precomputed_public_analytics_snapshot("client_reliability")
        except Exception as exc:
            _log_public_analytics_snapshot_read_failure("client_reliability", exc)
    result["client_observed"] = client_observed_status_section(
        snapshot,
        now=dt.datetime.now(dt.UTC),
    )
    return _apply_public_client_observed_policy(result, settings=settings)


def _client_observed_liveness(section: Any) -> dict[str, Any]:
    source = section if isinstance(section, Mapping) else {}
    raw_canary = source.get("canary")
    canary = raw_canary if isinstance(raw_canary, Mapping) else {}
    # Liveness may be public; reliability statistics may not. Keep this an
    # explicit allowlist so every future snapshot field stays private by default.
    result = {
        "available": source.get("available", False),
        "generated_at": source.get("generated_at"),
        "canary": {
            "last_seen_age_seconds": canary.get("last_seen_age_seconds"),
            "last_24h_count": canary.get("last_24h_count"),
        },
    }
    if "reason" in source:
        result["reason"] = source["reason"]
    elif not source:
        result["reason"] = "no_data"
    return result


def _apply_public_client_observed_policy(
    payload: dict[str, Any],
    *,
    settings: Settings,
) -> dict[str, Any]:
    result = dict(payload)
    if not settings.public_client_observed_enabled:
        result["client_observed"] = _client_observed_liveness(result.get("client_observed"))
    return result


#: Wall-clock bound this module puts on the outbox-lag read, independently of
#: whatever the storage driver promises. Above the drivers' own 3s caps on
#: purpose: their cap is the one that should normally fire (it can cancel the
#: statement, which this cannot), and this one exists for the case where theirs
#: does not -- a driver that ignores a timeout, a backend added later that
#: never had one, a wait that happens before any SQL is issued. A bound that
#: lives entirely inside the thing being bounded is a bound you cannot test.
STATUS_ANALYTICS_READ_TIMEOUT_SECONDS = 5.0


def _read_outbox_freshness_bounded(timeout: float) -> OutboxFreshness | None:
    """One drain-lag reading, or ``None`` if the store did not answer in time.

    The read runs on a daemon thread and the caller waits at most ``timeout``.
    Why the wait belongs HERE and not only in the drivers: this runs on the
    async /status.json build path, so a blocking read that overruns does not
    occupy one worker thread, it stops the EVENT LOOP -- every request this
    process is serving. The store side caps its pool wait and its statement,
    but those caps are the callee's promise about itself; this is the caller's
    own guarantee, and it holds for a backend that has not made that promise.

    The thread is a daemon and is deliberately not joined after the timeout:
    the point is that this function returns while the database is still not
    answering. It cannot be cancelled -- Python has no way to interrupt a
    blocking driver call -- so the abandoned read finishes into a result nobody
    reads, under the driver's own cap, and process exit never waits on it.
    """
    result: list[OutboxFreshness] = []

    def read() -> None:
        try:
            result.append(STORE.operational_analytics_outbox_freshness())
        except Exception:
            log.exception("operational_analytics_outbox_freshness_read_failed")

    worker = threading.Thread(target=read, name="status-analytics-lag", daemon=True)
    worker.start()
    worker.join(timeout)
    if worker.is_alive():
        log.warning(
            "operational_analytics_outbox_freshness_timed_out",
            extra={"timeout_seconds": timeout},
        )
        return None
    return result[0] if result else None


def _merge_analytics_status(payload: dict[str, Any]) -> dict[str, Any]:
    """Publish this cloud's operational-analytics drain lag.

    One wiring covers every deployment because every deployment runs this
    codebase; that is the property the fleet check in
    :mod:`clickhouse.check_fleet_analytics_freshness` relies on, and the reason
    the registry can insist that no cloud is missing the section.

    The analytics section has its own 60s cache, matching the response cadence.
    Snapshot rebuilds (every 15s) and stale-payload fallbacks share that window.
    Keep both the lag and generated_at from the observation: re-stamping an old
    value would make a frozen reading look fresh. Cache failures too, and never
    serve the previous successful reading after a failed refresh.

    Two bounds apply to each refresh: the store caps its own pool wait and
    statement (3s), and `_read_outbox_freshness_bounded` caps the caller's wait.

    Nothing in here may raise. The section is written unconditionally, and an
    exception escaping would drop the key -- which the fleet checker reads as
    "this deployment runs code too old to publish drain lag" and answers by
    sending somebody to redeploy a healthy service.
    """
    global _STATUS_ANALYTICS_CACHE
    with _STATUS_ANALYTICS_CACHE_LOCK:
        now = time.monotonic()
        cached = _STATUS_ANALYTICS_CACHE
        if cached is not None and now - cached[0] < max(60, STATUS_RESPONSE_CACHE_SECONDS):
            section = dict(cached[1])
        else:
            try:
                # Called through the declared `Store` surface rather than a getattr
                # probe, so a backend that stops implementing it fails mypy instead of
                # silently degrading every cloud's status page to "unreachable".
                reading = _read_outbox_freshness_bounded(STATUS_ANALYTICS_READ_TIMEOUT_SECONDS)
                section = analytics_status_from_reading(reading, now=dt.datetime.now(dt.UTC))
            except Exception:
                # The projection too, not just the read: it handles a value some
                # backend produced, and the clamps it runs are the last thing standing
                # between that value and an uncredentialed page.
                log.exception("operational_analytics_status_section_failed")
                section = analytics_status_unavailable(REASON_UNREACHABLE)
            _STATUS_ANALYTICS_CACHE = (time.monotonic(), dict(section))
    result = dict(payload)
    result[ANALYTICS_STATUS_KEY] = section
    return result


def _status_snapshot(settings: Settings) -> dict[str, Any]:
    global _STATUS_CACHE
    now = time.monotonic()
    if settings.environment != "test" and _STATUS_CACHE is not None:
        cached_at, payload = _STATUS_CACHE
        if now - cached_at < STATUS_SNAPSHOT_CACHE_SECONDS:
            return _apply_public_client_observed_policy(payload, settings=settings)
    if settings.environment != "test":
        try:
            precomputed = _precomputed_public_analytics_snapshot("status_inputs")
        except Exception as exc:
            _log_public_analytics_snapshot_read_failure("status_inputs", exc)
            if _STATUS_CACHE is not None:
                # Analytics uses its own 60s observation window; never reuse
                # this arbitrarily stale payload's lag or timestamp.
                return _apply_public_client_observed_policy(
                    _merge_analytics_status(_STATUS_CACHE[1]), settings=settings
                )
        else:
            if precomputed is not None:
                try:
                    samples = [
                        SyntheticProbeSample(**row)
                        for row in precomputed.get("samples", [])
                        if isinstance(row, dict)
                    ]
                    rollups = [
                        SyntheticRollup(**row)
                        for row in precomputed.get("rollups", [])
                        if isinstance(row, dict)
                    ]
                    payload = status_snapshot(samples, rollups=rollups, settings=settings)
                except (TypeError, ValueError):
                    log.exception("public_analytics_snapshot_invalid name=status_inputs")
                else:
                    payload = _merge_client_observed_status(payload, settings=settings)
                    payload = _merge_analytics_status(payload)
                    _STATUS_CACHE = (now, payload)
                    return payload
    # Keep the fallback bounded. Current state and headline latency come from
    # a small live sample window; 24h/48h history comes from compact rollups.
    try:
        payload = status_snapshot(
            _status_samples(hours=1),
            rollups=_status_rollups("snapshot"),
            settings=settings,
        )
    except Exception:
        if settings.environment != "test" and _STATUS_CACHE is not None:
            log.exception("status_live_fallback_failed_serving_stale")
            # Refresh analytics on its own cadence, as on the precomputed
            # fallback above.
            return _apply_public_client_observed_policy(
                _merge_analytics_status(_STATUS_CACHE[1]), settings=settings
            )
        raise
    payload = _merge_client_observed_status(payload, settings=settings)
    payload = _merge_analytics_status(payload)
    if settings.environment != "test":
        _STATUS_CACHE = (now, payload)
    return payload


async def _fleet_snapshot_cached(settings: Settings) -> dict[str, Any]:
    global _FLEET_CACHE

    def fresh() -> dict[str, Any] | None:
        if settings.environment != "test" and _FLEET_CACHE is not None:
            cached_at, payload = _FLEET_CACHE
            if time.monotonic() - cached_at < FLEET_SNAPSHOT_CACHE_SECONDS:
                return payload
        return None

    cached = fresh()
    if cached is not None:
        return cached
    # Single-flight: /fleet.json is public and its miss path fans out to
    # every peer cloud, so concurrent misses must coalesce into one rebuild
    # rather than one cross-cloud fetch storm per request.
    async with _FLEET_CACHE_LOCK:
        cached = fresh()
        if cached is not None:
            return cached
        payload = await fleet_snapshot(settings)
        if settings.environment != "test":
            _FLEET_CACHE = (time.monotonic(), payload)
        return payload


_FLEET_STATUS_COLORS = {
    "up": "#2e9e5b",
    "degraded": "#d99a2b",
    "routing_degraded": "#d99a2b",
    "trust_degraded": "#c2542e",
    "down": "#c43d3d",
    "unreachable": "#c43d3d",
    "unknown": "#8a8f98",
}


def _fleet_page_html(snapshot: dict[str, Any]) -> str:
    """Minimal server-rendered fleet page: one row per deployment, one row
    per scheduler heartbeat. Deliberately dependency-free and compact — this
    is the operator's "where do I look next" page, not a second status page.
    """

    def color(status: str) -> str:
        return _FLEET_STATUS_COLORS.get(status, "#8a8f98")

    def pill(status: str) -> str:
        label = html.escape(status.replace("_", " "))
        return (
            f'<span style="background:{color(status)};color:#fff;'
            'border-radius:9px;padding:2px 10px;font-size:13px;">'
            f"{label}</span>"
        )

    rows = []
    for row in snapshot.get("deployments", []):
        status = str(row.get("overall_status") or "unknown")
        components = row.get("components") or {}
        bad = {key: value for key, value in components.items() if value not in ("up", "unknown")}
        detail = (
            ", ".join(f"{key}: {value}" for key, value in sorted(bad.items()))
            if bad
            else "all components up"
        )
        stale = row.get("monitor_stale")
        monitor = "stale" if stale else ("fresh" if stale is not None else "n/a")
        rows.append(
            "<tr>"
            f'<td><a href="{html.escape(str(row.get("url") or ""))}">'
            f"{html.escape(str(row.get('name') or ''))}</a></td>"
            f"<td>{pill(status)}</td>"
            f"<td>{html.escape(str(row.get('headline') or ''))}</td>"
            f"<td>{html.escape(monitor)}</td>"
            f"<td>{html.escape(detail)}</td>"
            "</tr>"
        )
    beats = []
    for beat in snapshot.get("heartbeats", []):
        age = beat.get("age_seconds")
        beats.append(
            "<tr>"
            f"<td>{html.escape(str(beat.get('name') or ''))}</td>"
            f"<td>{pill('down' if beat.get('stale') else 'up')}</td>"
            f"<td>{html.escape(str(age) + 's' if age is not None else 'unknown')}</td>"
            f"<td>{html.escape(str(beat.get('last_beat_at') or ''))}</td>"
            "</tr>"
        )
    remediator = snapshot.get("remediator") or {}
    decisions = []
    for row in remediator.get("decisions") or []:
        decisions.append(
            "<tr>"
            f"<td>{html.escape(str(row.get('at') or ''))}</td>"
            f"<td>{html.escape(str(row.get('decision') or ''))}</td>"
            f"<td>{html.escape(str(row.get('detail') or ''))}</td>"
            "</tr>"
        )
    overall = str(snapshot.get("fleet_overall_status") or "unknown")
    table_css = "width:100%;border-collapse:collapse;margin:12px 0 28px"
    cell_css = (
        "th,td{text-align:left;padding:8px 12px;border-bottom:1px solid #2a2f3a;"
        "font-size:14px}th{color:#8a8f98;font-weight:600}"
    )
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>TrustedRouter Fleet</title>
<style>
body{{background:#0f1218;color:#e6e9ef;font:15px/1.5 -apple-system,'Segoe UI',sans-serif;
margin:0;padding:32px;max-width:1080px;margin-inline:auto}}
a{{color:#7ab7ff;text-decoration:none}} {cell_css}
h1{{font-size:20px;margin:0 0 4px}} h2{{font-size:16px;color:#8a8f98;margin:28px 0 0}}
</style></head><body>
<h1>TrustedRouter Fleet {pill(overall)}</h1>
<div style="color:#8a8f98;font-size:13px">generated {html.escape(str(snapshot.get("generated_at") or ""))}
 &middot; served by every control plane &middot; <a href="/fleet.json">fleet.json</a></div>
<h2>Deployments</h2>
<table style="{table_css}"><tr><th>deployment</th><th>status</th><th>headline</th>
<th>monitor</th><th>attention</th></tr>{"".join(rows)}</table>
<h2>Scheduler heartbeats (this deployment)</h2>
<table style="{table_css}"><tr><th>job</th><th>liveness</th><th>age</th><th>last beat</th></tr>
{"".join(beats) or '<tr><td colspan="4">no heartbeats recorded yet</td></tr>'}</table>
<h2>Remediator (mode: {html.escape(str(remediator.get("mode") or "off"))})</h2>
<table style="{table_css}"><tr><th>at</th><th>decision</th><th>detail</th></tr>
{"".join(decisions) or '<tr><td colspan="3">no decisions recorded — nothing needed fixing</td></tr>'}</table>
</body></html>"""


def _compact_status_json(
    snapshot: dict[str, Any],
    *,
    settings: Settings,
) -> dict[str, Any]:
    """Remove tooltip-only duplication from the machine-readable status feed."""
    payload = _apply_public_client_observed_policy(snapshot, settings=settings)
    compact_components: list[dict[str, Any]] = []
    for component in snapshot.get("components", []):
        compact_component = dict(component)
        compact_component["history"] = [
            {key: value for key, value in bucket.items() if key != "latency_breakdown"}
            for bucket in component.get("history", [])
        ]
        compact_components.append(compact_component)
    payload["components"] = compact_components
    # Carried through explicitly. This function is what /status.json actually
    # serves, and the fleet freshness check fails a cloud whose payload has no
    # `analytics` key -- so dropping it here would look exactly like a cloud
    # running code too old to publish drain lag.
    if ANALYTICS_STATUS_KEY in snapshot:
        payload[ANALYTICS_STATUS_KEY] = snapshot[ANALYTICS_STATUS_KEY]
    return payload


def _status_samples(*, hours: int = 48) -> list[Any]:
    if hours <= 1:
        return STORE.synthetic_probe_samples(limit=STATUS_LIVE_SAMPLE_LIMIT)
    samples = []
    for date in _dates_covering_recent_hours(hours=hours):
        samples.extend(
            STORE.synthetic_probe_samples(date=date, limit=STATUS_RAW_SAMPLE_LIMIT_PER_DAY)
        )
    deduped = {sample.id: sample for sample in samples}
    return sorted(deduped.values(), key=lambda sample: sample.created_at, reverse=True)


def _status_rollups(window: str) -> list[Any]:
    now = utcnow()
    if window == "snapshot":
        return [
            *STORE.synthetic_rollups(
                period="hour",
                since=_hour_rollup_since(now, hours=48),
                limit=STATUS_HOUR_ROLLUP_LIMIT,
            ),
            *_status_rollups("monthly"),
        ]
    if window in {"24h", "48h"}:
        return STORE.synthetic_rollups(
            period="hour",
            since=_hour_rollup_since(now, hours=24 if window == "24h" else 48),
            limit=STATUS_HOUR_ROLLUP_LIMIT,
        )
    if window == "daily":
        return STORE.synthetic_rollups(
            period="day",
            since=_day_rollup_since(now, months=STATUS_ROLLUP_RETENTION_MONTHS),
            limit=STATUS_DAY_ROLLUP_LIMIT,
        )
    if window == "monthly":
        rows = STORE.synthetic_rollups(
            period="month",
            since=_month_rollup_since(now, months=STATUS_ROLLUP_RETENTION_MONTHS),
            limit=STATUS_MONTH_ROLLUP_LIMIT,
        )
        if len(rows) >= STATUS_MONTH_ROLLUP_LIMIT:
            raise RuntimeError("monthly status rollup limit reached; refusing partial history")
        return rows
    return []


def _hour_rollup_since(now: dt.datetime, *, hours: int) -> str:
    base = now.astimezone(dt.UTC).replace(minute=0, second=0, microsecond=0)
    return _iso_utc(base - dt.timedelta(hours=max(hours - 1, 0)))


def _day_rollup_since(now: dt.datetime, *, months: int) -> str:
    return _iso_utc(_month_floor(now, months=months))


def _month_rollup_since(now: dt.datetime, *, months: int) -> str:
    return _iso_utc(_month_floor(now, months=months))


def _month_floor(now: dt.datetime, *, months: int) -> dt.datetime:
    current = now.astimezone(dt.UTC)
    month_index = current.year * 12 + current.month - 1
    cutoff_index = month_index - max(months - 1, 0)
    year, zero_based_month = divmod(cutoff_index, 12)
    return dt.datetime(year, zero_based_month + 1, 1, tzinfo=dt.UTC)


def _iso_utc(value: dt.datetime) -> str:
    return value.astimezone(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _dates_covering_recent_hours(*, hours: int) -> list[str]:
    now = utcnow()
    cutoff = now - dt.timedelta(hours=hours)
    dates = []
    current = cutoff.date()
    while current <= now.date():
        dates.append(current.isoformat())
        current += dt.timedelta(days=1)
    return dates


_CLOUD_LABELS = {"gcp": "Google Cloud", "aws": "AWS", "azure": "Azure"}


def _peer_status_pages(settings: Settings, *, hostname: str) -> list[dict[str, Any]]:
    """The other clouds' independently computed status pages.

    Every deployment builds this page from its OWN probes and its own store —
    the documents differ in components and in freshness, they are not mirrors.
    That is exactly why the links are worth rendering: when the cloud serving
    this page is the thing that is broken, the page a reader needs is served
    from somewhere else, and a reader who cannot reach this origin has no way
    to discover that another origin exists. Absolute cross-origin URLs for the
    same reason.

    Peers come from ``synthetic_fleet_peers``, the same list the peer_monitor
    probes already watch, so a cloud added to the fleet appears here with no
    second edit.
    """
    pages: list[dict[str, Any]] = []
    for name, base_url in fleet_peers(settings):
        peer_hostname = (urlparse(base_url).hostname or "").casefold()
        pages.append(
            {
                "name": name,
                "label": _CLOUD_LABELS.get(name, name.upper()),
                "url": f"{base_url.rstrip('/')}/status",
                "current": bool(peer_hostname) and peer_hostname == hostname,
            }
        )
    return pages


def _status_page_html(settings: Settings, *, host: str) -> str:
    hostname = host.split(":", 1)[0].lower()
    domain = control_domain_for_hostname(settings, hostname)
    site_url = (
        f"https://{status_hostname_for_domain(domain)}/"
        if is_status_hostname(settings, hostname)
        else f"https://{settings.trusted_domain}/status"
    )
    snapshot = _apply_public_client_observed_policy(_status_snapshot(settings), settings=settings)
    # Measured upstream-provider health from the rotation-probe / organic
    # benchmark samples. Informational provider watch — intentionally NOT part
    # of the router-core paging SLO above (a flaky upstream model must not page
    # router health), but surfaced here so provider errors are visible.
    leaderboard = _leaderboard_snapshot(settings)
    provider_health = sorted(
        (
            provider
            for provider in leaderboard.get("providers", [])
            if provider.get("sample_count", 0) > 0
        ),
        key=lambda p: (
            p.get("error_rate", 0.0),
            0 if p.get("p50_ttft_ms") is not None else 1,
            p.get("p50_ttft_ms") or 0,
            p.get("provider", ""),
        ),
    )
    return render_template(
        "public/status.html",
        api_base_url=(
            f"https://api.{domain}/v1"
            if domain != settings.trusted_domain
            else settings.api_base_url
        ),
        site_url=site_url,
        canonical_url=canonical_public_url(settings, "/status"),
        title="Status | TrustedRouter",
        heading="TrustedRouter Status",
        description=(
            "Check TrustedRouter availability across regions with live gateway, attestation, SDK, "
            "billing, provider fallback, latency, incident history, and router-core uptime signals."
        ),
        google_enabled=settings.google_oauth_enabled,
        github_enabled=settings.github_oauth_enabled,
        static_version=settings.release,
        snapshot=snapshot,
        public_client_observed_enabled=settings.public_client_observed_enabled,
        provider_health=provider_health,
        provider_health_window=leaderboard.get("window_label"),
        peer_status_pages=_peer_status_pages(settings, hostname=hostname),
    )
