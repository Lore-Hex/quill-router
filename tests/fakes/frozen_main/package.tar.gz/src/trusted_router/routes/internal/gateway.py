"""/internal/gateway/{authorize,settle,refund} — the cross-request
reservation handle the attested gateway uses.

Authorize reserves credits + per-key spend cap and returns an
authorization id. Settle and refund land on a separate request from
the authorize call (the enclave settles after streaming finishes).
The reservation is one-shot: a second settle on the same authorization
returns already_settled=True without double-charging.
"""

from __future__ import annotations

import copy
import datetime as dt
import functools
import hashlib
import json
import logging
import re
import threading
import time
import uuid
from collections import OrderedDict
from dataclasses import replace
from datetime import datetime
from functools import lru_cache
from itertools import product
from time import perf_counter
from typing import Any, cast
from urllib.parse import urlsplit

from fastapi import APIRouter, BackgroundTasks, Request
from fastapi.responses import JSONResponse
from starlette.concurrency import run_in_threadpool

from trusted_router import catalog as model_catalog
from trusted_router.acquisition import (
    record_free_credit_exhausted_safely,
    record_successful_api_call_safely,
)
from trusted_router.app_markup_billing import (
    APP_MARKUP_APP_ID_SETTLE_FIELD,
    APP_MARKUP_OWNER_SETTLE_FIELD,
    APP_MARKUP_PAYOUT_SETTLE_FIELD,
    app_markup_microdollars,
    app_markup_microdollars_from_charge,
    app_markup_owner_share_microdollars,
    app_markup_payout_event_id,
)
from trusted_router.auth import SettingsDep, is_api_key_expired
from trusted_router.byok_crypto import byok_cache_key, encrypted_secret_payload
from trusted_router.catalog import (
    DECIDE_PATH,
    MODELS,
    MONITOR_MODEL_ID,
    NAMED_DECISION_MODEL_PROVIDERS,
    PRIVATE_PROXY_MODEL_TARGETS,
    PROVIDERS,
    Model,
    ModelEndpoint,
    default_endpoint_for_model,
    effective_endpoint,
    endpoint_for_id,
    endpoint_meets_privacy_requirement,
    endpoint_zero_data_retention,
)
from trusted_router.client_context import parse_client_context, parse_gateway_request_id
from trusted_router.config import Settings, get_settings
from trusted_router.custom_model_billing import (
    USER_MODEL_ID_SETTLE_FIELD,
    USER_MODEL_OWNER_SETTLE_FIELD,
    USER_MODEL_PAYOUT_SETTLE_FIELD,
    custom_model_cost_microdollars,
    owner_share_microdollars,
    user_model_payout_event_id,
)
from trusted_router.custom_model_markup_billing import (
    CUSTOM_MODEL_MARKUP_CHARGE_SETTLE_FIELD,
    CUSTOM_MODEL_MARKUP_ID_SETTLE_FIELD,
    CUSTOM_MODEL_MARKUP_OWNER_SETTLE_FIELD,
    CUSTOM_MODEL_MARKUP_PAYOUT_SETTLE_FIELD,
    collected_custom_model_markup_microdollars,
    custom_model_markup_microdollars,
    custom_model_markup_owner_share_microdollars,
    custom_model_markup_payout_event_id,
)
from trusted_router.errors import api_error, assert_workspace_billing_active
from trusted_router.gateway_boot import (
    BootAuthHeader,
    GatewayBoot,
    parse_boot_auth_header,
    verify_boot_auth,
)
from trusted_router.gateway_timing import (
    gateway_phase,
    gateway_timing_phase,
    timed_gateway_async,
    timed_gateway_sync,
    worker_continuation,
)
from trusted_router.money import money_pair
from trusted_router.oauth_app_policy import oauth_app_is_effectively_suspended
from trusted_router.openai_service_tiers import (
    OPENAI_PRIORITY_MAX_PROMPT_TOKENS,
    OPENAI_SERVICE_TIERS,
    openai_priority_cost_microdollars,
    openai_priority_pricing,
)
from trusted_router.partner_billing import (
    PARASAIL_LIBERTY_2_0_MODEL_ID,
    PARTNER_OPERATOR_COST_SETTLE_FIELD,
    PartnerBillingMode,
    partner_billing_mode,
    partner_cost_microdollars,
)
from trusted_router.polyphemus import LEGACY_SELECTOR_FEE_MICRODOLLARS
from trusted_router.polyphemus import MODEL_ID as POLYPHEMUS_MODEL_ID
from trusted_router.polyphemus import SELECT_ROUTE_TYPE as POLYPHEMUS_SELECT_ROUTE_TYPE
from trusted_router.post_commit import defer_post_commit
from trusted_router.pricing import (
    SIGNED_RECEIPT_TOTAL_FEE_BASIS_POINTS,
    signed_receipt_price_microdollars,
)
from trusted_router.provider_compat import byok_storage_provider_candidates
from trusted_router.provider_contracts import (
    SAKANA_FUGU_MODEL_ID,
    provider_model_available_from_gateway_region,
)
from trusted_router.provider_locations import inference_location_metadata
from trusted_router.provider_types import estimate_tokens_from_text
from trusted_router.receipt_keys import (
    AWS_ATTESTATION_KIND,
    AZURE_ATTESTATION_KIND,
    GCP_ATTESTATION_KIND,
    attestation_commits_to_jwk,
    gcp_attestation_image_digest,
    normalize_receipt_jwk,
    receipt_kid,
    verify_gcp_attestation_chain,
)
from trusted_router.regions import choose_region, region_payload
from trusted_router.request_attribution import (
    InvalidAttribution,
    validate_request_attribution,
)
from trusted_router.request_tags import InvalidTags, merge_tags, tags_match, validate_tags
from trusted_router.routes.internal._shared import require_internal_gateway
from trusted_router.routing import (
    _apply_endpoint_provider_filters,
    _required_privacy_postures,
    canonical_model_id,
    chat_route_endpoint_candidates,
    decide_route_endpoint_candidates,
    embeddings_route_endpoint_candidates,
    image_route_endpoint_candidates,
    normalize_routing_inputs,
    provider_route_preferences,
    resolved_route_preferences,
    video_route_endpoint_candidates,
)
from trusted_router.routing_state import ROUTING_STATE
from trusted_router.schemas import (
    GatewayAuthorizeRequest,
    GatewayAuthorizeResponse,
    GatewayBootRegistrationRequest,
    GatewayHeartbeatRequest,
    GatewayResolveCustomModelRequest,
    GatewaySettleRequest,
    GatewaySettleResponse,
    GatewayValidateRequest,
)
from trusted_router.scopes import SCOPE_INFERENCE
from trusted_router.security import lookup_hash_api_key
from trusted_router.services import federation
from trusted_router.services.broadcast import (
    drain_broadcast_queue,
    enqueue_metadata_broadcast,
    gateway_destination_payload,
    should_drain_inline,
)
from trusted_router.services.federation import FederationClient, FederationUnavailable
from trusted_router.services.keyed_admission import KeyedConcurrencyAdmission
from trusted_router.services.receipt_key_collector import collect_receipt_keys
from trusted_router.services.settle_outbox_apply import normalized_prompt_accounting
from trusted_router.services.settle_outbox_drain import (
    drain_settle_outbox,
    spanner_settle_outbox,
)
from trusted_router.services.user_model_gateway_health import (
    record_user_model_gateway_result,
)
from trusted_router.services.user_model_secrets import (
    USER_MODEL_ENDPOINT_KEY_PURPOSE,
    USER_MODEL_SECRET_NAMESPACE,
    USER_MODEL_SIGNING_PURPOSE,
)
from trusted_router.services.user_model_slots import (
    acquire_user_model_slot,
    release_user_model_slot,
)
from trusted_router.stage_d import (
    billing_pricing_snapshot,
    canonical_pricing_snapshot,
    endpoint_pricing_document,
    parse_pricing_snapshot,
)
from trusted_router.stage_d import (
    endpoint_cost_microdollars_from_document as _stage_d_document_cost,
)
from trusted_router.storage import (
    STORE,
    Generation,
    ProviderBenchmarkSample,
    typed_billing_store,
)
from trusted_router.storage_custom_models import (
    is_creator_model_id,
    is_custom_model_id,
    is_user_provided_model_id,
    normalize_custom_model_id,
    normalize_user_provided_model_id,
)
from trusted_router.storage_errors import (
    DeferredSettlementCapReached,
    StoreConflict,
    conflict_store_error_types,
    transient_store_error_types,
)
from trusted_router.storage_gcp_io import spanner_rpc_budget
from trusted_router.storage_gcp_settle_outbox import ENQ_INSERTED, ENQ_REFRESHED
from trusted_router.storage_models import (
    SYNTHETIC_APP_NAME,
    AmbiguousGatewayRequestId,
    AppMarkupPayout,
    ByokProviderConfig,
    CustomModelMarkupPayout,
    GatewayAuthorization,
    SettleOutboxRow,
    TypedFinalizeResult,
    UserModelPayout,
    UserProvidedModel,
    decode_auth_record,
    generation_id_for_authorization,
    iso_now,
    workspace_billing_paused,
)
from trusted_router.synthetic.fleet import record_heartbeat
from trusted_router.synthetic.funding import ensure_monitor_funding, monitor_lookup_hash
from trusted_router.types import ErrorType, UsageType
from trusted_router.user_model_rules import (
    GATEWAY_RESERVATION_TTL_SECONDS,
    dispatch_budget,
    is_owner_fault,
    user_model_gateway_pair,
    user_model_is_on_the_clock,
)
from trusted_router.video_billing import (
    video_cost_microdollars,
    video_pricing_snapshot,
)

logger = logging.getLogger(__name__)

_LOG_VALUE_MAX_CHARS = 120


def _log_value(value: object) -> str:
    """One request-derived field, safe to interpolate into a log MESSAGE.

    ``GatewayAuthorizeRequest.model`` is an unconstrained string, so anything
    derived from it can carry newlines or control characters — enough to forge
    a second log line in a text-formatted sink. Strip those and bound the
    length; the field is for attribution, not for reconstructing the request.
    """
    text = str(value)
    cleaned = "".join(character for character in text if character.isprintable())
    if len(cleaned) > _LOG_VALUE_MAX_CHARS:
        cleaned = cleaned[:_LOG_VALUE_MAX_CHARS] + "...(truncated)"
    return cleaned or "<empty>"


def _log_home_host(home: str) -> str:
    """The peer plane's HOST only: a configured URL may carry a path, a query,
    or embedded credentials, none of which belong in a log line."""
    try:
        return urlsplit(home).hostname or "<unparseable>"
    except ValueError:
        return "<unparseable>"


REQUEST_METADATA_VERSION = 1
# The enclave stops waiting for response headers after 25 seconds. Preserve the
# transaction layer's 20-second retry budget while leaving five seconds for this
# process to serialize a structured retryable 503 and for network transit.
_BILLING_PATH_SPANNER_BUDGET_SECONDS = 20.0
_AUTHORIZE_ADMISSION = KeyedConcurrencyAdmission()
# Process-local harm limitation: this keeps one key from exhausting this
# instance's Spanner session pool. It cannot stop a fleet-wide settle convoy;
# at the 2026-08-25 incident scale, roughly 76 concurrent settles still survive
# the independent per-instance gates and can contend on the same Spanner key.
_SETTLE_ADMISSION = KeyedConcurrencyAdmission()
_BROADCAST_EMPTY_CACHE_TTL_SECONDS = 60.0
_BROADCAST_EMPTY_CACHE_MAX_ENTRIES = 1_024
_BROADCAST_EMPTY_CACHE: OrderedDict[str, float] = OrderedDict()
_BROADCAST_EMPTY_CACHE_LOCK = threading.Lock()
_STAGE_D_OVERRIDE_LOG_LOCK = threading.Lock()
_STAGE_D_OVERRIDE_LOGGED = False
_BOOT_WIRE_ATTESTATION_KINDS = {
    "aws": AWS_ATTESTATION_KIND,
    "azure": AZURE_ATTESTATION_KIND,
    "gcp": GCP_ATTESTATION_KIND,
}
_NATIVE_BATCH_ROUTE_PREFIX = "batch.native."
_ADDITIONAL_COST_ROUTE_TYPES = frozenset(
    {
        "responses.web_search.planner",
        "chat.completions.web_search.planner",
        "images",
        "videos",
    }
)
_NATIVE_BATCH_BILLED_FRACTION_BPS = {
    "openai": 5_000,
    "parasail": 5_000,
}
_NATIVE_BATCH_PROVIDER_FIELDS = frozenset(
    {
        "order",
        "allow_fallbacks",
        "require_parameters",
        "data_collection",
        "min_privacy",
        "jurisdiction",
        "usage",
        "only",
        "ignore",
        "quantizations",
        "sort",
        "max_price",
    }
)
_SETTLE_REPAIR_FIELDS = frozenset(
    {
        "authorization_id",
        "client",
        "gateway_request_id",
        "actual_input_tokens",
        "actual_output_tokens",
        "input_tokens",
        "output_tokens",
        "cache_read_input_tokens",
        "cache_creation_input_tokens",
        "service_tier",
        "request_id",
        "finish_reason",
        "status",
        "streamed",
        "usage_estimated",
        "elapsed_seconds",
        "first_token_seconds",
        "first_byte_seconds",
        "time_to_first_token_seconds",
        "time_to_first_byte_seconds",
        "cached_input_tokens",
        "cached_tokens",
        "reasoning_tokens",
        "error_status",
        "error_type",
        "app",
        "model",
        "selected_model",
        "endpoint",
        "selected_endpoint",
        "user",
        "session_id",
        "http_referer",
        "app_categories",
        "route_type",
        "additional_cost_microdollars",
        "video_input_mode",
        "video_duration_seconds",
        "video_resolution",
        "video_aspect_ratio",
        "video_generate_audio",
    }
)

def _stage_d_accepted_image_digests(
    request: Request,
    settings: Settings,
) -> frozenset[str]:
    """Current signed set plus the explicit, audited break-glass override."""

    accepted: frozenset[str] = frozenset()
    app = request.scope.get("app")
    resolver = getattr(getattr(app, "state", None), "stage_d_policy_resolver", None)
    if resolver is not None:
        resolver.kick()
        accepted = resolver.accepted_image_digests()

    override = settings.stage_d_accepted_gcp_digests
    if override:
        global _STAGE_D_OVERRIDE_LOGGED
        with _STAGE_D_OVERRIDE_LOG_LOCK:
            if not _STAGE_D_OVERRIDE_LOGGED:
                logger.warning(
                    "stage_d.policy_emergency_override digest_count=%s",
                    len(override),
                )
                _STAGE_D_OVERRIDE_LOGGED = True
        accepted = accepted | override
    return accepted


def _register_gateway_boot_sync(
    request: Request,
    body: GatewayBootRegistrationRequest,
    settings: Settings,
) -> dict[str, Any]:
    require_internal_gateway(request, settings)
    try:
        jwk = normalize_receipt_jwk(body.receipt_public_key)
        kid = receipt_kid(jwk)
        if body.kid != kid:
            raise ValueError("kid does not match the receipt public key")
        attestation_kind = _BOOT_WIRE_ATTESTATION_KINDS.get(
            body.attestation_kind,
            body.attestation_kind,
        )
        if not attestation_commits_to_jwk(
            body.attestation_evidence,
            attestation_kind,
            jwk,
        ):
            raise ValueError("attestation does not commit to the receipt public key")
        verified = False
        approved_at_registration = False
        image_digest = ""
        if attestation_kind == GCP_ATTESTATION_KIND:
            verify_gcp_attestation_chain(body.attestation_evidence)
            image_digest = gcp_attestation_image_digest(body.attestation_evidence)
            verified = True
            approved_at_registration = image_digest in _stage_d_accepted_image_digests(
                request,
                settings,
            )
        record = GatewayBoot(
            kid=kid,
            jwk=jwk,
            approved=approved_at_registration,
            verified=verified,
            image_digest=image_digest,
            attestation_kind=attestation_kind,
            registered_at=iso_now(),
            declares_usage_heartbeat=bool(
                body.capabilities is not None and body.capabilities.usage_heartbeat
            ),
            declares_stream_open_heartbeat=bool(
                body.capabilities is not None and body.capabilities.stream_open_heartbeat
            ),
        )
        stored = STORE.observe_gateway_boot(record)
    except ValueError as exc:
        raise api_error(400, str(exc), ErrorType.BAD_REQUEST) from exc
    return {"data": {"verified": stored.verified}}


@timed_gateway_async
async def authorize_gateway(
    request: Request,
    body: GatewayAuthorizeRequest,
    settings: Settings,
) -> dict[str, Any]:
    """Async entrypoint for the authorize path.

    The work below is entirely synchronous storage IO (no awaits), so run it in a
    worker thread via ``run_in_threadpool``. Left on the event loop, ONE contended
    workspace's slow authorize/reserve transaction stalls EVERY in-flight request
    sharing the loop (head-of-line blocking) — so unrelated requests fail even
    though they have nothing to do with the slow one. Offloading keeps the loop
    free while this request's blocking storage runs; the response is byte-identical.
    Kept ``async`` so callers/tests await it unchanged.
    """
    subject = body.api_key_lookup_hash or body.api_key_hash
    assert subject is not None  # GatewayAuthorizeRequest validates one identifier.
    if not _AUTHORIZE_ADMISSION.try_acquire(
        subject,
        limit=settings.gateway_authorize_max_in_flight_per_key,
    ):
        logger.warning(
            "billing.authorize_admission_limited",
            extra={
                "request_id": getattr(request.state, "request_id", None),
                "key_subject_fingerprint": hashlib.sha256(subject.encode("utf-8")).hexdigest()[:16],
                "limit": settings.gateway_authorize_max_in_flight_per_key,
            },
        )
        raise api_error(
            429,
            "Too many concurrent requests for this API key",
            ErrorType.RATE_LIMITED,
            headers={"Retry-After": "1"},
        )
    try:
        try:
            raw_body = await request.body()
        except RuntimeError:
            # Direct unit callers may construct a Request without an ASGI receive
            # channel. Real routed requests always provide the exact cached bytes.
            raw_body = b""
        continuation = worker_continuation() if settings.speculative_provider_shadow_enabled else None
        return await run_in_threadpool(
            cast(Any, _authorize_gateway_sync),  # wrapper consumes the private handoff keyword
            request,
            body,
            settings,
            raw_body,
            **({"_shadow_continuation": continuation} if continuation is not None else {}),
        )
    finally:
        _AUTHORIZE_ADMISSION.release(subject)


@timed_gateway_async
async def settle_gateway(
    request: Request,
    body: GatewaySettleRequest,
    settings: Settings,
    background_tasks: BackgroundTasks | None = None,
) -> dict[str, Any]:
    """Run one settlement off-loop behind the process-local per-key gate."""
    require_internal_gateway(request, settings)
    return await run_in_threadpool(
        _settle_gateway_with_admission_sync,
        body,
        settings=settings,
        background_tasks=background_tasks,
    )


async def heartbeat_gateway(
    request: Request,
    body: GatewayHeartbeatRequest,
    settings: Settings,
) -> dict[str, Any]:
    require_internal_gateway(request, settings)
    if not settings.stage_d_heartbeat_enabled:
        raise api_error(
            503,
            "Stage D heartbeats are disabled",
            ErrorType.SERVICE_UNAVAILABLE,
            headers={"Retry-After": "1"},
        )
    raw_body = await request.body()
    return await run_in_threadpool(
        _heartbeat_gateway_sync,
        request,
        body,
        settings,
        raw_body,
    )


@spanner_rpc_budget(_BILLING_PATH_SPANNER_BUDGET_SECONDS)
def _heartbeat_gateway_sync(
    request: Request,
    body: GatewayHeartbeatRequest,
    settings: Settings,
    raw_body: bytes,
) -> dict[str, Any]:
    require_internal_gateway(request, settings)
    authorization = STORE.get_gateway_authorization(body.authorization_id)
    if authorization is None:
        raise _heartbeat_rejection("unknown_authorization")
    if not _gateway_boot_auth_accepted(request, authorization, raw_body):
        raise _heartbeat_rejection("boot_not_accepted")
    typed_store = typed_billing_store(STORE)
    heartbeat = getattr(typed_store, "heartbeat_gateway_typed", None)
    if (
        typed_store is None
        or getattr(typed_store, "request_record_write_mode", "legacy") != "typed"
        or not callable(heartbeat)
    ):
        raise _heartbeat_rejection("out_of_cohort")
    try:
        started_at = dt.datetime.fromtimestamp(body.started_at_ms / 1000, tz=dt.UTC)
    except (OverflowError, OSError, ValueError) as exc:
        raise api_error(400, "started_at_ms is invalid", ErrorType.BAD_REQUEST) from exc
    canonical_body = json.dumps(
        body.model_dump(exclude_none=True),
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    result = heartbeat(
        authorization_id=body.authorization_id,
        seq=body.seq,
        started_at=started_at,
        selected_endpoint_id=body.selected_endpoint_id,
        usage=body.usage.canonical_counts(),
        heartbeat_hash=hashlib.sha256(canonical_body).hexdigest(),
        stream=body.stream,
        grace_seconds=settings.heartbeat_grace_seconds,
    )
    if not result.accepted:
        raise _heartbeat_rejection(str(result.reason))
    return {
        "accepted": True,
        "seq": int(result.seq),
        "expires_at_ms": int(result.expires_at_ms),
        "cap_micro": int(result.cap_micro),
        "running_micro": int(result.running_micro),
    }


def _gateway_boot_auth_accepted(
    request: Request,
    authorization: GatewayAuthorization,
    exact_body_bytes: bytes,
) -> bool:
    headers = request.headers.getlist("X-TR-Boot-Auth")
    boot_auth = parse_boot_auth_header(headers[0]) if len(headers) == 1 else None
    if boot_auth is None:
        return False
    if not authorization.stage_d_boot_kid or boot_auth.kid != authorization.stage_d_boot_kid:
        return False
    boot = STORE.get_gateway_boot(boot_auth.kid)
    return verify_boot_auth(
        boot=boot,
        auth=boot_auth,
        method=request.method,
        path=request.url.path,
        exact_body_bytes=exact_body_bytes,
        # Heartbeats identify the already-authorized request rather than
        # carrying a customer lookup hash. Equality preserves authorize's
        # verifier contract; the signature binds the authorization id and the
        # exact body bytes.
        signed_lookup_hash="",
        resolved_lookup_hash="",
        # The authorization-time kid is immutable. Membership in the live set
        # is intentionally not re-applied to an in-flight stream.
        accepted_image_digests=({boot.image_digest} if boot is not None else frozenset()),
    )


async def gateway_authorization_disposition(
    request: Request,
    authorization_id: str,
    settings: Settings,
) -> dict[str, Any]:
    require_internal_gateway(request, settings)
    raw_body = await request.body()
    return await run_in_threadpool(
        _gateway_authorization_disposition_sync,
        request,
        authorization_id,
        settings,
        raw_body,
    )


@spanner_rpc_budget(_BILLING_PATH_SPANNER_BUDGET_SECONDS)
def _gateway_authorization_disposition_sync(
    request: Request,
    authorization_id: str,
    settings: Settings,
    raw_body: bytes,
) -> dict[str, Any]:
    require_internal_gateway(request, settings)
    authorization = STORE.get_gateway_authorization(authorization_id)
    if authorization is None:
        raise api_error(404, "Gateway authorization not found", ErrorType.NOT_FOUND)
    if not _gateway_boot_auth_accepted(request, authorization, raw_body):
        raise api_error(401, "Gateway boot was not accepted", ErrorType.UNAUTHORIZED)
    return {
        "data": {
            "authorization_id": authorization.id,
            "disposition": _current_disposition(authorization),
        }
    }


async def gateway_authorization_by_gateway_request_id(
    request: Request,
    gateway_request_id: str,
    settings: Settings,
) -> JSONResponse:
    # This evidence read uses the same internal-gateway bearer credential as
    # the disposition route. It intentionally does not require a boot
    # signature: the post-stream pipeline and synthetic gate are the callers.
    require_internal_gateway(request, settings)
    return await run_in_threadpool(
        _gateway_authorization_by_gateway_request_id_sync,
        request,
        gateway_request_id,
        settings,
    )


@spanner_rpc_budget(_BILLING_PATH_SPANNER_BUDGET_SECONDS)
def _gateway_authorization_by_gateway_request_id_sync(
    request: Request,
    gateway_request_id: str,
    settings: Settings,
) -> JSONResponse:
    require_internal_gateway(request, settings)
    if parse_gateway_request_id(gateway_request_id) is None:
        raise api_error(
            400,
            "gateway request id must be rlog_ followed by 32 lowercase hex characters",
            ErrorType.BAD_REQUEST,
        )
    try:
        authorization = STORE.get_gateway_authorization_by_gateway_request_id(
            gateway_request_id
        )
    except AmbiguousGatewayRequestId:
        raise api_error(
            409,
            "Multiple authorizations share this trace; look up an authorization ID instead",
            "ambiguous_gateway_request_id",
        ) from None
    if authorization is None:
        return JSONResponse(
            {
                "error": {
                    "type": "not_found",
                    "message": "unknown gateway request id",
                }
            },
            status_code=404,
        )
    return JSONResponse(
        {
            "data": {
                "authorization_id": authorization.id,
                "gateway_request_id": authorization.gateway_request_id,
                "workspace_id": authorization.workspace_id,
                "authorization_kind": _gateway_authorization_kind(authorization),
                "settled": bool(authorization.settled),
                "disposition": _gateway_evidence_disposition(authorization),
                "stage_d_boot_kid": authorization.stage_d_boot_kid,
                "heartbeat_seq": (
                    int(authorization.heartbeat_seq)
                    if authorization.heartbeat_seq is not None
                    else None
                ),
            }
        }
    )


def _heartbeat_rejection(reason: str) -> Exception:
    code = 404 if reason == "unknown_authorization" else 401 if reason == "boot_not_accepted" else 409
    return api_error(
        code,
        "Gateway heartbeat rejected",
        ErrorType.HEARTBEAT_REJECTED,
        extra={"reason": reason},
    )


@spanner_rpc_budget(_BILLING_PATH_SPANNER_BUDGET_SECONDS)
@timed_gateway_sync
def _authorize_gateway_sync(
    request: Request,
    body: GatewayAuthorizeRequest,
    settings: Settings,
    raw_body: bytes = b"",
) -> dict[str, Any]:
    boot_auth_headers = request.headers.getlist("X-TR-Boot-Auth")
    boot_auth = (
        parse_boot_auth_header(boot_auth_headers[0]) if len(boot_auth_headers) == 1 else None
    )
    # The boot context carries the attested enclave's per-request signature
    # verdict from this wrapper into the implementation; Stage D cohort
    # admission reads it and nothing else does.
    boot_context: dict[str, Any] = {
        "raw_body": raw_body,
        "boot_auth": boot_auth,
        "boot_verified": False,
        "heartbeat_declared": False,
    }
    return _authorize_gateway_sync_impl(request, body, settings, boot_context)


def _authorize_gateway_sync_impl(
    request: Request,
    body: GatewayAuthorizeRequest,
    settings: Settings,
    boot_context: dict[str, Any],
) -> dict[str, Any]:
    """Core gateway-authorize logic, extracted from the route closure so it is a
    named, directly unit-testable function (#40). The registered route handler is
    a thin wrapper; behavior is byte-identical to the prior inline handler."""
    require_internal_gateway(request, settings)
    video_allowed_providers = _video_allowed_providers_header(request, body.route_type, validate_catalog=False)
    if body.video_resolution is not None and (
        body.route_type != "videos" or body.video_resolution not in {"480p", "720p", "1080p"}
    ):
        raise api_error(400, "video_resolution requires route_type videos and 480p, 720p, or 1080p", ErrorType.BAD_REQUEST)
    # key_lookup_ms covers the single folded auth snapshot: key, workspace, the
    # workspace's BYOK range and the boot row (#1428).
    gateway_timing_phase("key_lookup_ms")
    boot_auth = cast(BootAuthHeader | None, boot_context["boot_auth"])
    api_key, metadata, folded_byok, auth_context = _gateway_authorize_metadata(
        body, boot_kid=boot_auth.kid if boot_auth is not None else None,
    )
    if settings.speculative_provider_shadow_enabled:
        from trusted_router.services import speculation_shadow
        with speculation_shadow.isolate("resolved"):
            speculation_shadow.resolved(api_key, body.invocation_nonce)
    if api_key is None or api_key.disabled or is_api_key_expired(api_key.expires_at):
        if settings.speculative_provider_shadow_enabled and api_key is not None:
            with speculation_shadow.isolate("reason"):
                speculation_shadow.reason("key_disabled" if api_key.disabled else "key_expired")
        raise api_error(401, "Invalid API key", ErrorType.INVALID_API_KEY)
    _assert_gateway_key_scope(api_key)
    # Trusted key metadata, not the caller's workspace header or request body.
    # Preserve attribution if a later boot/workspace read fails before reserve.
    request.state.billing_workspace_id = api_key.workspace_id
    if boot_auth is not None:
        if auth_context is not None and auth_context.boot_record_loaded:
            raw_boot = auth_context.boot_record_body
            boot = decode_auth_record(raw_boot, GatewayBoot) if raw_boot is not None else None
        else:
            boot = STORE.get_gateway_boot(boot_auth.kid)
        accepted_image_digests = _stage_d_accepted_image_digests(request, settings)
        boot_context["boot_verified"] = verify_boot_auth(
            boot=boot,
            auth=boot_auth,
            method=request.method,
            path=request.url.path,
            exact_body_bytes=cast(bytes, boot_context["raw_body"]),
            signed_lookup_hash=body.api_key_lookup_hash,
            resolved_lookup_hash=api_key.lookup_hash,
            accepted_image_digests=accepted_image_digests,
        )
        boot_context["heartbeat_declared"] = bool(
            boot is not None and boot.declares_usage_heartbeat
        )
    if settings.speculative_provider_shadow_enabled:
        with speculation_shadow.isolate("boot_verified"):
            speculation_shadow.boot_verified(boot_context["boot_verified"], boot_auth.kid if boot_auth is not None else "")
    workspace = metadata.workspace if metadata is not None else STORE.get_workspace(api_key.workspace_id)
    gateway_timing_phase("routing_ms")
    if workspace is None:
        raise api_error(403, "Workspace is unavailable", ErrorType.FORBIDDEN)
    if workspace_billing_paused(workspace):
        if settings.speculative_provider_shadow_enabled:
            with speculation_shadow.isolate("reason"):
                speculation_shadow.reason("billing_paused")
        # Keep tenant attribution in the rendered message because Cloud Run's
        # stderr collector does not preserve arbitrary LogRecord extras. This
        # is billing metadata only: never include the raw key, body, or content.
        logger.warning(
            "billing.authorize_workspace_paused workspace_id=%s request_id=%s",
            workspace.id,
            getattr(request.state, "request_id", None),
        )
    assert_workspace_billing_active(workspace)
    # The synthetic monitor funds itself: a monthly idempotent grant applied
    # on its own authorize path, so a dry monitor self-heals on the next
    # probe instead of failing 402 for days (invisible availability loss —
    # the deep probes stop proving anything). One set-lookup for monitor
    # traffic, zero cost for everyone else.
    monitor_hash = monitor_lookup_hash(settings)
    is_monitor_request = (
        monitor_hash is not None and body.api_key_lookup_hash == monitor_hash
    )
    if is_monitor_request:
        ensure_monitor_funding(STORE, settings, workspace.id)
    try:
        request_tags = validate_tags(body.tags)
        effective_tags = merge_tags(api_key.tags, body.tags)
    except InvalidTags as exc:
        raise api_error(400, str(exc), ErrorType.INVALID_TAGS) from exc
    if is_monitor_request:
        # The dedicated key is the server-owned source of truth. Media
        # requests intentionally expose a smaller public schema than chat and
        # cannot carry metadata.trustedrouter_synthetic themselves.
        effective_tags = {**effective_tags, "purpose": "synthetic_monitoring"}
    body_dict, attribution = _gateway_authorize_body(body)
    _require_monitor_model_key(body_dict, api_key.lookup_hash, settings)
    requested_model_id = body.model
    # Only catalog video requests defer live preparation for early replay.
    # Classify the request string, never mutable model/catalog state.
    catalog_video_request = body.route_type == "videos" and not (
        is_custom_model_id(requested_model_id)
        or is_user_provided_model_id(requested_model_id)
    )
    custom_model = None
    user_model = None
    route_model_id = str(body_dict.get("model") or body.model)
    native_retention_allowed = False
    def prepare_model() -> None:
        nonlocal custom_model, user_model
        # Every guard below keys on the model id as a STRING, and routing rewrites
        # that string before it resolves a model (variant suffix, alias, dated
        # snapshot). `trev-1.0:nitro` and `trev-1.0-2026-09-19` therefore matched no
        # guard and routed as the model anyway: no decide-only rule, no host chain,
        # and a response naming the backing model. A pinned model is accepted under
        # its exact id only. Stated as "routing resolved it from something else",
        # not as a list of spellings: the first version of this guard listed the
        # variant suffixes and missed the dated one.
        for raw_model_id in (requested_model_id, *(body.models or [])):
            catalog_id = canonical_model_id(raw_model_id)
            if catalog_id == raw_model_id:
                continue
            catalog_model = MODELS.get(catalog_id)
            if catalog_id in PRIVATE_PROXY_MODEL_TARGETS or catalog_id == POLYPHEMUS_MODEL_ID or (
                catalog_model is not None and catalog_model.supports_decide
            ):
                raise api_error(
                    400,
                    f"{catalog_id} must be requested by its exact id, "
                    "without a routing variant or dated suffix",
                    ErrorType.BAD_REQUEST,
                )
        if body.models and any(
            canonical_model_id(model_id) == POLYPHEMUS_MODEL_ID
            for model_id in (requested_model_id, *body.models)
        ):
            raise api_error(400, "Polyphemus cannot be used with models fallback arrays", ErrorType.BAD_REQUEST)
        private_proxy_ids = {
            model_id
            for model_id in (requested_model_id, *(body.models or []))
            if model_id in PRIVATE_PROXY_MODEL_TARGETS
        }
        if private_proxy_ids and body.models:
            raise api_error(
                400,
                "Private proxy models cannot be combined with models fallback arrays",
                ErrorType.BAD_REQUEST,
            )
        if any(is_creator_model_id(model_id) for model_id in (body.models or [])):
            raise api_error(
                400,
                "Custom models cannot be used with models fallback arrays in v1",
                ErrorType.BAD_REQUEST,
            )
        custom_model = None
        user_model = None
        if is_custom_model_id(requested_model_id):
            normalized = normalize_custom_model_id(requested_model_id)
            custom_model = STORE.get_custom_model(normalized)
            if custom_model is None or not custom_model.enabled:
                raise api_error(404, "Custom model not found", ErrorType.NOT_FOUND)
            body_dict["model"] = custom_model.base_model_id
            body_dict.pop("models", None)
            body_dict["custom_model_id"] = custom_model.id
            body_dict["custom_model_revision"] = custom_model.revision
            _force_custom_model_credit_routes(body_dict)
        elif is_user_provided_model_id(requested_model_id):
            normalized = normalize_user_provided_model_id(requested_model_id)
            user_model = STORE.get_user_model(normalized)
            if (
                user_model is None
                or not user_model.enabled
                or user_model.status != "active"
                # Serving is gated until settle/refund exist for these
                # authorizations; an unreleasable hold is worse than a 404.
                or not settings.user_models_dispatch_enabled
            ):
                raise api_error(404, "Custom model not found", ErrorType.NOT_FOUND)
            if not user_model_is_on_the_clock(user_model, datetime.now(dt.UTC)):
                # The billing-path 5xx alert counts this 503; without a line the
                # request log alone cannot tell it from storage contention.
                logger.warning(
                    "billing.authorize_user_model_off_the_clock workspace_id=%s request_id=%s "
                    "user_model_id=%s kind=%s",
                    workspace.id,
                    getattr(request.state, "request_id", None),
                    _log_value(user_model.id),
                    _log_value(user_model.kind),
                )
                raise api_error(
                    503,
                    f"User-provided {user_model.kind} model {user_model.id} is off the clock",
                    ErrorType.MODEL_OFF_THE_CLOCK,
                )
            # Same fingerprint discipline as prompt wrappers: a same-key retry
            # after a material edit must 409, not replay stale frozen prices.
            body_dict.pop("models", None)
            body_dict["custom_model_id"] = user_model.id
            body_dict["custom_model_revision"] = user_model.revision
            _force_custom_model_credit_routes(
                body_dict,
                error_message="User-provided models do not support BYOK routes",
            )

    # Preserve main's validation order for non-video and creator-model requests.
    if not catalog_video_request:
        prepare_model()
    presented_idempotency_key = _gateway_idempotency_key(request, body)
    request_idempotency_key = presented_idempotency_key or str(uuid.uuid4())
    _require_native_batch_route_binding(body.route_type, request_idempotency_key)
    partner_mode = _partner_billing_mode_or_error(
        requested_model_id=requested_model_id,
        route_type=body.route_type,
        idempotency_key=request_idempotency_key,
    )

    def prepare_live_routing() -> None:
        nonlocal route_model_id, native_retention_allowed
        if catalog_video_request:
            prepare_model()
        if partner_mode is not None:
            _force_partner_credit_routes(body_dict)
        native_retention_allowed = _native_batch_request_allows_retention(body_dict, settings)
        # Embedding-only models can't go through the chat resolver (it
        # rejects supports_chat=False). Route them to the embeddings
        # resolver so the attested enclave can authorize + bill an
        # embeddings call exactly like a chat one.
        route_model_id = str(body_dict.get("model") or body.model)
        if route_model_id == POLYPHEMUS_MODEL_ID:
            if body.route_type != POLYPHEMUS_SELECT_ROUTE_TYPE or custom_model is not None:
                raise api_error(
                    400, "Polyphemus requires POST /v1/responses", ErrorType.MODEL_NOT_SUPPORTED
                )
            provider_options = body_dict.get("provider") or {}
            if isinstance(provider_options, dict) and provider_options.get("data_collection") == "deny":
                raise api_error(400, "Polyphemus does not support no-retention requests", ErrorType.BAD_REQUEST)
        elif body.route_type == POLYPHEMUS_SELECT_ROUTE_TYPE:
            raise api_error(400, "Invalid Polyphemus selection route", ErrorType.BAD_REQUEST)
        if body.additional_cost_reservation_microdollars and (
            _is_web_search_restricted_model(route_model_id)
            or _is_web_search_restricted_provider(body_dict.get("provider"))
        ):
            raise api_error(
                400,
                "web_search is not available for this privacy tier",
                ErrorType.BAD_REQUEST,
            )

    if not catalog_video_request:
        prepare_live_routing()
    region = choose_region(settings, body.region or None)
    is_video_request = body.route_type == "videos"
    is_image_request = body.route_type == "images"
    def prepare_fingerprint() -> tuple[dict[str, Any], str]:
        fingerprint_body = dict(body_dict)
        if is_video_request or is_image_request:
            # Provider quotes can change between retries. The enclave supplies a
            # keyed content fingerprint, so media idempotency binds to the logical
            # request without storing content or coupling replay to a fresh quote.
            fingerprint_body.pop("additional_cost_reservation_microdollars", None)
        # Preserve the pre-tagging router's distinction between an absent tags
        # field and an explicitly supplied empty object. That lets an idempotent
        # retry carrying tags={} replay an authorization created before rollout.
        if body.tags is not None:
            fingerprint_body["tags"] = request_tags
        else:
            fingerprint_body.pop("tags", None)
        body_dict["tags"] = effective_tags
        request_fingerprint = _gateway_authorize_fingerprint(
            workspace_id=workspace.id,
            key_hash=api_key.hash,
            body=fingerprint_body,
            idempotency_key=request_idempotency_key,
        )
        return fingerprint_body, request_fingerprint

    if catalog_video_request:
        fingerprint_body, request_fingerprint = prepare_fingerprint()

    def _replay_response(
        existing_authorization: Any,
        fallback: list[tuple[Model, ModelEndpoint]] | None = None,
    ) -> dict[str, Any]:
        gateway_timing_phase("post_commit_ms")
        if body.route_type == POLYPHEMUS_SELECT_ROUTE_TYPE:
            # The selector has no upstream idempotency contract. Never repeat
            # selection (including concurrent replays) on an existing hold.
            raise api_error(409, "Polyphemus request already admitted; use a new idempotency key for a new request", ErrorType.BAD_REQUEST)
        # Build the replay response from the STORED authorization (NOT current
        # routing), so a replay across catalog/pricing/BYOK drift advertises
        # the endpoint that was actually authorized (codex 3e route review #1).
        existing_candidates = _authorization_endpoint_candidates(
            existing_authorization,
            fallback or [],
            privacy_requirements=(
                frozenset() if catalog_video_request
                else _required_privacy_postures(effective_route_preferences)
            ),
            video_replay=catalog_video_request,
        )
        byok_configs = _byok_configs_for_candidates(
            existing_candidates, workspace.id, folded_rows=folded_byok,
        )
        broadcast_destinations = [
            payload
            for destination in _broadcast_destinations_for_authorize(workspace.id)
            if (payload := gateway_destination_payload(destination)) is not None
        ]
        existing_model, existing_endpoint = existing_candidates[0]
        existing_usage_type = UsageType.for_endpoint(existing_endpoint)
        byok_config = (
            _get_byok_provider(workspace.id, existing_endpoint.provider, byok_configs)
            if existing_usage_type.is_byok()
            else None
        )
        return _gateway_authorize_response(
            authorization=existing_authorization,
            workspace_id=workspace.id,
            key_hash=api_key.hash,
            model=existing_model,
            endpoint=existing_endpoint,
            requested_model_id=requested_model_id,
            model_usage_type=existing_usage_type,
            limit_usage_type=UsageType.coerce(existing_authorization.usage_type),
            estimate=existing_authorization.estimated_microdollars,
            credit_reservation_id=existing_authorization.credit_reservation_id,
            byok_config=byok_config,
            byok_configs=byok_configs,
            region=existing_authorization.region or region,
            settings=settings,
            broadcast_destinations=broadcast_destinations,
            endpoint_candidates=existing_candidates,
            idempotent_replay=True,
            custom_model=custom_model,
            stage_d_reason_override="replayed",
            async_request=request, async_body=body,
            async_federated=bool(workspace.federated_home or api_key.federated_home),
            # Replays never re-freeze prices; pricing_effective_at is assigned later.
            async_effective_at=None,
        )

    _typed_store = typed_billing_store(STORE)

    def _lookup_replay(
        fallback: list[tuple[Model, ModelEndpoint]] | None = None,
    ) -> dict[str, Any] | None:
        from trusted_router.storage_legacy_trust import BillingPausedError
        try:
            existing_authorization = (
                _typed_store.get_typed_authorization_by_idempotency(
                    workspace.id, api_key.hash, request_idempotency_key,
                )
                if _typed_store is not None
                else STORE.get_gateway_authorization_by_idempotency_key(
                    workspace.id, api_key.hash, request_idempotency_key,
                )
            )
        except BillingPausedError as exc:
            if settings.speculative_provider_shadow_enabled:
                with speculation_shadow.isolate("reason"):
                    speculation_shadow.reason("billing_paused")
            raise api_error(403, "billing_paused", ErrorType.FORBIDDEN) from exc

        if existing_authorization is not None:
            if (
                existing_authorization.idempotency_fingerprint != request_fingerprint
                and not _video_cross_region_replay_matches(
                    existing_authorization, workspace.id, api_key.hash,
                    fingerprint_body, request_idempotency_key,
                )
            ):
                raise api_error(
                    409,
                    "Idempotency key was already used for a different gateway request",
                    ErrorType.CONFLICT,
                )
            return _replay_response(existing_authorization, fallback)
        return None

    early_video_replay = catalog_video_request and (
        body.video_resolution is not None
        or bool(presented_idempotency_key and body.request_fingerprint)
    )
    if early_video_replay:
        # Recover frozen video terms before live catalog filtering can reject
        # a retry. This indexed read never reserves funds: the transaction below
        # still arbitrates concurrent first requests atomically after a miss.
        replay = _lookup_replay()
        if replay is not None:
            return replay

    video_allowed_providers = _video_allowed_providers_header(request, body.route_type)
    if catalog_video_request:
        prepare_live_routing()

    normalized_routing = normalize_routing_inputs(
        body_dict,
        settings,
        resolved_region=region,
    )
    route_preferences = normalized_routing.preferences
    requested_model = MODELS.get(route_model_id) if route_model_id else None
    is_embeddings_request = (
        requested_model is not None
        and requested_model.supports_embeddings
        and not requested_model.supports_chat
    )
    # Hosted decision models dispatch on the MODEL, like embeddings: a native
    # decision request names an ordinary chat model and takes the chat arm.
    is_decide_request = (
        requested_model is not None
        and requested_model.supports_decide
        and not requested_model.supports_chat
    )
    named_decision_chain = NAMED_DECISION_MODEL_PROVIDERS.get(route_model_id or "")
    supports_live_routing = (
        body.route_type in {"chat.completions", "responses", "messages"}
        and named_decision_chain is None
        and not (is_image_request or is_video_request or is_embeddings_request or is_decide_request)
    )
    if not supports_live_routing and (
        route_preferences.preferred_max_latency or route_preferences.preferred_min_throughput
    ):
        raise api_error(
            501,
            "Performance preferences currently require a synchronous text-generation endpoint",
            "not_supported_in_alpha",
        )
    if (is_decide_request or named_decision_chain is not None) and body.route_type != "decide":
        # A decision model has no chat surface. Jev would fail at the provider,
        # and a named model like trev-1.0 would silently become a plain chat
        # alias for its backing model on whichever host is cheapest -- not the
        # thing the name promises. Say so instead.
        raise api_error(
            400,
            f"{route_model_id} is a decision model: call POST {DECIDE_PATH}",
            ErrorType.MODEL_NOT_SUPPORTED,
        )
    if named_decision_chain is not None:
        # A caller excluding the entire pinned chain is an invalid request,
        # not an outage. Check policy before live regional availability so a
        # genuinely unavailable permitted host still returns retryable 503.
        permitted_hosts = set(named_decision_chain) - route_preferences.ignore
        if route_preferences.only:
            permitted_hosts.intersection_update(route_preferences.only)
        if not permitted_hosts:
            raise api_error(
                400,
                f"Provider filters exclude every supported host for {route_model_id}",
                ErrorType.BAD_REQUEST,
            )
    effective_route_preferences = route_preferences
    if not catalog_video_request:
        # Main prepares and validates creator models before fingerprinting.
        # Its resolution-triggered replay still precedes live routing and any
        # user-model slot acquisition; only catalog requests replay earlier.
        fingerprint_body, request_fingerprint = prepare_fingerprint()
        if body.video_resolution is not None:
            replay = _lookup_replay()
            if replay is not None:
                return replay

    # The authorization's one clock reading. The estimate, the pricing
    # snapshot and the stored created_at all use it, and settlement prices a
    # request without a snapshot at created_at. Two readings would hold a
    # request at one tariff and bill it at another whenever a scheduled price
    # change fell between them.
    pricing_effective_at = dt.datetime.now(dt.UTC)
    if user_model is not None:
        if is_image_request:
            raise api_error(
                400,
                "User-provided models do not support image generation",
                ErrorType.MODEL_NOT_SUPPORTED,
            )
        if video_allowed_providers is not None:
            # Owner-dispatch sentinels bypass catalog candidate construction;
            # they cannot satisfy an enclave video capability constraint.
            raise api_error(
                400, "Video provider constraints require catalog video routes",
                ErrorType.MODEL_NOT_SUPPORTED,
            )
        if _required_privacy_postures(route_preferences):
            # The owner's endpoint carries no tracked privacy posture, so a
            # privacy floor fails closed, as it does for any unknown route.
            raise api_error(
                400,
                "User-provided models cannot meet a provider privacy floor",
                ErrorType.MODEL_NOT_SUPPORTED,
            )
        endpoint_candidates = [_user_model_gateway_candidate(user_model)]
    elif is_video_request:
        endpoint_candidates = video_route_endpoint_candidates(
            normalized_routing,
            defer_no_fallback_selection=True,
            video_resolution=body.video_resolution,
            pricing_effective_at=pricing_effective_at,
            allowed_providers=video_allowed_providers,
        )
    elif is_image_request:
        if custom_model is not None:
            raise api_error(
                400,
                "Custom models do not support image generation",
                ErrorType.MODEL_NOT_SUPPORTED,
            )
        endpoint_candidates = image_route_endpoint_candidates(
            normalized_routing,
            defer_no_fallback_selection=True,
        )
    elif is_decide_request:
        resolved_candidates = decide_route_endpoint_candidates(
            normalized_routing,
            defer_no_fallback_selection=True,
        )
        effective_route_preferences = resolved_candidates.effective_preferences
        endpoint_candidates = resolved_candidates
    elif is_embeddings_request:
        endpoint_candidates = embeddings_route_endpoint_candidates(
            normalized_routing,
            defer_no_fallback_selection=True,
        )
        if not endpoint_candidates:
            raise api_error(400, "Model does not support embeddings", ErrorType.MODEL_NOT_SUPPORTED)
    else:
        resolved_candidates = chat_route_endpoint_candidates(
            normalized_routing,
            defer_no_fallback_selection=True,
        )
        effective_route_preferences = resolved_candidates.effective_preferences
        endpoint_candidates = resolved_candidates
        if not endpoint_candidates:
            raise api_error(
                400, "Model does not support chat completions", ErrorType.MODEL_NOT_SUPPORTED
            )
    endpoint_candidates = [
        (candidate_model, candidate_endpoint)
        for candidate_model, candidate_endpoint in endpoint_candidates
        if provider_model_available_from_gateway_region(
            candidate_endpoint.provider,
            candidate_endpoint.model_id,
            region,
        )
    ]
    byok_configs = _byok_configs_for_candidates(
        endpoint_candidates, workspace.id,
        folded_rows=folded_byok,
    )
    endpoint_candidates = _eligible_gateway_endpoint_candidates(
        endpoint_candidates, workspace.id, byok_configs,
    )
    if named_decision_chain is not None:
        # The chain is part of what the name means (and of its advertised
        # price), so it is enforced HERE, not merely requested by the gateway:
        # only the pinned hosts, in the pinned order, whatever the request's
        # provider preferences say.
        chain_rank = {provider: rank for rank, provider in enumerate(named_decision_chain)}
        endpoint_candidates = sorted(
            (
                candidate
                for candidate in endpoint_candidates
                if candidate[1].provider in chain_rank and not candidate[1].is_byok
            ),
            key=lambda candidate: chain_rank[candidate[1].provider],
        )
        if not endpoint_candidates:
            # Establish request compatibility independently of availability.
            # endpoints_for_model drops expired/retired routes, so use the
            # catalog entries (at effective prices) before those exclusions.
            # An available but request-excluded host says nothing about a
            # compatible host's outage. BYOK is never part of a named chain.
            pinned_credit_candidates = [
                (MODELS[candidate_endpoint.model_id], effective_endpoint(candidate_endpoint))
                for candidate_endpoint in model_catalog.MODEL_ENDPOINTS.values()
                if candidate_endpoint.model_id in normalized_routing.model_ids
                and candidate_endpoint.provider in chain_rank
                and not candidate_endpoint.is_byok
            ]
            # Reuse relaxation over the resolver's full backing candidates;
            # recomputing it over just pinned hosts would broaden the policy.
            if pinned_credit_candidates and not _apply_endpoint_provider_filters(
                pinned_credit_candidates, effective_route_preferences
            ):
                logger.info(
                    "billing.authorize_named_chain_filtered_by_request workspace_id=%s "
                    "request_id=%s model=%s region=%s",
                    workspace.id,
                    getattr(request.state, "request_id", None),
                    _log_value(route_model_id),
                    _log_value(region),
                )
                raise api_error(
                    400,
                    f"No host in the {route_model_id} chain matches the request's routing "
                    "filters; the chain's hosts are fixed, so relax the usage, privacy, "
                    "jurisdiction or provider filters",
                    ErrorType.BAD_REQUEST,
                )
            logger.warning(
                "billing.authorize_named_chain_unavailable workspace_id=%s request_id=%s "
                "model=%s region=%s",
                workspace.id,
                getattr(request.state, "request_id", None),
                _log_value(route_model_id),
                _log_value(region),
            )
            raise api_error(
                503,
                f"No host in the {route_model_id} chain is available; retry shortly",
                ErrorType.SERVICE_UNAVAILABLE,
                headers={"Retry-After": "2"},
            )
    input_tokens = body.estimated_input_tokens
    if custom_model is not None and custom_model.hidden_prompt.strip():
        input_tokens += estimate_tokens_from_text(custom_model.hidden_prompt)
    service_tier = _requested_service_tier_or_error(body.service_tier)
    endpoint_candidates = _service_tier_endpoint_candidates_or_error(
        endpoint_candidates,
        service_tier=service_tier,
        estimated_input_tokens=input_tokens,
    )
    additional_cost_reservation = body.additional_cost_reservation_microdollars
    if additional_cost_reservation:
        if body.route_type not in _ADDITIONAL_COST_ROUTE_TYPES:
            raise api_error(
                400,
                "additional cost reservations are only available for hosted search, image, or video",
                ErrorType.BAD_REQUEST,
            )
        # Hosted tools and asynchronous media are operator-funded, so their
        # fixed cost must settle against Credits rather than a BYOK route.
        endpoint_candidates = [
            (candidate_model, candidate_endpoint)
            for candidate_model, candidate_endpoint in endpoint_candidates
            if UsageType.for_endpoint(candidate_endpoint) == UsageType.CREDITS
        ]
    if supports_live_routing:
        endpoint_candidates = ROUTING_STATE.rank(
            endpoint_candidates, effective_route_preferences, region=region,
            session=(api_key.hash, requested_model_id, region, body.cache_affinity_key)
            if body.cache_affinity_key else None,
        )
    # ``allow_fallbacks=false`` removes alternate models in the resolver, but
    # provider selection must happen after regional, workspace/BYOK, and
    # service-tier eligibility. Truncating the raw catalog first can pin an
    # unusable endpoint and reject a model another eligible provider serves.
    if not route_preferences.allow_fallbacks:
        endpoint_candidates = endpoint_candidates[:1]
    if not endpoint_candidates:
        raise api_error(
            400,
            "No authorized route candidates are available for this workspace",
            ErrorType.PROVIDER_NOT_SUPPORTED,
        )
    model, endpoint = endpoint_candidates[0]

    output_tokens = body.output_estimate
    model_estimate = (
        custom_model_cost_microdollars(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            prompt_price=user_model.prompt_price_microdollars_per_million_tokens,
            completion_price=user_model.completion_price_microdollars_per_million_tokens,
        )
        if user_model is not None
        else partner_cost_microdollars(
            partner_mode,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
        )
        if partner_mode is not None
        else max(
            _endpoint_cost_microdollars_from_document(
                endpoint_pricing_document((candidate_endpoint,)),
                candidate_endpoint.id,
                input_tokens,
                output_tokens,
            )
            if body.video_resolution is not None
            else _endpoint_cost_microdollars(
                candidate_endpoint,
                input_tokens,
                output_tokens,
                effective_at=pricing_effective_at,
                service_tier=service_tier,
                reserve_auto=True,
            )
            for _candidate_model, candidate_endpoint in endpoint_candidates
        )
    )
    model_usage_type = UsageType.for_endpoint(endpoint)
    has_credit_candidate = any(
        UsageType.for_endpoint(candidate_endpoint) == UsageType.CREDITS
        for _candidate_model, candidate_endpoint in endpoint_candidates
    )
    reservation_usage_type = UsageType.CREDITS if has_credit_candidate else UsageType.BYOK
    receipt_fee_basis_points = (
        SIGNED_RECEIPT_TOTAL_FEE_BASIS_POINTS if body.inference_receipt else 0
    )
    if receipt_fee_basis_points and user_model is None and partner_mode is None:
        model_estimate = signed_receipt_price_microdollars(model_estimate, receipt_fee_basis_points)
    custom_model_markup_basis_points = (
        int(custom_model.markup_basis_points) if custom_model is not None else 0
    )
    custom_model_owner_user_id = (
        str(custom_model.owner_user_id) if custom_model is not None else ""
    )
    if custom_model_markup_basis_points > 0:
        model_estimate += custom_model_markup_microdollars(
            model_estimate,
            custom_model_markup_basis_points,
        )
    # Video candidates are either fixed-quote or output-token billed. Reserve
    # the largest possible route charge, not the sum of mutually exclusive routes.
    estimate = max(model_estimate, additional_cost_reservation) if is_video_request else model_estimate + additional_cost_reservation
    broadcast_destinations = [
        payload
        for destination in _broadcast_destinations_for_authorize(workspace.id)
        if (payload := gateway_destination_payload(destination)) is not None
    ]
    native_batch_eligible = _native_batch_eligibility(
        route_type=body.route_type,
        retention_allowed=native_retention_allowed,
        model_usage_type=model_usage_type,
        custom_model=custom_model,
        broadcast_destinations=broadcast_destinations,
        requested_model_id=requested_model_id,
        endpoint=endpoint,
    )
    if _typed_store is None and (catalog_video_request or body.video_resolution is None):
        replay = _lookup_replay(endpoint_candidates)
        if replay is not None:
            return replay
    # Suspension stops NEW authorizations. Resolve replay first so a lost
    # response can be recovered and in-flight work can settle under frozen terms.
    app_markup_basis_points, app_owner_user_id = _oauth_app_terms_for_key(api_key)
    if app_markup_basis_points > 0:
        # Settle-side caps compare against this frozen hold. If authorize held
        # only the base, those caps would claw the app markup back at settle.
        estimate += app_markup_microdollars(estimate, app_markup_basis_points)
    # Minted up front so a user-model concurrency slot can be keyed by it
    # before the reservation exists. It is a fresh uuid — never derived from
    # the caller's Idempotency-Key: a deterministic id would outlive its
    # 30-day authorization row inside the 400-day tr_credit_movement PK
    # (silently dropping a later payout) and let a mismatching concurrent
    # request release the winner's slot.
    authorization_id = _new_gateway_authorization_id()
    standard_endpoint_pricing = (
        custom_model is None
        and user_model is None
        and partner_mode is None
        and additional_cost_reservation == 0
        and not native_batch_eligible
    )
    stage_d_reason = _stage_d_eligibility_reason(
        eligibility_enabled=settings.stage_d_eligibility_enabled and not api_key.budget_strict,
        workspace_id=workspace.id,
        pilot_workspace_ids=settings.stage_d_pilot_workspaces,
        heartbeat_enabled=settings.stage_d_heartbeat_enabled,
        boot_accepted=bool(boot_context["boot_verified"]),
        heartbeat_declared=bool(boot_context.get("heartbeat_declared", False)),
        require_heartbeat_declaration=settings.stage_d_require_heartbeat_declaration,
        stream=body.stream,
        route_type=body.route_type,
        endpoint_candidates=endpoint_candidates,
        standard_endpoint_pricing=standard_endpoint_pricing,
        service_tier=service_tier,
        settlement_backend=(
            _typed_store is not None
            and getattr(_typed_store, "request_record_write_mode", "legacy") == "typed"
        ),
    )
    pricing_snapshot = None
    video_snapshot = (
        video_pricing_snapshot(
            (e if body.video_resolution is not None else effective_endpoint(e, at=pricing_effective_at)
             for _m, e in endpoint_candidates),
            output_tokens,
            resolution=body.video_resolution,
        )
        if body.route_type == "videos" else None
    )
    if stage_d_reason == "ok":
        pricing_snapshot = canonical_pricing_snapshot(
            endpoint_pricing_document(
                effective_endpoint(candidate_endpoint, at=pricing_effective_at)
                for _candidate_model, candidate_endpoint in endpoint_candidates
            )
        )
    user_model_slot_acquired = False
    if user_model is not None:
        user_model_slot_acquired = acquire_user_model_slot(
            user_model.id,
            authorization_id,
            limit=user_model.max_concurrency,
            kind=user_model.kind,
        )
        if not user_model_slot_acquired:
            raise api_error(
                429,
                f"User-provided model {user_model.id} is at capacity "
                f"({user_model.max_concurrency} concurrent)",
                ErrorType.RATE_LIMITED,
            )

    def release_user_model_slot_after_error() -> None:
        if user_model is not None and user_model_slot_acquired:
            release_user_model_slot(user_model.id, authorization_id)

    credit_reservation_id: str | None = None
    idempotent_replay = False
    # C1 removed the workspace cohort/denylist brake: GCP now always uses typed
    # billing when the store exposes that capability. Emergency rollback is the
    # previous deploy revision; the memory store below remains the test twin.
    if _typed_store is not None:
        import datetime as _dt

        from trusted_router.spend_windows import (
            enforced_window_limits,
            remember_spend_window_decision,
            spend_window_headers,
            spend_window_limit_error_message,
        )
        from trusted_router.storage_gcp_authorize import AuthorizeOutcome
        from trusted_router.storage_gcp_counters import key_usage_shard_count

        # Provider-native batches have a 24-hour completion window. Keep their
        # holds alive for two extra hours so a completion at the deadline can
        # still settle idempotently; ordinary request reservations remain 2h.
        reservation_ttl_seconds = _authorization_ttl_seconds(body.route_type)
        expires_at = _dt.datetime.now(_dt.UTC) + _dt.timedelta(seconds=reservation_ttl_seconds)
        # Per-window key caps (approximate). Omitted entirely for a BYOK
        # request on a key that excludes BYOK from its caps — same rule the
        # lifetime cap applies (authorize_atomic's window_limits contract).
        is_byok_request = not has_credit_candidate
        window_limits = (
            {}
            if is_byok_request and not api_key.include_byok_in_limit
            else enforced_window_limits(api_key)  # {} in alert mode → never blocks
        )
        key_usage_shards = key_usage_shard_count(api_key)
        try:
            with gateway_phase("store_ms", after="post_commit_ms"):
                outcome, authorization = _typed_store.authorize_gateway_typed(
                    workspace_id=workspace.id,
                    key_hash=api_key.hash,
                    authorization_id=authorization_id,
                    estimate=estimate,
                    has_credit_candidate=has_credit_candidate,
                    reservation_usage_type=reservation_usage_type,
                    model_id=model.id,
                    provider=endpoint.provider,
                    requested_model_id=requested_model_id,
                    candidate_model_ids=[m.id for m, _e in endpoint_candidates],
                    region=region,
                    endpoint_id=endpoint.id,
                    candidate_endpoint_ids=[e.id for _m, e in endpoint_candidates],
                    idempotency_key=request_idempotency_key,
                    tags=effective_tags,
                    idempotency_fingerprint=request_fingerprint,
                    app_id=api_key.app_id,
                    app_markup_basis_points=app_markup_basis_points,
                    receipt_fee_basis_points=receipt_fee_basis_points,
                    app_owner_user_id=app_owner_user_id,
                    key_usage_shards=key_usage_shards,
                    # The entity is already authenticated; a no-op reserve
                    # UPDATE would still lock uncapped usage counter rows.
                    # Window caps are enforced separately on a snapshot.
                    skip_key_limit=api_key.limit_microdollars is None and not api_key.budget_strict,
                    strict_budget=api_key.budget_strict,
                    strict_budget_alert_only=api_key.budget_alert_only,
                    # Metadata only selects the path; sequential reserve still
                    # checks the authoritative row for BYOK exclusions.
                    speculate_key_limit=(
                        api_key.limit_microdollars is not None
                        and (has_credit_candidate or api_key.include_byok_in_limit)
                    ),
                    custom_model_id=custom_model.id if custom_model else None,
                    custom_model_revision=custom_model.revision if custom_model else None,
                    custom_model_markup_basis_points=(
                        custom_model_markup_basis_points
                    ),
                    custom_model_owner_user_id=custom_model_owner_user_id,
                    user_provided_model_id=user_model.id if user_model else None,
                    user_provided_model_revision=user_model.revision if user_model else None,
                    user_model_prompt_price_microdollars_per_m=(
                        user_model.prompt_price_microdollars_per_million_tokens
                        if user_model
                        else None
                    ),
                    user_model_completion_price_microdollars_per_m=(
                        user_model.completion_price_microdollars_per_million_tokens
                        if user_model
                        else None
                    ),
                    user_model_owner_user_id=user_model.owner_user_id if user_model else None,
                    additional_cost_reservation_microdollars=additional_cost_reservation,
                    native_batch_eligible=native_batch_eligible,
                    expires_at=expires_at,
                    window_limits=window_limits or None,
                    pricing_snapshot=pricing_snapshot,
                    video_pricing_snapshot=video_snapshot,
                    stage_d_reason=stage_d_reason,
                    stage_d_prompt_tokens=input_tokens,
                    stage_d_max_output_tokens=output_tokens,
                    stage_d_boot_kid=(
                        boot_auth.kid
                        if boot_context["boot_verified"] and boot_auth is not None
                        else None
                    ),
                    invocation_nonce=body.invocation_nonce,
                    created_at=pricing_effective_at,
                )
        except conflict_store_error_types() as exc:
            release_user_model_slot_after_error()
            # The generic 503 request log cannot identify a tenant hot row.
            # Emit only safe billing metadata so an operator can reshard the
            # affected workspace without ever logging a key, prompt, or body.
            # request_id and error_class ride in the message so this line can
            # be joined with the app-level ``storage.transaction_aborted`` line
            # that answers the re-raise (the console formatter drops ``extra``).
            logger.warning(
                "billing.authorize_contention request_id=%s workspace_id=%s error_class=%s",
                getattr(request.state, "request_id", None),
                workspace.id,
                type(exc).__name__,
                extra={
                    "request_id": getattr(request.state, "request_id", None),
                    "workspace_id": workspace.id,
                    "requested_model": requested_model_id,
                    "estimated_microdollars": estimate,
                    "candidate_count": len(endpoint_candidates),
                    "key_usage_shards": key_usage_shards,
                    "error_class": type(exc).__name__,
                },
            )
            raise
        except transient_store_error_types() as exc:
            from trusted_router.strict_budget import StrictBudgetBusy

            release_user_model_slot_after_error()
            # Keep enough tenant-safe context to distinguish a Spanner
            # deadline, service outage, session exhaustion, or retry failure.
            # The request body, raw key, prompt, and output stay out of logs.
            logger.warning(
                "%s request_id=%s workspace_id=%s "
                "error_class=%s",
                "billing.authorize_strict_budget_busy"
                if isinstance(exc, StrictBudgetBusy)
                else "billing.authorize_storage_unavailable",
                getattr(request.state, "request_id", None),
                workspace.id,
                type(exc).__name__,
                extra={
                    "request_id": getattr(request.state, "request_id", None),
                    "workspace_id": workspace.id,
                    "requested_model": requested_model_id,
                    "estimated_microdollars": estimate,
                    "candidate_count": len(endpoint_candidates),
                    "key_usage_shards": key_usage_shards,
                    "error_class": type(exc).__name__,
                },
            )
            raise
        except BaseException:
            release_user_model_slot_after_error()
            raise
        window_decision = getattr(outcome, "rate_limit", None)
        remember_spend_window_decision(request, window_decision)
        if (
            outcome == AuthorizeOutcome.IDEMPOTENCY_MISMATCH
            or outcome.startswith(AuthorizeOutcome.KEY_WINDOW_LIMIT_EXCEEDED)
        ) and is_video_request and body.request_fingerprint and request_idempotency_key:
            # Only a rejected video retry pays this indexed read. A window
            # precheck can reject before the atomic idempotency check when the
            # original job consumed its budget. Recover only that exact hold;
            # neither path admitted a new reservation or provider call.
            existing_authorization = _typed_store.get_typed_authorization_by_idempotency(
                workspace.id, api_key.hash, request_idempotency_key,
            )
            if _video_cross_region_replay_matches(
                existing_authorization, workspace.id, api_key.hash,
                fingerprint_body, request_idempotency_key,
            ):
                release_user_model_slot_after_error()
                return _replay_response(existing_authorization, endpoint_candidates)
        if outcome == "billing_paused":
            release_user_model_slot_after_error()
            if settings.speculative_provider_shadow_enabled:
                with speculation_shadow.isolate("reason"):
                    speculation_shadow.reason("billing_paused")
            raise api_error(403, "billing_paused", ErrorType.FORBIDDEN)
        if outcome == AuthorizeOutcome.INSUFFICIENT_CREDITS:
            release_user_model_slot_after_error()
            record_free_credit_exhausted_safely(workspace.id)
            raise _insufficient_credits_error(workspace)
        if outcome.startswith(AuthorizeOutcome.KEY_WINDOW_LIMIT_EXCEEDED):
            release_user_model_slot_after_error()
            if window_decision is None:
                raise RuntimeError("typed window rejection omitted its rate-limit verdict")
            raise api_error(
                429,
                spend_window_limit_error_message(window_decision),
                ErrorType.KEY_WINDOW_LIMIT_EXCEEDED,
                headers=spend_window_headers(window_decision, retry_after=True),
            )
        if outcome in (AuthorizeOutcome.KEY_LIMIT_EXCEEDED, AuthorizeOutcome.KEY_MISSING):
            release_user_model_slot_after_error()
            raise api_error(402, "API key spend limit exceeded", ErrorType.KEY_LIMIT_EXCEEDED)
        if outcome == AuthorizeOutcome.IDEMPOTENCY_MISMATCH:
            release_user_model_slot_after_error()
            raise api_error(
                409,
                "Idempotency key was already used for a different gateway request",
                ErrorType.CONFLICT,
            )
        if authorization is None:
            release_user_model_slot_after_error()
            raise api_error(500, "gateway authorize failed", ErrorType.INTERNAL_ERROR)
        if outcome == AuthorizeOutcome.REPLAY:
            # concurrent-race replay: respond from the STORED authorization.
            # Our provisional slot belongs to the id that lost the race, not
            # to the stored authorization — give it back.
            release_user_model_slot_after_error()
            return _replay_response(authorization, endpoint_candidates)
        credit_reservation_id = authorization.credit_reservation_id
    else:
        from trusted_router.spend_windows import (
            KeyLimitExceeded,
            KeyWindowLimitExceeded,
            remember_spend_window_decision,
            spend_window_headers,
            spend_window_limit_error_message,
        )
        from trusted_router.storage_legacy_trust import BillingPausedError, legacy_pause_epoch

        expected_pause_epoch = (
            legacy_pause_epoch(STORE, workspace.id)
            if settings.spend_lease_trust_eligibility_enabled else None
        )
        try:
            with gateway_phase("store_ms", after="post_commit_ms"):
                key_limit_reservation = STORE.reserve_key_limit(
                    api_key.hash,
                    estimate,
                    usage_type=reservation_usage_type,
                )
            window_decision = key_limit_reservation.window_decision
            remember_spend_window_decision(request, window_decision)
        except KeyWindowLimitExceeded as exc:
            release_user_model_slot_after_error()
            remember_spend_window_decision(request, exc.decision)
            # InMemory twin of the typed window rejection (same 429 shape).
            raise api_error(
                429,
                spend_window_limit_error_message(exc.decision),
                ErrorType.KEY_WINDOW_LIMIT_EXCEEDED,
                headers=spend_window_headers(exc.decision, retry_after=True),
            ) from exc
        except KeyLimitExceeded as exc:
            release_user_model_slot_after_error()
            remember_spend_window_decision(request, exc.decision)
            raise api_error(
                402, "API key spend limit exceeded", ErrorType.KEY_LIMIT_EXCEEDED
            ) from exc
        except ValueError as exc:
            release_user_model_slot_after_error()
            raise api_error(
                402, "API key spend limit exceeded", ErrorType.KEY_LIMIT_EXCEEDED
            ) from exc

        settlement = "local"
        authorization_expires_at = (
            (
                dt.datetime.now(dt.UTC)
                + dt.timedelta(seconds=_authorization_ttl_seconds(body.route_type))
            )
            .isoformat()
            .replace("+00:00", "Z")
            if _is_native_batch_route(body.route_type)
            else None
        )
        if has_credit_candidate:
            try:
                with gateway_phase("store_ms", after="post_commit_ms"):
                    credit_reservation = STORE.reserve(
                        workspace.id,
                        api_key.hash,
                        estimate,
                        idempotency_key=request_idempotency_key,
                        key_reserved_microdollars=key_limit_reservation.reserved_microdollars,
                    )
                credit_reservation_id = credit_reservation.id
            except BillingPausedError as exc:
                release_user_model_slot_after_error()
                if settings.speculative_provider_shadow_enabled:
                    with speculation_shadow.isolate("reason"):
                        speculation_shadow.reason("billing_paused")
                raise api_error(403, "billing_paused", ErrorType.FORBIDDEN) from exc
            except ValueError as exc:
                # The local balance refused. On a peer plane with deferred
                # settlement on, a FEDERATED key falls back to spending on
                # credit at the home plane's ledger rather than 402ing.
                #
                # Local reserve is tried FIRST and this is only the fallback:
                # a workspace that has been explicitly pre-funded by credit
                # transfer must keep spending those transferred credits with
                # local settlement. Reversing the order would strand real
                # money that was deliberately moved here.
                if not _deferred_settlement_applies(settings, api_key):
                    release_user_model_slot_after_error()
                    STORE.refund_key_limit(
                        api_key.hash,
                        key_limit_reservation.reserved_microdollars,
                        usage_type=reservation_usage_type,
                    )
                    raise _insufficient_credits_error(workspace) from exc
                settlement = _DEFERRED_HOME_SETTLEMENT
                authorization_expires_at = _deferred_expires_at(settings)

        create_authorization = functools.partial(
            STORE.create_gateway_authorization,
            workspace_id=workspace.id,
            key_hash=api_key.hash,
            model_id=model.id,
            provider=endpoint.provider,
            usage_type=reservation_usage_type,
            estimated_microdollars=estimate,
            credit_reservation_id=credit_reservation_id,
            key_reserved_microdollars=key_limit_reservation.reserved_microdollars,
            authorization_id=authorization_id,
            requested_model_id=requested_model_id,
            candidate_model_ids=[
                candidate_model.id for candidate_model, _endpoint in endpoint_candidates
            ],
            region=region,
            endpoint_id=endpoint.id,
            candidate_endpoint_ids=[
                candidate_endpoint.id
                for _candidate_model, candidate_endpoint in endpoint_candidates
            ],
            idempotency_key=request_idempotency_key,
            tags=effective_tags,
            idempotency_fingerprint=request_fingerprint,
            app_id=api_key.app_id,
            app_markup_basis_points=app_markup_basis_points,
            receipt_fee_basis_points=receipt_fee_basis_points,
            app_owner_user_id=app_owner_user_id,
            custom_model_id=custom_model.id if custom_model else None,
            custom_model_revision=custom_model.revision if custom_model else None,
            custom_model_markup_basis_points=custom_model_markup_basis_points,
            custom_model_owner_user_id=custom_model_owner_user_id,
            user_provided_model_id=user_model.id if user_model else None,
            user_provided_model_revision=user_model.revision if user_model else None,
            user_model_prompt_price_microdollars_per_m=(
                user_model.prompt_price_microdollars_per_million_tokens if user_model else None
            ),
            user_model_completion_price_microdollars_per_m=(
                user_model.completion_price_microdollars_per_million_tokens if user_model else None
            ),
            user_model_owner_user_id=user_model.owner_user_id if user_model else None,
            additional_cost_reservation_microdollars=additional_cost_reservation,
            native_batch_eligible=native_batch_eligible,
            video_pricing_snapshot=video_snapshot,
            settlement=settlement,
            expires_at=authorization_expires_at,
            # The outstanding increment rides the SAME transaction that
            # inserts the authorization, so an idempotent replay (which
            # returns the pre-existing row and writes nothing) cannot
            # double-count, and a cap refusal cannot leave an authorization
            # behind. Doing it as a separate call could do both.
            deferred_cap_microdollars=(
                settings.federation_deferred_max_outstanding_microdollars
                if settlement == _DEFERRED_HOME_SETTLEMENT
                else None
            ),
            invocation_nonce=body.invocation_nonce,
            expected_pause_epoch=expected_pause_epoch,
            created_at=pricing_effective_at.isoformat().replace("+00:00", "Z"),
        )
        try:
            with gateway_phase("store_ms", after="post_commit_ms"):
                authorization = create_authorization()
        except BillingPausedError as exc:
            release_user_model_slot_after_error()
            if settings.speculative_provider_shadow_enabled:
                with speculation_shadow.isolate("reason"):
                    speculation_shadow.reason("billing_paused")
            raise api_error(403, "billing_paused", ErrorType.FORBIDDEN) from exc
        except DeferredSettlementCapReached as cap_exc:
            release_user_model_slot_after_error()
            # The key-limit escrow taken above must come back: nothing on this
            # plane would ever release it for a request that never became an
            # authorization (the reaper only sees authorizations).
            STORE.refund_key_limit(
                api_key.hash,
                key_limit_reservation.reserved_microdollars,
                usage_type=reservation_usage_type,
            )
            raise api_error(
                402,
                "This plane is holding the maximum unsettled spend for this workspace "
                "while the home plane is unreachable; it will clear as settlements are "
                "delivered.",
                ErrorType.DEFERRED_SETTLEMENT_CAP,
                headers={"Retry-After": "30"},
            ) from cap_exc
        except StoreConflict as conflict_exc:
            release_user_model_slot_after_error()
            # DSQL OCC exhausted its retries (a hot outstanding row under
            # burst load will do this). Same rule as the cap arm: the escrow
            # committed OUTSIDE this transaction, so nothing downstream will
            # ever release it for a request that produced no authorization —
            # swallowing this into a bare 503 leaks it silently, forever.
            STORE.refund_key_limit(
                api_key.hash,
                key_limit_reservation.reserved_microdollars,
                usage_type=reservation_usage_type,
            )
            logger.warning(
                "billing.authorize_conflict_after_escrow workspace_id=%s request_id=%s "
                "requested_model=%s estimated_microdollars=%s error_class=%s",
                workspace.id,
                getattr(request.state, "request_id", None),
                _log_value(requested_model_id),
                estimate,
                type(conflict_exc).__name__,
            )
            raise api_error(
                503,
                "Authorization contention; retry shortly.",
                ErrorType.SERVICE_UNAVAILABLE,
                headers={"Retry-After": "1"},
            ) from conflict_exc
        except BaseException:
            release_user_model_slot_after_error()
            raise
    byok_config = (
        _get_byok_provider(workspace.id, endpoint.provider, byok_configs) if model_usage_type.is_byok() else None
    )
    return _gateway_authorize_response(
        authorization=authorization,
        workspace_id=workspace.id,
        key_hash=api_key.hash,
        model=model,
        endpoint=endpoint,
        requested_model_id=requested_model_id,
        model_usage_type=model_usage_type,
        limit_usage_type=reservation_usage_type,
        estimate=estimate,
        credit_reservation_id=credit_reservation_id,
        byok_config=byok_config,
        byok_configs=byok_configs,
        region=region,
        settings=settings,
        broadcast_destinations=broadcast_destinations,
        endpoint_candidates=endpoint_candidates,
        idempotent_replay=idempotent_replay,
        custom_model=custom_model,
        stage_d_reason_override=stage_d_reason,
        async_request=request, async_body=body,
        async_federated=bool(workspace.federated_home or api_key.federated_home),
        async_effective_at=pricing_effective_at,
    )


def _gateway_validate_sync(
    request: Request,
    body: GatewayValidateRequest,
    settings: Settings,
) -> dict[str, Any]:
    require_internal_gateway(request, settings)
    api_key = _api_key_for_gateway_lookup(
        api_key_hash=body.api_key_hash,
        api_key_lookup_hash=body.api_key_lookup_hash,
    )
    if api_key is None or api_key.disabled or is_api_key_expired(api_key.expires_at):
        raise api_error(401, "Invalid API key", ErrorType.INVALID_API_KEY)
    _assert_gateway_key_scope(api_key)
    workspace = STORE.get_workspace(api_key.workspace_id)
    if workspace is None:
        raise api_error(403, "Workspace is unavailable", ErrorType.FORBIDDEN)
    assert_workspace_billing_active(workspace)
    from trusted_router.services.gateway_contract_warnings import report_gateway_contract_rejection

    report_gateway_contract_rejection(
        body.contract_rejection,
        route=body.route_type,
        workspace_id=workspace.id,
        credential_id=api_key.hash,
    )
    return {
        "data": {
            "workspace_id": workspace.id,
            "api_key_hash": api_key.hash,
            "route_type": body.route_type,
        }
    }


def _gateway_key_info_sync(
    request: Request,
    body: GatewayValidateRequest,
    settings: Settings,
) -> dict[str, Any]:
    """Key self-introspection for the enclave: the /v1/key passthrough.

    The enclave NEVER forwards the raw bearer to the control plane (the
    attested contract; authorize sends a lookup hash) — so agent budget
    reads come through here keyed by the same lookup hash + internal
    token. Deliberately no billing-pause gate: reading your own limits
    while paused is a harmless, useful read."""
    require_internal_gateway(request, settings)
    api_key = _api_key_for_gateway_lookup(
        api_key_hash=body.api_key_hash,
        api_key_lookup_hash=body.api_key_lookup_hash,
    )
    if api_key is None or api_key.disabled or is_api_key_expired(api_key.expires_at):
        raise api_error(401, "Invalid API key", ErrorType.INVALID_API_KEY)
    _assert_gateway_key_scope(api_key)
    from trusted_router.routes.keys import self_key_shape

    return {"data": self_key_shape(api_key)}


def _gateway_resolve_custom_model_sync(
    request: Request,
    body: GatewayResolveCustomModelRequest,
    settings: Settings,
) -> dict[str, Any]:
    require_internal_gateway(request, settings)
    api_key = _api_key_for_gateway_lookup(
        api_key_hash=body.api_key_hash,
        api_key_lookup_hash=body.api_key_lookup_hash,
    )
    if api_key is None or api_key.disabled or is_api_key_expired(api_key.expires_at):
        raise api_error(401, "Invalid API key", ErrorType.INVALID_API_KEY)
    _assert_gateway_key_scope(api_key)
    workspace = STORE.get_workspace(api_key.workspace_id)
    if workspace is None:
        raise api_error(403, "Workspace is unavailable", ErrorType.FORBIDDEN)
    assert_workspace_billing_active(workspace)
    if not is_creator_model_id(body.model):
        raise api_error(400, "Model is not a custom model", ErrorType.BAD_REQUEST)
    if is_user_provided_model_id(body.model):
        normalized = normalize_user_provided_model_id(body.model)
        user_model = STORE.get_user_model(normalized)
        if (
            user_model is None
            or not user_model.enabled
            or user_model.status != "active"
            or not settings.user_models_dispatch_enabled
        ):
            raise api_error(404, "Custom model not found", ErrorType.NOT_FOUND)
        budget = dispatch_budget(user_model.kind)
        return {
            "data": {
                "workspace_id": workspace.id,
                "api_key_hash": api_key.hash,
                "route_type": body.route_type,
                "custom_model": {
                    "id": user_model.id,
                    "name": user_model.name,
                    "kind": "user_provided",
                    "user_model_kind": user_model.kind,
                    # The envelopes below are bound (AAD) to the OWNER's
                    # workspace, a per-secret purpose, and the user_model
                    # namespace — not to the caller's workspace above; the
                    # enclave must decrypt with exactly these.
                    "secret_namespace": USER_MODEL_SECRET_NAMESPACE,
                    "owner_workspace_id": user_model.owner_workspace_id,
                    "owner_user_id": user_model.owner_user_id,
                    "endpoint_url": user_model.endpoint_url,
                    "upstream_model_id": user_model.upstream_model_id,
                    "revision": user_model.revision,
                    "supports_streaming": user_model.supports_streaming,
                    "endpoint_encrypted_secret": encrypted_secret_payload(
                        user_model.encrypted_endpoint_api_key
                    ),
                    "endpoint_secret_purpose": USER_MODEL_ENDPOINT_KEY_PURPOSE,
                    "signing_encrypted_secret": encrypted_secret_payload(
                        user_model.encrypted_signing_secret
                    ),
                    "signing_secret_purpose": USER_MODEL_SIGNING_PURPOSE,
                    "connect_timeout_seconds": budget.connect,
                    "first_byte_timeout_seconds": budget.first_byte,
                    "idle_timeout_seconds": budget.idle,
                    "total_timeout_seconds": budget.total,
                },
            }
        }
    else:
        normalized = normalize_custom_model_id(body.model)
        custom_model = STORE.get_custom_model(normalized)
    if custom_model is None or not custom_model.enabled:
        raise api_error(404, "Custom model not found", ErrorType.NOT_FOUND)
    return {
        "data": {
            "workspace_id": workspace.id,
            "api_key_hash": api_key.hash,
            "route_type": body.route_type,
            "custom_model": {
                "id": custom_model.id,
                "name": custom_model.name,
                "kind": "prompt_wrapper",
                "base_model_id": custom_model.base_model_id,
                "hidden_prompt": custom_model.hidden_prompt,
                "revision": custom_model.revision,
            },
        }
    }


def register(router: APIRouter) -> None:
    # Every handler below does synchronous storage IO. They run it via
    # run_in_threadpool so a slow/contended transaction on one request never
    # blocks the shared event loop for all others.
    #
    # These share AnyIO's default worker pool (40 tokens) with FastAPI's other
    # sync dependencies — deliberately, NOT a dedicated CapacityLimiter. Cloud
    # Run defaults to concurrency 8 (scripts/deploy/_lib.sh; also explicitly
    # set in scripts/deploy/internal_surface.sh), so at most ~8 request
    # offloads are ever in flight per instance (far under 40); load scales out
    # across instances, not up per-instance, and prod inference never touches
    # this service (it goes through the enclave). Give gateway storage its own
    # limiter only if TR_CLOUD_RUN_CONCURRENCY is raised toward the pool size.
    # Optional post-reply mirrors use their own bounded executor because
    # completed replies no longer consume Cloud Run request slots.
    @router.post("/internal/gateway/validate")
    async def gateway_validate(
        request: Request,
        body: GatewayValidateRequest,
        settings: SettingsDep,
    ) -> dict[str, Any]:
        return await run_in_threadpool(_gateway_validate_sync, request, body, settings)

    @router.post("/internal/gateway/key")
    async def gateway_key_info(
        request: Request,
        body: GatewayValidateRequest,
        settings: SettingsDep,
    ) -> dict[str, Any]:
        return await run_in_threadpool(_gateway_key_info_sync, request, body, settings)

    @router.post("/internal/gateway/resolve-custom-model")
    async def gateway_resolve_custom_model(
        request: Request,
        body: GatewayResolveCustomModelRequest,
        settings: SettingsDep,
    ) -> dict[str, Any]:
        return await run_in_threadpool(_gateway_resolve_custom_model_sync, request, body, settings)

    @router.post("/internal/gateway/authorize", responses={200: {"model": GatewayAuthorizeResponse}})
    async def gateway_authorize(
        request: Request,
        body: GatewayAuthorizeRequest,
        settings: SettingsDep,
    ) -> dict[str, Any]:
        return await authorize_gateway(request, body, settings)

    @router.post("/internal/gateway/heartbeat")
    async def gateway_heartbeat(
        request: Request,
        body: GatewayHeartbeatRequest,
        settings: SettingsDep,
    ) -> dict[str, Any]:
        return await heartbeat_gateway(request, body, settings)

    @router.get("/internal/gateway/authorizations/{authorization_id}/disposition")
    async def gateway_disposition(
        request: Request,
        authorization_id: str,
        settings: SettingsDep,
    ) -> dict[str, Any]:
        return await gateway_authorization_disposition(
            request,
            authorization_id,
            settings,
        )

    @router.get(
        "/internal/gateway/authorizations/by-gateway-request-id/{gateway_request_id}"
    )
    async def gateway_evidence_lookup(
        request: Request,
        gateway_request_id: str,
        settings: SettingsDep,
    ) -> JSONResponse:
        return await gateway_authorization_by_gateway_request_id(
            request,
            gateway_request_id,
            settings,
        )

    @router.post("/internal/gateway/spend-lease/register-boot")
    async def gateway_boot_register(
        request: Request,
        body: GatewayBootRegistrationRequest,
        settings: SettingsDep,
    ) -> dict[str, Any]:
        return await run_in_threadpool(
            _register_gateway_boot_sync,
            request,
            body,
            settings,
        )

    from trusted_router.routes.settlements import AsyncSettlementRoute

    legacy_route_class = router.route_class
    router.route_class = AsyncSettlementRoute

    @router.post("/internal/gateway/settle", responses={200: {"model": GatewaySettleResponse}})
    async def gateway_settle(
        request: Request,
        body: GatewaySettleRequest,
        settings: SettingsDep,
        background_tasks: BackgroundTasks,
    ) -> dict[str, Any]:
        return await settle_gateway(request, body, settings, background_tasks)

    @router.post("/internal/gateway/refund")
    async def gateway_refund(
        request: Request,
        body: GatewaySettleRequest,
        settings: SettingsDep,
        background_tasks: BackgroundTasks,
    ) -> dict[str, Any]:
        require_internal_gateway(request, settings)
        return await run_in_threadpool(
            _settle_gateway_authorization,
            body,
            success=False,
            settings=settings,
            background_tasks=background_tasks,
        )

    router.route_class = legacy_route_class

    @router.post("/internal/gateway/settle-outbox/drain")
    async def gateway_settle_outbox_drain(
        request: Request,
        settings: SettingsDep,
        limit: int = 100,
    ) -> dict[str, Any]:
        require_internal_gateway(request, settings)
        result = await run_in_threadpool(
            drain_settle_outbox,
            limit,
            reap_snapshot_booking_enabled=settings.reap_snapshot_booking_enabled,
            **({"settings": settings} if settings.settle_outbox_fast_drain_enabled else {}),
        )
        # Cloud Scheduler drives this on a cadence; the heartbeat makes that
        # cadence visible on /fleet so a silently-dead scheduler is seen.
        await run_in_threadpool(record_heartbeat, "job:settle-outbox-drain", settings=settings)
        return result

    @router.post("/internal/gateway/receipt-keys/collect")
    async def gateway_receipt_keys_collect(
        request: Request,
        settings: SettingsDep,
    ) -> dict[str, int]:
        """Cloud Scheduler pass for the append-only receipt-key log."""

        require_internal_gateway(request, settings)
        result = await run_in_threadpool(collect_receipt_keys, settings)
        if int(result.get("errors", 0)):
            logger.error(
                "receipt_key.collection_incomplete",
                extra={key: int(value) for key, value in result.items()},
            )
            raise api_error(
                503,
                "Receipt-key collection is incomplete",
                ErrorType.SERVICE_UNAVAILABLE,
            )
        await run_in_threadpool(
            record_heartbeat,
            "job:receipt-key-collector",
            settings=settings,
        )
        return result

    @router.post("/internal/gateway/home-settlement/drain")
    async def gateway_home_settlement_drain(
        request: Request,
        settings: SettingsDep,
        limit: int = 50,
    ) -> dict[str, Any]:
        """Run one forwarding pass of recorded debt to the home plane.

        The in-process scheduler drives this on its own; the endpoint is the
        operator's lever for "drain it NOW" (after a home outage clears) and
        the observability surface (the returned counts are the backlog
        story: forwarded / dead_lettered / clamped / outage).
        """
        require_internal_gateway(request, settings)
        from trusted_router.services.home_settlement import drain_home_settlements

        return {
            "data": await run_in_threadpool(lambda: drain_home_settlements(settings, limit=limit))
        }

    @router.post("/internal/gateway/deferred/reap")
    async def gateway_deferred_reap(
        request: Request,
        settings: SettingsDep,
        limit: int = 100,
    ) -> dict[str, Any]:
        """Reclaim deferred authorizations whose settle never arrived.

        A reaper that exists but is never run is the same as no reaper: each
        abandoned authorization (the enclave dying between authorize and
        settle — every deploy) leaks its estimate into the outstanding
        counter until the workspace hits the cap and 402s forever. This
        endpoint is the operator's lever today and the scheduler's target
        when the forwarder increment wires periodic passes.
        """
        require_internal_gateway(request, settings)
        reap = getattr(STORE, "reap_expired_deferred_authorizations", None)
        if reap is None:
            raise api_error(
                501,
                "This plane's store has no deferred-settlement reaper",
                ErrorType.ENDPOINT_NOT_SUPPORTED,
            )
        return {"data": await run_in_threadpool(lambda: reap(limit=limit))}


def _gateway_authorize_metadata(
    body: GatewayAuthorizeRequest, *, boot_kid: str | None = None,
) -> tuple[Any, Any, dict[str, Any] | None, Any]:
    # Hash-based callers retain their existing precedence/fallback semantics.
    # Enclaves send lookup hashes; Spanner can hydrate that entire chain at once.
    resolve = getattr(STORE, "gateway_api_key_auth_context", None)
    if not body.api_key_hash and body.api_key_lookup_hash and callable(resolve):
        context = resolve(body.api_key_lookup_hash, boot_kid=boot_kid)
        api_key = context.api_key if context is not None else None
        if api_key is not None and not getattr(api_key, "federated_home", ""):
            return api_key, context, context.byok_rows, context
        # Home revalidation may replace the key AND the shadow workspace.
        # Read the workspace after that refresh, exactly as the old path did.
        api_key = _federated_key_still_valid(api_key, body.api_key_lookup_hash)
        if context is not None and api_key is not None and api_key.workspace_id == context.api_key.workspace_id:
            # Federation can refresh workspace billing state, but credentials
            # remain local. Reuse them only for the same canonical workspace.
            return api_key, None, context.byok_rows, context
        # The boot row is independent of any refreshed workspace mapping.
        return api_key, None, None, context
    else:
        api_key = _api_key_for_gateway_authorization(body)
    return api_key, None, None, None


def _api_key_for_gateway_authorization(body: GatewayAuthorizeRequest) -> Any | None:
    return _api_key_for_gateway_lookup(
        api_key_hash=body.api_key_hash,
        api_key_lookup_hash=body.api_key_lookup_hash,
    )


def _gateway_idempotency_key(request: Request, body: GatewayAuthorizeRequest) -> str | None:
    raw = body.idempotency_key or request.headers.get("idempotency-key")
    if raw is None:
        return None
    key = raw.strip()
    if not key:
        return None
    if len(key) > 256:
        raise api_error(400, "idempotency-key is too long", ErrorType.BAD_REQUEST)
    return key


def _video_allowed_providers_header(
    request: Request, route_type: str | None, *, validate_catalog: bool = True,
) -> frozenset[str] | None:
    """Parse enclave-derived execution constraints without changing request identity."""
    values = request.headers.getlist("X-Quill-Video-Allowed-Providers")
    if not values:
        return None
    if route_type != "videos" or len(values) != 1 or len(values[0]) > 4096:
        raise api_error(400, "Invalid X-Quill-Video-Allowed-Providers header", ErrorType.BAD_REQUEST)
    providers = [value.strip(" \t") for value in values[0].split(",")]
    if (
        not 1 <= len(providers) <= 64
        or len(set(providers)) != len(providers)
        or any(re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", provider) is None
               or (validate_catalog and provider not in PROVIDERS) for provider in providers)
    ):
        raise api_error(400, "Invalid X-Quill-Video-Allowed-Providers header", ErrorType.BAD_REQUEST)
    return frozenset(providers)


def _gateway_authorize_body(body: GatewayAuthorizeRequest) -> tuple[dict[str, Any], Any]:
    """Canonical request metadata shared by authorization and replay lookup."""
    body_dict = body.model_dump(exclude_none=True)
    # The invocation nonce distinguishes enclave invocations, not logical
    # idempotency. A fresh invocation with the same public idempotency key must
    # replay the original nonce rather than mismatch the stored fingerprint.
    body_dict.pop("invocation_nonce", None)
    # Preserve pre-web-search idempotency fingerprints byte-for-byte for every
    # ordinary request. A nonzero hosted-tool reservation remains fingerprinted.
    if not body.additional_cost_reservation_microdollars:
        body_dict.pop("additional_cost_reservation_microdollars", None)
    if not body.inference_receipt:
        # Keep pre-receipt idempotency fingerprints stable for ordinary calls.
        body_dict.pop("inference_receipt", None)
    try:
        if body.tags is not None:
            body_dict["tags"] = validate_tags(body.tags)
        else:
            body_dict.pop("tags", None)
    except InvalidTags as exc:
        raise api_error(400, str(exc), ErrorType.INVALID_TAGS) from exc
    try:
        attribution = validate_request_attribution(
            user=body.user,
            session_id=body.session_id,
            trace=body.trace,
            app=body.app,
            http_referer=body.http_referer,
            app_categories=body.app_categories,
        )
    except InvalidAttribution as exc:
        raise api_error(400, str(exc), ErrorType.INVALID_REQUEST_METADATA) from exc
    for key in ("user", "session_id", "trace", "app", "http_referer", "app_categories"):
        body_dict.pop(key, None)
    body_dict.update(attribution.body_fields())
    return body_dict, attribution


def _gateway_authorize_fingerprint(
    *,
    workspace_id: str,
    key_hash: str,
    body: dict[str, Any],
    idempotency_key: str | None = None,
    legacy_video: bool = False,
) -> str:
    # Standard idempotency semantics: the key can replay the same logical
    # request, but a caller cannot reuse it for a different request body.
    # Keep dynamic catalog/routing output out of this fingerprint so a replay
    # across a deploy can still recover the original authorization record.
    material = {
        key: value
        for key, value in body.items()
        if key
        not in {
            "api_key_hash",
            "api_key_lookup_hash",
            "idempotency_key",
            "spend_lease_admission",
        }
    }
    if body.get("route_type") == "videos" and not legacy_video:
        # The enclave HMAC binds the logical request. These values describe
        # execution and can change when eligible providers change on rollout.
        for dynamic_key in (
            "video_resolution", "max_tokens", "max_output_tokens", "max_completion_tokens",
            "additional_cost_reservation_microdollars", "region",
        ):
            material.pop(dynamic_key, None)
    if _is_native_batch_idempotency_key(idempotency_key):
        # One encrypted Batch object is claimed across regions and rolling
        # enclave revisions. These fields are gateway estimates or execution
        # locality, not customer request identity. Keeping them in the hash can
        # turn a lost authorize response into an unrecoverable cross-region 409
        # and leave its hold live until TTL.
        for dynamic_key in {"region", "estimated_input_tokens", "max_output_tokens"}:
            material.pop(dynamic_key, None)
    material["workspace_id"] = workspace_id
    material["key_hash"] = key_hash
    encoded = json.dumps(material, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _video_cross_region_replay_matches(
    authorization: Any,
    workspace_id: str,
    key_hash: str,
    body: dict[str, Any],
    idempotency_key: str | None,
) -> bool:
    """Recover a video's original hold without changing persisted fingerprints.

    Video content/options are HMAC-bound by the enclave. Execution region,
    resolution, token limits and quotes may change; caller policy stays bound.
    Legacy hashes are checked exactly against reconstructed execution values,
    never accepted merely because the stored model or caller scope matches.
    """
    if (
        authorization is None
        or body.get("route_type") != "videos"
        or not body.get("request_fingerprint")
        or not idempotency_key
        or authorization.workspace_id != workspace_id
        or authorization.key_hash != key_hash
        or authorization.idempotency_key != idempotency_key
    ):
        return False
    def matches(candidate: dict[str, Any], *, legacy: bool = False) -> bool:
        return authorization.idempotency_fingerprint == _gateway_authorize_fingerprint(
            workspace_id=workspace_id, key_hash=key_hash,
            body=candidate, idempotency_key=idempotency_key, legacy_video=legacy,
        )

    original = {**body, "region": authorization.region}
    omitted_region = dict(body)
    omitted_region.pop("region", None)
    originals = (body, original, omitted_region)
    if any(matches(candidate) or matches(candidate, legacy=True) for candidate in originals):
        return True

    snapshot = getattr(authorization, "video_pricing_snapshot", None)
    try:
        frozen = json.loads(snapshot) if snapshot else {}
        # Before token billing, enclaves sent the fixed-price sentinel 1.
        limit = frozen.get("output_token_limit", 1)
        resolution = frozen.get("video_tariff_resolution")
    except (TypeError, ValueError, AttributeError):
        return False
    if type(limit) is not int or limit < 1 or resolution not in {None, "480p", "720p", "1080p"}:
        return False
    token_fields = ("max_tokens", "max_output_tokens", "max_completion_tokens")
    # Old enclaves used one or multiple aliases with the same effective limit.
    # Try absent/frozen/current values per alias to also preserve unchanged
    # redundant aliases. This bounded comparison covers main and the earlier
    # resolution-excluding hash without storing or rewriting request content.
    choices = [tuple(dict.fromkeys((None, limit, body.get(field)))) for field in token_fields]
    for candidate in originals:
        for values in product(*choices):
            legacy_body = {k: v for k, v in candidate.items() if k not in token_fields}
            legacy_body.pop("additional_cost_reservation_microdollars", None)
            legacy_body.update({k: v for k, v in zip(token_fields, values, strict=True) if v is not None})
            for old_resolution in (None, resolution):
                legacy_body.pop("video_resolution", None)
                if old_resolution is not None:
                    legacy_body["video_resolution"] = old_resolution
                if matches(legacy_body, legacy=True):
                    return True
    return False


def _new_gateway_authorization_id() -> str:
    """One fresh authorization id (same shape the typed store mints)."""
    return f"gwa-{uuid.uuid4().hex}"


def _authorization_endpoint_candidates(
    authorization: Any,
    fallback: list[tuple[Model, ModelEndpoint]],
    *,
    privacy_requirements: frozenset[int] = frozenset(),
    video_replay: bool = False,
) -> list[tuple[Model, ModelEndpoint]]:
    user_model_pair = _authorized_user_model_pair(authorization)
    if user_model_pair is not None:
        return [user_model_pair]
    candidates: list[tuple[Model, ModelEndpoint]] = []
    endpoint_ids = authorization.candidate_endpoint_ids or []
    if not endpoint_ids and authorization.endpoint_id:
        endpoint_ids = [authorization.endpoint_id]
    privacy_excluded = False
    for endpoint_id in endpoint_ids:
        endpoint = _endpoint_for_id_compat(endpoint_id)
        if video_replay:
            # Recovery grants no dispatch authority. A catalog removal or
            # changed privacy posture cannot hide the stored job/hold. Rebuild
            # identifiers from the frozen route ID when its catalog row is gone;
            # no current candidate or tariff may be substituted for that route.
            if endpoint is None:
                model_id, _, provider_usage = endpoint_id.rpartition("@")
                provider, _, usage = provider_usage.partition("/")
                endpoint = ModelEndpoint(
                    id=endpoint_id, model_id=model_id, provider=provider,
                    usage_type="BYOK" if usage == "byok" else "Credits",
                )
            replay_model = MODELS.get(endpoint.model_id) or Model(
                id=endpoint.model_id, name=endpoint.model_id,
                provider=endpoint.provider, context_length=0, supports_video=True,
            )
            candidates.append((replay_model, endpoint))
            continue
        if endpoint is None:
            continue
        # A replay never restores a route the request's privacy floor now
        # excludes.
        if not all(
            endpoint_meets_privacy_requirement(endpoint, requirement)
            for requirement in privacy_requirements
        ):
            privacy_excluded = True
            continue
        model = MODELS.get(endpoint.model_id)
        if model is None:
            continue
        candidates.append((model, endpoint))
    if not candidates and privacy_excluded:
        # Settlement and refund accept only routes this authorization holds,
        # so it cannot hand out the freshly filtered ones.
        raise api_error(
            409,
            "This authorization's routes no longer meet the requested privacy floor; "
            "retry with a new idempotency key",
            ErrorType.BAD_REQUEST,
        )
    return candidates or fallback


def _broadcast_destinations_for_authorize(workspace_id: str) -> list[Any]:
    """Skip the destination-index RPC briefly after an observed empty result."""
    now = time.monotonic()
    with _BROADCAST_EMPTY_CACHE_LOCK:
        expires_at = _BROADCAST_EMPTY_CACHE.get(workspace_id)
        if expires_at is not None:
            if now < expires_at:
                _BROADCAST_EMPTY_CACHE.move_to_end(workspace_id)
                return []
            del _BROADCAST_EMPTY_CACHE[workspace_id]

    destinations = STORE.list_broadcast_destinations(workspace_id)
    with _BROADCAST_EMPTY_CACHE_LOCK:
        if destinations:
            # Positive results are deliberately uncached: destination changes
            # must take effect on the next authorize. A newly-created first
            # destination can be hidden only by a previously cached empty result,
            # delaying response metadata and native-batch eligibility by at most
            # this cache's 60-second TTL.
            _BROADCAST_EMPTY_CACHE.pop(workspace_id, None)
        else:
            _BROADCAST_EMPTY_CACHE[workspace_id] = now + _BROADCAST_EMPTY_CACHE_TTL_SECONDS
            _BROADCAST_EMPTY_CACHE.move_to_end(workspace_id)
            while len(_BROADCAST_EMPTY_CACHE) > _BROADCAST_EMPTY_CACHE_MAX_ENTRIES:
                _BROADCAST_EMPTY_CACHE.popitem(last=False)
    return destinations


def _gateway_authorize_response(
    *,
    authorization: Any,
    workspace_id: str,
    key_hash: str,
    model: Model,
    endpoint: ModelEndpoint,
    requested_model_id: str,
    model_usage_type: UsageType,
    limit_usage_type: UsageType,
    estimate: int,
    credit_reservation_id: str | None,
    byok_config: Any | None,
    byok_configs: dict[str, Any] | None = None,
    region: str,
    settings: Settings,
    broadcast_destinations: list[dict[str, Any]],
    endpoint_candidates: list[tuple[Model, ModelEndpoint]],
    idempotent_replay: bool,
    custom_model: Any | None,
    stage_d_reason_override: str | None = None,
    async_request: Request | None = None,
    async_body: GatewayAuthorizeRequest | None = None,
    async_federated: bool = False,
    async_effective_at: dt.datetime | None = None,
) -> dict[str, Any]:
    """Compose the authorization response with a prospective generation identity.

    data.generation_id is recorded when the authorization reaches settled or
    reaped_snapshot (Stage D heartbeat snapshot booking). It is never recorded
    for refunded authorizations, including refunding reaps, even though an
    authorize replay returns the same prospective ID. Consumers must check the
    terminal authorization disposition before expecting a generation.
    """
    if settings.speculative_provider_shadow_enabled:
        from trusted_router.services import speculation_shadow
        with speculation_shadow.isolate("authorized"):
            speculation_shadow.authorized(authorization, tuple(candidate.id for _, candidate in endpoint_candidates[:16]), idempotent_replay,
                                          (endpoint.id, endpoint.provider, endpoint.upstream_id or model.id, region))
    stage_d = _gateway_stage_d_payload(
        authorization,
        reason_override=stage_d_reason_override,
    )
    response_model = (
        requested_model_id if requested_model_id in PRIVATE_PROXY_MODEL_TARGETS else None
    )
    upstream_model = endpoint.upstream_id or model.id
    provider_payload = _gateway_provider_route_payload(endpoint)
    video_resolution = (
        parse_pricing_snapshot(authorization.video_pricing_snapshot).get("video_tariff_resolution")
        if authorization.video_pricing_snapshot else None
    )
    async_additions: dict[str, Any] = {}
    if async_request is not None and async_request.headers.getlist("X-TR-Settlement-Mode") == ["async-v1"]:
        from trusted_router.services.async_settle import authorize_additions
        async_store = typed_billing_store(STORE)
        async_additions = authorize_additions(
            request=async_request, body=async_body, authorization=authorization,
            endpoints=[e for _, e in endpoint_candidates], settings=settings,
            typed=async_store is not None and getattr(async_store, "request_record_write_mode", "legacy") == "typed",
            federated=async_federated, replay=idempotent_replay, effective_at=async_effective_at,
        )
    return {
        "data": {
            "authorization_id": authorization.id,
            "generation_id": generation_id_for_authorization(authorization.id),
            "workspace_id": workspace_id,
            "api_key_hash": key_hash,
            "model": model.id,
            "upstream_model": upstream_model,
            "endpoint_id": endpoint.id,
            "provider": endpoint.provider,
            "provider_name": (PROVIDERS[endpoint.provider].name if endpoint.provider in PROVIDERS else endpoint.provider),
            "inference_location": inference_location_metadata(endpoint.provider, model.id),
            **provider_payload,
            "requested_model": requested_model_id,
            "response_model": response_model,
            "hide_public_metadata": response_model is not None,
            "usage_type": model_usage_type.value,
            "limit_usage_type": limit_usage_type.value,
            **money_pair("estimated_cost", estimate),
            "credit_reservation_id": credit_reservation_id,
            **_gateway_byok_payload(byok_config, workspace_id),
            "content_storage_enabled": False,
            "region": region,
            "regions": region_payload(settings),
            "broadcast_destinations": broadcast_destinations,
            "idempotent_replay": idempotent_replay,
            **(
                {"invocation_nonce": authorization.invocation_nonce}
                if idempotent_replay
                else {}
            ),
            "additional_cost_reservation_microdollars": (
                authorization.additional_cost_reservation_microdollars
            ),
            "receipt_fee_basis_points": authorization.receipt_fee_basis_points,
            # Eligible requests bill the served endpoint's authorization-time
            # snapshot, including on retries after a catalog refresh.
            "candidate_cost_reporting": billing_pricing_snapshot(authorization) is not None,
            "request_metadata_version": REQUEST_METADATA_VERSION,
            "native_batch_eligible": authorization.native_batch_eligible,
            **({"video_token_billing": True} if authorization.video_pricing_snapshot else {}),
            **({"video_tariff_resolution": video_resolution} if video_resolution is not None else {}),
            **stage_d,
            **async_additions,
            "tags": dict(authorization.tags),
            "custom_model": None
            if custom_model is None
            else {
                "id": custom_model.id,
                "name": custom_model.name,
                "base_model_id": custom_model.base_model_id,
                "hidden_prompt": custom_model.hidden_prompt,
                "revision": custom_model.revision,
            },
            "route_candidates": [
                _gateway_candidate_payload(
                    candidate_model,
                    candidate_endpoint,
                    workspace_id,
                    region,
                    byok_configs=byok_configs,
                )
                for candidate_model, candidate_endpoint in endpoint_candidates
            ],
        }
    }


def _stage_d_eligibility_reason(
    *,
    eligibility_enabled: bool = False,
    workspace_id: str = "",
    pilot_workspace_ids: frozenset[str] = frozenset(),
    heartbeat_enabled: bool = True,
    boot_accepted: bool = False,
    heartbeat_declared: bool = False,
    require_heartbeat_declaration: bool = False,
    stream: bool | None,
    route_type: str | None,
    endpoint_candidates: list[tuple[Model, ModelEndpoint]],
    standard_endpoint_pricing: bool,
    service_tier: str | None,
    settlement_backend: bool,
) -> str:
    # Emergency kill (2026-09-03): with eligibility off no request is declared in
    # the Stage D cohort, so the enclave never sends a heartbeat and streaming
    # takes the synchronous path exactly as before Stage D.
    if not eligibility_enabled:
        return "stage_d_disabled"
    if pilot_workspace_ids and workspace_id not in pilot_workspace_ids:
        return "workspace_not_pilot"
    if not heartbeat_enabled:
        return "heartbeats_disabled"
    if not boot_accepted:
        return "boot_not_accepted"
    if require_heartbeat_declaration and not heartbeat_declared:
        # A verified boot does not prove the enclave heartbeats: one that
        # registered without heartbeats on would relay this stream with none.
        return "heartbeat_undeclared"
    if stream is not True:
        return "not_streaming"
    if route_type not in {"chat.completions", "responses"}:
        return "route"
    if not all(
        UsageType.for_endpoint(candidate_endpoint) == UsageType.CREDITS
        for _candidate_model, candidate_endpoint in endpoint_candidates
    ):
        return "mixed_usage_type"
    if not standard_endpoint_pricing:
        return "pricing_kind"
    if service_tier in {"priority", "auto"}:
        return "service_tier"
    if not settlement_backend:
        return "settlement_backend"
    return "ok"


def _gateway_stage_d_payload(
    authorization: GatewayAuthorization,
    *,
    reason_override: str | None = None,
) -> dict[str, Any]:
    if reason_override is not None and reason_override != "ok":
        return {"stage_d": {"eligible": False, "reason": reason_override}}
    snapshot = authorization.pricing_snapshot
    reason = reason_override or authorization.stage_d_reason or "settlement_backend"
    if snapshot is None:
        return {"stage_d": {"eligible": False, "reason": reason}}
    document = parse_pricing_snapshot(snapshot)
    cap_micro = int(authorization.estimated_microdollars)
    return {
        "stage_d": {"eligible": True, "reason": "ok"},
        "candidate_prices": document["candidates"],
        "cap_micro": cap_micro,
    }


#: GatewayAuthorization.settlement value for spend booked as debt to the home
#: plane's ledger. Mirrors storage_postgres._DEFERRED_HOME_SETTLEMENT; the
#: value is written by this module and read by the store, so it is declared in
#: both rather than importing a backend-specific module into the route.
_DEFERRED_HOME_SETTLEMENT = "deferred_home"
#: Settlement kinds written by the regional-quota and spend-lease pilots
#: (removed 2026-09). Their escrow lived in a ledger that no longer exists, so
#: no live settlement can book them; the reaper releases no counters for their
#: "RegionalCredits" holds. Every such reservation had expired before this
#: code shipped, so the refusal below is a tripwire, not a path.
_RETIRED_SETTLEMENTS = frozenset({"regional_lease", "spend_lease"})


def _deferred_settlement_applies(settings: Settings, api_key: Any) -> bool:
    """Whether this request may spend on credit at the home plane's ledger.

    Two conditions, both required. The plane must have deferred settlement
    switched on, and the key must be FEDERATED — a locally issued key whose
    balance lives here is simply out of money, and letting it run up debt at
    a home plane that has no account for it would be nonsense.
    """
    if not getattr(settings, "federation_deferred_settlement_enabled", False):
        return False
    return bool(getattr(api_key, "federated_home", ""))


def _deferred_expires_at(settings: Settings) -> str:
    """When the reaper may reclaim this authorization's admitted estimate.

    Without an expiry there is no reclaim, and an enclave that dies between
    authorize and settle — which every deploy causes — leaks its estimate into
    the outstanding counter permanently.
    """
    from trusted_router.spend_windows import utcnow

    ttl = int(getattr(settings, "federation_deferred_authorization_ttl_seconds", 7200))
    expires = utcnow() + dt.timedelta(seconds=max(60, ttl))
    return expires.isoformat().replace("+00:00", "Z")


def _insufficient_credits_error(workspace: Any) -> Exception:
    """402, but say WHICH plane the money is on when that is the real answer.

    A federated workspace is a SHADOW of one on the home plane, and credits
    never federate — they seed at zero here and only an explicit transfer moves
    them (trusted_router.credit_transfer). So a bare "Insufficient credits"
    would be actively misleading: it tells a customer who has a healthy balance
    on the home plane to go top up, and it tells an operator nothing about the
    actual fix, which is to run a transfer.

    Deliberately NOT auto-transferring on demand. Three reasons, any one of
    which is disqualifying:

      * A leaked key would become a drain on the whole workspace balance, not
        just this plane's. Auto-transfer turns "spend up to the key's limit
        here" into "pull the home balance across a jurisdiction boundary and
        then spend it", and it re-arms itself on every subsequent request.
      * It reintroduces the coupling federation exists to remove: the first
        request on a cold key would block on a synchronous home-plane call
        that MOVES MONEY. If the home plane goes away mid-transfer, an
        inference request is holding an escrow it has no durable place to
        resolve.
      * Moving funds across planes is an audited action, not a cache fill.

    The message stays true whether the customer never transferred or
    transferred and then spent it, because both have the same fix.
    """
    if getattr(workspace, "federated_home", ""):
        return api_error(
            402,
            "No spendable credits on this plane. This workspace is federated: "
            "credits do not federate with identity and must be transferred to "
            "this plane explicitly. A balance on the home plane is not "
            "spendable here.",
            ErrorType.CREDITS_NOT_ON_THIS_PLANE,
        )
    return api_error(402, "Insufficient credits", ErrorType.INSUFFICIENT_CREDITS)


def _api_key_for_gateway_lookup(
    *,
    api_key_hash: str | None,
    api_key_lookup_hash: str | None,
) -> Any | None:
    """Resolve the caller's key, federating from the home plane on a miss.

    Hooked HERE and not inside the store on purpose. This function is the
    exclusive resolver for the four enclave endpoints (validate, key,
    resolve-custom-model, authorize). Hooking STORE.get_key_by_lookup_hash
    instead would also silently federate the direct-to-control-plane
    raw-bearer path, which verifies secret_hash — material a federated
    record deliberately does not carry. Same lookup, different trust
    decision; they must not share a code path.

    A LOCALLY ISSUED key is authoritative and returned as-is. A FEDERATED
    one is a cached copy of somebody else's record and is age-checked
    first — see `_federated_key_still_valid`.
    """
    api_key = None
    if api_key_hash:
        api_key = STORE.get_key_by_hash(api_key_hash)
    if api_key is None and api_key_lookup_hash:
        api_key = STORE.get_key_by_lookup_hash(api_key_lookup_hash)
    if api_key is not None and not getattr(api_key, "federated_home", ""):
        return api_key
    if not api_key_lookup_hash:
        # Nothing to re-resolve against. A federated record reached only by
        # key hash cannot be refreshed, so it is served as-is; the lookup-hash
        # path (which every enclave request uses) does the age check.
        return api_key
    return _federated_key_still_valid(api_key, api_key_lookup_hash)


def _assert_gateway_key_scope(api_key: Any) -> None:
    """Require `inference` for every kind of model-execution spend.

    This includes text, media, batch, and hosted-tool route types; the scope
    bounds the kind of authority rather than the model modality. See
    docs/design/oauth-scopes-and-app-economy.md, "Scopes: small, real,
    enforced".
    """
    scopes = frozenset(api_key.scopes)
    if scopes and SCOPE_INFERENCE not in scopes:
        raise api_error(
            403,
            f"API key is missing required scope: {SCOPE_INFERENCE}",
            ErrorType.INSUFFICIENT_SCOPE,
        )


def _oauth_app_terms_for_key(api_key: Any) -> tuple[int, str]:
    if not api_key.app_id:
        return 0, ""

    suspended, markup_basis_points, owner_user_id = _oauth_app_provenance(api_key)
    if suspended:
        # Do not report INVALID_API_KEY: enclaves negative-cache that result,
        # so un-suspending the app would not promptly restore its valid key.
        raise api_error(
            403,
            "OAuth app is missing or suspended; new authorizations are forbidden",
            ErrorType.FORBIDDEN,
        )
    return markup_basis_points, owner_user_id


def _oauth_app_provenance(api_key: Any) -> tuple[bool, int, str]:
    if getattr(api_key, "federated_home", ""):
        # Case 1: all federated app terms come from home. A peer-local app with
        # the same slug is unrelated for both restrictions and billing.
        suspended = bool(getattr(api_key, "federated_app_suspended", False))
        markup_basis_points = int(getattr(api_key, "federated_app_markup_basis_points", 0))
        owner_user_id = str(getattr(api_key, "federated_app_owner_user_id", ""))
    else:
        app = STORE.get_oauth_app(api_key.app_id)
        if app is None:
            # Case 3: an orphaned home-plane app key fails closed.
            suspended = True
            markup_basis_points = 0
            owner_user_id = ""
        else:
            # Case 2: a home-plane key uses its authoritative local app row.
            owner = (
                STORE.get_user(app.owner_user_id)
                if app.markup_basis_points > 0
                else None
            )
            suspended = oauth_app_is_effectively_suspended(app, owner)
            markup_basis_points = int(app.markup_basis_points)
            owner_user_id = str(app.owner_user_id)

    return suspended, markup_basis_points, owner_user_id


def _oauth_app_is_suspended_for_key(api_key: Any) -> bool:
    """Resolve app suspension from the key's authoritative provenance."""
    return _oauth_app_provenance(api_key)[0]


def _federated_key_still_valid(cached: Any | None, lookup_hash: str) -> Any | None:
    """Serve a federated key only while it is young enough to trust.

    This is the ENTIRE revocation mechanism for a peer plane. Nothing pushes a
    revocation across: `upsert_federated_api_key` runs on a cache MISS, so
    without an age check a key the customer deleted at home keeps authorizing
    here forever, spending whatever credits were transferred to this plane, and
    the only remedy is a manual per-region row delete. The same applies to the
    `workspace_billing_paused` bit the shadow workspace carries — a pause that
    never arrives cannot quiesce anything.

    Three bands, and the middle one is the whole reason this is not just "call
    home every time":

      * Younger than the SOFT TTL: served from the local database. No
        cross-plane call, which is the availability property being bought.
      * Between the soft and hard TTLs: re-resolved, but a home plane that
        cannot answer does NOT fail the request — the cached record still
        serves. An outage at home must not become an outage here.
      * Past the HARD TTL: refused unless home answers. At some age
        "probably still valid" stops being good enough for a credential.

    A home plane that answers "no such key" REVOKES immediately in every band:
    that is a verdict, not an outage. The negative cache in
    services/federation.py bounds how often a revoked key can ask.
    """
    settings = get_settings()
    home = getattr(settings, "federation_home_base_url", "") or ""
    token = getattr(settings, "federation_home_token", "") or ""
    if not home or not token:
        # Federation is off. There is nothing to refresh against, so expiring
        # the record would take the plane down over a config change without
        # making any revoked key one bit less usable.
        return cached

    age = _federated_record_age_seconds(cached)
    if cached is not None and age < federation.SOFT_TTL_SECONDS:
        return cached

    client = _federation_client(home, token)
    try:
        record = client.resolve(lookup_hash)
    except FederationUnavailable as exc:
        if cached is not None and age < federation.HARD_TTL_SECONDS:
            logger.warning(
                "serving a stale federated key (age %ds): home plane unavailable",
                int(age),
            )
            return cached
        logger.warning(
            "federation.key_directory_unavailable home_host=%s cached_age_s=%s error_class=%s",
            _log_home_host(home),
            # An unstampable cached record reads as infinitely old; int(inf)
            # would raise OverflowError and turn the 503 into a 500.
            None if cached is None or age == float("inf") else int(age),
            type(exc).__name__,
        )
        raise api_error(
            503,
            "Key directory is temporarily unavailable; retry shortly",
            ErrorType.SERVICE_UNAVAILABLE,
            headers={"Retry-After": "5"},
        ) from exc
    if record is None:
        # Home genuinely does not know it: never issued, or REVOKED. Either
        # way this plane must stop serving it, cached copy or not.
        return None
    return STORE.upsert_federated_api_key(record)


def _federated_record_age_seconds(api_key: Any | None) -> float:
    """Seconds since this shadow was written, or "infinitely old".

    `created_at` is stamped by `federated_api_key_from_record` on every write,
    so for a federated record it means "when this plane last heard from home",
    and a successful refresh resets it.

    An unparseable or missing stamp counts as hard-expired rather than fresh.
    A record whose age cannot be established is exactly the one that must not
    be trusted indefinitely, and the failure is loud (a refresh, or a 503)
    instead of silent.
    """
    if api_key is None:
        return float("inf")
    raw = str(getattr(api_key, "created_at", "") or "")
    if not raw:
        return float("inf")
    try:
        stamped = dt.datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return float("inf")
    if stamped.tzinfo is None:
        stamped = stamped.replace(tzinfo=dt.UTC)
    return max(0.0, (dt.datetime.now(dt.UTC) - stamped).total_seconds())


@lru_cache(maxsize=4)
def _federation_client(home: str, token: str) -> FederationClient:
    """One client per (home, token) so the breaker and single-flight state
    are shared across requests rather than reset on every call."""
    return FederationClient(home_base_url=home, peer_token=token)


def _require_monitor_model_key(
    body: dict[str, Any],
    api_key_lookup_hash: str,
    settings: Settings,
) -> None:
    if not _requests_monitor_model(body):
        return
    for expected in (settings.synthetic_monitor_api_key, settings.stage_d_probe_api_key):
        if expected and api_key_lookup_hash == lookup_hash_api_key(expected):
            return
    raise api_error(
        403,
        "trustedrouter/monitor is restricted to the synthetic monitor key",
        ErrorType.FORBIDDEN,
    )


def _requests_monitor_model(body: dict[str, Any]) -> bool:
    if str(body.get("model") or "").strip() == MONITOR_MODEL_ID:
        return True
    models = body.get("models")
    if isinstance(models, list):
        return any(str(model).strip() == MONITOR_MODEL_ID for model in models)
    return False


def _force_custom_model_credit_routes(
    body: dict[str, Any],
    *,
    error_message: str = "Custom models do not support BYOK routes",
) -> None:
    _force_credit_routes(body, error_message=error_message)


def _force_partner_credit_routes(body: dict[str, Any]) -> None:
    _force_credit_routes(body, error_message="Parasail Liberty does not support BYOK routes")


def _force_credit_routes(body: dict[str, Any], *, error_message: str) -> None:
    prefs = provider_route_preferences(body)
    if prefs.usage_type == UsageType.BYOK:
        raise api_error(
            400,
            error_message,
            ErrorType.MODEL_NOT_SUPPORTED,
        )
    provider = body.get("provider")
    if isinstance(provider, dict):
        body["provider"] = {**provider, "usage": "credits"}
    else:
        body["provider"] = {"usage": "credits"}


def _is_web_search_restricted_model(model_id: str) -> bool:
    model = model_id.strip().lower()
    return any(
        model == prefix or model.startswith(f"{prefix}-") or model.startswith(f"{prefix}/")
        for prefix in (
            "trustedrouter/zdr",
            "trustedrouter/e2e",
            "trustedrouter/confidential",
            "trustedrouter/eu",
            "trustedrouter/green",
        )
    )


def _is_web_search_restricted_provider(provider: Any) -> bool:
    if not isinstance(provider, dict):
        return False
    return str(provider.get("data_collection") or "").strip().lower() == "deny" or (
        str(provider.get("jurisdiction") or "").strip().lower() == "eu"
    )


def _report_route_fallbacks(body: GatewaySettleRequest) -> None:
    """Accumulate successful provider failovers in Sentry as warnings.

    Each event means one provider route failed pre-output and the attested
    gateway routed around it — harmless individually, invisible in aggregate
    until now. A model+provider pair that accumulates these is a dead default
    route (GMI/nemotron 2026-07-15, GMI/kimi-k3 2026-07-16): alert on volume,
    then demote the route (see _PROVIDER_UNSERVED_CREDITS_MODELS).
    Grouping: message embeds model + failed providers, so each pair gets its
    own Sentry issue whose event count IS the accumulation signal.
    """
    try:
        import sentry_sdk

        failures = [f for f in (getattr(body, "route_failures", None) or []) if isinstance(f, str)][
            :8
        ]
        providers = sorted({f.split("|", 1)[0] for f in failures if f})
        model = body.selected_model or body.model or "unknown"
        with sentry_sdk.push_scope() as scope:
            scope.set_level("warning")
            scope.set_tag("failover.model", model[:100])
            if providers:
                scope.set_tag("failover.failed_providers", ",".join(providers)[:200])
            scope.set_context(
                "route_failover",
                {
                    "fallbacks": getattr(body, "route_fallbacks", None),
                    "failures": failures,
                    "served_by": body.selected_endpoint or body.endpoint,
                },
            )
            sentry_sdk.capture_message(
                f"provider failover: {model} routed around {','.join(providers) or 'unknown'}"
            )
    except Exception:  # noqa: BLE001 - observability must never break settlement
        logger.warning("route fallback sentry report failed", exc_info=True)


def _refund_benchmark_sample_safely(
    body: GatewaySettleRequest,
    authorization: GatewayAuthorization,
    *,
    model: Any,
    selected_endpoint: ModelEndpoint,
    input_tokens: int,
    selected_usage_type: UsageType,
) -> ProviderBenchmarkSample | None:
    """The provider-error benchmark a refund records, or None if it cannot be built."""
    try:
        return ProviderBenchmarkSample.from_provider_error(
            model=model,
            provider_name=PROVIDERS[selected_endpoint.provider].name,
            input_tokens=input_tokens,
            elapsed_seconds=float(body.elapsed_seconds or 0.001),
            streamed=body.streamed,
            usage_type=selected_usage_type,
            error_status=body.error_status or 502,
            error_type=body.error_type or "provider_error",
            region=authorization.region,
            provider=selected_endpoint.provider,
            workspace_id=authorization.workspace_id,
        )
    except Exception:
        logger.warning(
            "provider benchmark write failed after refund finalize authorization_id=%s",
            authorization.id,
            exc_info=True,
        )
        return None


def _record_refund_benchmark_safely(
    sample: ProviderBenchmarkSample, authorization_id: str,
) -> None:
    try:
        STORE.record_provider_benchmark(sample)
    except Exception:
        # Money is already committed. Observability cannot change the response
        # or stop later background tasks. Storage retains its RPC deadlines.
        logger.warning(
            "provider benchmark write failed after refund finalize authorization_id=%s",
            authorization_id,
            exc_info=True,
        )


@spanner_rpc_budget(_BILLING_PATH_SPANNER_BUDGET_SECONDS)
@timed_gateway_sync
def _settle_gateway_with_admission_sync(
    body: GatewaySettleRequest,
    *,
    settings: Settings,
    background_tasks: BackgroundTasks | None = None,
) -> dict[str, Any]:
    with gateway_phase("key_lookup_ms", after="routing_ms"):
        authorization = STORE.get_gateway_authorization(body.authorization_id)
    if authorization is None:
        raise api_error(404, "Gateway authorization not found", ErrorType.NOT_FOUND)
    subject = authorization.key_hash
    if not _SETTLE_ADMISSION.try_acquire(
        subject,
        limit=settings.settle_per_key_inflight_limit,
    ):
        logger.warning(
            "billing.settle_admission_limited",
            extra={
                "key_subject_fingerprint": hashlib.sha256(subject.encode("utf-8")).hexdigest()[:16],
                "limit": settings.settle_per_key_inflight_limit,
            },
        )
        raise api_error(
            503,
            "Settlement is temporarily unavailable; retry shortly.",
            ErrorType.SERVICE_UNAVAILABLE,
            headers={"Retry-After": "1"},
        )
    try:
        return _settle_gateway_authorization(
            body,
            success=True,
            settings=settings,
            background_tasks=background_tasks,
            _authorization=authorization,
        )
    finally:
        _SETTLE_ADMISSION.release(subject)


@spanner_rpc_budget(_BILLING_PATH_SPANNER_BUDGET_SECONDS)
def _settle_gateway_authorization(
    body: GatewaySettleRequest,
    *,
    success: bool,
    settings: Settings,
    background_tasks: BackgroundTasks | None = None,
    _authorization: GatewayAuthorization | None = None,
) -> dict[str, Any]:
    timing_start = perf_counter()
    # getattr: some callers/tests build the settle body via model_construct,
    # which skips defaults for unset fields.
    if success and getattr(body, "route_fallbacks", None):
        _report_route_fallbacks(body)
    with gateway_phase("key_lookup_ms", after="routing_ms"):
        authorization = _authorization or STORE.get_gateway_authorization(body.authorization_id)
    if authorization is None:
        raise api_error(404, "Gateway authorization not found", ErrorType.NOT_FOUND)
    if authorization.settled:
        _release_user_model_slot_safely(authorization)
        # No timing line for replays: they are ~one point-read and would dominate
        # the latency dataset with noise.
        return {"data": _already_settled_gateway_data(authorization)}

    if authorization.settlement in _RETIRED_SETTLEMENTS:
        logger.error(
            "billing.settle_retired_settlement authorization_id=%s settlement=%s",
            authorization.id,
            authorization.settlement,
        )
        raise api_error(
            409,
            "Authorization belongs to a retired settlement kind",
            ErrorType.CONFLICT,
        )
    # Detached request-local inputs only. Finalize builds its own mutable copy;
    # reservation and authorization claims still read/guard state inside T3.
    # Heartbeat fields are merged from the live row by the settled UPDATE.
    authorization_snapshot = (
        copy.deepcopy(authorization) if authorization.settlement == "local" else None
    )

    if body.tags is not None:
        try:
            if not tags_match(body.tags, authorization.tags):
                logger.warning(
                    "gateway settlement tags ignored authorization_id=%s "
                    "authorized_tag_count=%d supplied_tag_count=%d",
                    authorization.id,
                    len(authorization.tags),
                    len(body.tags),
                )
        except InvalidTags as exc:
            logger.warning(
                "invalid gateway settlement tags ignored authorization_id=%s "
                "authorized_tag_count=%d error=%s",
                authorization.id,
                len(authorization.tags),
                str(exc),
            )

    settle_body = _settle_body_with_safe_attribution(body, authorization.id)
    settle_body = _settle_body_with_safe_client_context(settle_body, authorization.id)
    if _authorization_is_synthetic(authorization):
        metadata = settle_body.get("metadata")
        synthetic_metadata = dict(metadata) if isinstance(metadata, dict) else {}
        synthetic_metadata["trustedrouter_synthetic"] = "true"
        settle_body["metadata"] = synthetic_metadata
        settle_body["app"] = SYNTHETIC_APP_NAME
    if not success:
        client_context = settle_body.get("client")
        client_fields = client_context if isinstance(client_context, dict) else {}
        logger.info(
            "gateway.refund_client_context authorization_id=%s gateway_request_id=%s "
            "sdk=%s sdk_version=%s attempt=%s prev_outcome=%s prev_error_class=%s "
            "prev_host=%s failover_used=%s",
            authorization.id,
            settle_body.get("gateway_request_id"),
            client_fields.get("sdk"),
            client_fields.get("sdk_version"),
            client_fields.get("attempt"),
            client_fields.get("prev_outcome"),
            client_fields.get("prev_error_class"),
            client_fields.get("prev_host"),
            client_fields.get("failover_used"),
        )
    # This field is control-plane-owned. Never trust a caller-supplied value;
    # only the selected endpoint and frozen price history may set operator COGS.
    settle_body.pop(PARTNER_OPERATOR_COST_SETTLE_FIELD, None)
    settle_body.pop(USER_MODEL_PAYOUT_SETTLE_FIELD, None)
    settle_body.pop(USER_MODEL_OWNER_SETTLE_FIELD, None)
    settle_body.pop(USER_MODEL_ID_SETTLE_FIELD, None)
    settle_body.pop(CUSTOM_MODEL_MARKUP_PAYOUT_SETTLE_FIELD, None)
    settle_body.pop(CUSTOM_MODEL_MARKUP_CHARGE_SETTLE_FIELD, None)
    settle_body.pop(CUSTOM_MODEL_MARKUP_OWNER_SETTLE_FIELD, None)
    settle_body.pop(CUSTOM_MODEL_MARKUP_ID_SETTLE_FIELD, None)
    settle_body.pop(APP_MARKUP_PAYOUT_SETTLE_FIELD, None)
    settle_body.pop(APP_MARKUP_OWNER_SETTLE_FIELD, None)
    settle_body.pop(APP_MARKUP_APP_ID_SETTLE_FIELD, None)

    user_model_pair = _authorized_user_model_pair(authorization)
    selected_endpoint = _select_authorized_endpoint(authorization, body)
    if selected_endpoint is None:
        raise api_error(
            400,
            "selected endpoint was not authorized for this gateway request",
            ErrorType.BAD_REQUEST,
        )
    if (
        selected_endpoint.model_id == POLYPHEMUS_MODEL_ID
        and body.input_count == 0
        and body.output_count == 0
    ):
        # Pre-token-meter enclaves settle 0/0 usage with a fixed one-microdollar
        # fee. Preserve their tariff through rolling deploys and durable retries.
        # Keep the same authorization/idempotency key; never re-run selection.
        selected_endpoint = replace(
            selected_endpoint,
            prompt_price_microdollars_per_million_tokens=0,
            published_prompt_price_microdollars_per_million_tokens=0,
            request_price_microdollars=LEGACY_SELECTOR_FEE_MICRODOLLARS,
            price_tiers=(),
            published_price_tiers=(),
        )
    model = (
        user_model_pair[0]
        if user_model_pair is not None
        else MODELS.get(selected_endpoint.model_id)
    )
    if model is None:
        raise api_error(500, "Authorized model is no longer configured", ErrorType.INTERNAL_ERROR)
    auth_ms = (perf_counter() - timing_start) * 1000

    output_tokens = body.output_count
    service_tier = (
        None if user_model_pair is not None else _actual_service_tier_or_error(body.service_tier)
    )
    # Owner endpoints speak the OpenAI chat dialect, whose prompt_tokens
    # already INCLUDES any cached subset — the "trustedrouter" branch of
    # normalized_prompt_accounting (also what the outbox repair path uses).
    # Adding cache counts on top would double-bill the prompt and let an owner
    # who reports cached_tokens == prompt_tokens double their revenue. Owner
    # prices have no cache tier, so the whole prompt bills at the prompt price.
    uncached_input, total_input, cache_read, cache_creation = normalized_prompt_accounting(
        selected_endpoint.provider, body
    )
    if user_model_pair is not None:
        uncached_input = total_input
    partner_mode = _partner_billing_mode_or_error(
        requested_model_id=authorization.requested_model_id,
        route_type=body.route_type,
        idempotency_key=authorization.idempotency_key,
    )
    if user_model_pair is not None and partner_mode is not None:
        raise api_error(
            400,
            "User-provided models do not support partner billing",
            ErrorType.BAD_REQUEST,
        )
    if partner_mode is not None and UsageType.for_endpoint(selected_endpoint) != UsageType.CREDITS:
        raise api_error(
            400,
            "Parasail Liberty does not support BYOK routes",
            ErrorType.MODEL_NOT_SUPPORTED,
        )
    # Only Fugu defines this provider-private tier basis. Ignoring the field
    # for every other model prevents a future provider extension from silently
    # selecting a cheaper context tier.
    price_tier_input_tokens = _provider_price_tier_input_tokens(
        selected_endpoint,
        body.price_tier_input_tokens,
    )
    video_cost = None
    if success and authorization.video_pricing_snapshot is not None:
        if body.route_type != "videos" or total_input:
            raise api_error(400, "Video settlement requires video output usage only", ErrorType.BAD_REQUEST)
        try:
            video_cost = video_cost_microdollars(
                authorization.video_pricing_snapshot, selected_endpoint.id,
                output_tokens=output_tokens,
                quoted_microdollars=body.additional_cost_microdollars,
            )
        except ValueError as exc:
            raise api_error(400, str(exc), ErrorType.BAD_REQUEST) from exc
    billing_snapshot = billing_pricing_snapshot(authorization)
    actual_cost = (
        video_cost if video_cost is not None else custom_model_cost_microdollars(
            input_tokens=total_input,
            output_tokens=output_tokens,
            prompt_price=int(authorization.user_model_prompt_price_microdollars_per_m or 0),
            completion_price=int(authorization.user_model_completion_price_microdollars_per_m or 0),
        )
        if user_model_pair is not None
        else partner_cost_microdollars(
            partner_mode,
            input_tokens=total_input,
            output_tokens=output_tokens,
        )
        if partner_mode is not None
        else _endpoint_cost_microdollars_from_document(
            billing_snapshot,
            selected_endpoint.id,
            uncached_input,
            output_tokens,
            cache_read_tokens=cache_read,
            cache_creation_tokens=cache_creation,
            price_tier_input_tokens=price_tier_input_tokens,
        )
        if billing_snapshot is not None
        else _endpoint_cost_microdollars(
            selected_endpoint,
            uncached_input,
            output_tokens,
            cache_read_tokens=cache_read,
            cache_creation_tokens=cache_creation,
            price_tier_input_tokens=price_tier_input_tokens,
            effective_at=authorization.created_at,
            service_tier=service_tier,
        )
    )
    app_markup_micro = 0
    custom_model_markup_micro = 0
    if not success:
        # A refund books zero and releases the frozen hold. Never require a
        # route marker from a generic abort path; the authorization id is the
        # durable authority and refusing a refund can strand funds for 26h.
        actual_cost = 0
    elif user_model_pair is not None:
        # The token counts come from the PAYEE's own meter (the owner endpoint
        # reports usage; the enclave forwards it). Catalog providers are
        # trusted to overrun a hold by a little; an owner who reports
        # 10^7 tokens for a 10-token answer must not be able to drain the
        # caller and pocket 70%. The hold the caller authorized — estimated
        # prompt at frozen prices plus max_output — is the ceiling.
        if actual_cost > authorization.estimated_microdollars:
            logger.warning(
                "billing.user_model_settle_capped_to_hold",
                extra={
                    "authorization_id": authorization.id,
                    "user_provided_model_id": authorization.user_provided_model_id,
                    "reported_microdollars": actual_cost,
                    "hold_microdollars": authorization.estimated_microdollars,
                    "input_tokens": total_input,
                    "output_tokens": output_tokens,
                },
            )
            actual_cost = authorization.estimated_microdollars
    else:
        actual_cost = _native_batch_cost_or_error(
            actual_cost,
            route_type=body.route_type,
            provider=selected_endpoint.provider,
            idempotency_key=authorization.idempotency_key,
            native_batch_eligible=authorization.native_batch_eligible,
            selected_usage_type=UsageType.for_endpoint(selected_endpoint),
        )
    if (
        success
        and authorization.receipt_fee_basis_points > 0
        and UsageType.for_endpoint(selected_endpoint) == UsageType.CREDITS
        and user_model_pair is None
        and partner_mode is None
    ):
        actual_cost = signed_receipt_price_microdollars(
            actual_cost, authorization.receipt_fee_basis_points
        )
    if success and authorization.custom_model_markup_basis_points > 0:
        custom_model_markup_micro = custom_model_markup_microdollars(
            actual_cost,
            authorization.custom_model_markup_basis_points,
        )
        actual_cost += custom_model_markup_micro
    additional_cost = body.additional_cost_microdollars
    if (
        body.route_type == "videos"
        and authorization.video_pricing_snapshot is not None
        and success
    ):
        if actual_cost > authorization.estimated_microdollars:
            raise api_error(400, "Video token cost exceeds the authorized reservation", ErrorType.BAD_REQUEST)
    if user_model_pair is not None and additional_cost:
        raise api_error(
            400,
            "User-provided models do not support additional settlement cost",
            ErrorType.BAD_REQUEST,
        )
    if additional_cost:
        if body.route_type not in _ADDITIONAL_COST_ROUTE_TYPES:
            raise api_error(
                400,
                "additional cost settlement is only available for hosted search, image, or video",
                ErrorType.BAD_REQUEST,
            )
        if additional_cost > authorization.additional_cost_reservation_microdollars:
            raise api_error(
                400,
                "additional cost exceeds the authorized reservation",
                ErrorType.BAD_REQUEST,
            )
        if UsageType.for_endpoint(selected_endpoint) != UsageType.CREDITS:
            raise api_error(
                400,
                "additional cost settlement requires a Credits route",
                ErrorType.BAD_REQUEST,
            )
        actual_cost += additional_cost
    if success and authorization.app_markup_basis_points > 0:
        # THE HOLD AND THE CHARGE MUST MARK UP THE SAME BASE: authorize marks
        # model estimate plus hosted-tool/media reservation, so settle marks up
        # model cost plus the corresponding additional cost.
        proposed_app_markup_micro = app_markup_microdollars(
            actual_cost, authorization.app_markup_basis_points
        )
        actual_cost += proposed_app_markup_micro
    input_tokens = total_input
    selected_usage_type = UsageType.for_endpoint(selected_endpoint)
    if success and selected_endpoint.model_id == POLYPHEMUS_MODEL_ID:
        # The new selector meter can settle against an old one-microdollar
        # admission during a mixed rollout. Never exceed its frozen hold.
        actual_cost = min(actual_cost, authorization.estimated_microdollars)
    if success and authorization.app_markup_basis_points > 0:
        # THE PAYOUT IS A FUNCTION OF THE FINAL CHARGE: authorization freezes
        # the rate, while every clamp/cap/adjustment above decides the base.
        app_markup_micro = app_markup_microdollars_from_charge(
            actual_cost, authorization.app_markup_basis_points
        )
    if success and authorization.custom_model_markup_basis_points > 0:
        # Caps can truncate the proposed charge. The payout is based only on
        # the prompt-wrapper markup that survived the final cap, after the
        # outer app markup and hosted costs are removed.
        collected_custom_markup = collected_custom_model_markup_microdollars(
            actual_cost,
            authorization.custom_model_markup_basis_points,
            app_markup_basis_points=authorization.app_markup_basis_points,
            additional_cost_microdollars=additional_cost,
        )
        custom_model_markup_micro = min(
            custom_model_markup_micro,
            collected_custom_markup,
        )
    operator_cost = (
        owner_share_microdollars(max(0, actual_cost - app_markup_micro))
        if user_model_pair is not None
        else _endpoint_cost_microdollars(
            selected_endpoint,
            uncached_input,
            output_tokens,
            cache_read_tokens=cache_read,
            cache_creation_tokens=cache_creation,
            price_tier_input_tokens=price_tier_input_tokens,
            effective_at=authorization.created_at,
            service_tier=service_tier,
        )
        if partner_mode == PartnerBillingMode.INTERNAL
        else None
    )
    if (
        success
        and selected_usage_type == UsageType.CREDITS
        and actual_cost > authorization.estimated_microdollars
    ):
        logger.warning(
            "billing.settlement_exceeded_reservation",
            extra={
                "authorization_id": authorization.id,
                "workspace_id": authorization.workspace_id,
                "model": model.id,
                "provider": selected_endpoint.provider,
                "estimated_microdollars": authorization.estimated_microdollars,
                "actual_microdollars": actual_cost,
                "overrun_microdollars": actual_cost - authorization.estimated_microdollars,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
            },
        )
    generation_model_id = (
        PARASAIL_LIBERTY_2_0_MODEL_ID if partner_mode == PartnerBillingMode.TOP_LEVEL else model.id
    )
    generation_provider = (
        "parasail" if partner_mode == PartnerBillingMode.TOP_LEVEL else selected_endpoint.provider
    )
    generation_provider_name = PROVIDERS[generation_provider].name

    generation_id: str | None = None
    generation: Generation | None = None
    if success:
        generation = Generation.from_settle_body(
            authorization=authorization,
            provider_name=generation_provider_name,
            model_id=generation_model_id,
            usage_type=selected_usage_type,
            provider=generation_provider,
            body=settle_body,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            actual_cost_microdollars=actual_cost,
            app_markup_microdollars=app_markup_micro,
            custom_model_markup_microdollars=custom_model_markup_micro,
            operator_cost_microdollars=operator_cost,
        )
        generation_id = generation.id

    user_model_payout: UserModelPayout | None = None
    if user_model_pair is not None:
        owner_user_id = str(authorization.user_model_owner_user_id or "")
        user_model_id = str(authorization.user_provided_model_id or "")
        user_model_payout = UserModelPayout(
            owner_user_id=owner_user_id,
            model_id=user_model_id,
            amount_microdollars=(
                owner_share_microdollars(max(0, actual_cost - app_markup_micro)) if success else 0
            ),
            payer_workspace_id=authorization.workspace_id,
        )

    app_markup_payout: AppMarkupPayout | None = None
    if authorization.app_markup_basis_points > 0:
        app_markup_payout_micro = (
            app_markup_owner_share_microdollars(app_markup_micro) if success else 0
        )
        if app_markup_payout_micro > app_markup_micro:
            logger.error(
                "billing.app_markup_payout_exceeded_collected_markup",
                extra={
                    "authorization_id": authorization.id,
                    "payout_microdollars": app_markup_payout_micro,
                    "markup_microdollars": app_markup_micro,
                },
            )
            app_markup_payout_micro = app_markup_micro
        app_markup_payout = AppMarkupPayout(
            owner_user_id=authorization.app_owner_user_id,
            app_id=authorization.app_id,
            amount_microdollars=app_markup_payout_micro,
            payer_workspace_id=authorization.workspace_id,
        )

    custom_model_markup_payout: CustomModelMarkupPayout | None = None
    if authorization.custom_model_markup_basis_points > 0:
        custom_model_markup_payout = CustomModelMarkupPayout(
            owner_user_id=authorization.custom_model_owner_user_id,
            model_id=str(authorization.custom_model_id or ""),
            amount_microdollars=(
                custom_model_markup_owner_share_microdollars(
                    custom_model_markup_micro
                )
                if success
                else 0
            ),
            payer_workspace_id=authorization.workspace_id,
        )

    # C1 removed the GCP legacy finalize branch; Spanner finalizes through typed
    # billing unconditionally. The memory store still uses the single-book path.
    _typed_store = typed_billing_store(STORE)
    is_typed = _typed_store is not None
    intent_kind = "settle" if success else "refund"
    is_customer_billing_event = partner_mode != PartnerBillingMode.INTERNAL
    enqueue_ms = 0.0
    outbox_enqueued = False
    refill_required = (
        settings.service_surface == "internal"
        and success
        and is_customer_billing_event
        and selected_usage_type == UsageType.CREDITS
    )
    refill_attached = not refill_required
    # A refund's provider-error benchmark is pure computation; build it before
    # finalize so the one-commit settle can record it in its money commit.
    refund_benchmark = (
        None
        if success or _is_synthetic_settlement(body, authorization)
        else _refund_benchmark_sample_safely(
            body,
            authorization,
            model=model,
            selected_endpoint=selected_endpoint,
            input_tokens=input_tokens,
            selected_usage_type=selected_usage_type,
        )
    )
    durable_intent: SettleOutboxRow | None = None
    settle_intent: SettleOutboxRow | None = None
    if settings.settle_outbox_enabled:
        try:
            frozen_settle_body = _settle_repair_metadata(settle_body)
            if operator_cost is not None:
                frozen_settle_body[PARTNER_OPERATOR_COST_SETTLE_FIELD] = operator_cost
            if user_model_payout is not None:
                frozen_settle_body[USER_MODEL_PAYOUT_SETTLE_FIELD] = (
                    user_model_payout.amount_microdollars
                )
                frozen_settle_body[USER_MODEL_OWNER_SETTLE_FIELD] = user_model_payout.owner_user_id
                frozen_settle_body[USER_MODEL_ID_SETTLE_FIELD] = user_model_payout.model_id
            if app_markup_payout is not None:
                frozen_settle_body[APP_MARKUP_PAYOUT_SETTLE_FIELD] = (
                    app_markup_payout.amount_microdollars
                )
                frozen_settle_body[APP_MARKUP_OWNER_SETTLE_FIELD] = app_markup_payout.owner_user_id
                frozen_settle_body[APP_MARKUP_APP_ID_SETTLE_FIELD] = app_markup_payout.app_id
            if custom_model_markup_payout is not None:
                frozen_settle_body[CUSTOM_MODEL_MARKUP_CHARGE_SETTLE_FIELD] = (
                    custom_model_markup_micro
                )
                frozen_settle_body[CUSTOM_MODEL_MARKUP_PAYOUT_SETTLE_FIELD] = (
                    custom_model_markup_payout.amount_microdollars
                )
                frozen_settle_body[CUSTOM_MODEL_MARKUP_OWNER_SETTLE_FIELD] = (
                    custom_model_markup_payout.owner_user_id
                )
                frozen_settle_body[CUSTOM_MODEL_MARKUP_ID_SETTLE_FIELD] = (
                    custom_model_markup_payout.model_id
                )
            # §5.4 honest scope: durability starts only when this intent commits;
            # crashes before it still rely on enclave redelivery. MF4/MF5 freeze
            # the finalize path and exact resolved cost used by the inline attempt.
            settle_intent = SettleOutboxRow(
                authorization_id=authorization.id,
                intent_kind=intent_kind,
                settle_origin="typed" if is_typed else "legacy",
                actual_cost_micro=actual_cost,
                reservation_id=authorization.credit_reservation_id,
                selected_endpoint_id=selected_endpoint.id,
                model_id=generation_model_id,
                selected_usage_type=str(selected_usage_type),
                settle_body=json.dumps(frozen_settle_body, separators=(",", ":")),
                auto_refill_workspace_id=(
                    authorization.workspace_id if refill_required else None
                ),
            )
        except Exception:
            logger.error(
                "settle outbox enqueue failed authorization_id=%s",
                authorization.id,
                exc_info=True,
            )

    # Happy path: the intent, the charge, the done-mark and the benchmark in
    # ONE commit. Any failure (declined, aborted, deadline, unknown outcome)
    # falls through to the durable two-commit settle below, unchanged; the
    # store method documents why an unknown outcome is safe to follow with it.
    one_commit_result: TypedFinalizeResult | None = None
    one_commit_ms = 0.0
    settle_one_commit = (
        getattr(_typed_store, "typed_settle_one_commit_result", None) if is_typed else None
    )
    one_commit_attempted = settle_intent is not None and callable(settle_one_commit)
    if settle_intent is not None and callable(settle_one_commit):
        one_commit_start = perf_counter()
        try:
            with gateway_phase("store_ms", after="post_commit_ms"):
                one_commit_result = cast(
                    TypedFinalizeResult | None,
                    settle_one_commit(
                        authorization.id,
                        settle_intent=settle_intent,
                        success=success,
                        actual_microdollars=actual_cost,
                        selected_usage_type=selected_usage_type,
                        generation=generation,
                        user_model_payout=user_model_payout,
                        app_markup_payout=app_markup_payout,
                        custom_model_markup_payout=custom_model_markup_payout,
                        authorization_snapshot=authorization_snapshot,
                        refund_benchmark=refund_benchmark,
                        # The same refill grace the enqueue below would use.
                        intent_initial_delay_seconds=60,
                    ),
                )
        except Exception:
            logger.warning(
                "one-commit settle failed; using the durable two-commit settle "
                "authorization_id=%s",
                authorization.id,
                exc_info=True,
            )
        one_commit_ms = (perf_counter() - one_commit_start) * 1000
    if one_commit_result is not None:
        assert settle_intent is not None
        durable_intent = settle_intent
        # The intent committed, already resolved, with its refill attachment.
        outbox_enqueued = True
        refill_attached = (
            not refill_required
            or settle_intent.auto_refill_workspace_id == authorization.workspace_id
        )
    elif settle_intent is not None:
        enqueue_start = perf_counter()
        try:
            settle_outbox = spanner_settle_outbox()
            enqueue_outcome = settle_outbox.enqueue(
                settle_intent,
                # Grace so inline finalize wins the benign race; the drain only
                # sees rows whose inline attempt is dead >=60s, avoiding replays.
                initial_delay_seconds=60,
            )
            # The intent is durable at this exact point. Any later attachment,
            # inline-finalize, or response-side failure must report
            # intent_durable rather than inviting the enclave to infer that no
            # settlement record exists.
            outbox_enqueued = True
            # A leased/terminal row can differ from this attempt. Report only
            # the frozen intent that actually became durable, never this retry's
            # newly calculated price when enqueue preserved an older row.
            if enqueue_outcome in {ENQ_INSERTED, ENQ_REFRESHED}:
                durable_intent = settle_intent
            else:
                try:
                    durable_intent = settle_outbox.get(authorization.id, intent_kind)
                except Exception:
                    # A reporting lookup must not skip refill attachment or
                    # change whether the existing inline finalize is attempted.
                    logger.warning(
                        "durable settlement reporting lookup failed authorization_id=%s",
                        authorization.id,
                        exc_info=True,
                    )
            if settings.async_settle_protection and durable_intent is not None and durable_intent.async_version == 1:
                from trusted_router.services.async_settle_handler import finish

                # A concurrent async INSERT won. Discard all newly priced inputs.
                # Frozen apply uses the ordinary finalize and the original amount.
                finish(durable_intent, settle_outbox)
                winner = STORE.get_gateway_authorization(authorization.id)
                if winner is None or not winner.settled:
                    raise api_error(503, "Settlement is pending", ErrorType.SERVICE_UNAVAILABLE)
                return {"data": _already_settled_gateway_data(winner)}
            if refill_required:
                # A matching fresh INSERT already committed the attachment.
                # Pre-cutover combined rows have no refill columns. Attaching is
                # an independent NULL -> pending transition, so it is safe even
                # when the settlement row is actively leased or terminal.
                refill_attached = (
                    enqueue_outcome == ENQ_INSERTED
                    and settle_intent.auto_refill_workspace_id == authorization.workspace_id
                )
                if not refill_attached:
                    refill_attached = settle_outbox.attach_auto_refill(
                        authorization.id,
                        authorization.workspace_id,
                        initial_delay_seconds=60,
                    )
                if not refill_attached:
                    raise RuntimeError("settlement auto-refill attachment was not confirmed")
        except Exception:
            logger.error(
                "settle outbox enqueue failed authorization_id=%s",
                authorization.id,
                exc_info=True,
            )
        enqueue_ms = (perf_counter() - enqueue_start) * 1000

    if refill_required and not refill_attached:
        if outbox_enqueued:
            logger.error(
                "settlement deferred after refill attachment failure "
                "authorization_id=%s",
                authorization.id,
            )
            return {"data": _intent_durable_gateway_data(authorization, durable_intent)}
        raise api_error(
            503,
            "Settlement refill durability is temporarily unavailable",
            ErrorType.SERVICE_UNAVAILABLE,
        )

    if (
        is_typed
        and getattr(_typed_store, "request_record_write_mode", "legacy") == "typed"
        and settings.settle_outbox_enabled
        and not outbox_enqueued
    ):
        raise api_error(
            503,
            "Settlement durability is temporarily unavailable",
            ErrorType.SERVICE_UNAVAILABLE,
        )

    finalize_start = perf_counter()
    finalize_result = TypedFinalizeResult(
        finalized=False,
        activity_indexed=False,
    )
    if one_commit_result is not None:
        finalize_result = one_commit_result
        finalized = finalize_result.finalized
    elif is_typed:
        assert _typed_store is not None
        # Typed finalize atomically commits billing, the bounded generation
        # record, and the ClickHouse delivery intent. Benchmark delivery
        # happens after that commit.
        result_method = getattr(
            _typed_store,
            "typed_finalize_gateway_authorization_result",
            None,
        )
        if callable(result_method):
            try:
                with gateway_phase("store_ms", after="post_commit_ms"):
                    finalize_result = cast(
                        TypedFinalizeResult,
                        result_method(
                            authorization.id,
                            authorization_snapshot=authorization_snapshot,
                            success=success,
                            actual_microdollars=actual_cost,
                            selected_usage_type=selected_usage_type,
                            generation=generation,
                            user_model_payout=user_model_payout,
                            app_markup_payout=app_markup_payout,
                            custom_model_markup_payout=custom_model_markup_payout,
                            defer_post_commit=(
                                functools.partial(defer_post_commit, background_tasks)
                                if background_tasks is not None else None
                            ),
                            # Resolve the durable intent in the finalize commit
                            # itself (docs/design/durable-settle-outbox.md §7).
                            settle_outbox_done=(
                                (authorization.id, intent_kind)
                                if settings.settle_outbox_enabled and outbox_enqueued
                                else None
                            ),
                        ),
                    )
            except Exception:
                if not outbox_enqueued:
                    raise
                logger.exception(
                    "settlement deferred after inline finalize failure "
                    "authorization_id=%s",
                    authorization.id,
                )
                return {"data": _intent_durable_gateway_data(authorization, durable_intent)}
        else:
            try:
                with gateway_phase("store_ms", after="post_commit_ms"):
                    finalized_legacy_contract = _typed_store.typed_finalize_gateway_authorization(
                        authorization.id,
                        success=success,
                        actual_microdollars=actual_cost,
                        selected_usage_type=selected_usage_type,
                        generation=generation,
                        user_model_payout=user_model_payout,
                        app_markup_payout=app_markup_payout,
                        custom_model_markup_payout=custom_model_markup_payout,
                    )
            except Exception:
                if not outbox_enqueued:
                    raise
                logger.exception(
                    "settlement deferred after inline finalize failure "
                    "authorization_id=%s",
                    authorization.id,
                )
                return {"data": _intent_durable_gateway_data(authorization, durable_intent)}
            finalize_result = TypedFinalizeResult(
                finalized=finalized_legacy_contract,
                activity_indexed=finalized_legacy_contract,
            )
        finalized = finalize_result.finalized
    else:
        try:
            with gateway_phase("store_ms", after="post_commit_ms"):
                finalized = STORE.finalize_gateway_authorization(
                    authorization.id,
                    success=success,
                    actual_microdollars=actual_cost,
                    selected_usage_type=selected_usage_type,
                    generation=generation,
                )
        except Exception:
            if not outbox_enqueued:
                raise
            logger.exception(
                "settlement deferred after inline finalize failure authorization_id=%s",
                authorization.id,
            )
            return {"data": _intent_durable_gateway_data(authorization, durable_intent)}
        if finalized:
            _credit_user_model_payout_safely(
                authorization,
                success=success,
                payout=user_model_payout,
            )
            _credit_app_markup_payout_safely(
                authorization,
                success=success,
                payout=app_markup_payout,
            )
            _credit_custom_model_markup_payout_safely(
                authorization,
                success=success,
                payout=custom_model_markup_payout,
            )
        finalize_result = TypedFinalizeResult(
            finalized=finalized,
            activity_indexed=finalized,
        )
    finalize_ms = (
        one_commit_ms
        if one_commit_result is not None
        else (perf_counter() - finalize_start) * 1000
    )
    _release_user_model_slot_safely(authorization)
    if not finalized:
        # §3/§6/§7: leave the row pending on purpose. Inline's False only says
        # "claim lost"; it cannot distinguish a charged replay from reaper-free
        # lost charge. The drain's apply_frozen_settle outcome disambiguates, and
        # marking done here would silently swallow a lost charge.
        # No timing line for replays: they would dominate the latency dataset
        # with noise instead of measuring full settle/refund work.
        try:
            refreshed = STORE.get_gateway_authorization(authorization.id) or authorization
        except Exception:
            if outbox_enqueued:
                logger.exception(
                    "settlement disposition read failed after durable intent "
                    "authorization_id=%s",
                    authorization.id,
                )
                return {"data": _intent_durable_gateway_data(authorization, durable_intent)}
            raise
        if refreshed.settled:
            return {"data": _already_settled_gateway_data(refreshed)}
        if settings.async_settle_protection and getattr(STORE, "_database", None) is not None:
            # The atomic async fence can reject a rolling synchronous writer
            # while the reservation remains open. Resolve its frozen winner,
            # including when the ordinary outbox feature flag has rolled back.
            from trusted_router.services.async_settle_handler import finish

            existing_outbox = spanner_settle_outbox()
            for existing_kind in (intent_kind, "refund" if success else "settle"):
                existing_intent = existing_outbox.get(authorization.id, existing_kind)
                if existing_intent is not None and existing_intent.async_version == 1:
                    finish(existing_intent, existing_outbox)
                    winner = STORE.get_gateway_authorization(authorization.id)
                    if winner is not None and winner.settled:
                        return {"data": _already_settled_gateway_data(winner)}
        if outbox_enqueued:
            return {"data": _intent_durable_gateway_data(refreshed, durable_intent)}
        return {"data": _already_settled_gateway_data(refreshed)}
    _record_user_model_gateway_outcome_safely(
        authorization,
        success=success,
        error_status=body.error_status,
        error_type=body.error_type,
    )
    if success and body.route_type in {"chat.completions", "responses", "messages"}:
        if (body.streamed and not body.usage_estimated and body.first_token_seconds
                and body.elapsed_seconds and body.elapsed_seconds > body.first_token_seconds
                and body.output_count > 1):
            ROUTING_STATE.observe(
                selected_endpoint.id, authorization.region or "",
                latency=body.first_token_seconds,
                throughput=(body.output_count - 1) / (body.elapsed_seconds - body.first_token_seconds),
            )
        # Only a successful, committed selected route can refresh affinity.
        # Implicit sessions need an observed, discounted cache hit.
        discounted_cache = any(
            tier.prompt_cached_price_microdollars_per_million_tokens is not None
            and tier.prompt_cached_price_microdollars_per_million_tokens < tier.prompt_price_microdollars_per_million_tokens
            for tier in selected_endpoint.price_tiers
        )
        if body.cache_affinity_key and (body.cache_affinity_explicit or (cache_read > 0 and discounted_cache)):
            ROUTING_STATE.remember(
                (authorization.key_hash, authorization.requested_model_id or authorization.model_id,
                 authorization.region or "", body.cache_affinity_key),
                selected_endpoint.id,
            )
    mark_ms = 0.0
    if settings.settle_outbox_enabled and outbox_enqueued and finalize_result.activity_indexed:
        if finalize_result.outbox_marked is not None:
            # Resolved inside the finalize commit; mark_ms stays 0.0 so the
            # timing line keeps its shape (finalize_ms now includes the mark).
            if not finalize_result.outbox_marked:
                logger.info(
                    "settle outbox done mark skipped authorization_id=%s intent_kind=%s; "
                    "row leased or already resolved; drain will re-derive done",
                    authorization.id,
                    intent_kind,
                )
        else:
            # Legacy finalize contract: the intent was not resolved in the
            # finalize commit, so resolve it here as before.
            mark_start = perf_counter()
            try:
                marked = spanner_settle_outbox().mark(authorization.id, intent_kind, done=True)
                if marked is None:
                    logger.info(
                        "settle outbox done mark skipped authorization_id=%s "
                        "intent_kind=%s; row leased or already resolved; drain will "
                        "re-derive done",
                        authorization.id,
                        intent_kind,
                    )
            except Exception:
                # Safe to swallow: §7 says a crash/failure after inline finalize
                # leaves a pending replay, and the drain will re-derive done via
                # ALREADY_SETTLED_WITH_CHARGE / ALREADY_SETTLED_LEGACY.
                logger.error(
                    "settle outbox done mark failed authorization_id=%s",
                    authorization.id,
                    exc_info=True,
                )
            mark_ms = (perf_counter() - mark_start) * 1000
    elif finalized and settings.settle_outbox_enabled and outbox_enqueued:
        logger.warning(
            "settle activity index pending repair authorization_id=%s",
            authorization.id,
        )

    if success and is_customer_billing_event and selected_usage_type == UsageType.CREDITS:
        _schedule_auto_refill(
            authorization.workspace_id,
            authorization.id,
            settings,
            background_tasks,
        )
    if success and is_customer_billing_event:
        if background_tasks is not None:
            background_tasks.add_task(
                record_successful_api_call_safely,
                authorization.workspace_id,
                model=generation_model_id,
                provider=generation_provider,
            )
        else:
            record_successful_api_call_safely(
                authorization.workspace_id,
                model=generation_model_id,
                provider=generation_provider,
            )
        # Alert-mode budgets: email the owner when a window is crossed (never
        # blocks — the block happens at authorize for limit-mode keys). Off the
        # hot path; best-effort.
        from trusted_router.services.budget_alerts import maybe_send_budget_alerts

        if background_tasks is not None:
            background_tasks.add_task(
                maybe_send_budget_alerts,
                api_key_hash=authorization.key_hash,
                workspace_id=authorization.workspace_id,
                settings=settings,
            )
        else:
            maybe_send_budget_alerts(
                api_key_hash=authorization.key_hash,
                workspace_id=authorization.workspace_id,
                settings=settings,
            )
    if success and generation is not None:
        # Keep S27 before the reply: successful enqueue is durable today and
        # there is no durable replay intent for a skipped broadcast enqueue.
        # Moving this to BackgroundTasks would lose jobs on process restart.
        # Customers' webhooks must not gain a new object silently: the
        # correlation id is useful to them, the client telemetry object is not.
        broadcast_settle_body = dict(settle_body)
        broadcast_settle_body.pop("client", None)
        # App attribution is frozen from the key at authorize. Never let a
        # caller-supplied root field become forgeable broadcast metadata.
        broadcast_settle_body.pop("app_id", None)
        broadcast_settle_body.pop("price_tier_input_tokens", None)
        try:
            enqueue_metadata_broadcast(generation, settle_body=broadcast_settle_body)
            broadcast_enqueued = True
        except Exception:
            # Billing is already committed. Metadata observability is
            # best-effort and must never rewrite a successful settlement as a
            # retryable 5xx, which could make the enclave replay billed work.
            logger.error(
                "broadcast_metadata_enqueue_failed generation_id=%s workspace_id=%s",
                generation.id,
                generation.workspace_id,
                exc_info=True,
            )
            broadcast_enqueued = False
        if broadcast_enqueued and should_drain_inline(settings) and background_tasks is not None:
            background_tasks.add_task(
                drain_broadcast_queue,
                settings=settings,
            )
        elif broadcast_enqueued and should_drain_inline(settings):
            drain_broadcast_queue(settings=settings)
    if refund_benchmark is not None and one_commit_result is None:
        # A one-commit refund already recorded this sample in its money commit.
        try:
            if background_tasks is not None:
                defer_post_commit(
                    background_tasks,
                    _record_refund_benchmark_safely,
                    refund_benchmark,
                    authorization.id,
                )
            else:
                _record_refund_benchmark_safely(refund_benchmark, authorization.id)
        except Exception:
            logger.warning(
                "provider benchmark write failed after refund finalize "
                "authorization_id=%s",
                authorization.id,
                exc_info=True,
            )

    total_ms = (perf_counter() - timing_start) * 1000
    # Request-log latency minus total_ms ~= Cloud Run queue + transport time;
    # that subtraction is the point of this line (2026-07-05 latency investigation).
    logger.info(
        "settle timing authorization_id=%s success=%s origin=%s total_ms=%.1f "
        "auth_ms=%.1f enqueue_ms=%.1f finalize_ms=%.1f mark_ms=%.1f "
        "commit_path=%s one_commit_ms=%.1f",
        authorization.id,
        success,
        "typed" if is_typed else "legacy",
        total_ms,
        auth_ms,
        enqueue_ms,
        finalize_ms,
        mark_ms,
        # one_commit: enqueue+finalize+mark in one commit. fallback: that
        # attempt was declined or failed (its time is one_commit_ms) and the
        # durable two-commit settle ran. two_commit: never attempted.
        (
            "one_commit"
            if one_commit_result is not None
            else "fallback" if one_commit_attempted else "two_commit"
        ),
        one_commit_ms,
    )
    return {
        "data": {
            "authorization_id": authorization.id,
            "settled": True,
            "disposition": "finalized",
            "finalization_outcome": "settled" if success else "refunded",
            "generation_id": generation_id,
            **money_pair("cost", actual_cost),
            "usage_type": selected_usage_type.value,
            "limit_usage_type": authorization.usage_type.value,
            "model": generation_model_id,
            "endpoint_id": selected_endpoint.id,
            "provider": generation_provider,
            "region": authorization.region,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "reasoning_tokens": int(body.reasoning_tokens or 0),
            "cache_read_input_tokens": int(body.cache_read_input_tokens or 0),
        }
    }


def _credit_user_model_payout_safely(
    authorization: Any,
    *,
    success: bool,
    payout: UserModelPayout | None,
) -> None:
    if not success or payout is None or payout.amount_microdollars <= 0:
        return
    try:
        STORE.credit_user_earnings(
            payout.owner_user_id,
            payout.amount_microdollars,
            user_model_payout_event_id(authorization.id),
            custom_model_id=payout.model_id,
            payer_workspace_id=payout.payer_workspace_id,
        )
    except Exception:
        logger.error(
            "user_model_payout_failed authorization_id=%s owner=%s",
            authorization.id,
            payout.owner_user_id,
            exc_info=True,
        )


def _credit_app_markup_payout_safely(
    authorization: Any,
    *,
    success: bool,
    payout: AppMarkupPayout | None,
) -> None:
    if not success or payout is None or payout.amount_microdollars <= 0:
        return
    try:
        STORE.credit_user_earnings(
            payout.owner_user_id,
            payout.amount_microdollars,
            app_markup_payout_event_id(authorization.id),
            custom_model_id=payout.app_id,
            payer_workspace_id=payout.payer_workspace_id,
        )
    except Exception:
        logger.error(
            "app_markup_payout_failed authorization_id=%s owner=%s",
            authorization.id,
            payout.owner_user_id,
            exc_info=True,
        )


def _credit_custom_model_markup_payout_safely(
    authorization: Any,
    *,
    success: bool,
    payout: CustomModelMarkupPayout | None,
) -> None:
    if not success or payout is None or payout.amount_microdollars <= 0:
        return
    try:
        STORE.credit_user_earnings(
            payout.owner_user_id,
            payout.amount_microdollars,
            custom_model_markup_payout_event_id(authorization.id),
            custom_model_id=payout.model_id,
            payer_workspace_id=payout.payer_workspace_id,
        )
    except Exception:
        logger.error(
            "custom_model_markup_payout_failed authorization_id=%s owner=%s",
            authorization.id,
            payout.owner_user_id,
            exc_info=True,
        )


def _release_user_model_slot_safely(authorization: Any) -> None:
    model_id = authorization.user_provided_model_id
    if not model_id:
        return
    try:
        release_user_model_slot(model_id, authorization.id)
    except Exception:
        logger.warning(
            "user_model_slot_release_failed authorization_id=%s model_id=%s",
            authorization.id,
            model_id,
            exc_info=True,
        )


def _record_user_model_gateway_outcome_safely(
    authorization: Any,
    *,
    success: bool,
    error_status: int | None,
    error_type: str | None,
) -> None:
    model_id = authorization.user_provided_model_id
    if not model_id:
        return
    dispatch_success: bool | None = True if success else None
    if not success and is_owner_fault(error_status, error_type):
        dispatch_success = False
    if dispatch_success is None:
        return
    try:
        record_user_model_gateway_result(
            model_id,
            success=dispatch_success,
        )
    except Exception:
        # Deleting or renaming the live model never invalidates frozen billing.
        logger.warning(
            "user_model_dispatch_result_failed authorization_id=%s model_id=%s",
            authorization.id,
            model_id,
            exc_info=True,
        )


def _already_settled_gateway_data(authorization: Any) -> dict[str, Any]:
    """Return the stable winner of a settle/refund race.

    The billing authorization payload is authoritative. Generation/activity
    mirrors may lag or fail after the Spanner money transaction commits, so
    their presence must never be used to distinguish a charge from a refund.
    """
    try:
        authorization = STORE.get_gateway_authorization(authorization.id) or authorization
    except Exception:
        # The caller already has an authoritative terminal record. A replay
        # lookup is useful for freshness, but it must not turn a known money
        # disposition into a retryable transport failure.
        logger.warning(
            "settlement replay refresh failed authorization_id=%s",
            authorization.id,
            exc_info=True,
        )
    outcome = str(authorization.finalization_outcome or "").strip().lower()
    data: dict[str, Any] = {
        "authorization_id": authorization.id,
        "settled": outcome in {"settled", "reaped_snapshot"},
        "already_settled": True,
        "disposition": _current_disposition(authorization),
        "finalization_outcome": outcome or "pending",
    }
    if outcome == "refunded":
        data.update(money_pair("cost", 0))
        return data
    if outcome not in {"settled", "reaped_snapshot"}:
        # Rolling records without the explicit outcome fail closed. A missing
        # analytics generation cannot be interpreted as a refund.
        return data
    if authorization.finalized_generation_id:
        data["generation_id"] = authorization.finalized_generation_id
    data.update(money_pair("cost", int(authorization.finalized_cost_microdollars or 0)))
    if authorization.finalized_usage_type:
        data["usage_type"] = authorization.finalized_usage_type
    if authorization.finalized_model_id:
        data["model"] = authorization.finalized_model_id
    if authorization.finalized_provider:
        data["provider"] = authorization.finalized_provider
    if authorization.finalized_region:
        data["region"] = authorization.finalized_region
    data["input_tokens"] = int(authorization.finalized_input_tokens or 0)
    data["output_tokens"] = int(authorization.finalized_output_tokens or 0)
    data["reasoning_tokens"] = int(authorization.finalized_reasoning_tokens or 0)
    data["cache_read_input_tokens"] = int(authorization.finalized_cached_input_tokens or 0)
    return data


def _current_disposition(authorization: Any) -> str:
    outcome = str(authorization.finalization_outcome or "").strip().lower()
    if outcome == "reaped_snapshot":
        return "reaped_snapshot"
    if authorization.settled:
        return "already_finalized"
    return "intent_durable"


def _gateway_authorization_kind(authorization: GatewayAuthorization) -> str:
    if authorization.settlement in {"regional_lease", "spend_lease", "deferred_home"}:
        return "regional_lease"
    if authorization.settlement == "local" and typed_billing_store(STORE) is not None:
        return "local_typed"
    return "legacy"


def _gateway_evidence_disposition(authorization: GatewayAuthorization) -> str | None:
    outcome = str(authorization.finalization_outcome or "").strip().lower()
    if outcome in {"settled", "refunded"}:
        return "finalized"
    if outcome == "reaped_snapshot":
        return "reaped_snapshot"
    if authorization.settled:
        return "already_finalized"
    return None


def _intent_durable_gateway_data(
    authorization: Any, intent: SettleOutboxRow | None = None
) -> dict[str, Any]:
    data: dict[str, Any] = {
        "authorization_id": authorization.id,
        "settled": False,
        "already_settled": False,
        "disposition": "intent_durable",
        "finalization_outcome": "pending",
    }
    if intent is not None:
        data.update(money_pair("cost", intent.actual_cost_micro))
        if intent.model_id:
            data["model"] = intent.model_id
        if intent.selected_usage_type:
            data["usage_type"] = intent.selected_usage_type
        endpoint = endpoint_for_id(intent.selected_endpoint_id)
        if endpoint is not None:
            data["provider"] = endpoint.provider
    return data


def _settle_body_with_safe_attribution(
    body: GatewaySettleRequest, authorization_id: str
) -> dict[str, Any]:
    settle_body = body.model_dump(exclude_none=True)
    settle_body.pop("tags", None)
    attribution_keys = (
        "user",
        "session_id",
        "trace",
        "app",
        "http_referer",
        "app_categories",
    )
    try:
        attribution = validate_request_attribution(
            user=body.user,
            session_id=body.session_id,
            trace=body.trace,
            app=body.app,
            http_referer=body.http_referer,
            app_categories=body.app_categories,
        )
    except InvalidAttribution as exc:
        for key in attribution_keys:
            settle_body.pop(key, None)
        logger.warning(
            "invalid gateway settlement attribution dropped authorization_id=%s error_class=%s",
            authorization_id,
            type(exc).__name__,
        )
        return settle_body
    for key in attribution_keys:
        settle_body.pop(key, None)
    settle_body.update(attribution.body_fields())
    return settle_body


def _settle_body_with_safe_client_context(
    settle_body: dict[str, Any], authorization_id: str
) -> dict[str, Any]:
    """Soft-validate the enclave's client telemetry; drop it rather than 4xx.

    Telemetry may never fail settlement. Anything that does not match the
    closed vocabulary in ``client_context`` is removed and logged; the money
    path continues unchanged.
    """
    if "client" in settle_body:
        client_context = parse_client_context(settle_body.get("client"))
        if client_context is None:
            settle_body.pop("client", None)
            logger.warning(
                "invalid gateway settlement client context dropped "
                "authorization_id=%s error_class=%s",
                authorization_id,
                "ValidationError",
            )
        else:
            settle_body["client"] = client_context.model_dump(exclude_none=True)

    if "gateway_request_id" in settle_body:
        gateway_request_id = parse_gateway_request_id(settle_body.get("gateway_request_id"))
        if gateway_request_id is None:
            settle_body.pop("gateway_request_id", None)
        else:
            settle_body["gateway_request_id"] = gateway_request_id
    return settle_body


def _settle_repair_metadata(settle_body: dict[str, Any]) -> dict[str, Any]:
    """Freeze only fields needed to reconstruct activity metadata.

    The durable outbox is an operational repair log, not a content store.
    Lenient request extras, trace dictionaries, and arbitrary metadata are
    deliberately excluded. The one metadata bit retained marks synthetic
    traffic so repaired rows stay out of public provider benchmarks.
    """
    frozen = {key: value for key, value in settle_body.items() if key in _SETTLE_REPAIR_FIELDS}
    metadata = settle_body.get("metadata")
    if isinstance(metadata, dict) and _synthetic_metadata_enabled(metadata):
        frozen["metadata"] = {"trustedrouter_synthetic": "true"}
    return frozen


def _synthetic_metadata_enabled(metadata: dict[str, Any]) -> bool:
    return str(metadata.get("trustedrouter_synthetic")).strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def _authorization_is_synthetic(authorization: Any) -> bool:
    tags = getattr(authorization, "tags", None)
    return isinstance(tags, dict) and tags.get("purpose") == "synthetic_monitoring"


def _is_synthetic_settlement(
    body: GatewaySettleRequest,
    authorization: Any | None = None,
) -> bool:
    if authorization is not None and _authorization_is_synthetic(authorization):
        return True
    if body.app == "TrustedRouter Synthetic":
        return True
    metadata = body.metadata
    if not isinstance(metadata, dict):
        return False
    return _synthetic_metadata_enabled(metadata)


def _gateway_candidate_payload(
    model: Model,
    endpoint: ModelEndpoint,
    workspace_id: str,
    region: str,
    *,
    byok_configs: dict[str, Any] | None = None,
) -> dict[str, Any]:
    usage_type = UsageType.for_endpoint(endpoint)
    byok_config = (
        _get_byok_provider(workspace_id, endpoint.provider, byok_configs) if usage_type.is_byok() else None
    )
    return {
        "endpoint_id": endpoint.id,
        "model": model.id,
        "upstream_model": endpoint.upstream_id or model.id,
        "provider": endpoint.provider,
        "provider_name": (PROVIDERS[endpoint.provider].name if endpoint.provider in PROVIDERS else endpoint.provider),
        "inference_location": inference_location_metadata(endpoint.provider, model.id),
        **_gateway_provider_route_payload(endpoint),
        "usage_type": usage_type.value,
        **_gateway_byok_payload(byok_config, workspace_id),
        "region": region,
    }

def _gateway_provider_route_payload(endpoint: ModelEndpoint) -> dict[str, Any]:
    """Return provider-specific, typed enforcement metadata for the enclave."""

    if endpoint.provider == "wafer" and endpoint_zero_data_retention(endpoint) is True:
        return {"wafer_zdr_required": True}
    return {}


def _gateway_byok_payload(byok_config: Any | None, workspace_id: str) -> dict[str, Any]:
    if byok_config is None:
        return {
            "byok_secret_ref": None,
            "byok_encrypted_secret": None,
            "byok_cache_key": None,
            "byok_key_hint": None,
            "byok_provider": None,
        }
    envelope_provider = str(byok_config.provider)
    return {
        "byok_secret_ref": byok_config.secret_ref,
        "byok_encrypted_secret": encrypted_secret_payload(byok_config.encrypted_secret),
        "byok_cache_key": byok_cache_key(
            byok_config.encrypted_secret,
            workspace_id=workspace_id,
            provider=envelope_provider,
        ),
        "byok_key_hint": byok_config.key_hint,
        "byok_provider": envelope_provider,
    }


def _user_model_gateway_candidate(
    user_model: UserProvidedModel,
) -> tuple[Model, ModelEndpoint]:
    """Build the Credits-only authorization sentinel for owner dispatch.

    User-provided models deliberately do not enter the frozen catalog.  The
    gateway still needs a stable model/endpoint pair for its reservation
    record, so this pair exists only inside the authorization response; the
    enclave resolves the actual owner dispatch block separately.
    """
    return user_model_gateway_pair(
        model_id=user_model.id,
        name=user_model.name,
        revision=user_model.revision,
        prompt_price_microdollars_per_m=(user_model.prompt_price_microdollars_per_million_tokens),
        completion_price_microdollars_per_m=(
            user_model.completion_price_microdollars_per_million_tokens
        ),
        owner_user_id=user_model.owner_user_id,
        upstream_model_id=user_model.upstream_model_id,
    )


def _authorized_user_model_pair(
    authorization: Any,
) -> tuple[Model, ModelEndpoint] | None:
    """Rebuild a user-model sentinel only from authorization-frozen money facts.

    The live model is consulted solely for a display name. Its deletion,
    revision, prices, owner, endpoint, and secret material have no authority
    over settlement.
    """
    model_id = authorization.user_provided_model_id
    if not model_id:
        return None
    name = model_id
    try:
        live_model = STORE.get_user_model(model_id)
    except Exception:
        live_model = None
    if live_model is not None:
        name = live_model.name
    revision = authorization.user_provided_model_revision
    prompt_price = authorization.user_model_prompt_price_microdollars_per_m
    completion_price = authorization.user_model_completion_price_microdollars_per_m
    owner_user_id = authorization.user_model_owner_user_id
    if revision is None or prompt_price is None or completion_price is None or not owner_user_id:
        return None
    try:
        return user_model_gateway_pair(
            model_id=model_id,
            name=name,
            revision=int(revision),
            prompt_price_microdollars_per_m=int(prompt_price),
            completion_price_microdollars_per_m=int(completion_price),
            owner_user_id=owner_user_id,
            upstream_model_id=model_id,
        )
    except (TypeError, ValueError):
        return None


def _byok_configs_for_candidates(
    candidates: list[tuple[Model, ModelEndpoint]], workspace_id: str,
    *, folded_rows: dict[str, str] | None = None,
) -> dict[str, Any]:
    # Preserve alias preference in _get_byok_provider, deduplicate only the IO.
    providers = sorted({
        slug
        for _, endpoint in candidates
        if UsageType.for_endpoint(endpoint).is_byok()
        for slug in byok_storage_provider_candidates(endpoint.provider)
    })
    if folded_rows is not None:
        # Imported workspace ids can contain '#'. Match the COMPLETE entity id
        # before decoding so ws#other cannot contribute credentials to ws.
        # The range is complete: even a newly resolved slug has explicit absence.
        return {
            provider: decode_auth_record(raw, ByokProviderConfig) if raw is not None else None
            for provider in providers
            for raw in [folded_rows.get(f"{workspace_id}#{provider}")]
        }
    batch = getattr(STORE, "get_byok_providers", None)
    if callable(batch):
        return cast(dict[str, Any], batch(workspace_id, providers))
    return {provider: STORE.get_byok_provider(workspace_id, provider) for provider in providers}


def _eligible_gateway_endpoint_candidates(
    candidates: list[tuple[Model, ModelEndpoint]],
    workspace_id: str,
    byok_configs: dict[str, Any] | None = None,
) -> list[tuple[Model, ModelEndpoint]]:
    out: list[tuple[Model, ModelEndpoint]] = []
    for model, endpoint in candidates:
        usage_type = UsageType.for_endpoint(endpoint)
        if usage_type.is_byok() and _get_byok_provider(workspace_id, endpoint.provider, byok_configs) is None:
            continue
        out.append((model, endpoint))
    return out


def _get_byok_provider(
    workspace_id: str, provider: str, byok_configs: dict[str, Any] | None = None,
) -> Any | None:
    for storage_slug in byok_storage_provider_candidates(provider):
        config = (
            byok_configs[storage_slug]
            if byok_configs is not None and storage_slug in byok_configs
            else STORE.get_byok_provider(workspace_id, storage_slug)
        )
        if config is not None:
            return config
    return None


def _select_authorized_endpoint(
    authorization: Any, body: GatewaySettleRequest
) -> ModelEndpoint | None:
    user_model_pair = _authorized_user_model_pair(authorization)
    if user_model_pair is not None:
        frozen_model, frozen_endpoint = user_model_pair
        if body.selected_endpoint_id not in {None, frozen_endpoint.id}:
            return None
        # The enclave may echo the caller's raw spelling of the id
        # ("TrustedRouter/User-Foo", the short "user-foo" alias); authorize
        # normalized it before freezing, so compare normalized. A refused
        # settle here strands the hold, so be no stricter than the id grammar.
        selected_model_id = body.selected_model_id
        if (
            selected_model_id is not None
            and normalize_user_provided_model_id(selected_model_id) != frozen_model.id
        ):
            return None
        return frozen_endpoint
    authorized_endpoint_ids = authorization.candidate_endpoint_ids or []
    if not authorized_endpoint_ids and authorization.endpoint_id:
        authorized_endpoint_ids = [authorization.endpoint_id]
    selected_endpoint_id = body.selected_endpoint_id
    if selected_endpoint_id is not None:
        if selected_endpoint_id not in authorized_endpoint_ids:
            return None
        return _endpoint_for_id_compat(selected_endpoint_id)

    selected_model_id = body.selected_model_id or authorization.model_id
    if selected_model_id == authorization.model_id and authorization.endpoint_id:
        return _endpoint_for_id_compat(authorization.endpoint_id)

    for endpoint_id in authorized_endpoint_ids:
        endpoint = _endpoint_for_id_compat(endpoint_id)
        if endpoint is not None and endpoint.model_id == selected_model_id:
            return endpoint

    authorized_model_ids = authorization.candidate_model_ids or [authorization.model_id]
    if selected_model_id not in authorized_model_ids:
        return None
    model = MODELS.get(selected_model_id)
    return default_endpoint_for_model(model) if model is not None else None


def _endpoint_for_id_compat(endpoint_id: str) -> ModelEndpoint | None:
    endpoint = endpoint_for_id(endpoint_id)
    if endpoint is not None:
        return endpoint

    model_id, separator, usage_suffix = endpoint_id.partition("@gemini/")
    if not separator or usage_suffix not in {"prepaid", "byok"}:
        return None
    model = MODELS.get(model_id)
    if model is None:
        return None

    # Before the split, prepaid chat used Vertex while Gemini embeddings and
    # BYOK used AI Studio. Preserve that exact route when an authorization
    # created by the old control plane settles or replays after deployment.
    provider = (
        "google-ai-studio"
        if usage_suffix == "byok" or model.supports_embeddings
        else "google-vertex"
    )
    return endpoint_for_id(f"{model_id}@{provider}/{usage_suffix}")


def _requested_service_tier_or_error(service_tier: str | None) -> str | None:
    if service_tier is None:
        return None
    normalized = service_tier.strip().lower()
    if normalized not in OPENAI_SERVICE_TIERS:
        raise api_error(
            400,
            "service_tier must be default, auto, or priority",
            ErrorType.BAD_REQUEST,
        )
    return normalized


# Providers name the ordinary, non-expedited tier differently. Anthropic
# reports usage.service_tier="standard"; OpenAI reports "default". They mean
# the same thing and price the same, so both settle as "default".
#
# Deliberately NOT aliased: Anthropic "batch" and OpenAI "flex"/"scale" are
# cheaper tiers, and quietly settling one of those as "default" would overcharge
# the customer. An unrecognized tier still fails loudly rather than mis-pricing.
_SERVICE_TIER_SYNONYMS = {"standard": "default"}


def _actual_service_tier_or_error(service_tier: str | None) -> str | None:
    if service_tier is None:
        return None
    normalized = service_tier.strip().lower()
    normalized = _SERVICE_TIER_SYNONYMS.get(normalized, normalized)
    if normalized not in {"default", "priority"}:
        raise api_error(
            400,
            "settlement service_tier must be the actual default or priority tier",
            ErrorType.BAD_REQUEST,
        )
    return normalized


def _service_tier_endpoint_candidates_or_error(
    candidates: list[tuple[Model, ModelEndpoint]],
    *,
    service_tier: str | None,
    estimated_input_tokens: int,
) -> list[tuple[Model, ModelEndpoint]]:
    if service_tier is None:
        return candidates
    openai_candidates = [
        (model, endpoint) for model, endpoint in candidates if endpoint.provider == "openai"
    ]
    if service_tier in {"auto", "priority"}:
        openai_candidates = [
            (model, endpoint)
            for model, endpoint in openai_candidates
            if openai_priority_pricing(endpoint.model_id) is not None
        ]
    if service_tier == "priority" and estimated_input_tokens > OPENAI_PRIORITY_MAX_PROMPT_TOKENS:
        raise api_error(
            400,
            "OpenAI Priority processing does not support prompts over 272000 tokens",
            ErrorType.BAD_REQUEST,
        )
    if not openai_candidates:
        raise api_error(
            400,
            f"OpenAI {service_tier} processing is unavailable for the requested model",
            ErrorType.MODEL_NOT_SUPPORTED,
        )
    return openai_candidates


def _is_native_batch_route(route_type: str | None) -> bool:
    return (route_type or "").strip().lower().startswith(_NATIVE_BATCH_ROUTE_PREFIX)


def _native_batch_eligibility(
    *,
    route_type: str | None,
    retention_allowed: bool,
    model_usage_type: UsageType,
    custom_model: Any | None,
    broadcast_destinations: list[dict[str, Any]],
    requested_model_id: str,
    endpoint: ModelEndpoint,
) -> bool:
    """Freeze the provider-retention and discount decision at authorization."""
    return (
        _is_native_batch_route(route_type)
        and retention_allowed
        and model_usage_type == UsageType.CREDITS
        and custom_model is None
        and not broadcast_destinations
        and not requested_model_id.strip().lower().startswith("trustedrouter/")
        and endpoint.provider.strip().lower() in _NATIVE_BATCH_BILLED_FRACTION_BPS
    )


def _native_batch_request_allows_retention(body: dict[str, Any], settings: Settings) -> bool:
    """Fail closed on privacy/routing metadata visible to the control plane.

    Provider-native Batch APIs temporarily retain request and result content.
    The measured enclave separately validates the complete request body with a
    strict field allowlist before exporting content. This second gate covers
    the non-content routing state the control plane can independently verify.
    """
    if body.get("models"):
        return False
    if ":" in str(body.get("model") or ""):
        # Native Batch retention is an opt-in contract. Keep every shorthand
        # model variant on the managed path until that suffix is explicitly
        # audited, even when today's suffix changes only price or throughput.
        return False
    if body.get("service_tier"):
        return False
    if any(
        key in body
        for key in {
            "zdr",
            "e2e",
            "confidential",
            "data_collection",
            "min_privacy",
            "jurisdiction",
            "store",
        }
    ):
        return False
    provider = body.get("provider")
    if provider is not None and (
        not isinstance(provider, dict)
        or any(key not in _NATIVE_BATCH_PROVIDER_FIELDS for key in provider)
    ):
        return False
    provider = provider or {}
    if (
        str(provider.get("data_collection") or "").strip().lower() == "deny"
        or bool(str(provider.get("min_privacy") or "").strip())
        or bool(str(provider.get("jurisdiction") or "").strip())
        or str(provider.get("usage") or "").strip().lower() == "byok"
    ):
        return False
    preferences = resolved_route_preferences(body, settings)
    return not (
        preferences.data_collection == "deny"
        or preferences.min_privacy_rank > 0
        or preferences.provider_jurisdiction is not None
        or preferences.usage_type == "BYOK"
    )


def _is_native_batch_idempotency_key(idempotency_key: str | None) -> bool:
    return (idempotency_key or "").startswith("tr-native-batch:")


def _require_native_batch_route_binding(
    route_type: str | None,
    idempotency_key: str | None,
) -> None:
    if _is_native_batch_route(route_type) != _is_native_batch_idempotency_key(idempotency_key):
        raise api_error(
            400,
            "native Batch route must use its enclave-generated idempotency key",
            ErrorType.BAD_REQUEST,
        )


def _authorization_ttl_seconds(route_type: str | None) -> int:
    return 26 * 60 * 60 if _is_native_batch_route(route_type) else GATEWAY_RESERVATION_TTL_SECONDS


def _native_batch_cost_or_error(
    cost_microdollars: int,
    *,
    route_type: str | None,
    provider: str,
    idempotency_key: str | None = None,
    native_batch_eligible: bool = False,
    selected_usage_type: UsageType = UsageType.CREDITS,
) -> int:
    if not _is_native_batch_route(route_type):
        if _is_native_batch_idempotency_key(idempotency_key):
            raise api_error(
                400,
                "native Batch authorization requires native Batch settlement",
                ErrorType.BAD_REQUEST,
            )
        return cost_microdollars
    _require_native_batch_route_binding(route_type, idempotency_key)
    if not native_batch_eligible:
        raise api_error(
            400,
            "authorization is not eligible for native Batch settlement",
            ErrorType.BAD_REQUEST,
        )
    if selected_usage_type != UsageType.CREDITS:
        raise api_error(
            400,
            "native Batch settlement requires a prepaid provider route",
            ErrorType.MODEL_NOT_SUPPORTED,
        )
    billed_fraction_bps = _NATIVE_BATCH_BILLED_FRACTION_BPS.get(provider.strip().lower())
    if billed_fraction_bps is None:
        raise api_error(
            400,
            "selected provider does not support TrustedRouter native Batch settlement",
            ErrorType.MODEL_NOT_SUPPORTED,
        )
    if cost_microdollars <= 0:
        return 0
    # Round upward so a positive billable request never disappears below the
    # integer microdollar ledger's minimum unit.
    return max(1, (cost_microdollars * billed_fraction_bps + 9_999) // 10_000)


def _provider_price_tier_input_tokens(
    endpoint: ModelEndpoint,
    reported_input_tokens: int | None,
) -> int | None:
    """Admit a provider-private tier basis only for its pinned model contract."""

    if endpoint.provider == "sakana" and endpoint.model_id == SAKANA_FUGU_MODEL_ID:
        return reported_input_tokens
    return None


def _endpoint_cost_microdollars(
    endpoint: ModelEndpoint,
    input_tokens: int,
    output_tokens: int,
    *,
    cache_read_tokens: int = 0,
    cache_creation_tokens: int = 0,
    price_tier_input_tokens: int | None = None,
    effective_at: datetime | str | None = None,
    service_tier: str | None = None,
    reserve_auto: bool = False,
) -> int:
    """input_tokens must be the UNCACHED prompt tokens when cache counts
    are passed — cached reads/writes bill at the provider-specific
    multiple of the prompt price (see catalog.cache_token_prices_microdollars)."""
    endpoint = effective_endpoint(endpoint, at=effective_at)
    # A reseller may echo its upstream's tier; it does not change the
    # reseller's authorized catalog tariff. Only direct OpenAI routes use
    # OpenAI Priority prices, regardless of the publisher in model_id.
    if endpoint.provider == "openai" and (
        service_tier == "priority" or (service_tier == "auto" and reserve_auto)
    ):
        return openai_priority_cost_microdollars(
            endpoint.model_id,
            input_tokens,
            output_tokens,
            cache_read_tokens=cache_read_tokens,
            cache_creation_tokens=cache_creation_tokens,
        )
    document = endpoint_pricing_document((endpoint,))
    return _endpoint_cost_microdollars_from_document(
        document,
        endpoint.id,
        input_tokens,
        output_tokens,
        cache_read_tokens=cache_read_tokens,
        cache_creation_tokens=cache_creation_tokens,
        price_tier_input_tokens=price_tier_input_tokens,
    )


def _endpoint_cost_microdollars_from_document(
    document: dict[str, Any],
    endpoint_id: str,
    input_tokens: int,
    output_tokens: int,
    *,
    cache_read_tokens: int = 0,
    cache_creation_tokens: int = 0,
    price_tier_input_tokens: int | None = None,
) -> int:
    """The Stage D cost path, with the frozen document as its sole price input."""
    return _stage_d_document_cost(
        document,
        endpoint_id,
        input_tokens,
        output_tokens,
        cache_read_tokens=cache_read_tokens,
        cache_creation_tokens=cache_creation_tokens,
        price_tier_input_tokens=price_tier_input_tokens,
    )


def _partner_billing_mode_or_error(
    *,
    requested_model_id: str | None,
    route_type: str | None,
    idempotency_key: str | None,
) -> PartnerBillingMode | None:
    try:
        return partner_billing_mode(
            requested_model_id=requested_model_id,
            route_type=route_type,
            idempotency_key=idempotency_key,
        )
    except ValueError as exc:
        raise api_error(400, str(exc), ErrorType.BAD_REQUEST) from exc


def _schedule_auto_refill(
    workspace_id: str,
    authorization_id: str,
    settings: Settings,
    background_tasks: BackgroundTasks | None,
) -> None:
    from trusted_router.services.auto_refill import (
        maybe_charge_after_settle,
        settlement_auto_refill_idempotency_key,
    )

    # The internal surface has no Stripe credential. Its successful credit
    # settlement attached durable refill work to the settlement outbox row;
    # the control-owned drain performs the charge. Combined preserves the
    # legacy in-process behavior below.
    if settings.service_surface == "internal":
        return
    idempotency_key = settlement_auto_refill_idempotency_key(authorization_id)
    if background_tasks is not None:
        background_tasks.add_task(
            maybe_charge_after_settle,
            workspace_id,
            settings=settings,
            idempotency_key=idempotency_key,
        )
        return
    maybe_charge_after_settle(
        workspace_id,
        settings=settings,
        idempotency_key=idempotency_key,
    )
