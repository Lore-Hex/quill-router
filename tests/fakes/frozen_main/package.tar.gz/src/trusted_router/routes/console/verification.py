"""Account verification checklist and identity-verification launch."""

from __future__ import annotations

from fastapi import FastAPI, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, Response

from trusted_router import phone_verification as pv
from trusted_router.auth import SettingsDep
from trusted_router.config import Settings
from trusted_router.creator_identity import validate_creator_username
from trusted_router.identity_guidance import guidance_for
from trusted_router.money import (
    VERIFF_ATTEMPT_FEE_MICRODOLLARS,
    VERIFICATION_MIN_LIFETIME_TOPUP_MICRODOLLARS,
    format_money_display,
)
from trusted_router.routes.console._shared import ConsoleDep, render
from trusted_router.routes.identity_verify import start_identity_session
from trusted_router.storage import STORE
from trusted_router.verification_gates import missing_identity_verification_requirements


def register(app: FastAPI) -> None:
    @app.get("/console/account/verification")
    def console_verification(
        ctx: ConsoleDep,
        settings: SettingsDep,
        error: str = "",
        veriff: str = "",
        dev: str = "",
    ) -> Response:
        # The console dependency resolved this user in the same strong read as
        # the session; fetching it again would only add another round trip.
        user = ctx.user
        # Page progress only. Reuse this bounded-stale total for the displayed
        # checklist; the identity-start POST calls the same helper without an
        # override and therefore retains its strong authorization read.
        lifetime_topup = STORE.get_lifetime_topup_microdollars(
            user.id,
            allow_stale=True,
        )
        required = VERIFICATION_MIN_LIFETIME_TOPUP_MICRODOLLARS
        missing = missing_identity_verification_requirements(
            user,
            settings,
            lifetime_topup_microdollars=lifetime_topup,
        )
        guidance = guidance_for(
            user.identity_status,
            reason_code=user.veriff_decision_reason_code,
        )
        identity_labels = {
            "none": "Not started",
            "pending": "Pending",
            "approved": "Approved",
            "declined": "Declined",
            "resubmission_requested": "Resubmission requested",
            "expired": "Expired",
        }
        return HTMLResponse(
            render(
                "console/account/verification.html",
                settings=settings,
                ctx=ctx,
                active="verification",
                page_title="Account verification",
                page_subtitle="Complete each check once to unlock verified account features.",
                current_user=user,
                username_error=error if error.startswith("username_") else "",
                error=error,
                veriff_done=veriff == "done",
                dev_approved=bool(dev),
                lifetime_topup=lifetime_topup,
                lifetime_topup_display=format_money_display(lifetime_topup),
                lifetime_topup_required_display=format_money_display(required),
                lifetime_topup_required=required,
                lifetime_progress=min(100, int(lifetime_topup * 100 / required)),
                phone_funding_unlocked=lifetime_topup > 0,
                phone_requires_identity=pv.console_phone_requires_identity(user),
                identity_fee_display=format_money_display(
                    VERIFF_ATTEMPT_FEE_MICRODOLLARS
                ),
                identity_missing_requirements=missing,
                identity_missing_labels=[
                    _REQUIREMENT_LABELS.get(key, key) for key in missing
                ],
                identity_status=user.identity_status,
                identity_status_label=identity_labels.get(
                    user.identity_status,
                    "Not started",
                ),
                identity_action_label=_identity_action_label(user.identity_status),
                identity_guidance=guidance,
                identity_action_enabled=(
                    not missing
                    and not user.identity_verified
                    and _veriff_available(settings)
                ),
                veriff_available=_veriff_available(settings),
            )
        )

    @app.post("/console/account/verification/identity/start")
    def console_start_identity(
        ctx: ConsoleDep,
        settings: SettingsDep,
    ) -> Response:
        user = STORE.get_user(ctx.user.id) or ctx.user
        try:
            result = start_identity_session(
                user=user,
                workspace_id=ctx.workspace.id,
                settings=settings,
            )
        except HTTPException as exc:
            if exc.status_code == 402:
                error = "insufficient"
            elif exc.status_code == 403:
                error = "prereqs"
            elif exc.status_code == 409:
                return _back("")
            else:
                error = "veriff_unavailable"
            return _back(f"error={error}")
        return RedirectResponse(url=result.url, status_code=303)

    @app.post("/console/account/verification/username")
    def console_claim_creator_username(
        ctx: ConsoleDep,
        username: str = Form(..., min_length=3, max_length=32),
    ) -> Response:
        user = STORE.get_user(ctx.user.id) or ctx.user
        if not user.identity_verified or not (user.identity_verified_name or "").strip():
            return _back("error=username_verification")
        try:
            STORE.claim_user_username(user.id, validate_creator_username(username))
        except ValueError as exc:
            error = str(exc)
            if error == "creator_username_taken":
                return _back("error=username_taken")
            if error == "creator_username_immutable":
                return _back("error=username_immutable")
            return _back("error=username_invalid")
        return _back("username=saved")


#: The API keeps the machine-readable keys; the page shows words. A person
#: reading "phone_verified" is reading our schema, not an instruction.
_REQUIREMENT_LABELS = {
    "email": "a verified email address",
    "funding": "the minimum lifetime top-up",
}


def _identity_action_label(status: str) -> str:
    if status in {"declined", "resubmission_requested", "expired"}:
        return "Retry identity verification"
    if status == "pending":
        return "Resume identity verification"
    return "Start identity verification"


def _veriff_available(settings: Settings) -> bool:
    return settings.veriff_enabled or (
        settings.environment.lower() in {"local", "test"}
        and not settings.veriff_configured
    )


def _back(query: str) -> RedirectResponse:
    url = "/console/account/verification"
    if query:
        url += f"?{query}"
    return RedirectResponse(url=url, status_code=303)
