"""Pinned provider contract identifiers shared by runtime and refresh code."""

SAKANA_FUGU_MODEL_ID = "sakana-ai/fugu-ultra-v1.1"
SAKANA_NAMAZU_MODEL_ID = "sakana-ai/sakana-namazu-v1.0"
SAKANA_NAMAZU_ROUTE_HOLD_REASON = "provider-geographic-restriction"
NEXTBIT_UNSLOPNEMO_MODEL_ID = "thedrummer/unslopnemo-12b-v4.1"
NEXTBIT_UNSLOPNEMO_HOLD_REASON = "provider-alias-unavailable"
THIRD_PARTY_PASSTHROUGH_HOLD_REASON = "third-party-passthrough-disabled"
# These providers also advertise third-party API wrappers. Only their native
# hosted namespaces may route here; the original providers serve passthroughs.
_NATIVE_HOSTED_MODEL_PREFIXES = {
    "lightning": "lightning-ai/",
    "cloudflare-workers-ai": "@cf/",
}
_NATIVE_HOSTED_MODEL_EXCEPTIONS = frozenset({
    # Reviewed Workers AI early-access deployment, before model-search listing.
    ("cloudflare-workers-ai", "moonshotai/kimi-k3"),
})
# Hold a provider's prepaid routes when its operator key is rejected, e.g.
# {"crusoe": "operator-credential-rejected"}. Catalog discovery can succeed
# without validating inference credentials, so clear a hold only after a
# paid-path canary with the replacement key. Holds never affect a customer's
# own BYOK credentials. Crusoe (held October 3) was cleared on October 5 after
# its replacement key passed paid-path canaries.
PREPAID_PROVIDER_HOLD_REASONS: dict[str, str] = {}
OPERATOR_HELD_PROVIDER_MODELS = frozenset(
    {
        ("sakana", SAKANA_NAMAZU_MODEL_ID),
        # A listed alias is not proof of serving availability. Require a
        # reviewed recovery before refresh can re-enable this route.
        ("nextbit", NEXTBIT_UNSLOPNEMO_MODEL_ID),
        # September 20: discovery admits these standard RedPill IDs, but the
        # enclave's reviewed Phala dispatch map does not. Keep them out of
        # routing until a reviewed adapter release, not an attestation bypass.
        ("phala", "z-ai/glm-5.3"),
        ("phala", "z-ai/glm-5.3-flash"),
    }
)
EXACT_GLOBAL_SETTLEMENT_PROVIDER_MODELS = frozenset(
    {
        ("sakana", SAKANA_FUGU_MODEL_ID),
    }
)

# Native task meters include provider-side preprocessing. Preserve the exact
# reported input count, and do not apply the generic output-token price floor.
INPUT_ONLY_PROVIDER_MODELS = frozenset(
    ("scaledown", f"scaledown/{task}")
    for task in ("compress", "summarize", "extract", "classify")
)
EXACT_GLOBAL_SETTLEMENT_PROVIDER_MODELS |= INPUT_ONLY_PROVIDER_MODELS
PASSTHROUGH_RETAIL_PROVIDER_MODELS = frozenset(
    {
        # Match the public Fugu price used by other router marketplaces while
        # preserving Sakana's exact first-party cost in its manifest.
        ("sakana", SAKANA_FUGU_MODEL_ID),
    }
)
UNSUPPORTED_GATEWAY_REGIONS_BY_PROVIDER_MODEL = {
    # Sakana's API terms exclude the EEA, UK, and Switzerland, and the provider
    # may enforce that boundary by source IP. The Europe gateway therefore
    # cannot authorize Fugu until Sakana expands its supported regions.
    ("sakana", SAKANA_FUGU_MODEL_ID): frozenset({"europe-west4"}),
    ("sakana", SAKANA_NAMAZU_MODEL_ID): frozenset({"europe-west4"}),
}

# Fugu reports additive provider-side orchestration tokens only after a call.
# They are included in exact settlement, but may exceed the caller-derived
# estimate. Regional quota leases cap settlement to their initial escrow, so
# Fugu must stay on the global typed ledger until leases support exact overruns.

# Sakana's terms exclude the EEA, UK, and Switzerland, and its edge returns an
# HTML 403 to the europe-west4 gateway. The canonical API currently includes
# every gateway region in one DNS answer, so a region-local exclusion would
# make ordinary Namazu calls fail nondeterministically. Keep the discovered
# model visible but globally unroutable until canonical steering can guarantee
# a supported egress region without bypassing Sakana's geographic policy.


def provider_model_operator_held(
    provider_slug: str, model_id: str, upstream_id: str | None = None,
) -> bool:
    native_prefix = _NATIVE_HOSTED_MODEL_PREFIXES.get(provider_slug)
    native_id = upstream_id or model_id
    if native_prefix is not None and not native_id.startswith(native_prefix):
        if (provider_slug, native_id) not in _NATIVE_HOSTED_MODEL_EXCEPTIONS:
            return True
    return (provider_slug, model_id) in OPERATOR_HELD_PROVIDER_MODELS


def provider_model_requires_exact_global_settlement(
    provider_slug: str,
    model_id: str,
) -> bool:
    return (provider_slug, model_id) in EXACT_GLOBAL_SETTLEMENT_PROVIDER_MODELS


def provider_model_uses_passthrough_retail_price(
    provider_slug: str,
    model_id: str,
) -> bool:
    return (provider_slug, model_id) in PASSTHROUGH_RETAIL_PROVIDER_MODELS


def provider_model_available_from_gateway_region(
    provider_slug: str,
    model_id: str,
    gateway_region: str,
) -> bool:
    unsupported = UNSUPPORTED_GATEWAY_REGIONS_BY_PROVIDER_MODEL.get(
        (provider_slug, model_id),
        frozenset(),
    )
    return gateway_region not in unsupported
