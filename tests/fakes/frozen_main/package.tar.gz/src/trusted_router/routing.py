from __future__ import annotations

import dataclasses
import re
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, InvalidOperation
from typing import Any, TypeVar

from trusted_router.catalog import (
    AUTO_MODEL_ID,
    E2E_MODEL_ID,
    EU_FOCUSED_PROVIDER_ORDER,
    EU_MODEL_ID,
    FUSION_CODE_MODEL_ID,
    FUSION_MODEL_ID,
    MAPREDUCE_MODEL_ID,
    META_MODEL_IDS,
    MODELS,
    PRIVACY_TIER_ALIASES,
    PRIVACY_TIER_ZERO_RETENTION,
    PROVIDER_JURISDICTION_US,
    PROVIDERS,
    ROUTING_MODEL_ALIAS_TARGETS,
    ROUTING_MODEL_MIN_PRIVACY_TIERS,
    SELECTOR_MODEL_ID,
    SYNTH_CODE_MODEL_ID,
    SYNTH_MODEL_ID,
    US_PROVIDER_ONLY_MODEL_IDS,
    ZDR_MODEL_ID,
    Model,
    ModelEndpoint,
    auto_candidate_models,
    endpoint_meets_privacy_requirement,
    endpoint_stores_content,
    endpoints_for_model,
    meta_candidate_models,
)
from trusted_router.catalog_energy import GREEN_MODEL_ID, renewable_provider_slugs
from trusted_router.config import Settings
from trusted_router.errors import api_error
from trusted_router.image_generation import IMAGE_MODEL_ID_SET
from trusted_router.routing_state import Thresholds, parse_thresholds
from trusted_router.types import ErrorType
from trusted_router.video_billing import video_endpoint_for_resolution


@dataclass(frozen=True)
class RoutePreferences:
    order: tuple[str, ...] = ()
    only: frozenset[str] = frozenset()
    ignore: frozenset[str] = frozenset()
    allow_fallbacks: bool = True
    data_collection: str | None = None
    sort: str | None = None
    sort_partition: str = "model"
    usage_type: str | None = None
    provider_jurisdiction: str | None = None
    # Requested upstream privacy posture (see catalog.PRIVACY_TIER_*). These
    # are stable API values, not an implication ladder. 0 = no filter.
    min_privacy_rank: int = 0
    # Multiple aliases in a fallback list can require orthogonal guarantees,
    # such as both ZDR and confidential compute. The legacy rank remains for
    # API/debug compatibility; routing enforces every value in this set.
    privacy_requirements: frozenset[int] = frozenset()
    require_parameters: bool = False
    requested_parameters: frozenset[str] = frozenset()
    max_prompt_price_microdollars_per_million_tokens: int | None = None
    max_completion_price_microdollars_per_million_tokens: int | None = None
    preferred_max_latency: Thresholds = ()
    preferred_min_throughput: Thresholds = ()


@dataclass(frozen=True, slots=True)
class NormalizedRoutingInputs:
    """The sole normalized input consumed by route selection."""

    model_ids: tuple[str, ...]
    preferences: RoutePreferences
    route_type: str | None
    region: str | None
    service_tier: str | None
    usage_type: str | None
    fallback_policy: bool

_PROVIDER_ALIASES = {
    "google-ai": "google-ai-studio",
    "ai-studio": "google-ai-studio",
    "google-vertex-ai": "google-vertex",
    "vertex": "google-vertex",
    "vertex-ai": "google-vertex",
    "chatgpt": "openai",
    "chat-gpt": "openai",
    "mistralai": "mistral",
    "mistral-ai": "mistral",
    "moonshot": "kimi",
    "moonshot-ai": "kimi",
    "kimi": "kimi",
    "z-ai": "zai",
    "zhipu": "zai",
    "zhipuai": "zai",
    "together-ai": "together",
    "togetherai": "together",
}
_PROVIDER_GROUP_ALIASES: dict[str, tuple[str, ...]] = {
    # Before the provider split, both products were exposed as `gemini`.
    # Expand legacy filters to both real failure domains rather than silently
    # changing existing callers to just one of them.
    "gemini": ("google-vertex", "google-ai-studio"),
    "google": ("google-vertex", "google-ai-studio"),
}
_ROUTER_PROVIDER_SLUGS = frozenset(
    {
        "openrouter",
        "open-router",
        "trustedrouter",
        "trusted-router",
        "quillrouter",
        "quill-router",
    }
)

_PROVIDER_ROUTING_FIELDS = frozenset(
    {
        "preferred_max_latency",
        "preferred_min_throughput",
        "allow_fallbacks",
        "billing",
        "country",
        "data_collection",
        "headquarters_country",
        "ignore",
        "jurisdiction",
        "max_price",
        "min_privacy",
        "only",
        "order",
        "provider_country",
        "require_parameters",
        "sort",
        "usage",
        "usage_type",
        "zdr",
    }
)

_PARAMETER_CAPABILITY_ALIASES: dict[str, frozenset[str]] = {
    "max_tokens": frozenset({"max_tokens", "max_completion_tokens"}),
    "reasoning": frozenset({"reasoning", "reasoning_effort"}),
    "response_format": frozenset({"response_format", "structured_outputs"}),
}

# OpenRouter-style model-id suffixes. Append `:nitro` to a model id to
# re-sort the upstream provider list by throughput-first (equivalent to
# setting `provider.sort = "throughput"` in the request body — see
# https://openrouter.ai/docs/guides/routing/model-variants/nitro). The
# table is intentionally extensible: adding `:floor` (price-first),
# `:thinking`, etc is a one-line edit. Each value pair is the
# RoutePreferences field name + the value to force.
_VARIANT_SUFFIXES: dict[str, tuple[str, str]] = {
    ":nitro": ("sort", "throughput"),
    ":floor": ("sort", "price"),
}


# Throughput-first routing rank. Lower values are tried first for
# `provider.sort = "throughput"` and `:nitro`.
#
# Generated from the public /leaderboard provider table on 2026-06-27 with:
#   python scripts/update_provider_throughput_rank.py --write
# The generator admits only providers with enough samples, >=95% measured uptime,
# and positive p50 output tokens/second. Providers without reliable token/s data
# keep conservative secondary ranks so they do not beat measured fast routes.
_THROUGHPUT_RANK = {
    "baseten": 0,
    "deepseek": 1,
    "fireworks": 2,
    "kimi": 3,
    "siliconflow": 4,
    "deepinfra": 5,
    "minimax": 6,
    "crusoe": 7,
    # Current leaderboard rows do not expose enough usable token/s for these
    # providers. Keep strong prior ordering below the measured set until the
    # synthetic probes emit stable longer completions for every provider.
    "cerebras": 20,
    "mistral": 21,
    "openai": 22,
    "google-vertex": 23,
    "google-ai-studio": 24,
    "together": 25,
    "zai": 26,
    "anthropic": 27,
    "tinfoil": 28,
    "venice": 29,
    "grok": 30,
    "lightning": 31,
    "nebius": 32,
    "friendli": 33,
    "novita": 34,
    "phala": 35,
    "gmi": 36,
    "parasail": 37,
    "wafer": 38,
    "xiaomi": 39,
    "trustedrouter": 99,
}

# Phase 4 — reliability-informed DEFAULT routing preference. Lower = tried
# first. When a model is served by several prepaid hosts, default traffic
# routes to the more RELIABLE host rather than raw catalog order. Demotions are
# evidence-based, from measured uptime on the public leaderboard (2026-06):
# gmi ~82% (and slow ~2.8s TTFT), parasail ~87%, novita ~94% — all materially
# below the reliable open-weight hosts (deepinfra / cerebras / lightning /
# deepseek ~100%). Everything unlisted stays at the reliable default; within a
# tier the catalog order is preserved, so only models served by BOTH a flaky
# and a healthy host change. Explicit `provider.order` and
# `sort=price|throughput` still take precedence. (A future per-model measured
# snapshot will refine this static floor — see Phase 4 plan.)
_DEFAULT_PROVIDER_PREFERENCE = 0
_PROVIDER_PREFERENCE = {
    "novita": 3,
    "parasail": 4,
    "gmi": 5,
}

# Narrow, evidence-backed exceptions to the global provider preference. These
# affect only default routing; caller-supplied provider.order/sort still wins.
_MODEL_PROVIDER_PREFERENCE: dict[str, dict[str, int]] = {
    "z-ai/glm-5.2": {"parasail": -1},
    # Direct probes on 2026-10-05: NVIDIA accepted the model but returned no
    # headers within 95s; all three Chutes instances lacked evidence support.
    # Keep both routes observable and explicitly selectable while preferring
    # other backends for these exact models. Remove after verified recovery.
    "deepseek/deepseek-v4.1-flash": {"nvidia-nim": 10},
    "qwen/qwen3-235b-a22b-thinking-2507": {"chutes": 10},
    # Jev's vendor before the relay: one third party instead of two, and a
    # measured 238 ms median against ~330 ms through Vercel (2026-09-19, the
    # gateway's labeled ticket set). The relay stays as the failover.
    "typesafe-ai/jev": {"typesafe": -1},
}

_CandidateT = TypeVar("_CandidateT")


class RoutingCandidates(list[_CandidateT]):
    """List-compatible resolver result carrying the policy actually applied."""

    def __init__(self, candidates: list[_CandidateT], preferences: RoutePreferences) -> None:
        super().__init__(candidates)
        self.effective_preferences = preferences


def _coerce_routing_inputs(
    value: NormalizedRoutingInputs | dict[str, Any],
    settings: Settings | None,
) -> NormalizedRoutingInputs:
    if isinstance(value, NormalizedRoutingInputs):
        return value
    if settings is None:
        raise TypeError("raw routing bodies require Settings")
    return normalize_routing_inputs(value, settings)


def chat_route_candidates(
    inputs: NormalizedRoutingInputs | dict[str, Any],
    settings: Settings | None = None,
) -> list[Model]:
    inputs = _coerce_routing_inputs(inputs, settings)
    raw_ids, prefs = list(inputs.model_ids), inputs.preferences
    candidates: list[Model] = []
    seen: set[str] = set()
    for model_id in raw_ids:
        model = MODELS.get(model_id)
        if model is None or not model.supports_chat:
            raise api_error(
                400,
                f"Model does not support chat completions: {model_id}",
                ErrorType.MODEL_NOT_SUPPORTED,
            )
        if model.id not in seen:
            candidates.append(model)
            seen.add(model.id)

    candidates = _filter_candidates_soft_data_collection(candidates, prefs, _apply_provider_filters)
    if not candidates:
        raise api_error(
            400,
            "No route candidates match the requested provider filters",
            ErrorType.MODEL_NOT_SUPPORTED,
        )
    candidates = _sort_candidates(candidates, prefs)
    if not prefs.allow_fallbacks:
        return candidates[:1]
    return candidates


def chat_route_endpoint_candidates(
    inputs: NormalizedRoutingInputs | dict[str, Any],
    settings: Settings | None = None,
    *,
    defer_no_fallback_selection: bool = False,
) -> RoutingCandidates[tuple[Model, ModelEndpoint]]:
    inputs = _coerce_routing_inputs(inputs, settings)
    raw_ids, prefs = list(inputs.model_ids), inputs.preferences
    candidates: list[tuple[Model, ModelEndpoint]] = []
    seen: set[str] = set()
    for model_id in raw_ids:
        model = MODELS.get(model_id)
        if model is None or not model.supports_chat:
            raise api_error(
                400,
                f"Model does not support chat completions: {model_id}",
                ErrorType.MODEL_NOT_SUPPORTED,
            )
        for endpoint in endpoints_for_model(model.id):
            if endpoint.id in seen:
                continue
            candidates.append((model, endpoint))
            seen.add(endpoint.id)

    filtered = _filter_candidates_soft_data_collection(
        candidates, prefs, _apply_endpoint_provider_filters
    )
    if not filtered:
        raise api_error(
            400,
            "No route candidates match the requested provider filters",
            ErrorType.MODEL_NOT_SUPPORTED,
        )
    candidates = _sort_endpoint_candidates(filtered, prefs)
    if not prefs.allow_fallbacks and not defer_no_fallback_selection:
        candidates = candidates[:1]
    return RoutingCandidates(candidates, filtered.effective_preferences)


def image_route_endpoint_candidates(
    inputs: NormalizedRoutingInputs | dict[str, Any],
    settings: Settings | None = None,
    *,
    defer_no_fallback_selection: bool = False,
) -> list[tuple[Model, ModelEndpoint]]:
    """Resolve only models whose normalized image contract is implemented."""

    inputs = _coerce_routing_inputs(inputs, settings)
    raw_ids, prefs = list(inputs.model_ids), inputs.preferences
    candidates: list[tuple[Model, ModelEndpoint]] = []
    seen: set[str] = set()
    for model_id in raw_ids:
        model = MODELS.get(model_id)
        if model is None or model.id not in IMAGE_MODEL_ID_SET:
            raise api_error(
                400,
                f"Model does not support image generation: {model_id}",
                ErrorType.MODEL_NOT_SUPPORTED,
            )
        for endpoint in endpoints_for_model(model.id):
            if endpoint.id in seen:
                continue
            candidates.append((model, endpoint))
            seen.add(endpoint.id)

    candidates = _filter_candidates_soft_data_collection(
        candidates, prefs, _apply_endpoint_provider_filters
    )
    if not candidates:
        raise api_error(
            400,
            "No image route candidates match the requested provider filters",
            ErrorType.MODEL_NOT_SUPPORTED,
        )
    candidates = _sort_endpoint_candidates(candidates, prefs)
    if not prefs.allow_fallbacks and not defer_no_fallback_selection:
        return candidates[:1]
    return candidates


def catalog_endpoint_candidates(
    model: Model,
    prefs: RoutePreferences,
) -> list[tuple[Model, ModelEndpoint]]:
    """Endpoint candidates for the public model-endpoints catalog route.

    Unlike inference routing, this intentionally does not require
    `supports_chat`; the OpenRouter-compatible endpoint catalog should be able
    to describe any served model while still honoring provider filters.
    """
    candidates = [(model, endpoint) for endpoint in endpoints_for_model(model.id)]
    candidates = _filter_candidates_soft_data_collection(
        candidates, prefs, _apply_endpoint_provider_filters
    )
    candidates = _sort_endpoint_candidates(candidates, prefs)
    if not prefs.allow_fallbacks:
        return candidates[:1]
    return candidates


def decide_route_endpoint_candidates(
    inputs: NormalizedRoutingInputs | dict[str, Any],
    settings: Settings | None = None,
    *,
    defer_no_fallback_selection: bool = False,
) -> RoutingCandidates[tuple[Model, ModelEndpoint]]:
    """Endpoint candidates for a HOSTED decision model on POST /v1/decide.

    Only `supports_decide` models resolve here. A native decision request (an
    ordinary chat model the gateway drives with strict structured output)
    authorizes through `chat_route_endpoint_candidates` instead, because it
    really is a chat completion and bills as one. Cost here falls out of the
    per-endpoint prompt price: completion price is 0 on decision endpoints."""
    inputs = _coerce_routing_inputs(inputs, settings)
    raw_ids, prefs = list(inputs.model_ids), inputs.preferences
    candidates: list[tuple[Model, ModelEndpoint]] = []
    seen: set[str] = set()
    for model_id in raw_ids:
        model = MODELS.get(model_id)
        if model is None or not model.supports_decide:
            raise api_error(
                400,
                f"Model is not a decision model: {model_id}",
                ErrorType.MODEL_NOT_SUPPORTED,
            )
        for endpoint in endpoints_for_model(model.id):
            if endpoint.id in seen:
                continue
            candidates.append((model, endpoint))
            seen.add(endpoint.id)
    filtered = _filter_candidates_soft_data_collection(
        candidates, prefs, _apply_endpoint_provider_filters
    )
    if not filtered:
        raise api_error(
            400,
            "No route candidates match the requested provider filters",
            ErrorType.MODEL_NOT_SUPPORTED,
        )
    candidates = _sort_endpoint_candidates(filtered, prefs)
    if not prefs.allow_fallbacks and not defer_no_fallback_selection:
        candidates = candidates[:1]
    return RoutingCandidates(candidates, filtered.effective_preferences)


def embeddings_route_endpoint_candidates(
    inputs: NormalizedRoutingInputs | dict[str, Any],
    settings: Settings | None = None,
    *,
    defer_no_fallback_selection: bool = False,
) -> list[tuple[Model, ModelEndpoint]]:
    """Endpoint candidates for an embeddings request — the gateway-authorize
    analogue of `chat_route_endpoint_candidates`, accepting only
    `supports_embeddings` models. Cost falls out of the per-endpoint prompt
    price (completion price is 0 on embedding endpoints), so the enclave can
    authorize + bill an embeddings route exactly like a chat one."""
    inputs = _coerce_routing_inputs(inputs, settings)
    raw_ids, prefs = list(inputs.model_ids), inputs.preferences
    candidates: list[tuple[Model, ModelEndpoint]] = []
    seen: set[str] = set()
    for model_id in raw_ids:
        model = MODELS.get(model_id)
        if model is None or not model.supports_embeddings:
            raise api_error(
                400,
                f"Model does not support embeddings: {model_id}",
                ErrorType.MODEL_NOT_SUPPORTED,
            )
        for endpoint in endpoints_for_model(model.id):
            if endpoint.id in seen:
                continue
            candidates.append((model, endpoint))
            seen.add(endpoint.id)

    candidates = _filter_candidates_soft_data_collection(
        candidates, prefs, _apply_endpoint_provider_filters
    )
    if not candidates:
        raise api_error(
            400,
            "No route candidates match the requested provider filters",
            ErrorType.MODEL_NOT_SUPPORTED,
        )
    candidates = _sort_endpoint_candidates(candidates, prefs)
    if not prefs.allow_fallbacks and not defer_no_fallback_selection:
        return candidates[:1]
    return candidates


def video_route_endpoint_candidates(
    inputs: NormalizedRoutingInputs | dict[str, Any],
    settings: Settings | None = None,
    *,
    defer_no_fallback_selection: bool = False,
    video_resolution: str | None = None,
    pricing_effective_at: datetime | None = None,
    allowed_providers: frozenset[str] | None = None,
) -> list[tuple[Model, ModelEndpoint]]:
    """Resolve only provider endpoints backed by the attested video worker."""
    inputs = _coerce_routing_inputs(inputs, settings)
    raw_ids, prefs = list(inputs.model_ids), inputs.preferences
    candidates: list[tuple[Model, ModelEndpoint]] = []
    seen: set[str] = set()
    for model_id in raw_ids:
        model = MODELS.get(model_id)
        if model is None or not model.supports_video:
            raise api_error(
                400,
                f"Model does not support video generation: {model_id}",
                ErrorType.MODEL_NOT_SUPPORTED,
            )
        for endpoint in endpoints_for_model(model.id, at=pricing_effective_at):
            if endpoint.id in seen:
                continue
            # Intersect with the normalized caller policy below, before sorting
            # or selecting a single route. Soft-filter relaxation must never
            # restore a provider excluded by the enclave's capability set.
            if allowed_providers is not None and endpoint.provider not in allowed_providers:
                continue
            if video_resolution is not None:
                # All provider preferences must see the tariff that authorize
                # will freeze, including price caps, sorting and no-fallbacks.
                priced_endpoint = video_endpoint_for_resolution(endpoint, video_resolution)
                if priced_endpoint is None:
                    continue
                endpoint = priced_endpoint
            candidates.append((model, endpoint))
            seen.add(endpoint.id)

    candidates = _filter_candidates_soft_data_collection(
        candidates, prefs, _apply_endpoint_provider_filters
    )
    if not candidates:
        raise api_error(
            400,
            "No video route candidates match the requested provider filters",
            ErrorType.PROVIDER_NOT_SUPPORTED if video_resolution is not None else ErrorType.MODEL_NOT_SUPPORTED,
        )
    candidates = _sort_endpoint_candidates(candidates, prefs)
    if not prefs.allow_fallbacks and not defer_no_fallback_selection:
        return candidates[:1]
    return candidates


def provider_route_preferences(body: dict[str, Any]) -> RoutePreferences:
    raw_provider = body.get("provider")
    raw = raw_provider if isinstance(raw_provider, dict) else {}
    unknown = sorted(set(raw) - _PROVIDER_ROUTING_FIELDS)
    if unknown:
        raise api_error(
            400,
            f"Unknown provider routing option: {unknown[0]}",
            ErrorType.BAD_REQUEST,
        )

    order = tuple(_provider_filter_list("order", raw.get("order")))
    only = frozenset(_provider_filter_list("only", raw.get("only")))
    ignore = frozenset(_provider_filter_list("ignore", raw.get("ignore")))
    top_level_allow_fallbacks = body.get("allow_fallbacks")
    nested_allow_fallbacks = raw.get("allow_fallbacks")
    if top_level_allow_fallbacks is not None and not isinstance(
        top_level_allow_fallbacks, bool
    ):
        raise api_error(400, "allow_fallbacks must be a boolean", ErrorType.BAD_REQUEST)
    if nested_allow_fallbacks is not None and not isinstance(nested_allow_fallbacks, bool):
        raise api_error(400, "provider.allow_fallbacks must be a boolean", ErrorType.BAD_REQUEST)
    if (
        top_level_allow_fallbacks is not None
        and nested_allow_fallbacks is not None
        and top_level_allow_fallbacks != nested_allow_fallbacks
    ):
        raise api_error(
            400,
            "allow_fallbacks conflicts with provider.allow_fallbacks",
            ErrorType.BAD_REQUEST,
        )
    allow_fallbacks = (
        top_level_allow_fallbacks
        if top_level_allow_fallbacks is not None
        else nested_allow_fallbacks
    )
    if allow_fallbacks is None:
        allow_fallbacks_bool = True
    else:
        allow_fallbacks_bool = allow_fallbacks

    data_collection = raw.get("data_collection")
    if data_collection is not None:
        data_collection = str(data_collection).strip().lower()
        if data_collection not in {"allow", "deny"}:
            raise api_error(
                400,
                "provider.data_collection must be 'allow' or 'deny'",
                ErrorType.BAD_REQUEST,
            )

    sort, sort_partition = _sort_preferences(raw.get("sort"))
    usage_type = _usage_type(raw.get("usage") or raw.get("usage_type") or raw.get("billing"))
    provider_jurisdiction = _provider_jurisdiction(
        raw.get("jurisdiction")
        or raw.get("country")
        or raw.get("headquarters_country")
        or raw.get("provider_country")
    )

    # provider.min_privacy: route only to providers with this exact posture.
    # Accepts friendly names ("zdr", "confidential", "no_store", "any").
    # Unknown values are a 400 so a typo cannot silently weaken the request.
    min_privacy_rank = 0
    min_privacy = raw.get("min_privacy")
    if min_privacy is not None:
        key = str(min_privacy).strip().lower()
        if key not in PRIVACY_TIER_ALIASES:
            raise api_error(
                400,
                "provider.min_privacy must be one of: any, no_store, zdr, confidential (aliases: e2e, e2ee)",
                ErrorType.BAD_REQUEST,
            )
        min_privacy_rank = PRIVACY_TIER_ALIASES[key]
    privacy_requirements = frozenset({min_privacy_rank}) if min_privacy_rank else frozenset()

    zdr = raw.get("zdr")
    if zdr is not None and not isinstance(zdr, bool):
        raise api_error(400, "provider.zdr must be a boolean", ErrorType.BAD_REQUEST)
    if zdr:
        privacy_requirements = privacy_requirements | frozenset({PRIVACY_TIER_ZERO_RETENTION})
        min_privacy_rank = max(privacy_requirements)

    require_parameters = raw.get("require_parameters", False)
    if not isinstance(require_parameters, bool):
        raise api_error(
            400,
            "provider.require_parameters must be a boolean",
            ErrorType.BAD_REQUEST,
        )
    requested_parameters = _requested_parameters(body)
    max_prompt_price, max_completion_price = _max_token_prices(raw.get("max_price"))

    return RoutePreferences(
        order=order,
        only=only,
        ignore=ignore,
        allow_fallbacks=allow_fallbacks_bool,
        data_collection=data_collection,
        min_privacy_rank=min_privacy_rank,
        privacy_requirements=privacy_requirements,
        sort=sort,
        sort_partition=sort_partition,
        usage_type=usage_type,
        provider_jurisdiction=provider_jurisdiction,
        require_parameters=require_parameters,
        requested_parameters=requested_parameters,
        max_prompt_price_microdollars_per_million_tokens=max_prompt_price,
        max_completion_price_microdollars_per_million_tokens=max_completion_price,
        preferred_max_latency=parse_thresholds(raw.get("preferred_max_latency"), "preferred_max_latency"),
        preferred_min_throughput=parse_thresholds(raw.get("preferred_min_throughput"), "preferred_min_throughput"),
    )


def _requested_parameters(body: dict[str, Any]) -> frozenset[str]:
    raw = body.get("requested_parameters")
    if raw is None:
        return frozenset()
    if not isinstance(raw, list) or any(not isinstance(item, str) for item in raw):
        raise api_error(400, "requested_parameters must be a string array", ErrorType.BAD_REQUEST)
    return frozenset(item.strip() for item in raw if item.strip())


def _max_token_prices(value: Any) -> tuple[int | None, int | None]:
    if value is None:
        return None, None
    if not isinstance(value, dict):
        raise api_error(400, "provider.max_price must be an object", ErrorType.BAD_REQUEST)
    unknown = sorted(set(value) - {"prompt", "completion"})
    if unknown:
        raise api_error(
            400,
            f"Unsupported provider.max_price option: {unknown[0]}",
            ErrorType.BAD_REQUEST,
        )
    return (
        _price_limit_microdollars(value.get("prompt"), "provider.max_price.prompt"),
        _price_limit_microdollars(value.get("completion"), "provider.max_price.completion"),
    )


def _price_limit_microdollars(value: Any, field: str) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool):
        raise api_error(400, f"{field} must be a non-negative decimal", ErrorType.BAD_REQUEST)
    try:
        amount = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise api_error(400, f"{field} must be a non-negative decimal", ErrorType.BAD_REQUEST) from None
    if not amount.is_finite() or amount < 0:
        raise api_error(400, f"{field} must be a non-negative decimal", ErrorType.BAD_REQUEST)
    microdollars = amount * Decimal(1_000_000)
    if microdollars != microdollars.to_integral_value():
        raise api_error(
            400,
            f"{field} supports at most six decimal places",
            ErrorType.BAD_REQUEST,
        )
    return int(microdollars)


def _strip_variant_suffix(model_id: str) -> tuple[str, dict[str, str]]:
    """Detect an OpenRouter-style variant suffix on the model id. Returns
    `(stripped_id, overrides)`. `overrides` is empty if no suffix matches.
    Multiple suffixes don't compose today — first match wins."""
    for suffix, (key, value) in _VARIANT_SUFFIXES.items():
        if model_id.endswith(suffix):
            return model_id[: -len(suffix)], {key: value}
    return model_id, {}


def canonical_model_id(model_id: str) -> str:
    """The catalog id routing resolves a request's model string to.

    Routing rewrites what the client typed before it looks anything up: a
    variant suffix is stripped (`:nitro`, `:floor`), an alias is followed, a
    dated snapshot suffix is dropped (`-2026-09-19`), a bare OpenAI name gains
    its vendor prefix -- and these compose. A guard that must hold for a MODEL
    has to compare THIS id, never the raw string: `trev-1.0:nitro` and
    `trev-1.0-2026-09-19` are both `trev-1.0` to the router and different
    strings to `==`. Written as "whatever routing would do" rather than as a
    list of spellings, so a rewrite added later is covered without anyone
    remembering this function exists.
    """
    stripped, _overrides = _strip_variant_suffix(model_id)
    return resolve_model_alias(stripped)


def _routing_for_body(
    body: dict[str, Any], settings: Settings
) -> tuple[list[str], RoutePreferences]:
    """Strip variant suffixes from `body.model` / `body.models[]`, expand
    AUTO, build the RoutePreferences. Suffix-derived overrides win over
    body-set fields (per OpenRouter: the suffix is the explicit shorthand
    and is meant to be authoritative)."""
    prefs = provider_route_preferences(body)
    ids, overrides = _requested_model_ids(
        body,
        settings,
        include_fallback_models=prefs.allow_fallbacks,
    )
    if "sort" in overrides:
        prefs = dataclasses.replace(prefs, sort=overrides["sort"])
    if "order" in overrides:
        prefs = dataclasses.replace(
            prefs,
            order=tuple(_provider_filter_list("order", overrides["order"])),
        )
    if "only" in overrides:
        override_only = frozenset(_provider_filter_list("only", overrides["only"]))
        effective_only = override_only if not prefs.only else prefs.only & override_only
        if not effective_only:
            raise api_error(
                400,
                "No route candidates match the requested provider filters",
                ErrorType.MODEL_NOT_SUPPORTED,
            )
        prefs = dataclasses.replace(prefs, only=effective_only)
    if overrides.get("renewable_energy_only"):
        eligible = renewable_provider_slugs()
        effective_only = eligible if not prefs.only else prefs.only & eligible
        if not effective_only:
            raise api_error(400, "No renewable-energy route matches the provider filters", ErrorType.MODEL_NOT_SUPPORTED)
        prefs = dataclasses.replace(prefs, only=effective_only)
    override_requirements = frozenset(
        int(requirement) for requirement in overrides.get("privacy_requirements", ())
    )
    if override_requirements:
        requirements = prefs.privacy_requirements | override_requirements
        prefs = dataclasses.replace(
            prefs,
            min_privacy_rank=max(requirements),
            privacy_requirements=requirements,
        )
    if overrides.get("usage") == "Credits":
        if prefs.usage_type == "BYOK":
            raise api_error(
                400,
                "TrustedRouter orchestration models do not support BYOK routes",
                ErrorType.MODEL_NOT_SUPPORTED,
            )
        prefs = dataclasses.replace(prefs, usage_type="Credits")
    if "provider_jurisdiction" in overrides:
        jurisdiction = overrides["provider_jurisdiction"]
        if prefs.provider_jurisdiction and prefs.provider_jurisdiction != jurisdiction:
            raise api_error(
                400,
                "Requested model requires provider.jurisdiction='us'",
                ErrorType.MODEL_NOT_SUPPORTED,
            )
        prefs = dataclasses.replace(prefs, provider_jurisdiction=jurisdiction)
    if not prefs.allow_fallbacks and prefs.order:
        # OpenRouter treats `order` as a preference while fallbacks are enabled,
        # but disabling fallbacks prevents routing outside that ordered set.
        # Keep an explicit `only` restriction as the ceiling by intersecting it
        # with `order`; a disjoint request then fails closed in the normal
        # provider-filter path instead of silently selecting an unlisted host.
        ordered_providers = frozenset(prefs.order)
        effective_only = (
            prefs.only & ordered_providers if prefs.only else ordered_providers
        )
        if not effective_only:
            raise api_error(
                400,
                "No route candidates match the requested provider filters",
                ErrorType.MODEL_NOT_SUPPORTED,
            )
        prefs = dataclasses.replace(prefs, only=effective_only)
    return ids, prefs


def normalize_routing_inputs(
    body: dict[str, Any],
    settings: Settings,
    *,
    resolved_region: str | None = None,
) -> NormalizedRoutingInputs:
    """Build the one routing object selectors and Stage C are allowed to read."""

    model_ids, preferences = _routing_for_body(body, settings)
    return NormalizedRoutingInputs(
        model_ids=tuple(model_ids),
        preferences=preferences,
        route_type=str(body["route_type"]) if body.get("route_type") is not None else None,
        region=resolved_region if resolved_region is not None else body.get("region"),
        service_tier=(
            str(body["service_tier"]).strip().lower()
            if body.get("service_tier") is not None
            else None
        ),
        usage_type=preferences.usage_type,
        fallback_policy=preferences.allow_fallbacks,
    )


def resolved_route_preferences(body: dict[str, Any], settings: Settings) -> RoutePreferences:
    """Return the authoritative preferences after aliases and suffixes resolve.

    Cross-cutting policy gates must use this instead of reparsing raw provider
    fields, otherwise shorthand such as ``:zdr`` can diverge from routing.
    """
    return normalize_routing_inputs(body, settings).preferences


# OpenAI-style dated snapshot suffix, e.g. the "-2025-04-14" in
# "gpt-4.1-2025-04-14". Anthropic-style undashed dates ("20241022") don't match.
_DATED_SNAPSHOT_RE = re.compile(r"-\d{4}-\d{2}-\d{2}$")


def resolve_model_alias(model_id: str) -> str:
    """Map a bare or dated OpenAI-style id to its canonical catalog id.

    The OpenAI SDK and LiteLLM send the *bare* name (`gpt-4.1`) or OpenAI's
    *dated snapshot* (`gpt-4.1-2025-04-14`); our catalog ids are vendor-prefixed
    (`openai/gpt-4.1`). Accept what that tooling sends so it works against TR with
    no client-side shim. Conservative by design: only rewrites when the resolved
    id actually exists in the catalog — a genuinely unknown model is returned
    unchanged and still surfaces MODEL_NOT_SUPPORTED downstream. Catalog ids
    (already vendor-prefixed) short-circuit on the first check, so real ids and
    meta ids (AUTO / fusion / zdr / …) are never altered.
    """
    if model_id in ROUTING_MODEL_ALIAS_TARGETS:
        return ROUTING_MODEL_ALIAS_TARGETS[model_id]
    if model_id in MODELS:
        return model_id
    base = _DATED_SNAPSHOT_RE.sub("", model_id)
    for candidate in (model_id, base):
        if candidate in MODELS:
            return candidate
        prefixed = f"openai/{candidate}"
        if prefixed in MODELS:
            return prefixed
    return model_id


def _requested_model_ids(
    body: dict[str, Any],
    settings: Settings,
    *,
    include_fallback_models: bool = True,
) -> tuple[list[str], dict[str, Any]]:
    ids: list[str] = []
    overrides: dict[str, Any] = {}

    def take(raw: str) -> None:
        stripped, ovr = _strip_variant_suffix(raw)
        stripped = resolve_model_alias(stripped)
        if stripped in META_MODEL_IDS:
            overrides["usage"] = "Credits"
        if stripped == GREEN_MODEL_ID:
            overrides["renewable_energy_only"] = True
        if stripped in US_PROVIDER_ONLY_MODEL_IDS:
            overrides["provider_jurisdiction"] = PROVIDER_JURISDICTION_US
        if stripped in {
            SYNTH_MODEL_ID,
            SYNTH_CODE_MODEL_ID,
            FUSION_MODEL_ID,
            FUSION_CODE_MODEL_ID,
            SELECTOR_MODEL_ID,
            MAPREDUCE_MODEL_ID,
        }:
            raise api_error(
                501,
                "TrustedRouter orchestration models execute only inside the attested gateway; control-plane routing must not silently degrade to a single model",
                ErrorType.ENDPOINT_NOT_SUPPORTED,
            )
        if ovr:
            overrides.update(ovr)
        enforced_privacy_tier = ROUTING_MODEL_MIN_PRIVACY_TIERS.get(stripped)
        if enforced_privacy_tier is not None:
            # Retain every requested posture. ZDR and E2EE are orthogonal: a
            # fallback list that names both requires endpoints satisfying both,
            # independent of model order.
            requirements = set(overrides.get("privacy_requirements", ()))
            requirements.add(enforced_privacy_tier)
            overrides["privacy_requirements"] = frozenset(requirements)
        if stripped == ZDR_MODEL_ID:
            overrides["order"] = (
                "anthropic,openai,google-vertex,google-ai-studio,tinfoil,venice,phala"
            )
        elif stripped == E2E_MODEL_ID:
            overrides["order"] = "tinfoil,phala"
        elif stripped == EU_MODEL_ID:
            provider_order = ",".join(EU_FOCUSED_PROVIDER_ORDER)
            overrides["order"] = provider_order
            overrides["only"] = provider_order
        ids.extend(_expand_model_id(stripped, settings))

    model_id = str(body.get("model") or "").strip()
    if model_id:
        take(model_id)

    fallback_models = body.get("models")
    if not model_id and not include_fallback_models and fallback_models is not None:
        if not isinstance(fallback_models, list):
            raise api_error(400, "models must be an array of model IDs", ErrorType.BAD_REQUEST)
        if not fallback_models:
            raise api_error(400, "model is required", ErrorType.BAD_REQUEST)
        primary = fallback_models[0]
        if not isinstance(primary, str) or not primary.strip():
            raise api_error(400, "models must contain only model IDs", ErrorType.BAD_REQUEST)
        take(primary.strip())
    elif include_fallback_models and fallback_models is not None:
        if not isinstance(fallback_models, list):
            raise api_error(400, "models must be an array of model IDs", ErrorType.BAD_REQUEST)
        for item in fallback_models:
            if not isinstance(item, str) or not item.strip():
                raise api_error(400, "models must contain only model IDs", ErrorType.BAD_REQUEST)
            take(item.strip())

    if not ids:
        raise api_error(400, "model is required", ErrorType.BAD_REQUEST)
    return ids, overrides


def _expand_model_id(model_id: str, settings: Settings) -> list[str]:
    if model_id == AUTO_MODEL_ID:
        return [candidate.id for candidate in auto_candidate_models(settings.auto_model_order)]
    meta_candidates = meta_candidate_models(model_id)
    if meta_candidates:
        return [candidate.id for candidate in meta_candidates]
    return [model_id]


def _filter_candidates_soft_data_collection(
    candidates: list[_CandidateT],
    prefs: RoutePreferences,
    apply_fn: Callable[[list[_CandidateT], RoutePreferences], list[_CandidateT]],
) -> RoutingCandidates[_CandidateT]:
    """Apply provider filters with data_collection='deny' as a soft preference.

    Some OpenRouter-migrated clients send this compatibility flag on every request
    unconditionally, so it must not hard-fail routing when it is the only filter
    emptying an otherwise valid route. Explicit privacy floors and provider
    inclusion/exclusion filters remain hard.
    """
    filtered = apply_fn(candidates, prefs)
    # Keep OpenRouter compatibility soft only when it is the request's sole
    # privacy preference. Once a caller also asks for an explicit ZDR/E2EE
    # posture, silently dropping `deny` would violate the composed contract.
    if (
        not filtered
        and prefs.data_collection == "deny"
        and not _required_privacy_postures(prefs)
    ):
        relaxed = dataclasses.replace(prefs, data_collection=None)
        filtered = apply_fn(candidates, relaxed)
        if filtered:
            prefs = relaxed
    return RoutingCandidates(filtered, prefs)


def _required_privacy_postures(prefs: RoutePreferences) -> frozenset[int]:
    """Return every posture the route must satisfy.

    ``min_privacy_rank`` remains accepted for internal callers created before
    posture composition became explicit.
    """

    requirements = prefs.privacy_requirements
    if prefs.min_privacy_rank:
        requirements = requirements | {prefs.min_privacy_rank}
    return frozenset(requirements)


def _apply_provider_filters(candidates: list[Model], prefs: RoutePreferences) -> list[Model]:
    out: list[Model] = []
    privacy_requirements = _required_privacy_postures(prefs)
    for model in candidates:
        provider = PROVIDERS[model.provider]
        if prefs.only and model.provider not in prefs.only:
            continue
        if model.provider in prefs.ignore:
            continue
        if not _provider_matches_jurisdiction(provider, prefs.provider_jurisdiction):
            continue
        model_endpoints = endpoints_for_model(model.id)
        # Retention and confidential-compute guarantees are orthogonal. A TEE
        # route with no tracked retention promise must not satisfy deny/ZDR.
        if prefs.data_collection == "deny" and not any(
            not endpoint_stores_content(endpoint) for endpoint in model_endpoints
        ):
            continue
        if privacy_requirements and not any(
            all(
                endpoint_meets_privacy_requirement(endpoint, requirement)
                for requirement in privacy_requirements
            )
            for endpoint in model_endpoints
        ):
            continue
        if (
            prefs.require_parameters
            or prefs.max_prompt_price_microdollars_per_million_tokens is not None
            or prefs.max_completion_price_microdollars_per_million_tokens is not None
        ) and not any(
            _endpoint_matches_parameter_and_price_filters(endpoint, prefs)
            for endpoint in model_endpoints
        ):
            continue
        out.append(model)
    return out


def _sort_candidates(candidates: list[Model], prefs: RoutePreferences) -> list[Model]:
    with_index = list(enumerate(candidates))
    provider_order = {provider: index for index, provider in enumerate(prefs.order)}

    def key(item: tuple[int, Model]) -> tuple[int, int, int]:
        original_index, model = item
        order_rank = provider_order.get(model.provider, len(provider_order))
        if prefs.sort == "price":
            sort_rank = (
                model.prompt_price_microdollars_per_million_tokens
                + model.completion_price_microdollars_per_million_tokens
            )
        elif prefs.sort in {"latency", "throughput"}:
            sort_rank = _THROUGHPUT_RANK.get(model.provider, 50)
        else:
            # Default: preserve the caller's explicit `models` array order. The
            # reliability preference is applied at the ENDPOINT level (which host
            # serves a model), NOT here — reordering an explicit fallback list
            # would violate the caller's intended order.
            sort_rank = original_index
        return order_rank, sort_rank, original_index

    return [model for _, model in sorted(with_index, key=key)]


def _apply_endpoint_provider_filters(
    candidates: list[tuple[Model, ModelEndpoint]],
    prefs: RoutePreferences,
) -> list[tuple[Model, ModelEndpoint]]:
    out: list[tuple[Model, ModelEndpoint]] = []
    privacy_requirements = _required_privacy_postures(prefs)
    for model, endpoint in candidates:
        provider = PROVIDERS[endpoint.provider]
        if prefs.only and endpoint.provider not in prefs.only:
            continue
        if endpoint.provider in prefs.ignore:
            continue
        if not _provider_matches_jurisdiction(provider, prefs.provider_jurisdiction):
            continue
        if prefs.data_collection == "deny" and endpoint_stores_content(endpoint):
            continue
        if privacy_requirements and not all(
            endpoint_meets_privacy_requirement(endpoint, requirement)
            for requirement in privacy_requirements
        ):
            continue
        if prefs.usage_type is not None and endpoint.usage_type != prefs.usage_type:
            continue
        if not _endpoint_matches_parameter_and_price_filters(endpoint, prefs):
            continue
        out.append((model, endpoint))
    return out


def _endpoint_supports_requested_parameters(
    endpoint: ModelEndpoint,
    requested: frozenset[str],
) -> bool:
    supported = frozenset(endpoint.supported_parameters)
    for parameter in requested:
        alternatives = _PARAMETER_CAPABILITY_ALIASES.get(parameter, frozenset({parameter}))
        if supported.isdisjoint(alternatives):
            return False
    return True


def _endpoint_matches_parameter_and_price_filters(
    endpoint: ModelEndpoint,
    prefs: RoutePreferences,
) -> bool:
    if prefs.require_parameters and not _endpoint_supports_requested_parameters(
        endpoint, prefs.requested_parameters
    ):
        return False
    if (
        prefs.max_prompt_price_microdollars_per_million_tokens is not None
        and endpoint.prompt_price_microdollars_per_million_tokens
        > prefs.max_prompt_price_microdollars_per_million_tokens
    ):
        return False
    return not (
        prefs.max_completion_price_microdollars_per_million_tokens is not None
        and endpoint.completion_price_microdollars_per_million_tokens
        > prefs.max_completion_price_microdollars_per_million_tokens
    )


def _sort_endpoint_candidates(
    candidates: list[tuple[Model, ModelEndpoint]],
    prefs: RoutePreferences,
) -> list[tuple[Model, ModelEndpoint]]:
    with_index = list(enumerate(candidates))
    provider_order = {provider: index for index, provider in enumerate(prefs.order)}
    candidate_model_ids = {model.id for model, _endpoint in candidates}
    single_model_id = next(iter(candidate_model_ids)) if len(candidate_model_ids) == 1 else None

    model_order: dict[str, int] = {}
    for model, _endpoint in candidates:
        model_order.setdefault(model.id, len(model_order))

    def key(item: tuple[int, tuple[Model, ModelEndpoint]]) -> tuple[int, int, int, int]:
        original_index, (model, endpoint) = item
        order_rank = provider_order.get(endpoint.provider, len(provider_order))
        # Provider preference ranks endpoints within each requested model. It
        # must not reorder the caller's model fallback chain. The only explicit
        # opt-out is OpenRouter's global sort partition.
        model_rank = model_order[model.id] if prefs.sort_partition == "model" else 0
        if prefs.sort == "price":
            sort_rank = (
                endpoint.prompt_price_microdollars_per_million_tokens
                + endpoint.completion_price_microdollars_per_million_tokens
            )
        elif prefs.sort in {"latency", "throughput"}:
            sort_rank = _THROUGHPUT_RANK.get(endpoint.provider, 50)
        else:
            # Default: reliability-informed preference (Phase 4), catalog order
            # preserved within a tier via the original_index tiebreaker below.
            # A provider preference for one model must not promote that model
            # ahead of a caller's primary model or a meta-router's model order.
            model_preference = (
                _MODEL_PROVIDER_PREFERENCE.get(model.id, {}) if model.id == single_model_id else {}
            )
            sort_rank = model_preference.get(
                endpoint.provider,
                _PROVIDER_PREFERENCE.get(endpoint.provider, _DEFAULT_PROVIDER_PREFERENCE),
            )
        return model_rank, order_rank, sort_rank, original_index

    return [candidate for _, candidate in sorted(with_index, key=key)]


def _provider_slug(value: str) -> str:
    slug = value.strip().lower().replace("_", "-").replace(" ", "-")
    return _PROVIDER_ALIASES.get(slug, slug)


def _provider_filter_list(field: str, value: Any) -> list[str]:
    out: list[str] = []
    for item in _string_list(field, value):
        raw_slug = item.strip().lower().replace("_", "-").replace(" ", "-")
        slugs = _PROVIDER_GROUP_ALIASES.get(raw_slug, (_provider_slug(item),))
        if any(slug in _ROUTER_PROVIDER_SLUGS for slug in slugs):
            raise api_error(
                400,
                (
                    f"Routing filters cannot contain router name '{item}'. "
                    "Use model='trustedrouter/zdr' or another TrustedRouter alias, "
                    "and omit the router from provider filters."
                ),
                ErrorType.BAD_REQUEST,
            )
        for slug in slugs:
            if slug not in PROVIDERS:
                raise api_error(
                    400,
                    f"Unknown provider in provider.{field}: {item}",
                    ErrorType.BAD_REQUEST,
                )
            if slug not in out:
                out.append(slug)
    return out


def _provider_jurisdiction(value: Any) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise api_error(
            400,
            "provider.jurisdiction must be 'us'",
            ErrorType.BAD_REQUEST,
        )
    normalized = value.strip().lower().replace("-", "_").replace(" ", "_")
    if not normalized:
        return None
    if normalized in {"us", "usa", "united_states", "united_states_of_america"}:
        return PROVIDER_JURISDICTION_US
    raise api_error(
        400,
        "provider.jurisdiction currently supports only 'us'",
        ErrorType.BAD_REQUEST,
    )


def _provider_matches_jurisdiction(provider: Any, jurisdiction: str | None) -> bool:
    if jurisdiction is None:
        return True
    if jurisdiction == PROVIDER_JURISDICTION_US:
        return provider.provider_headquarters_country == PROVIDER_JURISDICTION_US
    return False


def _string_list(field: str, value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        values = [item.strip() for item in value.split(",") if item.strip()]
    elif isinstance(value, list):
        values = value
    else:
        raise api_error(
            400,
            f"provider.{field} must be an array of strings or a comma-separated string",
            ErrorType.BAD_REQUEST,
        )
    out: list[str] = []
    for item in values:
        if not isinstance(item, str) or not item.strip():
            raise api_error(
                400,
                f"provider.{field} must contain only provider names",
                ErrorType.BAD_REQUEST,
            )
        out.append(item)
    return out


def _sort_preferences(value: Any) -> tuple[str | None, str]:
    if value is None:
        return None, "model"
    partition = "model"
    if isinstance(value, str):
        candidate = value.strip().lower()
    elif isinstance(value, dict):
        raw = value.get("sort") or value.get("strategy") or value.get("by")
        candidate = str(raw or "").strip().lower()
        raw_partition = value.get("partition")
        if raw_partition is not None:
            partition = str(raw_partition).strip().lower()
            if partition not in {"model", "none"}:
                raise api_error(
                    400,
                    "provider.sort.partition must be 'model' or 'none'",
                    ErrorType.BAD_REQUEST,
                )
    else:
        raise api_error(400, "provider.sort must be a string or object", ErrorType.BAD_REQUEST)
    if candidate in {"price", "latency", "throughput"}:
        return candidate, partition
    if candidate:
        raise api_error(400, "provider.sort is unsupported", ErrorType.BAD_REQUEST)
    return None, partition


def _usage_type(value: Any) -> str | None:
    if value is None:
        return None
    candidate = str(value).strip().lower()
    if candidate in {"byok", "bring-your-own-key"}:
        return "BYOK"
    if candidate in {"credits", "credit", "prepaid"}:
        return "Credits"
    raise api_error(400, "provider.usage must be 'credits' or 'byok'", ErrorType.BAD_REQUEST)
