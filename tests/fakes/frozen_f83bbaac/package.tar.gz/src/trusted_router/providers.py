from __future__ import annotations

import os
import time
import uuid
from collections.abc import AsyncIterator
from typing import Any

from trusted_router.catalog import PROVIDERS, Model
from trusted_router.provider_adapters import (
    anthropic_chat,
    anthropic_messages_stream,
    cohere_embeddings,
    gemini_chat,
    gemini_chat_stream,
    gemini_embeddings,
    openai_compatible_chat,
    openai_compatible_chat_stream,
    openai_compatible_embeddings,
)
from trusted_router.provider_payloads import (
    deterministic_embedding,
    is_vertex_openai_model,
    messages,
)
from trusted_router.provider_streaming import (
    anthropic_sse,
    chunk_text,
    stream_openai_chunks,
)
from trusted_router.provider_types import (
    ProviderError,
    ProviderResult,
    ProviderStreamState,
    estimate_tokens_from_messages,
    estimate_tokens_from_text,
    mock_text,
)
from trusted_router.secrets import LocalKeyFile
from trusted_router.wafer_policy import wafer_zdr_support

OPENAI_COMPATIBLE_PROVIDERS: dict[str, tuple[tuple[str, ...], str]] = {
    "byteplus": (("BYTEPLUS_API_KEY",), "https://ark.ap-southeast.bytepluses.com/api/v3"),
    "abliterate": (("ABLITERATE_API_KEY",), "https://abliterate.ai/api/v1"),
    "meta": (("OPENROUTER_API_KEY",), "https://openrouter.ai/api/v1"),
    "openrouter": (("OPENROUTER_API_KEY",), "https://openrouter.ai/api/v1"),
    "openai": (("OPENAI_API_KEY",), "https://api.openai.com/v1"),
    "cerebras": (("CEREBRAS_API_KEY",), "https://api.cerebras.ai/v1"),
    "deepseek": (("DEEPSEEK_API_KEY",), "https://api.deepseek.com"),
    "mistral": (("MISTRAL_API_KEY",), "https://api.mistral.ai/v1"),
    "kimi": (("KIMI_API_KEY", "MOONSHOT_API_KEY"), "https://api.moonshot.ai/v1"),
    "zai": (("ZAI_API_KEY", "ZHIPU_API_KEY"), "https://api.z.ai/api/paas/v4"),
    "together": (("TOGETHER_API_KEY",), "https://api.together.xyz/v1"),
    "fireworks": (
        ("FIREWORKS_API_KEY", "FIREWORKS_AI_API_KEY"),
        "https://api.fireworks.ai/inference/v1",
    ),
    # DeepInfra — OpenAI-compatible chat + embeddings (serves Qwen3-Embedding-8B).
    "deepinfra": (("DEEPINFRA_API_KEY",), "https://api.deepinfra.com/v1/openai"),
    # Voyage AI — OpenAI-shaped embeddings (voyage-3-large).
    "voyage": (("VOYAGE_API_KEY",), "https://api.voyageai.com/v1"),
    # Xiaomi MiMo — OpenAI-compatible chat (MiMo-V2 / V2.5).
    "xiaomi": (("XIAOMI_API_KEY",), "https://api.xiaomimimo.com/v1"),
    # Baseten Model APIs — OpenAI-compatible chat completions.
    "baseten": (("BASETEN_API_KEY",), "https://inference.baseten.co/v1"),
    # Telnyx Inference — OpenAI-compatible chat completions.
    "telnyx": (("TELNYX_API_KEY",), "https://api.telnyx.com/v2/ai/openai"),
    # Thinking Machines Lab Tinker OpenAI-compatible sampler.
    "thinkingmachines": (
        ("THINKING_MACHINES_API_KEY", "TINKER_API_KEY"),
        "https://tinker.thinkingmachines.dev/services/tinker-prod/oai/api/v1",
    ),
    # Wafer serverless API — OpenAI-compatible chat completions with
    # request-scoped ZDR when `Wafer-ZDR: required` is present.
    "wafer": (("WAFER_API_KEY",), "https://pass.wafer.ai/v1"),
    # Crusoe Managed Inference — OpenAI-compatible chat completions.
    "crusoe": (("CRUSOE_API_KEY",), "https://api.inference.crusoecloud.com/v1"),
    # Makora Inference — OpenAI-compatible chat completions. Their tooling
    # documents MAKORA_OPTIMIZE_TOKEN, so accept both names locally.
    "makora": (("MAKORA_API_KEY", "MAKORA_OPTIMIZE_TOKEN"), "https://inference.makora.com/v1"),
    "chutes": (("CHUTES_API_KEY",), "https://llm.chutes.ai/v1"),
    "digitalocean": (("DIGITAL_OCEAN_API_KEY",), "https://inference.do-ai.run/v1"),
    "cloudflare-workers-ai": (
        ("CLOUDFLARE_WORKERS_AI_API_TOKEN",),
        "https://api.cloudflare.com/client/v4/accounts/{account_id}/ai/v1",
    ),
    "inceptron": (("INCEPTRON_API_KEY",), "https://api.inceptron.io/v1"),
    "morph": (("MORPH_API_KEY",), "https://api.morphllm.com/v1"),
    "atlas-cloud": (("ATLAS_CLOUD_API_KEY",), "https://api.atlascloud.ai/v1"),
    "streamlake": (
        ("STREAMLAKE_API_KEY",),
        "https://vanchin.streamlake.ai/api/gateway/v1/endpoints",
    ),
    "neurometric": (
        ("NEUROMETRIC_API_KEY",),
        "https://wharf.neurometric.ai/v1",
    ),
    "engy": (("ENGY_API_KEY",), "https://api.engy.ai/v1"),
    "pearl": (
        ("PEARL_RESEARCH_API_KEY",),
        "https://inference.pearlresearch.ai/v1",
    ),
    "databricks": (
        ("DATABRICKS_TOKEN",),
        "https://invalid-unconfigured.cloud.databricks.com/serving-endpoints",
    ),
    # 0G Private Computer. TeeTLS only attests the router; forcing private
    # ensures inference itself uses a TeeML confidential-compute route.
    "zero-g": (("ZERO_G_API_KEY",), "https://router-api.0g.ai/v1"),
    # Alibaba Cloud Model Studio / DashScope — workspace-scoped OpenAI-compatible endpoint.
    "alibaba": (
        ("ALIBABA_API_KEY", "DASHSCOPE_API_KEY", "ALIYUN_API_KEY"),
        "https://ws-el6e4bpnggpx7g88.eu-central-1.maas.aliyuncs.com/compatible-mode/v1",
    ),
    "sakana": (("SAKANA_API_KEY",), "https://api.sakana.ai/v1"),
    # W&B Serverless Inference, hosted on CoreWeave infrastructure.
    "wandb": (("WANDB_API_KEY",), "https://api.inference.wandb.ai/v1"),
    "nscale": (("NSCALE_API_KEY",), "https://inference.api.nscale.com/v1"),
    "regolo": (("REGOLO_API_KEY",), "https://api.regolo.ai/v1"),
    "lyceum": (("LYCEUM_API_KEY",), "https://api.lyceum.technology/openai/v1"),
    "confidential-ai": (("CONFIDENTIAL_AI_API_KEY",), "https://api.confidential.ai/v1"),
    "nvidia-nim": (("NVIDIA_NIM_API_KEY",), "https://integrate.api.nvidia.com/v1"),
}

__all__ = [
    "OPENAI_COMPATIBLE_PROVIDERS",
    "ProviderClient",
    "ProviderError",
    "ProviderResult",
    "ProviderStreamState",
    "estimate_tokens_from_messages",
    "estimate_tokens_from_text",
    "stream_openai_chunks",
]


class ProviderClient:
    def __init__(self, key_file: LocalKeyFile, live: bool = False) -> None:
        self.key_file = key_file
        self.live = live

    async def chat(self, model: Model, request: dict[str, Any]) -> ProviderResult:
        provider = PROVIDERS[model.provider]
        if self.live:
            openai_compatible = OPENAI_COMPATIBLE_PROVIDERS.get(model.provider)
            if openai_compatible is not None:
                env_keys, base_url = openai_compatible
                return await self._openai_compatible_chat(
                    model,
                    request,
                    env_keys=env_keys,
                    base_url=self._provider_base_url(model.provider, base_url),
                    extra_headers=self._provider_extra_headers(model),
                )
            if model.provider == "anthropic":
                return await self._anthropic_chat(model, request)
            if model.provider == "google-ai-studio":
                return await self._gemini_chat(model, request)
            if model.provider == "google-vertex" and is_vertex_openai_model(model):
                return await self._vertex_openai_compatible_chat(model, request)

        started = time.monotonic()
        text = mock_text(model.id)
        return ProviderResult(
            text=text,
            input_tokens=estimate_tokens_from_messages(messages(request)),
            output_tokens=estimate_tokens_from_text(text),
            finish_reason="stop",
            provider_name=provider.name,
            request_id=f"req-{uuid.uuid4()}",
            usage_estimated=True,
            elapsed_seconds=max(time.monotonic() - started, 0.001),
        )

    def new_stream_state(self, model: Model, request: dict[str, Any]) -> ProviderStreamState:
        return ProviderStreamState(
            provider_name=PROVIDERS[model.provider].name,
            request_id=f"req-{uuid.uuid4()}",
            input_tokens=estimate_tokens_from_messages(messages(request)),
        )

    def stream_chat(
        self,
        model: Model,
        request: dict[str, Any],
        state: ProviderStreamState,
    ) -> AsyncIterator[bytes]:
        if self.live:
            openai_compatible = OPENAI_COMPATIBLE_PROVIDERS.get(model.provider)
            if openai_compatible is not None:
                env_keys, base_url = openai_compatible
                return self._openai_compatible_chat_stream(
                    model,
                    request,
                    state,
                    env_keys=env_keys,
                    base_url=self._provider_base_url(model.provider, base_url),
                    extra_headers=self._provider_extra_headers(model),
                )
            if model.provider == "anthropic":
                return self._anthropic_messages_stream(
                    model, request, state, output_format="openai"
                )
            if model.provider == "google-ai-studio":
                return self._gemini_chat_stream(model, request, state)
            if model.provider == "google-vertex" and is_vertex_openai_model(model):
                return self._vertex_openai_compatible_chat_stream(model, request, state)
        return self._synthetic_chat_stream(model, request, state)

    def stream_messages(
        self,
        model: Model,
        request: dict[str, Any],
        state: ProviderStreamState,
    ) -> AsyncIterator[bytes]:
        if self.live and model.provider == "anthropic":
            return self._anthropic_messages_stream(model, request, state, output_format="anthropic")
        return self._synthetic_anthropic_messages_stream(model, request, state)

    async def embeddings(self, model: Model, request: dict[str, Any]) -> dict[str, Any]:
        if self.live:
            if model.provider == "cohere":
                api_key = self._secret("COHERE_API_KEY")
                if not api_key:
                    raise RuntimeError("COHERE_API_KEY is not configured")
                return await cohere_embeddings(model, request, api_key=api_key)
            if model.provider == "google-ai-studio":
                api_key = self._secret("GEMINI_API_KEY")
                if not api_key:
                    raise RuntimeError("GEMINI_API_KEY is not configured")
                return await gemini_embeddings(model, request, api_key=api_key)
            openai_compatible = OPENAI_COMPATIBLE_PROVIDERS.get(model.provider)
            if openai_compatible is not None:
                env_keys, base_url = openai_compatible
                api_key = self._secret_any(env_keys)
                if not api_key:
                    raise RuntimeError(
                        f"{_credential_label(env_keys, model.provider)} is not configured"
                    )
                return await openai_compatible_embeddings(
                    model,
                    request,
                    api_key=api_key,
                    base_url=self._provider_base_url(model.provider, base_url),
                )
        # Synthetic fallback (no live providers): deterministic vectors so
        # local/test embedding calls are reproducible without a real key.
        input_value = request.get("input", "")
        inputs = input_value if isinstance(input_value, list) else [input_value]
        return {
            "object": "list",
            "data": [
                {
                    "object": "embedding",
                    "embedding": deterministic_embedding(str(item)),
                    "index": index,
                }
                for index, item in enumerate(inputs)
            ],
            "model": model.id,
            "usage": {
                "prompt_tokens": sum(max(1, len(str(item)) // 4) for item in inputs),
                "total_tokens": sum(max(1, len(str(item)) // 4) for item in inputs),
            },
        }

    async def _openai_compatible_chat(
        self,
        model: Model,
        request: dict[str, Any],
        *,
        env_keys: tuple[str, ...] | None = None,
        auth_token: str | None = None,
        base_url: str,
        extra_headers: dict[str, str] | None = None,
    ) -> ProviderResult:
        api_key = auth_token or self._secret_any(env_keys)
        if not api_key:
            raise RuntimeError(f"{_credential_label(env_keys, model.provider)} is not configured")
        return await openai_compatible_chat(
            model,
            request,
            api_key=api_key,
            base_url=base_url,
            extra_headers=extra_headers,
        )

    async def _anthropic_chat(self, model: Model, request: dict[str, Any]) -> ProviderResult:
        api_key = self._secret("ANTHROPIC_API_KEY")
        if not api_key:
            raise RuntimeError("ANTHROPIC_API_KEY is not configured")
        return await anthropic_chat(model, request, api_key=api_key)

    def _openai_compatible_chat_stream(
        self,
        model: Model,
        request: dict[str, Any],
        state: ProviderStreamState,
        *,
        env_keys: tuple[str, ...],
        auth_token: str | None = None,
        base_url: str,
        extra_headers: dict[str, str] | None = None,
    ) -> AsyncIterator[bytes]:
        api_key = auth_token or self._secret_any(env_keys)
        if not api_key:
            raise RuntimeError(f"{_credential_label(env_keys, model.provider)} is not configured")
        return openai_compatible_chat_stream(
            model,
            request,
            state,
            api_key=api_key,
            base_url=base_url,
            extra_headers=extra_headers,
        )

    def _anthropic_messages_stream(
        self,
        model: Model,
        request: dict[str, Any],
        state: ProviderStreamState,
        *,
        output_format: str,
    ) -> AsyncIterator[bytes]:
        api_key = self._secret("ANTHROPIC_API_KEY")
        if not api_key:
            raise RuntimeError("ANTHROPIC_API_KEY is not configured")
        return anthropic_messages_stream(
            model, request, state, api_key=api_key, output_format=output_format
        )

    async def _synthetic_chat_stream(
        self,
        model: Model,
        request: dict[str, Any],
        state: ProviderStreamState,
    ) -> AsyncIterator[bytes]:
        result = await self.chat(model, {**request, "stream": False})
        state.request_id = result.request_id
        state.provider_name = result.provider_name
        state.input_tokens = result.input_tokens
        state.output_tokens = result.output_tokens
        state.finish_reason = result.finish_reason
        state.usage_estimated = result.usage_estimated
        state.elapsed_seconds = result.elapsed_seconds
        state.text_parts = [result.text]
        state.tool_calls = result.tool_calls
        async for chunk in stream_openai_chunks(
            request_id=result.request_id,
            model_id=model.id,
            text=result.text,
            finish_reason=result.finish_reason,
        ):
            yield chunk

    async def _synthetic_anthropic_messages_stream(
        self,
        model: Model,
        request: dict[str, Any],
        state: ProviderStreamState,
    ) -> AsyncIterator[bytes]:
        result = await self.chat(model, {**request, "stream": False})
        state.request_id = result.request_id
        state.provider_name = result.provider_name
        state.input_tokens = result.input_tokens
        state.output_tokens = result.output_tokens
        state.finish_reason = result.finish_reason
        state.usage_estimated = result.usage_estimated
        state.elapsed_seconds = result.elapsed_seconds
        state.text_parts = [result.text]
        state.tool_calls = result.tool_calls
        yield anthropic_sse(
            "message_start",
            {
                "type": "message_start",
                "message": {
                    "id": result.request_id,
                    "type": "message",
                    "role": "assistant",
                    "content": [],
                    "model": model.id,
                    "stop_reason": None,
                    "usage": {"input_tokens": result.input_tokens, "output_tokens": 0},
                },
            },
        )
        yield anthropic_sse(
            "content_block_start",
            {
                "type": "content_block_start",
                "index": 0,
                "content_block": {"type": "text", "text": ""},
            },
        )
        for token in chunk_text(result.text):
            yield anthropic_sse(
                "content_block_delta",
                {
                    "type": "content_block_delta",
                    "index": 0,
                    "delta": {"type": "text_delta", "text": token},
                },
            )
        yield anthropic_sse("content_block_stop", {"type": "content_block_stop", "index": 0})
        yield anthropic_sse(
            "message_delta",
            {
                "type": "message_delta",
                "delta": {"stop_reason": result.finish_reason, "stop_sequence": None},
                "usage": {"output_tokens": result.output_tokens},
            },
        )
        yield anthropic_sse("message_stop", {"type": "message_stop"})

    async def _gemini_chat(self, model: Model, request: dict[str, Any]) -> ProviderResult:
        api_key = self._secret("GEMINI_API_KEY")
        if not api_key:
            raise RuntimeError("GEMINI_API_KEY is not configured")
        return await gemini_chat(model, request, api_key=api_key)

    def _gemini_chat_stream(
        self,
        model: Model,
        request: dict[str, Any],
        state: ProviderStreamState,
    ) -> AsyncIterator[bytes]:
        api_key = self._secret("GEMINI_API_KEY")
        if not api_key:
            raise RuntimeError("GEMINI_API_KEY is not configured")
        return gemini_chat_stream(model, request, state, api_key=api_key)

    async def _vertex_openai_compatible_chat(
        self, model: Model, request: dict[str, Any]
    ) -> ProviderResult:
        token, base_url = self._vertex_auth_and_base_url()
        return await self._openai_compatible_chat(
            model,
            request,
            auth_token=token,
            base_url=base_url,
        )

    def _vertex_openai_compatible_chat_stream(
        self,
        model: Model,
        request: dict[str, Any],
        state: ProviderStreamState,
    ) -> AsyncIterator[bytes]:
        token, base_url = self._vertex_auth_and_base_url()
        return self._openai_compatible_chat_stream(
            model,
            request,
            state,
            env_keys=("VERTEX_ACCESS_TOKEN",),
            auth_token=token,
            base_url=base_url,
        )

    @staticmethod
    def _provider_extra_headers(model: Model) -> dict[str, str]:
        if model.provider == "zero-g":
            return {"X-0G-Provider-Trust-Mode": "private"}
        if model.provider == "wafer" and wafer_zdr_support(model.upstream_id or model.id) is True:
            return {"Wafer-ZDR": "required"}
        return {}

    def _secret(self, name: str | None) -> str | None:
        if name is None:
            return None
        return self.key_file.get(name) or os.environ.get(name)

    def _secret_any(self, names: tuple[str, ...] | None) -> str | None:
        # Treat the explicitly supplied key file as one source. Check every
        # accepted alias there before consulting ambient process variables;
        # otherwise KIMI_API_KEY in the environment can unexpectedly override
        # MOONSHOT_API_KEY in the caller's key file (and likewise for Makora).
        for name in names or ():
            value = self.key_file.get(name)
            if value:
                return value
        for name in names or ():
            value = os.environ.get(name)
            if value:
                return value
        return None

    def _provider_base_url(self, provider: str, default: str) -> str:
        if provider == "kimi":
            return self._secret("KIMI_BASE_URL") or self._secret("MOONSHOT_BASE_URL") or default
        if provider == "cloudflare-workers-ai":
            account_id = self._secret("CLOUDFLARE_WORKERS_AI_ACCOUNT_ID")
            if not account_id:
                raise RuntimeError("CLOUDFLARE_WORKERS_AI_ACCOUNT_ID is required")
            return default.format(account_id=account_id)
        if provider == "databricks":
            host = (self._secret("DATABRICKS_HOST") or "").strip().rstrip("/")
            if not host:
                raise RuntimeError("DATABRICKS_HOST is required")
            return f"{host}/serving-endpoints"
        return self._secret(f"{provider.upper()}_BASE_URL") or default

    def _vertex_auth_and_base_url(self) -> tuple[str, str]:
        token = self._secret("VERTEX_ACCESS_TOKEN") or self._secret("GOOGLE_OAUTH_ACCESS_TOKEN")
        project_id = (
            self._secret("VERTEX_PROJECT_ID")
            or self._secret("GOOGLE_CLOUD_PROJECT")
            or self._secret("GCP_PROJECT_ID")
            or self._secret("TR_GCP_PROJECT_ID")
        )
        location = (
            self._secret("VERTEX_LOCATION")
            or self._secret("GOOGLE_CLOUD_REGION")
            or self._secret("TR_PRIMARY_REGION")
            or "us-central1"
        )

        if token is None or project_id is None:
            try:
                import google.auth
                from google.auth.transport.requests import Request
            except ImportError as exc:
                raise RuntimeError("google-auth is required for Vertex ADC") from exc
            credentials, default_project = google.auth.default(
                scopes=["https://www.googleapis.com/auth/cloud-platform"]
            )
            if token is None:
                credentials.refresh(Request())
                token = credentials.token
            if project_id is None:
                project_id = default_project

        if not token:
            raise RuntimeError("VERTEX_ACCESS_TOKEN or Google ADC is required for Vertex")
        if not project_id:
            raise RuntimeError("VERTEX_PROJECT_ID or Google ADC project is required for Vertex")

        base_url = self._secret("VERTEX_OPENAI_BASE_URL")
        if base_url:
            return token, base_url.rstrip("/")

        host = (
            "aiplatform.googleapis.com"
            if location == "global"
            else f"{location}-aiplatform.googleapis.com"
        )
        return (
            token,
            f"https://{host}/v1beta1/projects/{project_id}/locations/{location}/endpoints/openapi",
        )


def _credential_label(env_keys: tuple[str, ...] | None, provider: str) -> str:
    if env_keys:
        return " or ".join(env_keys)
    return provider + " credentials"
