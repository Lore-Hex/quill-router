"""Step 3: conditional-DML enforcement on the typed counter tables.

See docs/design/billing-typed-counters.md.

This is the deadlock fix. Instead of read-modify-write (a shared read lock that
upgrades to exclusive -> wound-wait deadlock under per-tenant concurrency), each
reserve is a SINGLE conditional UPDATE that takes the row write lock directly and
atomically checks-and-decrements:

    UPDATE tr_credit_balance SET reserved = reserved + @est
     WHERE workspace_id=@ws AND shard=@shard
       AND (total_credits - total_usage - reserved) >= @est

``execute_update()`` returns the modified-row count: 1 = accepted, 0 = rejected
(insufficient). Concurrent reservers serialize on the row write lock instead of
deadlocking; the predicate re-evaluates against committed state.

Standard DML only (NOT partitioned DML); these run inside ``run_in_transaction``
so ABORTED is retried. They must NOT be mixed with Spanner mutations in the same
transaction (docs §5) — the authorize/settle transactions are DML-only.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from trusted_router.async_settle_fence import APPLY_PAYLOAD
from trusted_router.storage_gcp_batch_dml import DmlStatement
from trusted_router.storage_gcp_counters import UNSHARDED

# Importing GUARD_STATUSES would cycle because storage_gcp_settle_outbox imports
# the retention helpers below. Keep this SQL list in sync with that tuple.
_OUTBOX_GUARD_STATUS_SQL = "'pending', 'dead'"

_CLAIM_RESERVATION_SQL = (
    "UPDATE tr_reservation SET settled=true, actual_micro=@actual, "
    "settled_usage_type=@sut, terminal_at=@terminal_at "
    "WHERE reservation_id=@rid AND settled=false"
)
_CLAIM_RESERVATION_GUARDED_SQL = (
    "UPDATE tr_reservation SET settled=true, actual_micro=@actual, "  # noqa: S608
    "settled_usage_type=@sut, terminal_at = IF("
    "EXISTS (SELECT 1 FROM tr_settle_outbox o "
    "WHERE o.authorization_id = tr_reservation.authorization_id "
    f"AND o.status IN ({_OUTBOX_GUARD_STATUS_SQL})), NULL, @terminal_at) "
    "WHERE reservation_id=@rid AND settled=false"
)
_COMPLETE_RESERVATION_RETENTION_SQL = (
    "UPDATE tr_reservation SET terminal_at=@terminal_at "
    "WHERE reservation_id=@rid AND settled=true AND terminal_at IS NULL"
)
_COMPLETE_RESERVATION_RETENTION_GUARDED_SQL = (
    "UPDATE tr_reservation SET terminal_at=@terminal_at "  # noqa: S608
    "WHERE reservation_id=@rid AND settled=true AND terminal_at IS NULL "
    "AND NOT EXISTS (SELECT 1 FROM tr_settle_outbox o "
    "WHERE o.authorization_id = tr_reservation.authorization_id "
    f"AND o.status IN ({_OUTBOX_GUARD_STATUS_SQL}))"
)

# reserve_key outcomes (the per-key spend-cap counterpart of reserve_credit).
KEY_ACCEPTED = "accepted"  # hold taken (row-count 1)
KEY_NO_HOLD = "no_hold"  # uncapped key, or BYOK excluded from the cap: proceed
KEY_INSUFFICIENT = "insufficient"  # capped and over the cap -> 402
KEY_MISSING = "missing"  # typed row absent -> fail closed (drift / not backfilled)


def reserve_credit(
    transaction: Any, param_types: Any, workspace_id: str, amount: int, *, shard: int = UNSHARDED
) -> bool:
    """Atomically reserve `amount` against the workspace credit balance.

    True = accepted (row-count 1); False = insufficient credits (row-count 0).
    """
    # Static table name (literal, not interpolated) + bound params only.
    sql = (
        "UPDATE tr_credit_balance SET reserved = reserved + @est "
        "WHERE workspace_id=@ws AND shard=@shard "
        "AND (total_credits - total_usage - reserved) >= @est"
    )
    count = transaction.execute_update(
        sql,
        params={"est": int(amount), "ws": workspace_id, "shard": shard},
        param_types={
            "est": param_types.INT64,
            "ws": param_types.STRING,
            "shard": param_types.INT64,
        },
    )
    return count == 1


def reserve_credit_statement(
    param_types: Any, workspace_id: str, amount: int, *, shard: int = UNSHARDED,
    check_pause: bool = False,
) -> DmlStatement:
    """First-candidate credit hold for the authorize hold-time batch.

    billing_pause_causes is ARRAY<STRING(32)> (migrate_typed_counters.sh).
    NULL/empty arrays are unpaused; every nonempty array is paused, including
    arrays containing empty strings or NULL. This matches billing_paused_row.
    Keep reserve_credit and returning DML unchanged as the fallback oracle.
    """
    pause_predicate = (
        " AND COALESCE(ARRAY_LENGTH(billing_pause_causes), 0) = 0" if check_pause else ""
    )
    return (
        "UPDATE tr_credit_balance SET reserved = reserved + @est "  # noqa: S608 - fixed clauses
        "WHERE workspace_id=@ws AND shard=@shard "
        "AND (total_credits - total_usage - reserved) >= @est" + pause_predicate,
        {"est": int(amount), "ws": workspace_id, "shard": shard},
        {"est": param_types.INT64, "ws": param_types.STRING, "shard": param_types.INT64},
    )


def reserve_credit_with_pause(
    transaction: Any, param_types: Any, workspace_id: str, amount: int, *, shard: int = UNSHARDED
) -> tuple[bool, bool]:
    """Return (reserved, paused) from the affected credit row in one RPC.

    An empty result is insufficient credit, not pause evidence. The caller must
    finish its bounded shard search before applying the funded shard's verdict.
    """
    from trusted_router.trust_eligibility import billing_paused_row

    rows = list(transaction.execute_sql(
        "UPDATE tr_credit_balance SET reserved = reserved + @est "
        "WHERE workspace_id=@ws AND shard=@shard "
        "AND (total_credits - total_usage - reserved) >= @est "
        "THEN RETURN billing_pause_causes, pause_epoch",
        params={"est": int(amount), "ws": workspace_id, "shard": shard},
        param_types={
            "est": param_types.INT64,
            "ws": param_types.STRING,
            "shard": param_types.INT64,
        },
    ))
    return (True, billing_paused_row(rows[0])) if rows else (False, False)

def debit_workspace_credit(
    transaction: Any,
    param_types: Any,
    workspace_id: str,
    amount: int,
    *,
    now: Any,
) -> bool:
    """Atomically remove a grant from authoritative shard zero.

    This is deliberately a negative grant (``total_credits`` down), never
    booked usage. The conditional predicate keeps current usage and live holds
    covered even under concurrent debits.
    """
    if amount <= 0:
        raise ValueError("amount_must_be_positive")
    count = transaction.execute_update(
        "UPDATE tr_credit_balance "
        "SET total_credits = total_credits - @amt, updated_at=@now "
        "WHERE workspace_id=@ws AND shard=0 "
        "AND (total_credits - total_usage - reserved) >= @amt",
        params={"amt": int(amount), "now": now, "ws": workspace_id},
        param_types={
            "amt": param_types.INT64,
            "now": param_types.TIMESTAMP,
            "ws": param_types.STRING,
        },
    )
    return count == 1


def debit_credit_shard(
    transaction: Any,
    param_types: Any,
    workspace_id: str,
    amount: int,
    *,
    shard: int,
) -> bool:
    """Conditionally remove `amount` of idle sub-budget from ONE credit shard.

    True = debited (row-count 1); False = that shard's headroom did not cover
    it, and nothing changed.

    The predicate ``(total_credits-total_usage-reserved)>=@move`` is what makes
    this a CONDITIONAL debit rather than a blind decrement: the row write lock
    is taken by the UPDATE itself and the predicate re-evaluates against
    committed state, so two concurrent debits cannot both pass a check that
    only one shard's headroom can satisfy.

    It moves only headroom — never booked usage, never a live reservation — so
    a debit can no more strand an in-flight hold than it can overdraw.

    Extracted from `transfer_credit_budget`, whose donor half this is verbatim,
    so cross-plane escrow debits the sharded balance through the SAME statement
    the shard rebalancer has been running in production rather than a second
    hand-written one that could drift from it.
    """
    if amount <= 0:
        raise ValueError("credit shard debit amount must be positive")
    count = transaction.execute_update(
        "UPDATE tr_credit_balance SET total_credits=total_credits-@move "
        "WHERE workspace_id=@ws AND shard=@donor "
        "AND (total_credits-total_usage-reserved)>=@move",
        params={
            "move": int(amount),
            "ws": workspace_id,
            "donor": shard,
        },
        param_types={
            "move": param_types.INT64,
            "ws": param_types.STRING,
            "donor": param_types.INT64,
        },
    )
    return count == 1


def credit_credit_shard(
    transaction: Any,
    param_types: Any,
    workspace_id: str,
    amount: int,
    *,
    shard: int,
    now: Any,
) -> int:
    """Add `amount` to ONE credit shard. Returns the modified-row count.

    Unconditional by design — a credit cannot fail a headroom test — so the
    ONLY thing the row count reports is whether the shard row exists. Callers
    must treat 0 as a hard error: it means the authoritative balance row is
    missing, and silently continuing would book a credit nowhere.
    """
    return transaction.execute_update(
        "UPDATE tr_credit_balance "
        "SET total_credits = total_credits + @amount, "
        "source_updated_at=@now, updated_at=@now "
        "WHERE workspace_id=@ws AND shard=@shard",
        params={
            "amount": int(amount),
            "now": now,
            "ws": workspace_id,
            "shard": shard,
        },
        param_types={
            "amount": param_types.INT64,
            "now": param_types.TIMESTAMP,
            "ws": param_types.STRING,
            "shard": param_types.INT64,
        },
    )


def transfer_credit_budget(
    transaction: Any,
    param_types: Any,
    workspace_id: str,
    amount: int,
    *,
    donor_shard: int,
    target_shard: int,
) -> bool:
    """Atomically move idle sub-budget from one credit shard to another.

    The donor predicate permits moving only current headroom, never usage or a
    live reservation. Both DML statements run in the caller's transaction; a
    failure must make the caller roll the whole transaction back so the global
    sum of ``total_credits`` cannot change.
    """
    if amount <= 0:
        raise ValueError("credit budget transfer amount must be positive")
    if donor_shard == target_shard:
        raise ValueError("credit budget donor and target must differ")
    if not debit_credit_shard(
        transaction, param_types, workspace_id, amount, shard=donor_shard
    ):
        return False
    target_count = transaction.execute_update(
        "UPDATE tr_credit_balance SET total_credits=total_credits+@move "
        "WHERE workspace_id=@ws AND shard=@target",
        params={
            "move": int(amount),
            "ws": workspace_id,
            "target": target_shard,
        },
        param_types={
            "move": param_types.INT64,
            "ws": param_types.STRING,
            "target": param_types.INT64,
        },
    )
    return target_count == 1


def release_credit(
    transaction: Any,
    param_types: Any,
    workspace_id: str,
    hold: int,
    actual: int,
    *,
    shard: int = UNSHARDED,
) -> int:
    """Release the EXACT recorded credit hold and book `actual` usage.

    For refund pass actual=0 (releases the hold, books no usage). Returns the
    modified-row count; the caller asserts == 1 (a 0-row release must not be
    silently accepted — it strands the hold and loses the charge).

    The `reserved >= @hold` guard makes a stale/double release a 0-row no-op
    instead of driving `reserved` negative (which would inflate apparent
    availability) — row-count 0 trips the caller's assert/alarm.
    """
    sql = (
        "UPDATE tr_credit_balance "
        "SET reserved = reserved - @hold, total_usage = total_usage + @actual "
        "WHERE workspace_id=@ws AND shard=@shard AND reserved >= @hold"
    )
    count = transaction.execute_update(
        sql,
        params={"hold": int(hold), "actual": int(actual), "ws": workspace_id, "shard": shard},
        param_types={
            "hold": param_types.INT64,
            "actual": param_types.INT64,
            "ws": param_types.STRING,
            "shard": param_types.INT64,
        },
    )
    free = int(hold) - int(actual)
    if count == 1 and free > 0:
        from trusted_router.storage_gcp_trust import absorb_unrecovered_recovery_tx

        absorbed = absorb_unrecovered_recovery_tx(
            transaction,
            param_types,
            workspace_id=workspace_id,
            amount_micro=free,
            # Lazy on purpose (#1071 follow-up): the shard-set read takes
            # ReaderShared on EVERY credit shard while this transaction holds
            # Exclusive on one of them — the cross-shard X-on-mine/S-on-yours
            # wait that defeats credit sharding — and costs one RPC per
            # settle. absorb only needs it when a payment claim exists.
            shard_count=lambda: _credit_shard_count_from_rows(
                transaction, param_types, workspace_id
            ),
            now=datetime.now(UTC),
            read_entity_tx=None,
            write_entity_tx=None,
        )
        if absorbed:
            debited = transaction.execute_update(
                "UPDATE tr_credit_balance SET total_credits=total_credits-@amount "
                "WHERE workspace_id=@ws AND shard=@shard "
                "AND (total_credits-total_usage-reserved)>=@amount",
                params={
                    "amount": absorbed,
                    "ws": workspace_id,
                    "shard": shard,
                },
                param_types={
                    "amount": param_types.INT64,
                    "ws": param_types.STRING,
                    "shard": param_types.INT64,
                },
            )
            if int(debited) != 1:
                raise RuntimeError("released credit could not satisfy recovery debt")
    return count


def release_credit_no_debt_statement(
    param_types: Any, workspace_id: str, hold: int, actual: int, *, shard: int,
) -> DmlStatement:
    """Speculative release: exact hold and transactional absence of recovery debt.

    A zero requires rollback of the entire batch before sequential classification.
    Match absorb_unrecovered_recovery_tx's workspace/payment debt predicate.
    """
    return (
        "UPDATE tr_credit_balance "
        "SET reserved = reserved - @hold, total_usage = total_usage + @actual "
        "WHERE workspace_id=@ws AND shard=@shard AND reserved >= @hold "
        "AND (@hold <= @actual OR NOT EXISTS ("
        "SELECT 1 FROM tr_trust_event "
        "WHERE workspace_id=@ws AND kind='payment' AND unrecovered_micro>0))",
        {"hold": int(hold), "actual": int(actual), "ws": workspace_id, "shard": shard},
        {"hold": param_types.INT64, "actual": param_types.INT64,
         "ws": param_types.STRING, "shard": param_types.INT64},
    )


def _credit_shard_count_from_rows(
    transaction: Any, param_types: Any, workspace_id: str
) -> int:
    rows = list(
        transaction.execute_sql(
            "SELECT shard FROM tr_credit_balance WHERE workspace_id=@pk ORDER BY shard",
            params={"pk": workspace_id},
            param_types={"pk": param_types.STRING},
        )
    )
    observed = [int(row[0]) for row in rows]
    if observed != list(range(len(observed))) or not observed:
        raise RuntimeError("configured tr_credit_balance shard set is incomplete")
    return len(observed)


def reserve_key_statement(
    param_types: Any, key_hash: str, amount: int, *, is_byok: bool,
    shard: int = UNSHARDED,
) -> DmlStatement:
    """The capped-key hold statement, shared by sequential and speculative DML."""
    sql = (
        "UPDATE tr_key_limit SET reserved = reserved + @est "
        "WHERE key_hash=@kh AND shard=@shard AND limit_micro IS NOT NULL "
        "AND (@is_byok = FALSE OR include_byok = TRUE) "
        "AND (limit_micro - usage - IF(include_byok, byok_usage, 0) - reserved) >= @est"
    )
    return (
        sql,
        {"est": int(amount), "kh": key_hash, "shard": shard, "is_byok": bool(is_byok)},
        {
            "est": param_types.INT64,
            "kh": param_types.STRING,
            "shard": param_types.INT64,
            "is_byok": param_types.BOOL,
        },
    )


def reserve_key(
    transaction: Any,
    param_types: Any,
    key_hash: str,
    amount: int,
    *,
    is_byok: bool,
    shard: int = UNSHARDED,
) -> str:
    """Atomically reserve `amount` against the per-key spend cap.

    Single conditional UPDATE: it matches (and holds) only a capped key whose
    available headroom covers `amount`, AND only when the cap applies to this
    usage type (BYOK is skipped when the key excludes BYOK). On row-count 0 we
    classify with a point-read IN THE SAME TRANSACTION (codex#2 #3) so the 0 is
    not ambiguous: missing row vs uncapped vs BYOK-excluded vs truly insufficient.

    Returns one of KEY_ACCEPTED / KEY_NO_HOLD / KEY_INSUFFICIENT / KEY_MISSING.
    """
    sql, params, types = reserve_key_statement(
        param_types, key_hash, amount, is_byok=is_byok, shard=shard,
    )
    count = transaction.execute_update(sql, params=params, param_types=types)
    if count == 1:
        return KEY_ACCEPTED
    rows = list(
        transaction.execute_sql(
            "SELECT limit_micro, include_byok FROM tr_key_limit "
            "WHERE key_hash=@kh AND shard=@shard",
            params={"kh": key_hash, "shard": shard},
            param_types={"kh": param_types.STRING, "shard": param_types.INT64},
        )
    )
    if not rows:
        return KEY_MISSING
    limit_micro, include_byok = rows[0][0], rows[0][1]
    if limit_micro is None:
        return KEY_NO_HOLD  # uncapped
    if is_byok and not include_byok:
        return KEY_NO_HOLD  # BYOK excluded from this key's cap
    return KEY_INSUFFICIENT  # capped and over the cap


# Lazy per-window bump, appended to the release UPDATE. `@wamt` is the amount
# that counts toward the key's caps for this settle (0 for a BYOK settle on a
# key that excludes BYOK — computed in SQL off the row's own include_byok so it
# matches reserve semantics). A stale window (start < current floor) is
# replaced, not added to — that IS the reset; no cron ever runs. COALESCE:
# rows that predate the window DDL read NULL usage until first touched
# (Spanner can't ADD COLUMN NOT NULL on an existing table).
_WINDOW_BUMP_SQL = (
    ", day_usage = IF(day_start IS NULL OR day_start < @day_floor,"
    " @day_wamt, COALESCE(day_usage, 0) + @day_wamt)"
    ", day_start = IF(day_start IS NULL OR day_start < @day_floor, @day_floor, day_start)"
    ", week_usage = IF(week_start IS NULL OR week_start < @week_floor,"
    " @week_wamt, COALESCE(week_usage, 0) + @week_wamt)"
    ", week_start = IF(week_start IS NULL OR week_start < @week_floor, @week_floor, week_start)"
    ", month_usage = IF(month_start IS NULL OR month_start < @month_floor,"
    " @month_wamt, COALESCE(month_usage, 0) + @month_wamt)"
    ", month_start = IF(month_start IS NULL OR month_start < @month_floor, @month_floor, month_start)"
)

# The common settle path has already-current window boundaries. Keep those
# boundary columns out of its SET list so Spanner does not take exclusive cell
# locks on values that did not change. The guarded UPDATE below falls back to
# _WINDOW_BUMP_SQL whenever any boundary needs its lazy roll.
_CURRENT_WINDOW_BUMP_SQL = (
    ", day_usage = COALESCE(day_usage, 0) + @day_wamt"
    ", week_usage = COALESCE(week_usage, 0) + @week_wamt"
    ", month_usage = COALESCE(month_usage, 0) + @month_wamt"
)
_CURRENT_WINDOW_PREDICATE_SQL = (
    " AND day_start IS NOT NULL AND day_start >= @day_floor"
    " AND week_start IS NOT NULL AND week_start >= @week_floor"
    " AND month_start IS NOT NULL AND month_start >= @month_floor"
)


def release_key_statement(
    param_types: Any,
    key_hash: str,
    hold: int,
    actual: int,
    *,
    book_to_byok: bool,
    window_floors: dict[str, Any],
    shard: int = UNSHARDED,
    windows: str = "current",
) -> DmlStatement:
    """Exact key release SQL for the key's spend windows.

    ``"current"`` matches only a key whose three windows are all current, and
    leaves their boundary columns out of the SET list; ``"stale"`` matches only
    a key with at least one window to roll forward; ``"any"`` rolls whatever
    needs it. The first two are complementary: on a key whose hold is covered,
    exactly one of them matches.
    """
    usage_col = "byok_usage" if book_to_byok else "usage"
    # BYOK settles count toward the caps (incl. windows) only when the key's own
    # include_byok says so — gated in SQL so it matches reserve semantics. On an
    # excluded settle the bump is +0, but a stale window still rolls forward.
    wamt = "IF(include_byok, @actual, 0)" if book_to_byok else "@actual"
    # usage_col/wamt are compile-time constants picked by a bool; values bind as params.
    params = {
        "hold": int(hold),
        "actual": int(actual),
        "kh": key_hash,
        "shard": shard,
        "day_floor": window_floors["daily"],
        "week_floor": window_floors["weekly"],
        "month_floor": window_floors["monthly"],
    }
    bound_param_types = {
        "hold": param_types.INT64,
        "actual": param_types.INT64,
        "kh": param_types.STRING,
        "shard": param_types.INT64,
        "day_floor": param_types.TIMESTAMP,
        "week_floor": param_types.TIMESTAMP,
        "month_floor": param_types.TIMESTAMP,
    }
    current_window_sql = _CURRENT_WINDOW_BUMP_SQL
    rolled_window_sql = _WINDOW_BUMP_SQL
    for window in ("day", "week", "month"):
        current_window_sql = current_window_sql.replace(f"@{window}_wamt", wamt)
        rolled_window_sql = rolled_window_sql.replace(f"@{window}_wamt", wamt)
    fast_sql = (
        "UPDATE tr_key_limit "  # noqa: S608
        f"SET reserved = reserved - @hold, {usage_col} = {usage_col} + @actual"
        + current_window_sql
        + " WHERE key_hash=@kh AND shard=@shard AND reserved >= @hold"
        + _CURRENT_WINDOW_PREDICATE_SQL
    )
    if windows == "current":
        return fast_sql, params, bound_param_types
    if windows not in {"stale", "any"}:
        raise ValueError(f"unknown key window mode: {windows!r}")
    sql = (
        "UPDATE tr_key_limit "  # noqa: S608
        f"SET reserved = reserved - @hold, {usage_col} = {usage_col} + @actual"
        + rolled_window_sql
        + " WHERE key_hash=@kh AND shard=@shard AND reserved >= @hold"
    )
    if windows == "stale":
        # The IS NOT NULL guards keep the predicate TRUE or FALSE, never NULL,
        # so NOT is its exact complement.
        sql += " AND NOT (" + _CURRENT_WINDOW_PREDICATE_SQL.removeprefix(" AND ") + ")"
    return sql, params, bound_param_types


def release_key(
    transaction: Any,
    param_types: Any,
    key_hash: str,
    hold: int,
    actual: int,
    *,
    book_to_byok: bool,
    window_floors: dict[str, Any],
    shard: int = UNSHARDED,
) -> int:
    """Release the EXACT recorded key hold and book `actual` to usage/byok_usage,
    and bump the lazy per-window counters in the same statement.

    `hold` is the exact amount taken at reserve (0 if no hold was taken — uncapped
    or BYOK-excluded); `book_to_byok` selects the usage column by the SETTLED
    usage type. Refund = actual 0 (window bump is then +0 — a no-op that still
    lazily rolls the window forward, which is harmless). `window_floors` is
    spend_windows.window_floors(now). The `reserved >= @hold` guard makes a
    stale/double release a 0-row no-op rather than driving reserved negative.
    Returns the modified-row count (caller asserts == 1).
    """
    for windows in ("current", "any"):
        sql, params, types = release_key_statement(
            param_types, key_hash, hold, actual, book_to_byok=book_to_byok,
            window_floors=window_floors, shard=shard, windows=windows,
        )
        count = transaction.execute_update(sql, params=params, param_types=types)
        if count == 1:
            return 1
    return count


def key_limit_exists(
    transaction: Any,
    param_types: Any,
    key_hash: str,
    *,
    shard: int = UNSHARDED,
) -> bool:
    """Classify a 0-row key release inside the same read-write transaction."""
    rows = list(
        transaction.execute_sql(
            "SELECT 1 FROM tr_key_limit WHERE key_hash=@kh AND shard=@shard",
            params={"kh": key_hash, "shard": shard},
            param_types={"kh": param_types.STRING, "shard": param_types.INT64},
        )
    )
    return bool(rows)


# ── tr_reservation: durable hold record + scoped idempotency + settle claim ──
# The reservation row records the EXACT holds taken at authorize (so settle
# releases exactly those, codex#1 #5), the resolved usage types (hold vs settled,
# codex#2 #2), and the scoped idempotency key. The atomic authorize INSERTs it;
# settle/refund CLAIM it (first-writer-wins). All DML so it composes into the
# DML-only authorize/settle transactions (no mutation mixing).

RESERVATION_COLUMNS = (
    "reservation_id", "workspace_id", "key_hash", "ws_shard", "credit_shard", "key_shard",
    "credit_reserved_micro", "key_reserved_micro", "hold_usage_type",
    "authorization_id", "idempotency_scope", "idempotency_fingerprint", "expires_at",
    "created_at",
)


def read_reservation_by_idempotency(
    transaction: Any, param_types: Any, idempotency_scope: str
) -> dict | None:
    """Point-read the existing reservation for a scoped idempotency key (replay).

    Returns the row (incl. fingerprint + the exact holds) or None. The caller
    verifies the fingerprint and replays without re-debiting.
    """
    rows = list(
        transaction.execute_sql(
            "SELECT reservation_id, credit_reserved_micro, key_reserved_micro, "
            "hold_usage_type, authorization_id, idempotency_fingerprint, settled, "
            "credit_shard, ws_shard, key_shard "
            "FROM tr_reservation WHERE idempotency_scope=@scope",
            params={"scope": idempotency_scope},
            param_types={"scope": param_types.STRING},
        )
    )
    if not rows:
        return None
    r = rows[0]
    credit_shard = r[7] if r[7] is not None else (r[8] or UNSHARDED)
    return {
        "reservation_id": r[0],
        "credit_reserved_micro": r[1],
        "key_reserved_micro": r[2],
        "hold_usage_type": r[3],
        "authorization_id": r[4],
        "idempotency_fingerprint": r[5],
        "settled": r[6],
        "credit_shard": int(credit_shard),
        "key_shard": int(r[9] or UNSHARDED),
    }


def read_reservation(transaction: Any, param_types: Any, reservation_id: str) -> dict | None:
    """Point-read a reservation by id (for settle/refund and the reaper)."""
    rows = list(
        transaction.execute_sql(
            "SELECT reservation_id, workspace_id, key_hash, ws_shard, credit_shard, key_shard, "
            "credit_reserved_micro, key_reserved_micro, hold_usage_type, "
            "settled_usage_type, actual_micro, authorization_id, settled, expires_at "
            "FROM tr_reservation WHERE reservation_id=@rid",
            params={"rid": reservation_id},
            param_types={"rid": param_types.STRING},
        )
    )
    if not rows:
        return None
    r = rows[0]
    keys = (
        "reservation_id", "workspace_id", "key_hash", "ws_shard", "credit_shard", "key_shard",
        "credit_reserved_micro", "key_reserved_micro", "hold_usage_type",
        "settled_usage_type", "actual_micro", "authorization_id", "settled", "expires_at",
    )
    result = dict(zip(keys, r, strict=True))
    raw_credit_shard = result.get("credit_shard")
    result["credit_shard"] = int(
        raw_credit_shard if raw_credit_shard is not None else (result.get("ws_shard") or UNSHARDED)
    )
    return result


def insert_reservation(transaction: Any, param_types: Any, **fields: Any) -> None:
    sql, params, types = reservation_insert_statement(param_types, **fields)
    transaction.execute_update(sql, params=params, param_types=types)


def reservation_insert_statement(param_types: Any, **fields: Any) -> DmlStatement:
    """INSERT a reservation row. Raises ALREADY_EXISTS (NOT retried) on a scoped
    idempotency-key conflict — the caller converts that to the replay path."""
    pt = param_types
    types = {
        "reservation_id": pt.STRING, "workspace_id": pt.STRING, "key_hash": pt.STRING,
        "ws_shard": pt.INT64, "credit_shard": pt.INT64, "key_shard": pt.INT64,
        "credit_reserved_micro": pt.INT64, "key_reserved_micro": pt.INT64,
        "hold_usage_type": pt.STRING, "authorization_id": pt.STRING,
        "idempotency_scope": pt.STRING, "idempotency_fingerprint": pt.STRING,
        "expires_at": pt.TIMESTAMP, "created_at": pt.TIMESTAMP,
    }
    cols = ", ".join(RESERVATION_COLUMNS)
    binds = ", ".join(f"@{c}" for c in RESERVATION_COLUMNS)
    values = {c: fields.get(c) for c in RESERVATION_COLUMNS}
    values["credit_shard"] = fields.get(
        "credit_shard", fields.get("ws_shard", UNSHARDED)
    )
    return (
        f"INSERT INTO tr_reservation ({cols}) VALUES ({binds})",  # noqa: S608 - fixed column list
        values,
        {c: types[c] for c in RESERVATION_COLUMNS},
    )


def claim_reservation(
    transaction: Any,
    param_types: Any,
    reservation_id: str,
    *,
    actual_micro: int,
    settled_usage_type: str,
    terminal_at: Any | None = None,
    defer_retention: bool = False,
    outbox_available: bool = True,
    expires_before: Any | None = None,
    async_fence: bool = False,
) -> bool:
    """Claim a reservation for settle/refund: first caller wins.

    True = this caller won the claim (row-count 1, settled flipped false->true);
    False = already settled (row-count 0, a replay) -> do NOT touch counters.
    Persists `actual_micro` + `settled_usage_type` so the durable reservation
    records the exact settled amount for audit / reaper reconciliation.
    """
    sql, params, types = claim_reservation_statement(
        param_types, reservation_id, actual_micro=actual_micro,
        settled_usage_type=settled_usage_type, terminal_at=terminal_at,
        defer_retention=defer_retention, outbox_available=outbox_available,
        expires_before=expires_before, async_fence=async_fence,
    )
    return transaction.execute_update(sql, params=params, param_types=types) == 1


def claim_reservation_statement(
    param_types: Any, reservation_id: str, *, actual_micro: int,
    settled_usage_type: str, terminal_at: Any | None = None,
    defer_retention: bool = False, outbox_available: bool = True,
    expires_before: Any | None = None,
    async_fence: bool = False,
) -> DmlStatement:
    """Build the same conditional claim for standalone or batch execution.

    A deferred claim writes ``terminal_at=NULL`` whatever the outbox holds: the
    guarded form would compute ``IF(EXISTS(...), NULL, NULL)``. So only a claim
    that arms retention pays for the retention subquery. With async enabled,
    a legacy claim racing an accepted async intent must also respect its frozen
    payload. The NOT EXISTS fence adds one primary-key range read on
    tr_settle_outbox by authorization_id inside the money transaction, including
    deferred claims; it is the only extra read. Pending/leased and dead rows
    freeze holds; operator-approved release and abandoned rows do not. With the
    flag off, SQL, parameters and types remain byte-identical to legacy. Measured
    2026-10-01 (SPANNER_SYS, one hour) before this: the guarded claim was the
    costliest statement, ~6.5 ms CPU per execution and 36% of all query CPU, at
    ~39k executions/hour, one per finalize. Finalize (and reaper) claims all
    defer retention, so that subquery never changed what they wrote.
    """
    resolved_terminal_at = (
        None if defer_retention else (terminal_at or datetime.now(UTC))
    )
    guarded = outbox_available and resolved_terminal_at is not None
    sql = _CLAIM_RESERVATION_GUARDED_SQL if guarded else _CLAIM_RESERVATION_SQL
    params = {
            "rid": reservation_id,
            "actual": int(actual_micro),
            "sut": settled_usage_type,
            "terminal_at": resolved_terminal_at,
        }
    types = {
            "rid": param_types.STRING,
            "actual": param_types.INT64,
            "sut": param_types.STRING,
            "terminal_at": param_types.TIMESTAMP,
        }
    if outbox_available and async_fence:
        from trusted_router.storage_gcp_settle_outbox import _GUARD_STATUS_SQL

        # Fence rolling legacy writers inside the money transaction. Only the
        # frozen apply primitive can book an async intent; arithmetic is unchanged.
        binding = APPLY_PAYLOAD.get()
        sql += (
            " AND NOT EXISTS (SELECT 1 FROM tr_settle_outbox a "  # noqa: S608 - fixed guard statuses
            "WHERE a.authorization_id = tr_reservation.authorization_id "
            f"AND a.status IN ({_GUARD_STATUS_SQL}) "
            "AND a.async_version=1 AND (@async_hash IS NULL OR "
            "(a.intent_kind=@async_kind AND "
            "(a.payload_hash!=@async_hash OR a.actual_cost_micro!=@actual))))"
        )
        params["async_hash"] = binding[0] if binding else None
        params["async_kind"] = binding[1] if binding else None
        types["async_hash"] = param_types.STRING
        types["async_kind"] = param_types.STRING
    if expires_before is not None:
        # The reaper's snapshot scan is advisory. This predicate is the final
        # row-count guard, inside the same read-write transaction as booking;
        # a heartbeat renewal after the scan therefore cannot lose its hold.
        sql += " AND expires_at < @reap_now"
        params["reap_now"] = expires_before
        types["reap_now"] = param_types.TIMESTAMP
    return sql, params, types


def complete_reservation_retention(
    transaction: Any,
    param_types: Any,
    reservation_id: str,
    *,
    terminal_at: Any,
    outbox_available: bool = True,
) -> int:
    """Start TTL only after all durable settlement repair work is complete."""
    return transaction.execute_update(
        _COMPLETE_RESERVATION_RETENTION_GUARDED_SQL
        if outbox_available
        else _COMPLETE_RESERVATION_RETENTION_SQL,
        params={
            "rid": reservation_id,
            "terminal_at": terminal_at,
        },
        param_types={
            "rid": param_types.STRING,
            "terminal_at": param_types.TIMESTAMP,
        },
    )


def clear_reservation_retention(transaction: Any, param_types: Any, reservation_id: str) -> int:
    sql, params, types = reservation_retention_clear_statement(param_types, reservation_id)
    return transaction.execute_update(sql, params=params, param_types=types)


def reservation_retention_clear_statement(param_types: Any, reservation_id: str) -> DmlStatement:
    """Make a reservation TTL-ineligible while durable repair is outstanding."""
    return (
        "UPDATE tr_reservation SET terminal_at=NULL "
        "WHERE reservation_id=@rid AND terminal_at IS NOT NULL",
        {"rid": reservation_id},
        {"rid": param_types.STRING},
    )


def insert_entity_dml(
    transaction: Any, param_types: Any, kind: str, entity_id: str, body_json: str,
) -> None:
    sql, params, types = entity_insert_statement(param_types, kind, entity_id, body_json)
    transaction.execute_update(sql, params=params, param_types=types)


def entity_insert_statement(param_types: Any, kind: str, entity_id: str, body_json: str) -> DmlStatement:
    """DML INSERT of a tr_entities JSON row (e.g. gateway_authorization), so it
    composes into the DML-only authorize transaction instead of a mutation.
    PENDING_COMMIT_TIMESTAMP() is the last touch of the row; raises ALREADY_EXISTS
    on a duplicate (kind,id)."""
    return (
        "INSERT INTO tr_entities (kind, id, body, updated_at) "
        "VALUES (@kind, @id, @body, PENDING_COMMIT_TIMESTAMP())",
        {"kind": kind, "id": entity_id, "body": body_json},
        {
            "kind": param_types.STRING,
            "id": param_types.STRING,
            "body": param_types.STRING,
        },
    )


def insert_entity_dml_at(
    transaction: Any, param_types: Any, kind: str, entity_id: str, body_json: str, now: Any
) -> None:
    """DML INSERT a tr_entities row with a client `updated_at` (NOT
    PENDING_COMMIT_TIMESTAMP), so MULTIPLE tr_entities DML statements can run in
    one transaction without the PCT same-table trap (codex 3e). Raises
    ALREADY_EXISTS on duplicate (kind,id)."""
    transaction.execute_update(
        "INSERT INTO tr_entities (kind, id, body, updated_at) "
        "VALUES (@kind, @id, @body, @now)",
        params={"kind": kind, "id": entity_id, "body": body_json, "now": now},
        param_types={
            "kind": param_types.STRING, "id": param_types.STRING,
            "body": param_types.STRING, "now": param_types.TIMESTAMP,
        },
    )


def delete_entity_dml(
    transaction: Any, param_types: Any, kind: str, entity_id: str
) -> int:
    """DML DELETE of a tr_entities row. Returns the modified-row count.

    The DML counterpart of the `transaction.delete(...)` MUTATION helper. It
    exists because Spanner forbids mixing DML and mutations in one transaction
    (docs §5): a transaction that has already run conditional balance DML — as
    every credit-transfer resolution does — cannot then delete its recovery-queue
    index row by mutation without faulting. Deleting by DML keeps the row's
    removal in the SAME transaction as the balance change it accompanies, which
    is what makes "left the queue" and "the verdict was applied" one fact.

    A 0 count is not an error here: the caller is removing a row that may
    legitimately be absent already.
    """
    return transaction.execute_update(
        "DELETE FROM tr_entities WHERE kind=@kind AND id=@id",
        params={"kind": kind, "id": entity_id},
        param_types={"kind": param_types.STRING, "id": param_types.STRING},
    )


def update_entity_body_dml(
    transaction: Any, param_types: Any, kind: str, entity_id: str, body_json: str, now: Any
) -> int:
    """DML UPDATE a tr_entities row's body (e.g. mark gateway_authorization
    settled) with a client `updated_at`. Returns the modified-row count."""
    return transaction.execute_update(
        "UPDATE tr_entities SET body=@body, updated_at=@now "
        "WHERE kind=@kind AND id=@id",
        params={"kind": kind, "id": entity_id, "body": body_json, "now": now},
        param_types={
            "kind": param_types.STRING, "id": param_types.STRING,
            "body": param_types.STRING, "now": param_types.TIMESTAMP,
        },
    )
