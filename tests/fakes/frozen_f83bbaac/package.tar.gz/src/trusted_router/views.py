"""Shared Jinja2 environment for the route modules.

Every route module that renders HTML imports `render_template` from
here so we have one Jinja env, one search path, and consistent
autoescape behaviour. Adding a new auth/console/marketing page is just
dropping a `.html` under templates/ — no per-module Jinja boilerplate.
"""

from __future__ import annotations

import datetime as dt
import hashlib
from functools import lru_cache
from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, select_autoescape

from trusted_router.content_handling import CONTENT_HANDLING_CLAIM
from trusted_router.middleware import current_csp_nonce
from trusted_router.provider_branding import provider_logo_url
from trusted_router.seo_meta import seo_meta_description, seo_title

TEMPLATES_DIR = Path(__file__).parent / "templates"


@lru_cache(maxsize=1)
def _auth_styles_version() -> str:
    # Auth routes do not receive the dashboard's release context. Fingerprint
    # both files once per process so immutable CSS URLs change with their bytes.
    static_dir = Path(__file__).parent / "static"
    content = (static_dir / "auth.css").read_bytes() + (static_dir / "charter.css").read_bytes()
    return hashlib.sha256(content).hexdigest()[:16]


def _format_uptime(value: float | None, decimals: int = 4) -> str:
    """Render an uptime percentage. Caps display at "99.99%" — claiming
    a literal 100.0000% with a few hundred probe samples behind it is
    overconfident; "99.99%+" reads honest, matches what
    status.anthropic.com / status.github.com surface, and stops the eye
    from interpreting "100%" as a guarantee.

    Threshold is `>= 99.995` so values that would round to 100 at 4
    decimals of precision get the cap; anything that actually rounds
    below that shows its real number."""
    if value is None:
        return "n/a"
    if value >= 99.995:
        return ">99.99%"
    return f"{value:.{decimals}f}%"


def _format_datetime_iso(value: int | float | str | None) -> str:
    """Render a Unix timestamp (or ISO string passthrough) as a compact
    human-readable date. Used by the credits-page payment-history table
    so a row like `created=1779582083` displays as `2026-05-24 01:01 UTC`.

    Pass-through behavior for strings means we can wire this to anything
    that's already iso-formatted server-side (e.g. last_auto_refill_at)
    without converting first.
    """
    if value is None or value == "":
        return "—"
    if isinstance(value, str):
        return value  # already iso-formatted
    try:
        ts = float(value)
    except (TypeError, ValueError):
        return "—"
    return dt.datetime.fromtimestamp(ts, tz=dt.UTC).strftime("%Y-%m-%d %H:%M UTC")


@lru_cache(maxsize=1)
def _env() -> Environment:
    env = Environment(
        loader=FileSystemLoader(TEMPLATES_DIR),
        autoescape=select_autoescape(["html"]),
        keep_trailing_newline=True,
    )
    env.filters["uptime_pct"] = _format_uptime
    env.filters["datetime_iso"] = _format_datetime_iso
    env.filters["seo_title"] = seo_title
    env.filters["seo_meta_description"] = seo_meta_description
    env.globals["provider_logo_url"] = provider_logo_url
    env.globals["content_handling_claim"] = CONTENT_HANDLING_CLAIM
    # Callable, not a value: this env is lru_cached and shared across
    # requests, so it must read the per-request ContextVar at render time.
    env.globals["csp_nonce"] = current_csp_nonce
    env.globals["auth_styles_version"] = _auth_styles_version
    return env


def render_template(name: str, **context: Any) -> str:
    return _env().get_template(name).render(**context)
